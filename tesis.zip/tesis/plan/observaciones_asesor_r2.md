# Levantar las observaciones mayores del asesor (ronda 2, 2026-11-10)

Origen: revisión del asesor (`1.docx`, formato de revista IEEE, recomendación «Major Rev»).
Indicación del asesor: levantar las observaciones, con prioridad en las mayores; el inglés es opcional (el usuario decidió incluirlo).
Ronda anterior (18 observaciones, cerrada): `revision_observaciones.md`.

## Problema
¿Cómo levantar la falta de comparación externa y la novedad incremental en menos de una semana, sin reentrenar y en ≤ 20 páginas?

## Dirección recomendada
Dos frentes con resultados existentes.

1. **Comparación externa.** Tabla en la sección II con 3 a 5 trabajos publicados: prioridad a los que usan Chapman-Shaoxing/Ningbo; si no los hay, PTB-XL (Strodthoff) y Ribeiro como «otra base». Métricas tal como las reportan sus autores y una columna de no equivalencia (clases, partición, métrica). Contraste **cualitativo** con la caída entre instituciones observada en el Challenge 2020 (Perez Alday): su cifra usa la métrica del Challenge, así que no se pone junto a nuestro F1.
2. **Novedad.** Replantear el aporte como réplica que mide lo que el original no pudo medir: la caída en instituciones no vistas bajo protocolo sellado, el efecto de las etiquetas anotadas en parte (pérdida enmascarada) y la transferencia de la calibración. Citar las diferencias pareadas de la pérdida enmascarada que ya están en `capitulos/cifras_t19.tex` (hoy el artículo solo cita las de AUROC):

   | F1 macro, enmascarado − sin enmascarar | A | B | C | D |
   |---|---|---|---|---|
   | Ensemble (`DP3mP3`) | −0.021 [−0.028; −0.013] | +0.044 [0.038; 0.049] | +0.045 [0.039; 0.052] | +0.052 [0.049; 0.056] |
   | v1 (`DP1mP1`) | — | +0.038 [0.032; 0.043] | +0.021 [0.015; 0.027] | +0.044 [0.040; 0.048] |

   El bootstrap mide la incertidumbre del conjunto de prueba, no la variabilidad entre entrenamientos: la limitación de «una corrida» se reformula, no desaparece.

**Orden:** (1) contenido en español: resumen con F1 y AUROC en oraciones separadas, tabla de la sección II, contribuciones, párrafo de la pérdida enmascarada, limitación 13 y observaciones menores reales; (2) traducción al inglés (texto, tablas y etiquetas de las figuras); (3) respuesta al asesor en LaTeX, en inglés.

## Supuestos a validar
- [ ] Hay 2–3 trabajos con F1/AUROC macro en Chapman o Ningbo → búsqueda con fuentes reales, límite de medio día.
- [ ] La tabla nueva y el texto en inglés caben en 20 páginas (hoy: 18) → compilar y contar.
- [ ] Las cifras se citan con macros `\cf{}`, no a mano.
- [ ] Las observaciones de tablas «malformadas», «sefal», «6pocas» y el «%» del resumen son artefactos de extracción → revisar el PDF compilado.

## Alcance mínimo
**Dentro:** tabla de trabajos publicados, párrafo de contribuciones, párrafo de la pérdida enmascarada con IC, limitación reformulada, resumen, observaciones menores reales (tabla VIII cortada, ref. [29], columna «Mejora», «Diferencia con v1» duplicada, 0.096 frente a 0.10), traducción al inglés y respuesta en LaTeX.

## Lo que no se hace (y por qué)
- **Modelo de Ribeiro sobre C/D:** es la comparación más fuerte, pero no cabe en una semana → va como trabajo futuro en las conclusiones.
- **Nuevas semillas o ablaciones:** sin tiempo; el bootstrap pareado cubre parte de la crítica.
- **Métrica del Challenge:** regla del proyecto; solo se cita su hallazgo cualitativo.
- **Versión en Word** (del artículo o de la respuesta): solo si el asesor la pide; se haría desde el LaTeX terminado.
- **Edición profesional del inglés:** fuera del alcance del curso.
- **Conservar el LaTeX en español:** la versión en inglés lo reemplaza.

## Preguntas abiertas
- Si la búsqueda en Chapman/Ningbo no encuentra nada, ¿basta con PTB-XL/Ribeiro como «otra base»?
- La limitación 13 y la regla de `CLAUDE.md` dicen «sin comparación con otros trabajos ni con el Challenge»: hay que reescribirlas para permitir comparar con resultados publicados, manteniendo la prohibición de calcular la métrica del Challenge.
