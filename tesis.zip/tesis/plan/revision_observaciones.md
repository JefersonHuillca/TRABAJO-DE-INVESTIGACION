# Revisión de las 18 observaciones contra su criterio de aceptación literal

## Cierre E14 (2026-11-01, contra el PDF final: 20 págs., `verificar_tex.py` 0 errores, `auditar_citas.py` OK)

**Recuento final: 13 cumplidas · 4 con reserva declarada (1, 2, 4 y 6) · la 17 descartada por el usuario el 2026-11-01. Ninguna abierta.** La reserva de la 6 viene de que el código se declara solo con GitHub, sin archivo con DOI (E15, cancelada el 2026-11-01).
Cambios frente al 2026-10-30: la **2 pasa de abierta a «con reserva»**; la **3 pasa de «con reserva» a cumplida** (10 semillas); la 6 pasa de abierta a «con reserva» y la 17 queda descartada al decidir el usuario no archivar con DOI.

| Obs. | Qué dice el artículo y dónde | Veredicto final |
|---|---|---|
| **1** Fuga por paciente | Resumen y Métodos: reparto por origen y, en PTB-XL y PTB, por paciente (0 pacientes repartidos). Limitación 3: el 31.9 % de A (1 578 registros) y C y D no traen identificador. Las afirmaciones primarias descansan en C y D (instituciones enteras que el entrenamiento no vio); A y B son desarrollo | **Con reserva** (escrita, no desaparece: no hay identificadores en C ni D) |
| **2** Partición confirmatoria | Métodos (Evaluación): C y D no intervinieron en ninguna decisión de diseño; protocolo externo sellado con SHA-256 antes de ejecutar ningún modelo sobre ellas, con registro de uso y desviaciones. Limitación 1 y Resumen: «no es plena» (las exclusiones y la regla de clases evaluables usaron cabeceras y recuentos de etiquetas de C y D; el diseño general se eligió mirando una prueba anterior; B no es independiente del diseño) | **Con reserva** (cumple el procedimiento; no una partición «no modificada» ni sin información de cabeceras) |
| **3** Una corrida por receta | 10 semillas de v1 y v2 (Tabla XII), media ± DE, prueba de signos con mínimo posible p = 0.002: el ensemble supera a la mejor receta en 10 de 10 semillas en A (p = 0.002) y no fuera de ella (1 de 10 en C, 5 de 10 en D). Limitación 4: 5 semillas se añadieron tras ver A y B (desviación 5); CNN, enmascaradas y ablaciones son una corrida | **Cumplida** (para las recetas principales; el límite de las demás queda escrito) |
| **4** Líneas base / Challenge | CNN y temperatura evaluadas también en C y D (Tabla VI); Limitación 13: sin comparación con otros trabajos ni con el Challenge, por la regla del proyecto | **Con reserva** (sin cambio) |
| **5** Ec. (3) | Sin cambios; Ec. (3) visible en la pág. 5 | Cumplida |
| **6** Reproducibilidad | `paquete_t19/` reconstruido el 2026-11-01 desde `main` (6b8f7dc): 1 507 archivos, 2.1 GB, pesos, predicciones de A, B, C y D, protocolos, análisis y verificador. `verificar_paquete.py`: OK (1 040 valores en A y B y 592 en C y D, tolerancia 1e-6). `--completo` (bootstrap byte a byte): ver nota al final. El paquete queda solo en local; el repositorio de GitHub trae el código, las pruebas, la descarga de las bases y los comandos del procedimiento (Declaraciones) | **Con reserva** (no hay archivo público de predicciones ni pesos) |
| **7** Etiquetas sin clase | Métricas sobre clases evaluables en C y D (Tabla IV: 18 y 133 registros sin clase; LVH no evaluable en C), cobertura documentada, variantes enmascaradas | Cumplida |
| 8 `w_c` | Definido en Métodos (pág. 5) | Cumplida |
| 9 Tabla III | **Re-vista hoy** (pág. 5): positivos por partición, códigos y prevalencia legibles | Cumplida |
| 10 Fig. 3→4 | El pie define AEct-J y da los positivos de cada fila | Cumplida |
| 11 Terminología | Sin «S.Tach» ni «convulsión» en `.tex` ni en las figuras (`STach` es el nombre de la clase) | Cumplida |
| 12 Tabla X→XVIII | **Re-vista hoy** (pág. 16): unidades en el pie, «un solo sorteo por nivel» y sin IC declarados | Cumplida |
| 13 Fig. 6 | En el PDF (pág. 14), citada antes | Cumplida |
| 14 IC | AUROC, AUPRC y coincidencia exacta con IC en la Tabla IX (A, B, C y D); AUROC, AUPRC y F1 con IC en las Tablas VI y VII (C y D) | Cumplida |
| 15 «coincidencia exacta» | Definida en Métodos y en el pie de la Tabla IX | Cumplida |
| 16 Orden de cita | `auditar_citas.py` OK con las 18 tablas y 7 figuras | Cumplida |
| **17** DOI y licencia | La licencia consta (GPL-3.0, CC BY 4.0); Declaraciones cita la URL de GitHub y no un DOI | **Descartada** por el usuario (2026-11-01): no se persigue |
| 18 Tabla I | **Re-vista hoy** (pág. 3): correspondencia con el original, legible y alineada | Cumplida |

Qué no se pudo comprobar hoy: la lectura del PDF fue visual en las Tablas I, III, VI a VIII y XVIII (págs. 3, 5, 8 y 16), no en las 18; el resto se comprobó con los verificadores y el texto.

---

Registro anterior (2026-10-30), conservado.

Fecha: 2026-10-30. Fuente: el texto original del revisor, pegado por el usuario ese día (no mi resumen anterior).
Comprobado hoy: `verificar_tex.py` (0 errores), `auditar_citas.py` (OK) y lectura de `capitulos/*.tex` y `evidencia/cifras_t19.csv`.
**No re-comprobado hoy (formato visual):** la legibilidad de las Tablas I, III y X (Obs. 9, 12 y 18); se revisaron en T5 y T18.

**Actualización del mismo día:** con las decisiones E0.6 a E0.9 (C y D primarios, 10 semillas; el DOI y el paquete en un archivo público se descartaron después, el 2026-11-01), las columnas «Con el plan» ya reflejan lo decidido.

**Recuento:** 12 cumplidas · 3 con reserva (1, 3, 4) · 3 abiertas (2, 6, 17).
Antes contaba 13 resueltas, 2 con reserva y 3 abiertas. **El cambio es la Obs. 3**: cumple la forma del criterio, pero la prueba de signos con 5 semillas no puede dar p < 0.05 (mínimo 0.0625), así que no "determina" si la ganancia supera la variabilidad. El artículo lo declara; por honestidad pasa a «con reserva».

## Observaciones críticas y mayores (1 a 7)

| Obs. | Criterio de aceptación (resumen) | Evidencia hoy | Veredicto | Con el plan de Chapman y Ningbo |
|---|---|---|---|---|
| **1** Fuga por paciente | Manifiesto disjunto por paciente; **todas** las afirmaciones primarias respaldadas por esa división; lo previo, rotulado exploratorio o retirado | PTB-XL y PTB se separan por paciente (0 pacientes en dos particiones). El 31.9 % de la prueba A (1 578 registros: CPSC 2018, su ampliación e INCART) no tiene identificador, y el artículo lo declara; el subconjunto de A separado por paciente (3 371 registros) da F1 0.765, rotulado exploratorio | **Con reserva** | C y D son instituciones enteras que el entrenamiento no vio: cumplen la separación por construcción institucional, **no por identificador** (las cabeceras no traen ninguno), así que «ningún identificador en más de una partición» no se puede comprobar en C ni D. Decidido (E0.7): las afirmaciones primarias pasan a C y D y A y B se rotulan exploratorias; el criterio se cumple en sustancia y la reserva queda escrita |
| **2** Partición confirmatoria | Evaluación confirmatoria en una partición no modificada; el manuscrito dice **explícitamente** que ninguna decisión de diseño la usó; el verificador inspecciona el protocolo y el historial de división | No existe: el artículo declara que la prueba influyó en el diseño. Georgia (B) se retuvo en T19, pero las decisiones previas se vieron con una prueba que incluía parte de ese origen | **Abierta** | C y D la satisfacen si el protocolo se hashea antes de toda predicción **y** lleva un historial de uso de C y D (qué se miró y qué no) y el artículo lo dice con esas palabras (E6, E10) |
| **3** Una corrida por receta | Varias semillas, media ± DE y pruebas pareadas **suficientes para determinar** si la ganancia supera la variabilidad | v1 y v2 con 5 semillas (P3 sale de cada par), media ± DE y prueba de signos exacta bilateral. El ensemble supera al mejor individual en 5 de 5 semillas en A, pero **p mínimo 0.0625**. CNN, enmascaradas y ablaciones son una sola corrida (el artículo lo dice) | **Con reserva** | Decidido (E0.8): 10 semillas de v1 y v2 antes de congelar (E16; mínimo de la prueba ≈ 0.002), y P1, P2 y P3 se evalúan con las 10 en C y D. CNN, enmascaradas y temperatura seguirán siendo corrida única y el texto debe decirlo |
| **4** Líneas base y estado de la técnica | Líneas base con los mismos datos, división, métricas y protocolo, carga de trabajo documentada; **comparaciones compatibles con el Challenge 2020**; beneficios respaldados frente a esas líneas base | CNN con la misma carga de trabajo, línea base de temperatura y ablaciones, con parámetros y tiempo en la Tabla; el artículo declara «sin comparación con otros trabajos ni con el Challenge» | **Con reserva**: cumple las líneas base, **no** la comparación con el Challenge ni la tabla de métodos previos de las Recomendaciones | CNN y temperatura se evalúan también en C y D (corrida única). La reserva sobre el Challenge la fija la regla del proyecto y no cambia |
| **5** Ec. (3) | Ecuación inequívoca y coherente con lo descrito e implementado | El texto dice que se promedian probabilidades y que la afín se aplica al logit de ese promedio, con la definición de logit | **Cumplida** | Nada |
| **6** Reproducibilidad | Repositorio **archivado**, público, con entorno, división, semillas y script de evaluación que **regenere las métricas** | En GitHub: código, `constraints.txt`, el procedimiento. **No** están en GitHub (viven en `tesis/`, fuera de git): el manifiesto de partición, las predicciones por registro, los hashes, `calcular_t19.py` y `analizar_t19.py`. Los pesos no se regeneran bit a bit | **Abierta** | Decidido el 2026-11-01: sin archivo con DOI; E12 deja GitHub al día y el paquete completo queda en local (`verificar_paquete.py --completo` regenera las métricas) |
| **7** Etiquetas y registros sin clase | Manejo de registros sin clase documentado; métricas que separen error del modelo de ausencia de anotación | Métricas sin los registros sin clase en A y B, tabla de cobertura por origen, evaluación enmascarada; el artículo reconoce que las etiquetas no las revisó un cardiólogo | **Cumplida** | Se extiende a C y D con la misma regla (E3). Un registro sin ninguna de las 12 clases es negativo solo para las clases que la fuente anota |

## Observaciones menores (8 a 18)

| Obs. | Comprobación de hoy | Veredicto |
|---|---|---|
| 8 `w_c` | Definido como negativos entre positivos de entrenamiento | Cumplida |
| 9 Tabla III | Formato (no re-visto hoy) | Cumplida, sin re-comprobar |
| 10 Fig. 3 | El pie define AEct-J y da los positivos de cada fila | Cumplida |
| 11 Terminología | No hay «S.Tach» ni «convulsión» en los `.tex` ni en los scripts de figuras | Cumplida |
| 12 Tabla X | Unidades y «un solo sorteo» (no re-visto hoy) | Cumplida, sin re-comprobar |
| 13 Fig. 6 | Está en el PDF (pág. 15, citada antes) | Cumplida |
| 14 IC | AUROC, AUPRC y coincidencia exacta traen IC en las cifras de la Tabla de sistemas | Cumplida |
| 15 «coincidencia exacta» | Definida en Métodos y en el primer uso de Resultados | Cumplida |
| 16 Orden de cita | `auditar_citas.py` OK: toda tabla y figura se cita antes | Cumplida |
| 17 DOI y licencia | La licencia consta (GPL-3.0 el código, CC BY 4.0 los datos); no hay DOI: Declaraciones cita la URL de GitHub (se descartó el archivo, 2026-11-01) | **Descartada** por el usuario |
| 18 Tabla I | Formato (no re-visto hoy) | Cumplida, sin re-comprobar |

Recomendaciones del revisor: reposicionar como estudio de reproducibilidad (ya es una «réplica metodológica»), tabla de métodos previos y líneas base con los mismos datos (líneas base sí; métodos previos no, por la regla) y repositorio con DOI (no: se descartó, el código se declara con GitHub).

## Qué cambia en el plan por esta revisión

1. **Obs. 1 y 2 piden más que «hacer la evaluación»:** piden que las afirmaciones primarias descansen en ella y que se diga qué partición se usó para qué. Decidido (E0.7): los primarios son C y D.
2. **E6 gana un «historial de uso» de C y D**, porque el verificador de la Obs. 2 inspecciona exactamente eso. La regla de clases evaluables (≥ 50 positivos) usa recuentos de etiquetas de C y D: es información de la partición, aunque no sean predicciones, y se declara.
3. **Las tablas y figuras nuevas pueden reabrir las menores.** E8 y E10 llevan la lista: IC de AUROC, AUPRC y coincidencia exacta (14), definición de abreviaturas y positivos por fila (10), unidades (12), cita antes de aparecer (16), alineación y legibilidad (9 y 18), terminología unificada (11).
4. **La Obs. 3 queda con reserva** hoy; se cierra de fondo con 10 semillas (E0.8, decidido; E16).
5. **La Obs. 6 no se cierra solo con GitHub**; queda con reserva al no archivar el paquete completo (decisión del 2026-11-01).
