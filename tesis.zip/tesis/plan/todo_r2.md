# Tareas: observaciones del asesor (ronda 2)

Plan y decisiones: `plan_r2.md`. Intención: `observaciones_asesor_r2.md`.

**Verificación común** de toda tarea que toca el artículo (desde la raíz):
- `bash tesis/compilar.sh` → 0 (sin errores, sin citas ni referencias indefinidas, ≤ 20 páginas);
- `python tesis/scripts/verificar_tex.py` → 0 errores;
- `python tesis/scripts/auditar_citas.py` → OK.

## Fase 1: contenido (español)

- [x] **T1 Línea base y triaje de menores** (S) — Dependencias: ninguna — **hecha el 2026-11-10**
  - Línea base: `compilar.sh` → 18 págs., 0 errores de TeX, 0 citas o referencias indefinidas, 0 avisos de BibTeX; `verificar_tex.py` → OK (0 errores; avisos: 3 `\label` sin `\ref` y 20 entradas sin citar en `references.bib`, ya existentes); `auditar_citas.py` → OK.
  - Triaje (contra `main.pdf` extraído con `pdftotext` y contra el `.tex`):

    | Observación | Veredicto | Evidencia |
    |---|---|---|
    | Resumen: se confunden el AUROC y el F1 | Artefacto (pero se reescribe en T5) | PDF: «F1 macro … en C y … en D (AUROC macro de 0.86 y 0.86), frente a 0.750 ± 0.005 en la prueba interna A…»; la extracción perdió los paréntesis |
    | Resumen: «0.86 %» | Artefacto | El PDF dice «0.86 y 0.86», sin %; macros `XSmP3CAuroc`/`XSmP3DAuroc` = 0.86 |
    | «sefal», «reine», «proba- . bilidades», «6pocas» | Artefacto | 0 apariciones en el PDF extraído; «señal» aparece 16 veces |
    | «AECopy_Junctional», «Tab», «S Tach» | Artefacto | El PDF dice «AEctopy_Junctional», «TAb», «STach» |
    | Tablas I–XV «malformadas» | Artefacto | Columnas correctas en `pdftotext -layout`; el triaje anterior (Obs. 9) ya la revisó en la pág. 5 |
    | Tabla VIII cortada en «0.544 [0.» | Artefacto | El PDF tiene «0.544 [0.540; 0.549] 0.62 0.51 389 1 047 0.013 0.061» completo |
    | «Diferencia con v1» duplicada (Tabla XIII) | Artefacto | Una columna bajo «Prueba A» y otra bajo «Prueba B» |
    | Columna «Mejora» poco clara (Tabla XI) | Artefacto | Definida en la nota de la tabla (`03_resultados.tex:233`): semillas, de 10, en que el ensemble supera a la mejor receta individual |
    | 0.096 frente a 0.10 | **Real (claridad)** | `03_resultados.tex`: las diferencias se calculan sin redondear y los AUROC se muestran con 2 decimales (0.96 − 0.86); falta decirlo → T5 |
    | Ref. [29] incompleta | **Real** | `Zheng2020database` no muestra el DOI ni el número de artículo: IEEEtran no imprime el campo `doi`, y las demás entradas lo llevan en `note`. Afecta a 7 entradas citadas de `references_extra.bib`: `Gomez2021comparative`, `PerezAlday2022physionet`, `Pollard2026physionet`, `Zheng2020database`, `Zheng2022physionet`, `Reyna2022challenge`, `Reyna2021will` → T5 |
    | ECE de P3t (0.13): aclarar en el pie de la Tabla VI | Opcional | La revisión la da por consistente; solo pide aclararlo en el pie → T5 si cabe |
  - Compilar el estado actual y anotar páginas (se esperan 18) y la salida del verificador.
  - Revisar cada observación menor contra el PDF compilado y marcarla como real o como artefacto de extracción:
    - el «%» del resumen;
    - «sefal», «reine», «6pocas», «AECopy_Junctional»;
    - tablas «malformadas»;
    - tabla VIII cortada;
    - ref. [29];
    - columna «Mejora»;
    - «Diferencia con v1» duplicada;
    - 0.096 frente a 0.10.
  - Aceptación: tabla de triaje en este archivo (observación → real/artefacto → evidencia: página o línea del `.tex`).
  - Archivos: ninguno del artículo.

- [x] **T2 Búsqueda bibliográfica** (S, límite de medio día) — Dependencias: T1 — **hecha el 2026-11-10**
  - Búsqueda: OpenAlex (3 consultas, 75 resultados: Chapman, Ningbo, validación entre bases); 8 candidatos leídos; cifras comprobadas contra el texto del artículo (`pdftotext` del PDF o texto literal de PMC), no contra resúmenes automáticos.
  - Trabajos para la tabla (4):

    | Trabajo | Base y protocolo | Clases / entrada | Cifra reportada (fuente) | Por qué no es comparable |
    |---|---|---|---|---|
    | Hannun 2019 (`Hannun2019cardiologist`, ya citado) | 328 registros de 328 pacientes, comités de cardiólogos | 12 ritmos, 1 derivación, Holter | F1 ponderado 0.837 (conjunto) y 0.807 (secuencia); AUC ponderado 0.977 y 0.978 (Tabla 1, PMC6784839) | Una derivación, otra población, F1 ponderado por frecuencia |
    | Strodthoff 2021 (`Strodthoff2021deep`, ya citado) | PTB-XL, partición recomendada, 100 Hz | 71 etiquetas («all») / 5 superclases, 12 derivaciones | AUC macro xresnet1d101: 0.925 («all») y 0.928 (superclases) (Tabla II, arXiv v1; la versión JBHI no se comprobó) | Misma base que el entrenamiento (sin evaluación externa); otras etiquetas |
    | Zhou 2024 (`Zhou2024semisupervised`, nuevo) | G12EC, PTB-XL, Chapman, Ningbo; protocolo entre bases: entrena con 3, prueba en la 4.ª; 3 semillas | 5 superclases reanotadas, 12 derivaciones; semisupervisado con 1 % de etiquetas | AUC macro de ECGMatch en base no vista: Chapman 0.900 ± 0.002, Ningbo 0.874 ± 0.002 (Tabla 3); dentro de la base: 0.912 y 0.925 (Tabla 2, 5 % de etiquetas) | 5 superclases frente a 12 clases; 1 % de etiquetas; Chapman y Ningbo separados |
    | Leinonen 2024 (`Leinonen2024empirical`, nuevo) | Challenge 2021 + SPH; validación cruzada de 4 particiones frente a «dejar fuera un origen» | 17 etiquetas, 12 derivaciones; ResNet, transformer, LR, XGBoost | La validación cruzada de 4 particiones sobrestima el AUC macro en 0.112 (ResNet), 0.040, 0.047 y 0.068; dejar fuera un origen da −0.006, −0.030, 0.001 y 0.004 (Tabla 5) | No reporta AUC por base en números (solo en una figura); sirve como evidencia del sesgo, no como cifra de desempeño |
  - Descartados:
    - Han 2023 (Physiol Meas) y Xu 2022: por base solo reportan la métrica del Challenge (regla del proyecto).
    - Ribeiro 2020: Nature exige iniciar sesión y no se pudieron verificar las cifras; se mantiene la cita existente sin números.
    - Avetisyan 2023: base privada.
  - Respuesta a la pregunta abierta: no hay trabajos con F1 macro en Chapman/Ningbo con nuestras clases; Zhou es el más cercano (AUC macro en base no vista). La tabla usa los 4 de arriba.
  - BibTeX: `Zhou2024semisupervised` y `Leinonen2024empirical` añadidas a `references_extra.bib` (metadatos de CrossRef, con `note` para que se imprima el DOI). `verificar_tex.py` → OK.
  - Buscar trabajos con F1 o AUROC macro en Chapman-Shaoxing o Ningbo y, como respaldo, en PTB-XL (Strodthoff ya está citado) o en la población de Ribeiro.
  - Aceptación:
    - 3 a 5 trabajos con métrica, base, clases y partición anotadas, y DOI verificado;
    - ninguno se incluye solo con la métrica del Challenge;
    - entradas BibTeX nuevas en `references_extra.bib`.
  - Archivos: `tesis/references_extra.bib`.

- [x] **T3 Tabla de estado del arte, limitación 13 y regla de CLAUDE.md** (M) — Dependencias: T2 — **hecha el 2026-11-10**
  - Cifras de la literatura: 10 filas `Lit*` en `evidencia/cifras_extra.csv` (fuente: clave y tabla del artículo), añadidas a `ESTATICAS` en `scripts/calcular_t19.py`; `cifras_t19.tex` regenerado, con solo esas 10 líneas nuevas (diff comprobado). Respaldo previo en el scratchpad de la sesión.
  - `01b_relacionados.tex`: párrafo nuevo (Zhou y Leinonen) y la **Tabla I** `tab:literatura` (`table*`, 5 filas). La antigua Tabla I (correspondencia) pasa a ser la II y se renumeran las demás.
  - Limitación 13 (`04_discusion.tex`) → «Comparación con otros trabajos solo indirecta».
  - `CLAUDE.md` (local, excluido de git): la regla permite citar cifras publicadas en métricas propias; sigue prohibido calcular la métrica del Challenge y compararse con sus resultados o su clasificación.
  - Verificación: 18 págs., 0 errores, 0 `Overfull` > 10 pt; `verificar_tex.py` OK; `auditar_citas.py` OK (Tabla I citada antes de aparecer). Revisada visualmente en la pág. 3.
  - Hallazgo: `verificar_tex.py` no detecta un `\cfs{id}` cuyo id no tenga versión con signo (la macro sale vacía, sin error). Pasó con `LitLeinLso`, ya corregido; ninguna otra macro del artículo tiene el problema (comprobación con un script aparte).
  - Tabla en `01b_relacionados.tex`: trabajo, base, clases, métrica reportada y por qué no es directamente comparable; fila propia con `\cf{}`.
  - Párrafo de contraste cualitativo con la caída entre instituciones del Challenge 2020 (Perez Alday), sin poner su cifra junto a nuestro F1.
  - Reescribir la limitación 13 (`04_discusion.tex:49`): ahora sí hay comparación con resultados publicados, no equivalente.
  - Actualizar la regla de `CLAUDE.md`: se permite citar resultados publicados; sigue prohibido calcular la métrica del Challenge y compararse con su clasificación.
  - Aceptación: la tabla se cita antes de aparecer; verificación común en verde.
  - Archivos: `capitulos/01b_relacionados.tex`, `capitulos/04_discusion.tex`, `CLAUDE.md` (repositorio).

- [x] **T4 Novedad** (M) — Dependencias: T1 — **hecha el 2026-11-10**
  - Introducción: oración de aporte tras «réplica metodológica»: no es un algoritmo nuevo, sino medir tres aspectos que el original no podía medir (caída en instituciones no vistas con protocolo sellado, etiquetas anotadas en parte, transferencia de la calibración).
  - Resultados («Pérdida enmascarada»): diferencias pareadas del F1 macro en C y D para las tres parejas, con IC; las 6 son positivas con IC por encima de 0 (v1: +0.021 y +0.044; v2: +0.064 y +0.060; ensemble: +0.045 y +0.052). Las de A y B ya estaban.
  - Limitación 4: el mismo signo en v1 y v2 (entrenamientos distintos) y en B, C y D reduce, pero no elimina, la posibilidad de un efecto de una sola corrida.
  - Conclusiones: punto 4 con cifras; trabajo futuro con una línea base publicada (Ribeiro) en C y D.
  - Verificación: **19 págs.** (antes 18), 0 errores, 0 `Overfull` > 10 pt; `verificar_tex.py` y `auditar_citas.py` OK; todas las `\cfs` definidas.
  - Introducción (`01_introduccion.tex`): replantear objetivos y contribuciones como réplica que mide lo que el original no pudo medir: caída en instituciones no vistas bajo protocolo sellado, etiquetas anotadas en parte (pérdida enmascarada) y transferencia de la calibración.
  - Resultados (`03_resultados.tex`): párrafo con las diferencias pareadas en F1 macro (`\cfs{DP3mP3BF1mac}`, `\cfs{XDP3mP3CF1mac}`, `\cfs{XDP3mP3DF1mac}` y sus IC; también `DP1mP1`, y el negativo en A).
  - Limitación de «una corrida»: el efecto se repite en v1 y en el ensemble, con IC bootstrap del conjunto de prueba; no mide la variabilidad entre entrenamientos.
  - Conclusiones: trabajo futuro con un modelo publicado (Ribeiro) evaluado en C y D.
  - Aceptación: ninguna cifra escrita a mano; el texto no afirma más de lo que dicen los IC.
  - Archivos: `capitulos/01_introduccion.tex`, `03_resultados.tex`, `04_discusion.tex`, `05_conclusiones.tex`.

- [x] **T5 Resumen y menores reales** (S) — Dependencias: T1 — **hecha el 2026-11-10**
  - Resumen (español e inglés): F1 macro y AUROC macro en oraciones separadas, con las cuatro pruebas (AUROC: 0.86, 0.86, 0.95 y 0.83); oración sobre la pérdida enmascarada; «no se comparan cifras» → «se sitúan junto a las publicadas, sin compararlas directamente» (coherente con la Tabla I).
  - 0.096 frente a 0.10: oración en `03_resultados.tex` (las diferencias se calculan sin redondear; la Tabla VII muestra dos decimales).
  - Referencias: `note = {{doi}: …}` en las 7 entradas de `references_extra.bib` que no imprimían el DOI; `Zheng2020database` con `pages = {48}` (número de artículo según CrossRef). Las 3 de PhysioNet son DOI de DataCite. En el PDF, la [31] (antes [29]) ya dice «vol. 7, no. 1, p. 48, 2020, doi: 10.1038/s41597-020-0386-x».
  - Sin hacer (opcional): pie de la Tabla VI sobre el ECE de P3t; la revisión lo da por consistente.
  - Verificación: 19 págs., 0 errores; `verificar_tex.py` y `auditar_citas.py` OK; todas las `\cfs` definidas.
  - Resumen: F1 macro y AUROC macro en oraciones separadas (las cuatro bases), sin paréntesis que puedan perderse.
  - Corregir solo los menores que T1 marcó como reales.
  - Aceptación: cada menor real tiene su línea corregida anotada en la tabla de T1.
  - Archivos: `capitulos/00_resumen.tex` y los que indique T1.

- [x] **T5b Paquete de la webapp = sistema evaluado (P3)** — decidido por el usuario el 2026-11-10 — **hecha el 2026-11-11**
  - Repositorio (sin commit): `models/*.pt` y `deploy/` regenerados con `tools/export_inference_bundle.py` desde `saved/t19/t19_v1` y `t19_v2` (`best.pt`), calibración de `runs/t19/eval/p1`, `p2` y `p3_A`; informes de T19 (comparación v1–v2 y robustez de v2). Insumos en `runs/t19/bundle/`.
  - Ejemplos: 4 de los 7 anteriores estaban en el entrenamiento o la validación de T19 → regenerados con `tools/build_examples.py` desde las predicciones de P3 en A y B (HR10268, E09078, E00792, E04333, A1119, Q2649, E07827).
  - Tests: ids de ejemplo actualizados en `tests/test_payload_size.py` (A3763 → E09078) y `tests/test_ui_content.py` (HR09549 → E07827). Paquete, despliegue, webapp y ejemplos en verde; `test_deploy_config` pasa con el cambio de ejemplos en el índice (comprobado con un índice temporal; en el real pasará al hacer `git add`). Único fallo: `test_requirements` por `tesis/obsoleto/` (local, anterior).
  - Prueba de humo `tools/smoke_deployment.py`: 19/19. `tools/check_docs_commands.py`: 0 problemas.
  - Webapp frente a evaluación (`scripts/web_vs_evaluacion.py`, evidencia `evidencia/webapp/web_vs_evaluacion_A300.json`): 299 registros de A; 231 de 10 s con diferencia media 3.5e-5, máxima 1.3e-3 y 0 decisiones distintas; 68 largos con media 0.009, máxima 0.60 y 9 decisiones distintas (promedio de ventanas, por diseño). La cifra anterior (4e-5 en 1019 registros largos) no se reproduce con este paquete.
  - Fig. 6: E00014 (prueba B) con interfaz en inglés; el informe PDF solo existe en español (lo dice el pie). Evidencia anterior en `evidencia/webapp/anterior/`.
  - Artículo: métodos (sección de la webapp), resultados (coherencia separada por duración, E00014 en B), pie de la Fig. 6, limitación «Aplicación web», conclusión 5 y Disponibilidad. 19 págs., chequeos en verde.
  - `.md` del repositorio: `webapp/README.md`, `webapp/examples/README.md`, `webapp/CONTEXT.md`, `deploy/CONTEXT.md`, `CONTEXT.md` (etapa 08), `docs/resultados_finales.md`.

### Triaje completo de `1.docx` (secciones 0 a 10), 2026-11-10
Cada punto del documento, no solo las secciones 5 y 6. «Hecho» = cambio en el artículo; «Respuesta» = se explica en T11 sin cambiar el artículo.

| Sección | Punto | Veredicto | Acción |
|---|---|---|---|
| 0 | Artefactos de extracción, tablas «malformadas» | Artefacto | Respuesta (el PDF está bien; ver T1) |
| 2 | Novedad 2/5, claridad 3/5 | Real | Hecho: T4 (novedad), T5 (resumen), fase 2 (inglés) |
| 3a / 5.2 | Resumen: F1 y AUROC confundidos | Artefacto, pero se reescribió | Hecho: T5 |
| 3c / 5.1 / C3 / 4B-9 | Falta tabla comparativa y líneas base externas | Real | Hecho: T2 y T3 (Tabla I); la línea base reproducida en igualdad de condiciones queda como trabajo futuro (respuesta) |
| C2 / 5.3 | Novedad incremental | Real | Hecho: T4 |
| C5 / C9 / 4B-10 | Repositorio no verificado | Fuera de nuestro control | Respuesta: el repositorio es público (enlace) |
| C6 / 7 | Ablaciones de una sola corrida | Real | Hecho en parte: T4 (pérdida enmascarada repetida en v1 y v2, en B, C y D); el resto queda como limitación (respuesta) |
| C7 / 5.4 | Español | Real | Fase 2 (T6–T10) |
| 4B-11 | Pesos del modelo no mencionados | **Real** | Hecho: oración en Disponibilidad (`06_declaraciones.tex`): los pesos evaluados no se publican; el repositorio trae solo el paquete de la webapp |
| 6 | «0.86 %», «sefal», «6pocas», «AECopy», «Tab», «S Tach» | Artefacto | Respuesta |
| 6 | 0.096 frente a 0.10 | Real (claridad) | Hecho: T5 |
| 6 | ECE de P3t: aclarar en el pie de la Tabla VI | Ya está | Respuesta: la nota define P3t y el texto da los ECE |
| 6 | Ref. [29] incompleta | Real | Hecho: T5 (7 referencias) |
| 7 | F1 0.491 (C) y 0.462 (D) frente a 0.478 y 0.456 del resumen | Correcto, pero confunde | Respuesta: 0.491/0.462 son una corrida (Tabla VII, la nota lo dice: semillas 42 y 43); 0.478/0.456 son la media de 10 semillas |
| 7 | Pérdida enmascarada «+0.025 (B), −0.023 (A)» | **El revisor se equivoca** | Respuesta: las cifras del artículo son +0.044 [0.038; 0.049] en B y −0.021 [−0.028; −0.013] en A (ensemble); +0.025 y +0.023 son de otras frases |
| 8 | Tabla I: simplificar o dividir | Opcional | Respuesta: 3 columnas con delimitadores claros en el PDF |
| 8 | Tabla II: «Et./reg.» ambiguo | Ya definido | Respuesta: la nota lo define («etiquetas de las 12 clases por registro»); se puede desabreviar en T7 si cabe |
| 8 | Tabla III: una fila por clase | Ya está | Respuesta |
| 8 | Tablas VI, VII, VIII («0.544 [0.»), XIII | Artefacto | Respuesta |
| 8 | Tabla XI: «Mejora» poco clara | Ya definida en la nota | Respuesta |
| 8 | Tabla XII: columna «Min» | Ya definida en la nota | Respuesta |
| 8 | Fig. 4 (matriz de confusión): vectorial | **En parte real** | T10: texto y ejes son vectoriales, pero las celdas son una imagen de 252×252 px (`imshow`); regenerar 100 % vectorial (`pcolormesh`) al traducir |
| 8 | Fig. 5 (confiabilidad): vectorial | Ya lo es (0 imágenes raster) | Respuesta |
| 8 | Fig. 6: pie que describa el contenido | Ya lo hace | Respuesta (el pie describe ambas capturas) |
| 8 | Ecuaciones y notación | Sin observación | — |
| 9 | Ética y cumplimiento | Sin observación | — |
| 10 | Condiciones de reconsideración (5) | — | Cubiertas por T3, T4, T5 y la fase 2; reformatear tablas: el PDF ya las muestra bien |

### Checkpoint 1: contenido en español
- [x] Verificación común en verde; páginas anotadas (19 de 20).
- [x] `grep -niE "\bIA\b|\bAI\b|Claude|LLM"` en `tesis/capitulos` y `tesis/evidencia`: solo «TRIPOD+AI» (nombre de la guía) y la declaración de uso de herramientas en `06_declaraciones.tex`.
- [ ] **El usuario revisa el PDF en español antes de traducir.**

## Fase 2: traducción al inglés

**Hecha el 2026-11-11 (T6 a T10).** Antes de traducir se archivó la versión en español completa en `obsoleto/espanol_2026-11-11/` (`tesis/` no está en git, así que no hay otro respaldo). Cada capítulo se comparó con su versión en español con un script que cuenta macros `\cf`/`\cfs`, citas, referencias, etiquetas y fórmulas: todo coincide, salvo una `\ref{tab:literatura}` añadida a propósito en la discusión (el original decía «ni compara cifras con las del original», que ya no es exacto con la Tabla I). Resultado: **18 págs.**, 0 errores, 0 `Overfull` > 10 pt, `verificar_tex.py` y `auditar_citas.py` OK.
- `main.tex`: `babel` en `english`, título, autores, «Advisor», «TABLE»; `auditar_citas.py` acepta «Table(s)»/«and» además del español.
- Resumen: queda solo el inglés (ya actualizado en T5).
- Figuras: diagrama TikZ y `hacer_figuras.py` en inglés; matriz de confusión con `pcolormesh` y barra de color sin rasterizar → `pdfimages` da 0 imágenes en las cuatro figuras de datos. Fig. 6: interfaz en inglés (T5b); el informe PDF y los rótulos del trazado siguen en español (lo dice el pie).
- Restos de español: solo nombres propios y comentarios de LaTeX. IA: solo «TRIPOD+AI» y la declaración de uso de herramientas.

- [x] **T6 Preámbulo, resumen, introducción y relacionados** (M) — Dependencias: Checkpoint 1
  - `main.tex`: `babel` en `english`; quitar `es-nodecimaldot`, `es-tabla` y las redefiniciones de `\captionsspanish`; títulos y palabras clave.
  - Traducir `00_resumen.tex`, `01_introduccion.tex` y `01b_relacionados.tex`.
  - Ajustar `compilar.sh` y `verificar_tex.py` solo si dependen del español, sin relajar ningún chequeo.
  - Aceptación: verificación común en verde con el resto aún en español.
  - Archivos: `main.tex`, los tres capítulos y, si hace falta, los scripts de verificación.

- [x] **T7 Métodos** (M) — Dependencias: T6
  - Traducir `02_metodos.tex` (texto, tablas, pies y ecuaciones; las macros no cambian).
  - Aceptación: verificación común en verde.

- [x] **T8 Resultados** (M) — Dependencias: T6
  - Traducir `03_resultados.tex` (encabezados: IC → CI, «Mejora» → «Gain» con su nota, etc.).
  - Aceptación: verificación común en verde.

- [x] **T9 Discusión, conclusiones y declaraciones** (S) — Dependencias: T6
  - Traducir `04_discusion.tex`, `05_conclusiones.tex` y `06_declaraciones.tex`.
  - Aceptación: verificación común en verde; los matices de las limitaciones se conservan frente al español del Checkpoint 1.

- [x] **T10 Figuras** (S) — Dependencias: T6
  - Etiquetas en inglés en `scripts/hacer_figuras.py` y `figuras/tikz/d_arquitectura.tex`; regenerar desde la raíz con `python tesis/scripts/hacer_figuras.py`.
  - Pie de la Fig. 6: indicar que la interfaz está en español.
  - Matriz de confusión 100 % vectorial: `pcolormesh` (o `imshow(..., rasterized=False)` no basta) en lugar de `imshow` en `confusion()`; comprobar con `pdfimages -list figuras/fig_confusion.pdf` → 0 imágenes.
  - Aceptación: las figuras regeneradas sin texto en español (salvo la Fig. 6); verificación común en verde.
  - Archivos: `scripts/hacer_figuras.py`, `figuras/tikz/d_arquitectura.tex`, `figuras/*.pdf`.

### Checkpoint 2: artículo en inglés
- [x] Verificación común en verde; ≤ 20 páginas.
- [x] `grep -nP "[áéíóúñ¿¡]"` en `capitulos/*.tex`: solo nombres propios, instituciones y la Fig. 6.
- [x] Búsqueda de menciones a IA, igual que en el Checkpoint 1.
- [x] El usuario revisa el PDF en inglés.

## Fase 3: respuesta al asesor

- [x] **T11 Respuesta al asesor** (M) — Dependencias: Checkpoint 2 — **hecha el 2026-11-11**
  - `tesis/respuesta_asesor.tex` → `respuesta_asesor.pdf` (4 págs., inglés): resumen, 4 mayores, 8 menores, sección 7 (0.491/0.462 son de una corrida; «+0.025/−0.023» no son las cifras de la pérdida enmascarada), sección 8 (tablas y figuras), reproducibilidad (repositorio y pesos) y el cambio no pedido del paquete de la webapp.
  - Cifras con `\cf{}` (`\input{capitulos/cifras_t19}`) y números de tablas, figuras y secciones con `xr` desde `main.aux`: compilar antes `main.tex`, luego `pdflatex respuesta_asesor.tex` dos veces. 0 errores, 0 referencias indefinidas, 0 `Overfull`; sin menciones a IA.
  - `tesis/respuesta_asesor.tex` en inglés, que carga las mismas cifras (`\input{capitulos/cifras_t19.tex}`) para citar números con `\cf{}`.
  - Observaciones mayores primero, después las menores. Cada una con: qué se cambió, dónde (sección, tabla, página) o por qué no aplica (artefacto de extracción, con la evidencia de T1).
  - Compilación con MiKTeX igual que el artículo.
  - Aceptación: cada observación de `1.docx` tiene su respuesta; el PDF compila sin errores; sin menciones a IA.
  - Archivos: `tesis/respuesta_asesor.tex` (+ PDF).

### Checkpoint final
- [x] `main.pdf` y `respuesta_asesor.pdf` compilan; verificación común en verde.
- [ ] El usuario revisa ambos antes de enviarlos.
- [ ] Word: solo si el asesor lo pide (fuera de este plan).
