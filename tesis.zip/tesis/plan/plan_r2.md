# Plan: levantar las observaciones del asesor (ronda 2)

Intención y alcance confirmados: `observaciones_asesor_r2.md`. Lista de tareas: `todo_r2.md`.
Las listas de rondas anteriores (`plan.md`, `todo.md`) no se tocan.

## Resumen
Responder la revisión «Major Rev» del asesor en menos de una semana, sin reentrenar y en ≤ 20 páginas (hoy: 18). El trabajo tiene tres fases:

1. Corregir el contenido en español: comparación externa, novedad, resumen y observaciones menores reales.
2. Traducir el artículo completo al inglés, con figuras incluidas.
3. Escribir la respuesta al asesor en LaTeX, en inglés.

## Decisiones
- **Contenido antes que idioma.** Así se corrige una sola vez, y se revisa en español, que es donde el usuario lee más rápido.
- **Cifras solo con macros `\cf{}`.** `verificar_tex.py` rechaza números escritos a mano que no estén en `evidencia/cifras_t19.csv`. La traducción no toca las macros.
- **Pérdida enmascarada sin entrenar.** Se citan las diferencias pareadas `DP1mP1*` y `DP3mP3*`, que ya están en `cifras_t19.tex`.
- **Comparación externa sin la métrica del Challenge.**
  - La tabla lleva resultados publicados tal como los reportan sus autores, con una columna de no equivalencia.
  - El hallazgo de Perez Alday entra solo como contraste cualitativo.
  - La regla de `CLAUDE.md` y la limitación 13 se reescriben en ese sentido.
- **Figuras regenerables por script.** `scripts/hacer_figuras.py` solo lee `runs/t19/eval/` y `evidencia/`, y el diagrama es TikZ. Las capturas de la webapp (Fig. 6) siguen en español; su pie lo dice.
- **Traducción por capítulos.** Cada tarea compila sola; `babel` pasa a `english` en la primera.
- **Verificación común** (todas las tareas que tocan el artículo; desde la raíz):
  - `bash tesis/compilar.sh`: sale con 0 si no hay errores de TeX, citas ni referencias indefinidas, y si hay 20 páginas o menos.
  - `python tesis/scripts/verificar_tex.py`: 0 errores.
  - `python tesis/scripts/auditar_citas.py`: OK.

## Grafo de dependencias
```
T1 línea base y triaje de menores
 ├─ T2 búsqueda bibliográfica ─ T3 tabla de estado del arte + limitación 13 + regla CLAUDE.md
 ├─ T4 novedad (contribuciones, pérdida enmascarada, trabajo futuro)
 └─ T5 resumen + menores reales
        └─ [Checkpoint 1: contenido en español revisado por el usuario]
             ├─ T6 preámbulo + resumen + introducción + relacionados → inglés
             ├─ T7 métodos → inglés
             ├─ T8 resultados → inglés
             ├─ T9 discusión + conclusiones + declaraciones → inglés
             └─ T10 figuras → inglés
                  └─ [Checkpoint 2: artículo completo en inglés]
                       └─ T11 respuesta al asesor (LaTeX, inglés)
                            └─ [Checkpoint final]
```
T3, T4 y T5 son independientes entre sí. T6 va primero en la fase 2 porque cambia `babel`; T7 a T10 pueden ir en cualquier orden después.

## Tareas
El detalle de cada una está en `todo_r2.md`.

### Fase 1: contenido (español)
- T1 Línea base y triaje de menores (S)
- T2 Búsqueda bibliográfica con límite de medio día (S, riesgo alto: va primero)
- T3 Tabla de estado del arte, limitación 13 y regla de CLAUDE.md (M)
- T4 Novedad: contribuciones, párrafo de la pérdida enmascarada y trabajo futuro (M)
- T5 Resumen y menores reales (S)

### Checkpoint 1
Compila en ≤ 20 páginas, verificador en 0 y auditoría OK. El usuario revisa el contenido en español antes de traducir.

### Fase 2: traducción
- T6 a T9: capítulos (S o M cada una)
- T10 Figuras (S)

### Checkpoint 2
Compila en ≤ 20 páginas, verificador en 0 y sin restos de español fuera de nombres propios, referencias y la Fig. 6.

### Fase 3: respuesta
- T11 Respuesta al asesor (M)

### Checkpoint final
Ambos PDF compilan y el usuario los revisa antes de enviarlos.

## Riesgos
| Riesgo | Impacto | Mitigación |
|---|---|---|
| No hay trabajos con F1/AUROC macro en Chapman/Ningbo | Medio | Medio día de búsqueda como máximo; si no hay nada, se usan PTB-XL y Ribeiro como «otra base» |
| La tabla nueva hace pasar de 20 páginas | Medio | El inglés suele ocupar menos; si aun así no cabe, se recorta en métodos o discusión, no en la tabla |
| `verificar_tex.py` o `compilar.sh` asumen el español (babel, `es-nodecimaldot`, «TABLA») | Medio | T6 cambia el preámbulo y compila antes de traducir el resto; si el verificador falla por idioma, se ajusta el script, no la regla |
| Una traducción cambia el sentido de una afirmación cuidadosamente acotada (confirmatorio frente a exploratorio, «con reserva») | Alto | Traducir capítulo por capítulo y revisar contra el español del Checkpoint 1; no reescribir afirmaciones |
| Referencias inventadas o con metadatos erróneos | Alto | Cada referencia nueva se verifica con DOI o con la fuente real |
| Mención a IA en el artículo, la evidencia o la respuesta | Medio | Búsqueda de «IA», «AI», «Claude», «LLM» en cada checkpoint (salvo Declaraciones) |

## Preguntas abiertas
- Si T2 no encuentra trabajos en Chapman/Ningbo, ¿basta con PTB-XL y Ribeiro? Se decide en T2 con lo que aparezca.
- ¿La respuesta al asesor menciona que varias observaciones vienen de la extracción del texto, o solo indica que «se revisó y el PDF lo muestra correctamente»? Se propone el tono en T11.
