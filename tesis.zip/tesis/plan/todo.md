# Tareas: revisiones externas del artículo IEEE

> **Nota (2026-11-01): reorganización de carpetas.** `tesis/ieee/` pasó a ser `tesis/` (la tesis completa y el artículo anterior se borraron por
> redundantes) y las rutas de este documento ya están corregidas. `hacer_docx.py`, `ajustar_flotantes.py`, `word_a_pdf.ps1`, `calcular_extra.py` y
> `manifiesto.py` están en `tesis/obsoleto/`: lo que se diga aquí de ellos es historial. Mapa vigente: `tesis/CONTEXT.md`.

Plan, dependencias, criterios y riesgos: `tesis/plan/plan.md` (revisado con el asesor, 2026-10-22). Fase 0 hecha (2026-10-23); el resto sigue sin implementar.
Verificación base de toda tarea de texto: `python tesis/scripts/verificar_tex.py` (0 errores) y `bash tesis/compilar.sh` (≤ 20 págs).
Tamaños: XS = 1 archivo · S = 1–2 · M = 3–5 · L = 5 o más (dividir al ejecutar).

## Decisiones previas (el usuario)

- [ ] **D1** ~~Evaluación externa con el Challenge 2021~~ — **RETIRADA el 2026-10-26** por decisión del usuario (descarga a ≤ 10 KB/s; no se usa nada del Challenge 2021). Alternativas A–D en `plan.md`. **Reabierta el 2026-10-30** para Chapman-Shaoxing y Ningbo: ver Fase 7 y `plan_externa.md` (pendiente E0)
- [x] **D2** Enmascarado en entrenamiento: final o secundario → **decidido (2026-10-23): secundario**
- [x] **D3** Reparto agrupado por paciente → **decidido (2026-10-23): omitir por ahora**
- [x] **D4** Tres decimales solo en el F1 macro y su IC, regenerados desde las predicciones → **decidido (2026-10-23): sí**
- [x] **D5** Publicar predicciones por registro, etiquetas evaluadas, umbrales y manifiesto en el repositorio → **decidido (2026-10-23): sí; la publicación en GitHub requiere la orden explícita del usuario cuando llegue el momento**
- [x] **D6** Ablaciones: matriz mínima y dirigida (aumentación, suavizado, selección por F1) → **decidido (2026-10-23): matriz mínima y dirigida**
- [x] **D3 reabierta** → resuelta el 2026-10-26: no se omite; el reparto agrupado se hace en T19 (opción C), junto con la prueba B por origen (opción B)
- [ ] **D8** Comparación con el Challenge 2020: se mantiene la regla de no compararse con sus resultados (recomendado); líneas base propias en T13/T14
- [x] **D7** La CNN de referencia entra en el protocolo externo y se entrena antes de T11 → **decidido (2026-10-23): sí**

## Fase 0: forma y trazabilidad (sin cómputo)

- [x] **T1** (S) Manifiesto de reproducibilidad: commit, hashes, versiones, comandos — HECHO: manifiesto generado y verificable (`scripts/manifiesto.py`, 32 archivos)
- [x] **T2** (XS) Evidencia fechada del enlace de Hannun (HTTP + Wayback) — HECHO: 404 registrado el 2026-10-23 y captura archivada del 2024-10-09 citada en [5]
- [x] **T3** (S) Tabla VI: puntos retrospectivos frente a umbrales de uso + cifras con umbrales de validación — HECHO: Tabla VI y su texto separados de los umbrales de uso; sensibilidad y especificidad con umbrales de validación
- [x] **T4** (S) F1 macro e IC con tres decimales, regenerados (necesita D4) — HECHO: F1 macro 0.756 (0.748 a 0.764) regenerado y aplicado en Resumen, Abstract, IV-A, Tabla V, Discusión y Conclusiones
- [x] **T5** (S) Legibilidad de las tablas a tamaño real (Tablas I, V, IX) — HECHO: tablas a 8 pt (pie de la plantilla, ≥ 7 pt), sin desbordes, Tablas I y V revisadas a tamaño real

### Punto de control 0
- [x] Verificador en 0 errores, 12 páginas (≤ 20), tablas legibles; **pendiente: el usuario revisa el texto de la Tabla VI**

## Fase 1: auditoría interna con datos existentes

- [x] **T6** (M) Auditoría de calibración y umbrales con modelos congelados (CV de 5 pliegues solo de calibración y umbrales; no es validación independiente) — HECHO: F1 de validación 0.77 dentro de muestra y 0.76 fuera de pliegue (optimismo 0.006); ECE 0.008 en ambos; umbrales con desviación media 0.034 (máx. 0.083, STach). Texto en Resultados IV-D y Discusión, con la salvedad de que no es validación independiente
- [x] **T7** (M) Prueba sin solape identificable (sin los 738 registros) y sin los 24 registros sin clase, con IC; análisis descriptivo — HECHO: sin los 738 solapados F1 macro 0.752 (0.743 a 0.760); sin los 24 registros sin clase 0.758; solo identificables sin solape 0.758; 51 de 3 061 falsos positivos caen en los registros sin clase
- [x] **T8** (M) Cobertura de etiquetas por origen, documentada; define clases evaluables y tratamiento de las desconocidas — HECHO: `evidencia/cobertura_etiquetas.csv` (96 celdas, 8 orígenes con Chapman-Shaoxing y Ningbo): 8 de las 10 celdas sin positivos confirmadas por la documentación, 2 sin poder confirmar (PTB), 0 contradichas; CPSC-Extra y Georgia sin documentar; INCART con positivos de 4 clases fuera de su tabla de diagnósticos

### Punto de control 1
- [x] Toda cifra se regenera con scripts (`calcular_extra.py` lee los CSV de T6–T8); 13 págs, verificador en 0 errores, manifiesto de 35 archivos
- [x] Limitaciones internas explícitas en el texto
- [ ] **Pendiente: revisión del usuario antes de descargar datos externos** (D1 ya decidida) y decisiones D3 reabierta y D8

## Fase 2: evaluación confirmatoria externa — ANULADA el 2026-10-26

- [ ] ~~**T9** (S) Protocolo que congela el experimento completo (modelos incl. CNN, preprocesamiento, etiquetas, umbrales, métricas, exclusiones, por procedencia), con hash y fecha~~ — protocolo externo anulado (`evidencia/protocolo_externo.md` queda marcado como ANULADO)
- [ ] **T13** (M, GPU ≈ 0.5 h) CNN 1D convencional, entrenada y calibrada **antes** de T11 — **AL FINAL**, junto con la ResNet reentrenada con todos los cambios (decisión del usuario 2026-10-26); la corrida incompleta de `saved/` no se usa
- [ ] ~~**T10** (M) Descarga de las dos carpetas, verificación con SHA-256 frente a `ecg-arrhythmia`, HDF5 por procedencia, auditoría de códigos, duplicados y pacientes~~ — CANCELADA: no se descarga nada; se detuvo una descarga en curso (2 735 archivos, 165 MB en `dataset2021/`, que no se usa)
- [ ] ~~**T11** (M) Una sola evaluación con el sistema congelado; predicciones por registro conservadas~~ — CANCELADA: no hay datos externos

### Punto de control 2
- [ ] Informe externo con todo congelado; exclusiones según reglas previas; predicciones guardadas
- [ ] El usuario revisa el resultado antes de la Fase 3; ningún F1 mínimo condiciona su validez; el procedimiento no cambia tras verlo

## Fase 3: etiquetas desconocidas (necesita D2; exploratorio)

- [ ] **T12a** (M) Pérdida enmascarada + pruebas (`tests/test_masked_loss.py`)
- [ ] **T12b** (M, GPU ≈ 3 h) Entrenar y evaluar enmascarado, pareado con el actual
- [ ] **T12c** (S) Texto de Métodos y Limitaciones

## Fase 4: ablaciones (necesita D6; exploratorias)

- [ ] **T14** (M, GPU ≈ 4–6 h) Quitar de uno en uno aumentación, suavizado y selección por F1; una ejecución por variante (no mide variabilidad)

## Fase 5: aplazado por el usuario

- [ ] **T15** (L, GPU ≈ 10 h o más) Semillas múltiples sobre la configuración final (después de T12–T14)

## Segunda revisión del asesor (2026-10-23)

- [x] **T17** (M) Paquete de reproducibilidad archivable — ARMADO el 2026-10-27 en `tesis/paquete_t19/` (`scripts/armar_paquete_t19.py`, `--rehacer` lo reconstruye; 616 archivos, 1.1 GB con los 17 `best.pt`, unos 100 MB con `--sin-pesos`): código del commit `303d4b3`, reparto, protocolo y registro, configuraciones, pesos, calibración, umbrales, predicciones de los 23 sistemas, resultados, `LEEME.md`, `LICENCIA.md`, `manifiesto.json`, `SHA256SUMS.txt` y `verificar_paquete.py` (hashes, partición, umbrales y métricas sin datos ni GPU; `--completo` repite el bootstrap y sale byte a byte igual). **Pendiente, del usuario:** decidir la licencia de lo que no es código (`LICENCIA.md`, comprobar antes que la base del Challenge 2020 permite redistribuir lo derivado), publicar el código y el paquete y obtener el DOI; luego sustituir el `\TODO` de Declaraciones
- [x] **T18** (M) Correcciones menores de manuscrito: Obs. 5, 8–16 y 18 (Ec. 3 y $w_c$, Tablas I, III, VII y X, Fig. 3, «coincidencia exacta», orden de cita) — HECHO (2026-10-23): Obs. 5, 8–16 y 18 resueltas o comprobadas como no aplicables; `auditar_citas.py` sin tablas ni figuras antes de su cita

## Decidido el 2026-10-26: A ahora; B y C en el reentrenamiento final

- [x] **A** Mantener la prueba interna como exploratoria y declararlo (ya está en el artículo)
- [ ] **T19** (L, GPU) Reentrenamiento final: reparto nuevo (Georgia fuera como prueba B; PTB-XL y PTB agrupados por paciente), protocolo hasheado antes de entrenar, recetas v1/v2 sin cambios + secundarios (enmascarado, CNN, ablaciones, semillas); incluye T12, T13, T14 y T15. Escalonar: 1 semilla de cada sistema, luego semillas, luego variantes
  - [x] **T19a** código y pruebas (2026-10-26, rama `feat/reparto-por-origen-y-paciente`, sin commit): `grouped_origin_split` + `--holdout-origin/--groups-csv` + `tools/make_patient_groups.py` + `mask_unannotated`; 28 pruebas nuevas; humo real de 1 época con la máscara; reparto real: 0 de 19 131 pacientes en dos particiones; train 22 895 / val 4 913 / prueba A 4 949 / prueba B (Georgia) 10 344
  - [x] **T19b** protocolo escrito y hasheado el 2026-10-26: `evidencia/protocolo_t19.md` (SHA-256 `e74e28f5…`), desviaciones en `protocolo_t19_desviaciones.md`, manifiesto de 39 archivos
  - [x] Código de T19a commiteado: `303d4b3` (local, sin subir); borrados `dataset2021/`, `descargar_challenge2021.sh` y la CNN incompleta (2026-10-26)
  - [x] HDF5 nuevos construidos y verificados contra el protocolo (2026-10-26): `data/cinc2020_12_origen/`, 0 pacientes repartidos, tamaños exactos
  - [x] T19c entrenar (2026-10-27): etapas 1 (P1, P2), 2 (CNN y variantes enmascaradas) y 3 (semillas 101 a 104 y cuatro ablaciones), 17 entrenamientos en total (2, 3 y 12)
  - [x] T19d evaluación única en A y B de los 19 sistemas de la etapa 3 y de las etapas 1 y 2, con análisis en `evidencia/t19_etapa1|2|3/` y registro con SHA-256 en `evidencia/protocolo_t19_registro.md`; paquete T17 armado (ver abajo)
  - [x] T19e integración en el texto (2026-10-27): `scripts/calcular_t19.py` genera `evidencia/cifras_t19.csv` y `capitulos/cifras_t19.tex` (el artículo ya no carga `cifras.tex` ni `cifras_extra.tex`); `hacer_figuras.py` lee las predicciones de P3 en A y B; Resumen, Introducción, Métodos, Resultados, Discusión, Conclusiones, Apéndice y Declaraciones reescritos con el reparto nuevo

## Fase 6: integración

- [~] **T16** (M) Integración final: HECHA la integración (2026-10-27): verificador en 0 errores, `compilar.sh` 15 págs (≤ 20), `auditar_citas.py` OK. **Pendiente:** revisión del texto y aprobación del usuario; el manifiesto (`manifiesto.py`) sigue describiendo la evaluación anterior (T17); un `\TODO` en Declaraciones (publicar el código y el paquete con DOI); la versión Word y `calcular_extra.py` quedan obsoletos

### Punto de control final
- [ ] ≤ 20 págs, verificador en 0 errores, nada exploratorio presentado como confirmatorio, faltantes declarados como limitación

## Limpieza de versiones pasadas o inválidas (evaluada el 2026-10-26; **nada se ha borrado**)

Resumen: es factible, pero libera poco (≈ 270 MB; lo grande, `data/cinc2020_12` 9.8 GB y `dataset2020`, hace falta). Los candidatos están en `plan.md`, sección «Limpieza».

## Estado de las 18 observaciones de la segunda revisión del asesor (2026-10-27, tras T16 y T17; el artículo tiene 16 págs)

**Cierre E14 (2026-11-01, contra el PDF final de 20 págs.): 13 cumplidas y 4 con reserva declarada (1, 2, 4 y 6); la 17 la descartó el usuario el mismo día al cancelar el archivo con DOI.** La 2 pasa de abierta a con reserva (C y D con protocolo sellado, pero «no es plena», lo dice el artículo); la 3 pasa a cumplida (10 semillas, p mínimo 0.002); la 6 queda con reserva (el código y los comandos están en GitHub, sin archivo con DOI) y la 17 se descarta. Detalle por observación en `revision_observaciones.md`. Lo que sigue es el recuento anterior, conservado.

**Revisado el 2026-10-30 contra el criterio de aceptación literal: 12 cumplidas, 3 con reserva (1, 3 y 4), 3 abiertas (2, 6 y 17). La Obs. 3 pasó de resuelta a «con reserva»** (la prueba de signos con 5 semillas no puede dar p < 0.05). Detalle en `revision_observaciones.md`. El resto de este bloque es el recuento del 2026-10-27.

- **Resueltas (13 el 2026-10-27; 12 el 2026-10-30, sin la 3):** 3 (5 semillas, media ± desviación y prueba de signos; ahora con reserva), 5, 7, 8, 9, 10, 11, 12 (Tabla XIII, robustez de v2 en A y B con unidades y un sorteo declarado), 13, 14, 15, 16 y 18.
- **Resueltas con una reserva declarada en el artículo (2):** 1 (separación por paciente solo donde hay identificador: PTB-XL y PTB, con 0 pacientes repartidos; tablas etiquetadas y F1 del subconjunto de A por paciente; el resto de A es por registro) y 4 (CNN con carga de trabajo equivalente y línea base de la calibración por temperatura; la comparación con resultados del Challenge sigue fuera por la regla del proyecto).
- **Abiertas, dependen de publicar o de datos nuevos (3):** 2 (no existe una partición nunca usada para el diseño; el artículo lo declara y no se puede cerrar con los datos que quedan), 6 (el material está en `paquete_t19/`, solo en local) y 17 (sin DOI: el código se declara con GitHub).
- Hecho en esta pasada: etapas exploratorias 4 (temperatura) y 5 (robustez) y subconjunto por paciente, anotados como desviación 4; `tasks/` fuera del repo; verificador y constructor del paquete corregidos; Word y PDF viejos movidos a `obsoleto/`.

## Fase 7: cerrar las observaciones con Chapman-Shaoxing y Ningbo (plan de 2026-10-30; nada ejecutado)

Detalle, criterios, riesgos y grafo en `plan_externa.md`. Una sola evaluación del sistema T19 ya congelado, sin ajustar nada con estos datos. La descarga de `dataset2021/` (script del usuario) sigue en marcha.
**Decidido el 2026-10-30 (usuario):** prohibición de datos del Challenge 2021 levantada solo para `chapman_shaoxing` y `ningbo`; **sin DOI, solo GitHub** (E0.6; se había decidido archivar con DOI el 2026-10-30 y se canceló el 2026-11-01); C y D como resultados primarios (E0.7); 10 semillas (E0.8); paquete completo solo en local (E0.9). **Por ahora solo el plan: no se ejecuta ni se publica nada hasta que el usuario lo ordene.**
**Qué cierra, si se ejecuta:** Obs. 2 (por el procedimiento, no por el valor del F1) · 3 (de fondo, con 10 semillas) · 6 y 17 (con reserva: GitHub, sin DOI) · refuerza 1 y 4 (las reservas se reducen, no desaparecen) · protege 7.
**Camino mínimo:** E0 (hecha) → E1 → E2 → E3 → E4 → E5 → E16 → E6 → E7 → E8 → E9 → E10(a,b) → E11 → E15 → E10(c) → E12 → E14. Solo E13 es opcional. E16 puede correr en la GPU mientras baja la descarga.

- [x] **E0** (XS, todas) Decisiones del usuario, **hechas el 2026-10-30**: E0.1 prohibición levantada solo para `chapman_shaoxing` y `ningbo` (sin levantar la regla de no usar la métrica ni los resultados del Challenge) · E0.2 todos los grupos de sistemas · E0.3 titular por origen · E0.4 mínimo de 50 positivos por clase evaluable · E0.5 E13 sí, pero después de E8 · E0.6 sin DOI, solo GitHub (decisión final del 2026-11-01) · E0.7 C y D primarios · E0.8 10 semillas · E0.9 paquete completo solo en local. **Aun así no se ejecuta nada hasta que el usuario lo ordene.**
- [x] **E1** (S, Obs. 2) Descarga completa (10 247 y 34 905 pares `.hea`/`.mat`) verificada con `SHA256SUMS.txt` del Challenge 2021. **2026-10-31: descarga terminada por el usuario; recuentos, pares, tamaños y cabeceras verificados; SHA-256 en 90 303 de 90 304 archivos; `ningbo/g3/JS13118.mat` falla (tres descargas coinciden entre sí y no con el hash publicado): **el usuario decidió excluir ese registro (2026-10-31)** por la regla «hash distinto del publicado»; quedan 45 151 registros. **E1 CERRADA.** `S23074.hea` renombrado a `JS23074.hea` por orden del usuario (ver `plan_externa.md`, «Avances»)**
- [x] **E2** (M, Obs. 7 y 1) Auditoría de cabeceras y códigos SNOMED: positivos por clase y origen, códigos sin clase, registros sin clase, duplicados internos, pacientes. **HECHA 2026-10-31:** 18 y 133 registros sin clase; 87 grupos de `.mat` idénticos (71 entre C y D); pacientes por ECG no confirmado
- [x] **E3** (S, Obs. 7) Cobertura documentada con cita por celda y clases evaluables por origen, fijadas antes de ver predicciones. **HECHA 2026-10-31:** las 12 clases cubiertas; evaluables 11 en Chapman (`LVH` tiene 21 positivos) y 12 en Ningbo; archivo `cobertura_externa.csv`
- [x] **E4** (M, Obs. 2 y 1; **FUSIONADA el 2026-11-01: PR #37, `main` en b468599**; el worktree y la rama se borraron) Constructor de prueba externa en el repositorio (`ecg/datasets.py`, `build_external_test.py`, pruebas); PR con CI verde, sin menciones de la tesis ni de IA; con lista de exclusiones (`JS13118`)
- [x] **E5** (M, Obs. 1 y 2) HDF5 `test_c.h5` y `test_d.h5`, duplicados frente a entrenamiento, validación, A y B, SHA-256 en `reparto_externo.json`
- [x] **E16** (M, GPU ≈ 8 h, Obs. 3; **HECHA el 2026-11-01**: entrenamiento, evaluación única en A y B, análisis con 10 semillas (`t19_etapa6/`), cifras (`calcular_t19.py`), artículo (16 págs., 0 errores) y paquete rehecho (950 archivos, 41 sistemas, 27 pesos); todo registrado) 5 semillas más de v1 y v2 **antes de E6**; desviación 5; regenerar el análisis de la etapa 3 y las cifras, y revisar el texto que dice «cinco semillas». No depende de los datos externos
- [~] **E6** (S, **Obs. 2**; **protocolo sellado el 2026-11-01 (52b70fbd…), falta la revisión del usuario**) Protocolo externo con hash y fecha, escrito **antes** de cualquier predicción, con el historial de uso de C y D y las 10 semillas; el usuario lo revisa
- [x] **E7** (HECHA el 2026-11-01; 74 carpetas `_C`/`_D`; interrumpida por un apagón y reanudada con P1t, P2t y P3t) (M, GPU, Obs. 2, 3, 4 y 7) Evaluación única: P1/P2/P3 con sus 10 semillas, P1m/P2m/P3m, CNN, P1t/P2t/P3t; calibración y umbrales ya guardados; el script se detiene si la carpeta existe
- [x] **E8** (HECHA el 2026-11-01; `evidencia/t19_etapa7/`) (M, Obs. 2, 3, 4 y 7) Análisis de la etapa 6 con `analizar_t19.py`: clases evaluables, IC por *bootstrap*, semillas, comprobación contra la evaluación original
- [x] **E9** (HECHA el 2026-11-01: `calcular_t19.py` genera las cifras de C y D, E13 y las semillas externas (28 494 cifras, ninguna anterior cambió) y `hacer_figuras.py` añade `fig_externa`) (S, Obs. 2) Cifras (`calcular_t19.py`) y figuras con C y D, sin decimales a mano
- [x] **E10** (HECHA el 2026-11-01: métodos, resultados, discusión, resumen, conclusiones y declaraciones con C y D como evaluación primaria; la disponibilidad del código remite a GitHub con los comandos del repositorio; 20 págs., `verificar_tex.py` 0 errores, `auditar_citas.py` OK) (L, en tres partes; Obs. 2, 1, 4, 3, 7 y 17) Artículo: (a) Métodos, (b) Resultados, (c) Discusión, Resumen, Conclusiones y Declaraciones; C y D titulan, A y B pasan a desarrollo/exploratorios; el texto dice que ninguna decisión de diseño usó C ni D; ≤ 20 págs.
- [x] **E11** (**HECHA el 2026-11-01**: paquete reconstruido desde `main` en 6b8f7dc, 1 507 archivos, 2.1 GB, con pesos y etapa 7; `verificar_paquete.py` OK y `--completo` OK byte a byte en 67 min (etapas 1, 2, 3, 4, 6, 7 y E13); tras corregir el LEEME (siete citas) se reconstruyó y se volvió a verificar sin `--completo`; **queda solo en local, no se publica**) (M, Obs. 6 y 17) Paquete de reproducibilidad **completo, con pesos** (≈ 2 GB), con la etapa 6; `verificar_paquete.py --completo` en copia limpia
- [x] ~~**E15** Publicar el paquete en un archivo con DOI~~ — CANCELADA el 2026-11-01 por orden del usuario: la subida del .zip de 1.22 GB fallaba hacia el 80 %. Se borró el material preparado y el código se declara solo con el repositorio de GitHub (Declaraciones)
- [x] **E12** (HECHA el 2026-11-01: PR #39 fusionada, `main` en 6b8f7dc) (S, Obs. 6) Repositorio: versionar `descargar_challenge2021.sh`, README y `CONSTRAINTS.md`, para que «las predicciones se regeneran con el procedimiento del repositorio» valga también para C y D; misma PR que E4
- [x] **E14** (S, las 18; **HECHO el 2026-11-01**: las 18 repasadas contra el PDF final de 20 págs.; sin cambios de diseño, así que no hay desviación nueva. Tras cancelar el archivo con DOI el 2026-11-01: 13 cumplidas y 4 con reserva (1, 2, 4 y 6), con la 17 descartada por el usuario; ver `revision_observaciones.md`) Cierre: repasar las 18 contra el PDF final, actualizar «Estado de las 18 observaciones» y las desviaciones
- Opcional, ajena a las observaciones: [x] **E13** (M) recalibración local exploratoria, después de registrar E8 (desviación 6); **HECHA el 2026-11-01**, `evidencia/e13_recalibracion_local/`
- [x] ~~**E17** Paquete sin pesos como *Release* de GitHub~~ — CANCELADA el 2026-10-30; el paquete tampoco se publica en otro lado (ver E15)

### Punto de control 0 (tras E3): datos completos y verificados, clases evaluables con cita, ninguna predicción
### Punto de control 1 (tras E5): constructor fusionado, HDF5 verificados, ninguna predicción
### Punto de control 2 (tras E6): protocolo hasheado y revisado por el usuario
### Punto de control 3 (tras E8): resultados anotados tal como salieron, sin reevaluar; revisión con el usuario antes del artículo
### Punto de control final: verificador en 0 errores, ≤ 20 págs, citas en orden; Obs. 2 cerrada con evidencia; 3 con 10 semillas; 6 con la reserva de que solo hay GitHub (sin DOI), 17 descartada; 1 y 4 con la reserva redactada
