# Plan: cerrar las observaciones del asesor con Chapman-Shaoxing y Ningbo

> **Nota (2026-11-01): reorganización de carpetas.** `tesis/ieee/` pasó a ser `tesis/` (la tesis completa y el artículo anterior se borraron por
> redundantes) y las rutas de este documento ya están corregidas. `hacer_docx.py`, `ajustar_flotantes.py`, `word_a_pdf.ps1`, `calcular_extra.py` y
> `manifiesto.py` están en `tesis/obsoleto/`: lo que se diga aquí de ellos es historial. Mapa vigente: `tesis/CONTEXT.md`.

Estado: **solo planificación, nada implementado** (rehecho el 2026-10-30 para partir de las observaciones). Reabre la decisión D1 y sustituye a T9, T10 y T11 de `plan.md`, anuladas el 2026-10-26.
**Decidido el 2026-10-30 (usuario):** E0.1 hecha: se levanta la prohibición de datos del Challenge 2021 solo para `chapman_shaoxing` y `ningbo`. **Por orden del usuario, por ahora solo existe este plan: ninguna tarea se ejecuta (ni código, ni PR, ni HDF5, ni evaluación) hasta que lo ordene.**
**E0 completa (2026-10-30):** el usuario aplicó mis recomendaciones para E0.2 a E0.5 y E0.7 a E0.9 (ver «Decisiones» al final). **E0.6: sin DOI, solo GitHub** (decisión final del 2026-11-01).
Revisión contra el criterio literal de cada observación: [`revision_observaciones.md`](revision_observaciones.md).
Esta carpeta está excluida de git; `tasks/` tiene el plan de la demo (otro trabajo) y no se toca. La lista de tareas está en `todo.md`, Fase 7.

## Objetivo

**Estado tras E14 (2026-11-01):** 13 cumplidas y 4 con reserva declarada (1, 2, 4 y 6; la 6 porque el código está en GitHub, sin archivo con DOI); la 17 la descartó el usuario. Lo que sigue en este párrafo y en la tabla es el planteamiento original (2026-10-30): 12 cumplidas, 3 con reserva (1, 3 y 4) y 3 abiertas (2, 6 y 17).

Lo vital son las 18 observaciones de la segunda revisión del asesor. Contra el criterio de aceptación literal de cada una (revisión en [`revision_observaciones.md`](revision_observaciones.md)), al 2026-10-30: 12 cumplidas, 3 con reserva declarada (1, 3 y 4) y 3 abiertas (2, 6 y 17).
Evaluar el sistema T19 ya congelado en Chapman-Shaoxing (prueba C, 10 247 registros) y Ningbo (prueba D, 34 905) **solo vale la pena si cambia ese recuento**. Esta tabla dice cuánto lo cambia, sin adornar.

| Obs. | Estado hoy | Qué hace este plan | Resultado esperado | Se da por cerrada cuando |
|---|---|---|---|---|
| **2** Partición confirmatoria nunca usada | **Abierta**: el artículo declara que no existe una | Dos orígenes que no intervinieron en el diseño y un protocolo con hash y fecha anterior a toda predicción (E6 antes de E7) | **Se cierra.** Por el procedimiento, no por el valor del F1: se reporta sea cual sea | El protocolo está hasheado antes de E7, el artículo reescribe las limitaciones 1 y 2 y dice qué es ya confirmatorio (C y D) y qué no (A; B solo en parte) |
| **1** Reparto disjunto por paciente | Reserva declarada: solo PTB-XL y PTB tienen identificador; el 31.9 % de A (1 578 registros) no | C y D son instituciones enteras que el entrenamiento y la calibración no vieron, con búsqueda de duplicados de señal (E5). Cumplen la separación por construcción institucional, no por identificador | **Se reduce la reserva, no desaparece:** en C y D «ningún identificador en más de una partición» no se puede comprobar, porque las cabeceras no traen ninguno | Las afirmaciones primarias descansan en C y D, A y B se rotulan exploratorias (E0.7, decidido) y el artículo escribe la reserva sin sobrevender |
| **4** Líneas base y estado de la técnica | Reserva declarada: no se compara con resultados del Challenge (regla del proyecto) | La CNN convencional y la calibración por temperatura se evalúan también en C y D | **Se refuerza la parte de líneas base. La reserva de la comparación con el Challenge sigue** | La tabla externa incluye CNN y temperatura con el mismo protocolo; la reserva se mantiene redactada igual |
| **3** Una corrida por receta | **Con reserva:** 5 semillas y media ± desviación, pero la prueba de signos no puede dar p < 0.05 (mínimo 0.0625); CNN, enmascaradas y ablaciones son una sola corrida | Se entrenan 5 semillas más de v1 y v2 antes de congelar (E0.8 decidido, E16) y P1, P2 y P3 se evalúan con las 10 en C y D; CNN, enmascaradas y temperatura quedan como corrida única y el texto lo dice | **Con 10 semillas la prueba de signos ya puede dar p < 0.05** (mínimo ≈ 0.002); si las ganancias no son consistentes, se reporta lo que salga | Resultados de A, B, C y D con 10 semillas, media ± desviación y prueba de signos, y la reserva restante (corrida única de CNN, enmascaradas y temperatura) redactada |
| **7** Clases no anotadas | Resuelta (cobertura documentada, métricas sin esos registros) | Se amplía la tabla de cobertura a los dos orígenes y se evalúa solo donde la fuente anota; los sistemas con pérdida enmascarada se evalúan también | Se mantiene resuelta | Cada celda origen-clase de C y D tiene su cita; ninguna clase no cubierta cuenta como negativo |
| **6** Reproducibilidad parcial | Abierta: en GitHub faltan el manifiesto de partición, las predicciones por registro y los scripts de análisis (viven en `tesis/`, fuera de git) | GitHub queda al día con el constructor y la descarga de C y D (E4 y E12), para que la frase de Declaraciones «se regeneran con el procedimiento del repositorio» siga siendo cierta | **Con reserva**: sin archivo público de predicciones ni pesos de los sistemas evaluados | Declaraciones remite al repositorio y a sus comandos (E10 y E14) |
| **17** DOI y licencia archivados | Abierta: Declaraciones cita la URL de GitHub, no un DOI (la licencia sí consta: GPL-3.0 el código, CC BY 4.0 los datos) | Sin DOI: Declaraciones cita la URL del código y la licencia | **Con reserva**: no hay DOI | Declaraciones y el repositorio coinciden en la licencia |
| 5, 8 a 16 y 18 | Cumplidas (9, 12 y 18 sin re-comprobar el formato hoy) | El texto y las tablas nuevos no deben reabrirlas: lista de comprobación en E8 y E10; E14 las repasa contra el PDF final | Se mantienen cumplidas | `verificar_tex.py` en 0 errores, citas en orden, ≤ 20 páginas |

**En una frase:** si se ejecuta, el plan cierra la 2 (con C y D como evaluación primaria), cierra la 3 de fondo con 10 semillas, deja la 6 y la 17 con reserva (GitHub, sin DOI), refuerza la 1 y la 4 y protege la 7. Las reservas que quedan son la 1 (sin identificadores de paciente), la 4 (sin comparación con el Challenge), la 6 y la 17 (sin archivo con DOI).

**Sin DOI (decidido el 2026-11-01).** Las Obs. 6 y 17 piden un archivo público con DOI. Se intentó subir el paquete completo (unos 2 GB) a un servicio de archivo, pero la subida del .zip fallaba hacia el 80 %. El usuario decidió declarar el código solo con su repositorio de GitHub; el paquete completo queda en `tesis/paquete_t19/`.
**Momento:** no aplica (E15 cancelada).

## Lo que no cambia

- Se mantiene la regla de CLAUDE.md: del Challenge solo se usa su **base de datos**; no se calcula su métrica ni se compara con sus resultados. Levantar la prohibición de datos del 2026-10-26 para estas dos carpetas no levanta esta regla.
- Nada de IA ni de la tesis en lo que va a GitHub;

## Datos (comprobado el 2026-10-30)

- Challenge 2021 v1.0.3, carpetas `training/chapman_shaoxing` (10 247 registros) y `training/ningbo` (34 905); suman los 45 152 de `ecg-arrhythmia`. 10 s a 500 Hz, 12 derivaciones, códigos SNOMED-CT en la cabecera: el mismo formato que los seis orígenes de 2020, así que el preprocesamiento no cambia. Licencia CC BY 4.0.
- El origen de cada registro es su carpeta, y `infer_source_db` (`ecg/datasets.py`) ya lo toma de la ruta. `ecg-arrhythmia` no separa los dos orígenes, por eso se usa el Challenge 2021.
- **Descarga:** el script `descargar_challenge2021.sh` (del usuario, `wget -r -N -c` secuencial, ya en marcha) baja ~120 KB por registro; medido el 2026-10-30, 19 registros en 30 s (≈ 0.6 por segundo): unas 20 h en total y ~5.5 GB.
  La ruta equivalente del espejo de AWS (`physionet-open.s3.amazonaws.com/challenge-2021/1.0.3/...`) respondió 404, así que lo práctico es **bajar varias subcarpetas `gN` en paralelo** (`-N -c` reanuda). `SHA256SUMS.txt` del Challenge 2021 está en physionet.org y sirve para verificar (E1).
- Tamaño de los HDF5 de prueba: ~240 KB por registro (como `test_b.h5`), es decir, ~2.5 GB (C) y ~8.4 GB (D); hay 343 GB libres.
- Las cabeceras no traen identificador de paciente y no está comprobado cuántos ECG hay por paciente (la fuente de Chapman habla de más de 10 000 pacientes; de Ningbo no consta). Hasta que E2 lo aclare con la documentación, los IC serán por registro y se declara la suposición.

## Decisiones de diseño y por qué

- **Todo se congela antes de calificar** (Obs. 2): sistemas, pesos, calibración, umbrales, preprocesamiento, mapeo de etiquetas, clases evaluables, métricas y reglas, en un protocolo con SHA-256 y fecha (E6). Sobre los datos externos solo se miran cabeceras y recuentos de etiquetas; **ninguna predicción** existe hasta E7.
- **Ningún ajuste con estos datos:** los umbrales y la calibración son los de la validación de los cinco orígenes de entrenamiento. Se espera una caída como la de Georgia; se reporta sea cual sea. Si el número es malo, la Obs. 2 se cierra igual: la observación pide la partición, no un buen resultado.
- **Sistemas evaluados, cada grupo ligado a una observación:**
  - P1, P2 y P3 con sus 10 semillas (E0.8; E16) → Obs. 2 y 3 (sin las semillas, un lector reabriría la 3 en la parte externa).
  - P1m, P2m, P3m (pérdida enmascarada) → Obs. 7: es donde más importa, porque estas fuentes anotan pocas clases.
  - CNN convencional y P1t, P2t, P3t (temperatura) → Obs. 4. Las enmascaradas, la CNN y la temperatura son corrida única (semilla 0), y el texto lo dice, como ya hace en A y B.
  - No se evalúan las 4 ablaciones: no responden a ninguna observación.
- **Clases evaluables por origen, fijadas antes (Obs. 7):** Chapman y Ningbo anotan sobre todo ritmos y algunas morfologías. Una clase es evaluable si la documentación de la fuente la cubre **y** hay un mínimo de positivos (n fijado en el protocolo). La métrica titular es el F1 macro de P3 **sobre las clases evaluables de cada origen**; el F1 con las 12 clases va como diagnóstico, porque una clase sin anotar no es lo mismo que una clase sin positivos. Una clase no cubierta no cuenta como negativo.
- **C y D por separado.** Son instituciones distintas; el agregado se informa, pero no es el titular.
- **Registros sin ninguna de las 12 clases:** se conservan como negativos, como en A y B, y se informa también el resultado sin ellos.
- **Lo exploratorio queda rotulado y va después:** la recalibración local (E13) solo se hace cuando la evaluación confirmatoria está medida y registrada, y entra como desviación 6 (la 5 es la ampliación de semillas, E16).
- El código nuevo (constructor de prueba externa) va en una PR al repositorio, con pruebas, sin menciones de la tesis ni del artículo. Los resultados, el protocolo y el artículo siguen fuera de git.

## Camino mínimo y grafo de dependencias

**Camino mínimo:** E0 (hecha) → E1 → E2 → E3 → E4 → E5 → E16 → E6 → E7 → E8 → E9 → E10(a,b) → E11 → E15 → E10(c) → E12 → E14. Solo E13 (exploración) es opcional. E16 no depende de los datos externos: puede correr en la GPU mientras baja la descarga.

```
E0 decisiones (usuario)
  ├── E1 descarga ──> E2 auditoría ──> E3 cobertura y clases evaluables ─┐   (Obs. 7)
  └── E4 constructor de prueba (código, PR) ──────────────────────────────┤
                                                                          v
                  E5 HDF5 y duplicados ──> E6 PROTOCOLO (hash, congela) ──> E7 evaluación única (GPU)   (Obs. 2)
                                                                          │
                                                                          v
   E16 más semillas (antes de E6; en paralelo a la descarga)                               (Obs. 3)
                          E8 análisis ──> E9 cifras ──> E10(a,b) ──> E11 paquete (solo local) ──> E10(c) ──> E14 cierre
                            │                                                                  (Obs. 6 y 17)               ▲
                            ├── E13 exploración (opcional)                  E12 repositorio: descarga y README (tras E4) ──┘
```

## Tareas

Cada tarea dice a qué observación sirve. Una tarea sin observación es opcional.

### Fase 0: decisiones y datos (sin tocar el sistema)

**E0. Decisiones del usuario (XS).** Sirve a: todas. Levantar, solo para `chapman_shaoxing` y `ningbo`, la prohibición del 2026-10-26 de usar datos del Challenge 2021 (sin levantar la regla de no usar su métrica ni sus resultados);
sistemas, métrica titular, mínimo de positivos y E13; y cuándo publicar (E0.6). **HECHA el 2026-10-30:** E0.1 prohibición levantada, E0.2 todos los grupos de sistemas, E0.3 titular por origen, E0.4 mínimo de 50 positivos, E0.5 E13 sí pero después de E8, E0.6 sin DOI, solo GitHub (decisión final del 2026-11-01), E0.7 C y D como resultados primarios, E0.8 10 semillas, E0.9 paquete completo solo en local. Aceptación: las decisiones anotadas en `todo.md`. Dependencias: ninguna.

**E1. Descarga completa y verificada (S, horas en segundo plano).** Sirve a: Obs. 2 (base). Bajar las dos carpetas con varias subcarpetas `gN` en paralelo (reanudable) y verificarlas. **CERRADA el 2026-10-31:** descarga terminada por el usuario; SHA-256 verificado en 90 303 de 90 304 archivos; el que falla, `ningbo/g3/JS13118.mat`, es idéntico al que sirve el servidor y el usuario decidió excluir ese registro (regla «hash distinto del publicado»); `S23074.hea` renombrado a `JS23074.hea` (ver «Avances»).
Aceptación: 10 247 y 34 905 pares `.hea`/`.mat`, ningún `.hea` sin `.mat`, y los SHA-256 coinciden con `SHA256SUMS.txt` del Challenge 2021.
Verificación: recuento por carpeta y `sha256sum -c` sobre la lista filtrada. Dependencias: E0. Archivos: `descargar_challenge2021.sh` (el del usuario; se versiona en E12). Es el camino más largo (≈ 20 h): hay que empezarlo ya.

**E2. Auditoría de cabeceras y códigos (M).** Sirve a: Obs. 7 y 1. Con `examples/cinc2020/audit_dx_codes.py` (y un script de recuentos si falta): derivaciones, frecuencia y duración de cada registro; códigos SNOMED y su mapeo a las 12 clases;
códigos sin clase; registros sin ninguna clase; duplicados dentro del origen; cuántos ECG hay por paciente según la documentación. Aceptación: `evidencia/auditoria_externa.csv` con positivos por clase y origen y la lista de códigos sin clase.
Verificación: los totales por origen coinciden con E1. Dependencias: E1. Sin predicciones. **HECHA el 2026-10-31** (`scripts/auditar_externa.py`; ver «Avances»).

**E3. Cobertura documentada y clases evaluables (S).** Sirve a: Obs. 7. Añadir los dos orígenes a `evidencia/cobertura_etiquetas.csv` con una cita por celda (ficha de PhysioNet, Zheng et al. 2020 en *Scientific Data*, página del Challenge 2021),
fijar la regla de «clase evaluable» y el tratamiento de las no cubiertas. Aceptación: una fila por origen y clase con su cita y su estado; la lista de clases evaluables de C y de D.
Verificación: cada cita respalda su celda; el tratamiento es el mismo que ya resolvió la Obs. 7 en los seis orígenes. Dependencias: E2. Archivos: `evidencia/cobertura_externa.csv` (archivo aparte, porque cinco scripts leen `cobertura_etiquetas.csv`) y `references_extra.bib` (las citas entran en E10). **HECHA el 2026-10-31** (`scripts/cobertura_externa.py`; ver «Avances»).

#### Punto de control 0
- [x] Los dos orígenes completos y verificados; códigos auditados; clases evaluables fijadas con cita
- [x] Ninguna predicción del sistema sobre estos datos

### Fase 1: código y conjuntos de prueba

**E4. Constructor de prueba externa (M).** Sirve a: Obs. 2 y 1. `build_external_test` en `ecg/datasets.py` y `examples/cinc2020/build_external_test.py`: todos los registros de un origen a un HDF5 de solo prueba (`test_c.h5`, `test_d.h5`),
con el mismo preprocesamiento y la misma ventana central, sin partición y sin el error de `build_datasets` por clases sin positivos. Pruebas con registros sintéticos (como `tests/test_dataset_build.py`). El constructor acepta una lista de exclusiones (hoy: `JS13118`, por hash distinto del publicado) y las cuenta en su salida.
Aceptación: con la misma señal, el HDF5 externo es idéntico al que habría salido como `test` en `build_datasets`; una clase sin positivos no falla. Verificación: `python -m pytest tests/test_external_build.py -q` y la suite.
Dependencias: ninguna (se hace mientras baja la descarga). Archivos: `ecg/datasets.py`, `examples/cinc2020/build_external_test.py`, `tests/test_external_build.py`, `examples/cinc2020/README.md`, `ecg/CONTEXT.md`.
Va en una PR al repositorio (CI verde, sin menciones de la tesis ni de IA); al cambiar comandos, se actualizan los `.md` que los citan.

**E5. Construir y auditar los HDF5 (M).** Sirve a: Obs. 1 y 2. Construir `data/cinc2020_12_origen/test_c.h5` y `test_d.h5`; comprobar recuentos y que no haya errores de procesamiento; buscar duplicados exactos de la señal preprocesada frente a entrenamiento,
validación, prueba A y prueba B; registrar los SHA-256 en `evidencia/reparto_externo.json`. Aceptación: 10 247 y 34 905 registros (menos las exclusiones que fije la regla, listadas; hoy una, decidida el 2026-10-31: `JS13118` de Ningbo, con hash publicado distinto; ver «Avances»); 0 errores; duplicados contados y tratados según el protocolo.
Verificación: un script de comprobación, como `verificar_reparto_t19.py`. Dependencias: E1, E4. Ningún modelo toca estos archivos.

#### Punto de control 1
- [ ] PR del constructor fusionada con el CI en verde; HDF5 verificados; duplicados contados
- [ ] Todavía no existe ninguna predicción de C ni de D

### Fase 2: congelar

**E6. Protocolo externo (S).** Sirve a: Obs. 2 (es la tarea que la cierra). `evidencia/protocolo_externo_t19.md` con SHA-256 y fecha, escrito **antes** de E7, en el formato de `protocolo_t19.md`: sistemas y hashes de pesos, calibración y umbrales (incluidas las semillas); preprocesamiento; mapeo de etiquetas;
clases evaluables por origen (E3); métrica titular (F1 macro sobre las clases evaluables de cada origen) y secundarias (AUROC, AUPRC, ECE, Brier, F1 con 12 clases, por clase, sin los registros sin clase);
IC del 95 % por *bootstrap* (1 000 remuestreos, semilla 0); exclusiones; reglas (una sola evaluación, se reporta sea cual sea, ningún ajuste); qué queda como exploratorio. Aceptación: hash y fecha registrados; **historial de uso de C y D** (qué se hizo con ellos antes de E7: descarga, auditoría de cabeceras y códigos, recuentos de etiquetas para la regla de ≥ 50 positivos, búsqueda de duplicados, y que ninguno intervino en receta, calibración, umbral ni punto de operación, que es lo que inspecciona el verificador de la Obs. 2);
ninguna carpeta `*_C` ni `*_D` en `runs/t19/eval/`. Verificación: el hash guardado coincide con el archivo. Dependencias: E0, E3, E5.

#### Punto de control 2
- [ ] Protocolo escrito, fechado y hasheado; revisado por el usuario antes de ejecutar nada

### Fase 3: evaluación única

**E7. Evaluación única (M, GPU, tiempo a medir).** Sirve a: Obs. 2, 3, 4 y 7. Etapa 6 de `evaluar_t19.sh`: configuraciones `*_testc.json` y `*_testd.json` (como las `_testb`: solo cambia `test`) y `evaluate.py` / `ensemble_evaluate.py` con la calibración y los umbrales ya guardados
de cada sistema, una sola vez por sistema y origen; el script se detiene si la carpeta ya existe. Sistemas: P1, P2, P3 (con las semillas de la etapa 3), P1m, P2m, P3m, CNN, P1t, P2t, P3t. El tiempo se mide con una pasada sobre B antes de lanzar.
Aceptación: una carpeta por sistema, semilla y origen; SHA-256 de las predicciones en el registro. Verificación: los umbrales de C y D son byte a byte los de A y B (mismos de validación).
Dependencias: E6. Archivos: `scripts/evaluar_t19.sh`, `runs/t19/config/`.

**E8. Análisis de la etapa 6 (M).** Sirve a: Obs. 2, 3, 4 y 7. `analizar_t19.py` con las pruebas C y D: máscara de clases evaluables por origen (la columna `clases_anotadas` ya existe para los orígenes de A), métrica titular, secundarias, por clase, por origen, A y B menos C y D no pareadas, IC por *bootstrap*,
media ± desviación y prueba de signos de las semillas, comparación del ensemble con el mejor individual, SHA-256 de las predicciones y comprobación contra `metrics_global.csv`. Aceptación: `evidencia/t19_etapa6/` con el formato de las etapas 1 a 4; las tablas derivadas llevan IC de AUROC, AUPRC y coincidencia exacta (Obs. 14). Verificación: los valores puntuales coinciden con scikit-learn y con la evaluación original (tolerancias de las etapas anteriores).
Dependencias: E7. Archivos: `scripts/analizar_t19.py`.

#### Punto de control 3
- [ ] Resultados leídos y anotados en el registro tal como salieron; ninguna reevaluación ni ajuste
- [ ] Revisión con el usuario antes de tocar el artículo

### Fase 4: integración y cierre de las observaciones

**E9. Cifras y figuras (S).** Sirve a: Obs. 2. `calcular_t19.py` genera los identificadores de C y D (tabla de orígenes ampliada, titular, secundarias, por clase) y `hacer_figuras.py` añade C y D donde corresponda.
Aceptación: `verificar_tex.py` sin cifras a mano. Dependencias: E8.

**E10. Artículo (L, dividir en tres).** Sirve a: Obs. 2, 1, 4, 3, 7 y 17. (a) Métodos: la fuente externa, la Tabla II con los dos orígenes, clases evaluables y protocolo externo; (b) Resultados: subsección y tabla con A, B, C y D juntos, con CNN y temperatura (Obs. 4) y media ± desviación (Obs. 3);
(c) Discusión, Resumen y Conclusiones: las limitaciones 1 y 2 se reescriben (qué es confirmatorio y qué no, sin sobrevender), la reserva de la Obs. 1 queda redactada sobre A, el Resumen y las Conclusiones titulan C y D como evaluación primaria (E0.7) y A y B pasan a desarrollo/exploratorios con sus reservas, y se citan Zheng et al. (*Scientific Data*), el conjunto del Challenge 2021 y la referencia estándar de PhysioNet. Declaraciones se amplía con las dos carpetas externas (públicas, CC BY 4.0, no se redistribuyen) y remite al repositorio de GitHub con la licencia y los comandos (sin DOI; E15 cancelada).
Aceptación: `verificar_tex.py` en 0 errores, `compilar.sh` con ≤ 20 págs (hoy 16), `auditar_citas.py` OK; nada exploratorio presentado como confirmatorio. **El texto dice explícitamente que ninguna decisión de diseño (receta, calibración, umbral, punto de operación, ensemble) usó C ni D (Obs. 2)** y que la regla de clases evaluables usó recuentos de etiquetas de C y D. Lista de comprobación de lo nuevo, para no reabrir las menores: abreviaturas definidas y positivos por fila en las figuras (10), unidades (12), cita antes de aparecer (16), alineación y legibilidad (9 y 18), terminología unificada (11) y «coincidencia exacta» definida (15). Dependencias: E9; la parte (c), también E15.

**E11. Paquete de reproducibilidad (M, en el camino mínimo).** Sirve a: Obs. 6 y 17 (queda solo en local). Se reconstruye **completo, con pesos** (unos 2 GB con las 10 semillas) y la etapa 6. Añadir las predicciones, los umbrales, las configuraciones `_testc/_testd`, el protocolo externo, `reparto_externo.json` y los resultados de la etapa 6; extender `verificar_paquete.py`; actualizar `LICENCIA.md` y `LEEME.md`
con las citas de los dos orígenes; reconstruir. Aceptación: `verificar_paquete.py --completo` OK en una copia limpia y sin menciones prohibidas. Dependencias: E8 y E10(a,b).

**E14. Cierre de las 18 observaciones (S).** Sirve a: todas. Con el PDF final, repasar las 18 una por una (la tabla del principio): qué dice el artículo, dónde, y si se mantiene o cambia el estado; actualizar «Estado de las 18 observaciones» en `todo.md` y los cambios en `protocolo_t19_desviaciones.md`.
Aceptación: una línea por observación con su evidencia (sección, tabla o figura del PDF); ninguna observación resuelta queda reabierta por el texto nuevo. Verificación: `verificar_tex.py`, `auditar_citas.py`, `compilar.sh`. Dependencias: E10, E11.

**E12. Repositorio: descarga y documentación (S).** Sirve a: Obs. 6. Declaraciones dice que las predicciones «se regeneran con el procedimiento de evaluación del repositorio»; para que siga siendo cierto con C y D, el repositorio necesita la descarga y el constructor.
Versionar `descargar_challenge2021.sh` (con el estilo del de 2020), explicar en el README cómo descargar, construir y evaluar, y actualizar `CONSTRAINTS.md` (pruebas y comandos). `dataset2021/` ya lo cubre `/dataset*/` en `.gitignore`. Puede ir en la misma PR que E4 para un solo ciclo de CI; la línea del README con el DOI se añade en una PR pequeña tras E15.
Aceptación: CI verde, 0 problemas en `check_docs_commands.py`, sin menciones de la tesis ni de IA. Dependencias: E4.

**E15. Publicar el paquete en un archivo con DOI — CANCELADA el 2026-11-01:** la subida fallaba hacia el 80 %; el usuario la sustituyó por declarar el código con GitHub (E10(c)).



**E16. Más semillas (decidida en E0.8; en el camino mínimo; GPU ≈ 8 h, estimada de la etapa 3: 9 h 18 min por 12 entrenamientos).** Sirve a: Obs. 3. Entrenar 5 semillas más de v1 y v2 con la misma receta y calendario, **antes de E6**, para que las 10 queden en el protocolo. No depende de los datos externos: puede correr mientras baja la descarga.
Es una desviación (la 5): el protocolo T19 fijaba 5 semillas y ya se vio p = 0.0625; ampliar después de verlo es una parada que depende de los datos. Se anota con fecha y se reportan los resultados con 5 y con 10. Hay que regenerar el análisis de la etapa 3 con 10 semillas (`analizar_t19.py --etapa 3`), las cifras (`calcular_t19.py`) y revisar el texto escrito a mano que dice «cinco semillas».
Aceptación: prueba de signos con 10 semillas (p mínimo ≈ 0.002), media ± desviación, desviación registrada y `verificar_tex.py` en 0 errores. Dependencias: ninguna técnica.

**E17. Paquete sin pesos como *Release* de GitHub — CANCELADA el 2026-10-30:** y el paquete tampoco se publica en otro lado (ver E15).

#### Punto de control final
- [ ] Verificador en 0 errores, ≤ 20 págs, citas en orden, paquete verificado
- [ ] Obs. 2 cerrada con evidencia; 3 con 10 semillas (la prueba de signos ya puede rechazar); 6 y 17 con la reserva de que solo hay GitHub (sin DOI); Obs. 1 y 4 con la reserva reducida y redactada; 7 sigue cumplida

### Exploración (opcional, ajena a las observaciones)

**E13. Recalibración local (M, exploratoria).** No sirve a ninguna observación: explica la caída, no la corrige. Solo cuando E8 esté registrada: una mitad de cada origen recalibra y reajusta umbrales y la otra mide. Rotulado exploratorio, con su desviación anotada (la 6). Dependencias: E8 y la decisión de E0.

## Riesgos y mitigaciones

| Riesgo | Observación afectada | Impacto | Mitigación |
|---|---|---|---|
| Mirar predicciones antes de congelar el protocolo invalida lo confirmatorio | 2 | Alto | E6 antes de E7; el script de evaluación se detiene si ya existe la carpeta |
| La descarga tarda ~20 h registro a registro | 2 | Alto | Subcarpetas `gN` en paralelo, `-N -c`; empezar ya |
| Pocas clases evaluables en C y D (anotan sobre todo ritmos): el macro no es comparable con A y B | 2 y 7 | Alto | Clases evaluables fijadas antes con cita; F1 de 12 clases solo como diagnóstico; por clase en la tabla |
| El texto nuevo reabre una observación resuelta (semillas sin repetir en C y D, clases no cubiertas contadas como negativas) | 3 y 7 | Medio | Semillas y mismo tratamiento de cobertura en E7 y E3; E14 repasa las 18 |
| Se vende como confirmatorio algo que no lo es del todo (B se vio en el diseño en parte; A también) | 2 | Medio | El texto dice qué es confirmatorio: C y D; E10(c) y E14 lo comprueban contra el PDF |
| Si C y D son los primarios y salen bajos, el titular del artículo baja | 1 y 2 | Medio | Se reporta tal cual; la observación pide la partición, no un buen número; A y B quedan como contexto exploratorio |
| Resultado mucho peor que A | 2 | Medio | Se reporta tal cual; es información, como B; la observación se cierra por el procedimiento; E13 lo explica sin cambiar el titular |
| Más de un ECG por paciente (no consta) | 1 | Medio | IC por registro y suposición declarada; si E2 detecta identificadores, IC por clúster |
| Duplicados con los orígenes de 2020 | 1 | Medio | E5 compara hashes de la señal preprocesada |
| Códigos SNOMED de Chapman/Ningbo fuera del esquema de 12 clases | 7 | Medio | E2 los lista; los registros sin clase se conservan como negativos y se informa con y sin ellos |
| (retirado el 2026-11-01: ya no se publica un archivo con DOI) | 6 y 17 | - | - |
| Las 10 semillas cambian cifras de la etapa 3 ya citadas en el artículo | 3 | Medio | Las cifras salen de `calcular_t19.py` y `verificar_tex.py` detecta lo escrito a mano; se reportan 5 y 10; desviación 5 |
| Ampliar las semillas tras ver p = 0.0625 es una parada que depende de los datos | 3 | Medio | Se declara como desviación y se reportan ambos resultados |
| Más resultados no caben en 20 págs | todas | Medio | Tabla compacta con A, B, C y D; ≈ 1 pág. extra sobre las 16 actuales |
| El código nuevo rompe la CI del repositorio | ninguna | Medio | Suite completa en una copia limpia antes de la PR; sin menciones de la tesis ni de IA |

## Decisiones (E0, todas tomadas el 2026-10-30)

El usuario aplicó mis recomendaciones para E0.2 a E0.5 y E0.7 a E0.9, e invirtió E0.6. Se reconfirman antes de escribir el protocolo (E6), que es donde quedan fijadas.

- **E0.1** Se levanta la prohibición del 2026-10-26 solo para `chapman_shaoxing` y `ningbo`; la regla de no usar la métrica ni los resultados del Challenge sigue.
- **E0.2** Se evalúan todos los grupos de sistemas: P1, P2 y P3 con sus semillas; P1m, P2m y P3m; CNN; P1t, P2t y P3t. Cada grupo protege una observación y es solo inferencia. Sin las 4 ablaciones.
- **E0.3** Titular por origen (C y D por separado); el agregado va como secundario.
- **E0.4** Una clase es evaluable con la fuente que la cubre y **al menos 50 positivos** en ese origen. El umbral se fija en el protocolo con la auditoría E2 a la vista y sin mirar predicciones.
- **E0.5** Se hace E13 (recalibración local), pero solo después de registrar el resultado confirmatorio (E8); entra como desviación 6. No es necesaria para ninguna observación.
- **E0.6** **Sin DOI, solo GitHub** (decisión final del 2026-11-01; el 2026-10-30 se había decidido archivar con DOI). E15 queda cancelada y las Obs. 6 y 17 quedan con reserva.
- **E0.7** **Decidida: C y D son los resultados primarios del artículo.** A y B pasan a desarrollo/exploratorios, con sus reservas. Cambia el Resumen, el titular y las Conclusiones (E10).
- **E0.8** **Decidida: sí, 10 semillas de v1 y v2** antes de congelar el protocolo (E16). Cuesta ≈ 8 h de GPU y se anota como desviación 5.
- **E0.9** **El paquete completo, con pesos, queda solo en local** (`tesis/paquete_t19/`); ni en un archivo con DOI ni en una *Release* de GitHub (E17, cancelada).

## Avances (registro con fecha)

### 2026-10-31: E1 revisada, el usuario terminó la descarga

Se hizo solo lectura local y cabeceras HTTP. **No hay ninguna predicción ni ningún HDF5.**

- **Recuentos:** 45 152 `.hea` y 45 152 `.mat` (`chapman_shaoxing`: 10 247 en 11 subcarpetas; `ningbo`: 34 905 en 35), 5.4 GB. Sin archivos vacíos ni ajenos, sin nombres de registro repetidos entre subcarpetas, y `wget` ya no corre.
- **Integridad:** todos los `.mat` pesan exactamente 120 024 bytes. Las 45 152 cabeceras dicen 12 derivaciones, 500 Hz y 5 000 muestras, traen 12 líneas de señal y una línea `Dx` no vacía, y apuntan a un `.mat` que existe.
- **Errores en los registros de `wget`:** 156 respuestas HTTP 502, 58 fallos SSL y 4 lecturas fallidas, todos transitorios y reintentados. No dejaron archivos truncados que se noten por tamaño.
- **Una rareza de origen, resuelta por orden del usuario:** en `ningbo/g13` la cabecera se llamaba `S23074.hea` y apuntaba a `JS23074.mat`; faltaba `S23074.mat`. El servidor publica `S23074.hea` (736 bytes, 2022-07-20) y no existe `JS23074.hea`, así que no era un fallo de descarga. `scan_records` empareja por nombre y lo habría dejado fuera.
  El usuario pidió renombrarla si de verdad apuntaba. Se comprobó antes: las 12 líneas de señal de la cabecera apuntan a `JS23074.mat`, que existe, y ambos archivos coincidían con su hash publicado. **Se renombró `S23074.hea` a `JS23074.hea` el 2026-10-31; el contenido no se tocó** (su hash sigue siendo `00f0317f…` y la primera línea sigue diciendo `S23074`). Es la única diferencia de nombres con el árbol publicado. Tras el cambio, las 10 247 cabeceras de Chapman y las 34 905 de Ningbo tienen su `.mat` con el mismo nombre, así que el escaneo del proyecto no pierde ningún registro por esto.
  Para E6 y para quien reproduzca: la verificación de hashes de ese archivo se hace con el nombre original.
- **SHA-256 (2026-10-31; el usuario dejó `SHA256SUMS.txt` en `dataset2021/physionet.org/files/challenge-2021/1.0.3/`):** el archivo mide 17 305 274 bytes, como anunciaba el servidor, y trae 20 494 líneas de Chapman (2 × 10 247) y 69 810 de Ningbo (2 × 34 905). De los 90 304 archivos `.hea` y `.mat`, **90 303 coinciden** (45 s).
  **Falla `ningbo/g3/JS13118.mat`, y no es un daño de la descarga.** El 2026-10-31 el usuario autorizó volver a bajarlo: el archivo del servidor es idéntico byte a byte al local (hash `bbd5fe83…`; el publicado es `de32699c…`). El servidor sirve hoy un contenido distinto del que lista `SHA256SUMS.txt`. El usuario bajó además por su cuenta `JS13118.hea` y `JS13118.mat` (en `Downloads`, 2026-10-31 10:24): son idénticos byte a byte; el `.hea` coincide con el publicado y el `.mat` no. Son tres descargas independientes (`wget`, `curl` y el navegador) con los mismos bytes.
  La señal no es ruido de bytes: es un ECG de 12 derivaciones con **tres transitorios a fondo de escala**, que el usuario vio también en un visor como tres barras negras. Están a 5.46–5.50, 5.76–5.84 y 6.14–6.23 s, simultáneos en las 12 derivaciones (108 de 5 000 muestras, con valores hasta ±32 700; más de ±30 mV con la ganancia de 1 000/mV). Fuera de ellos la amplitud es normal (desviación típica mediana 447 frente a 188 del vecino `JS13117`) y la señal es suave. Es compatible con un artefacto de registro real o con contenido alterado; no se distingue sin el original. Como el registro dura 10 s y la ventana del proyecto es de 10 s, esos transitorios entrarían a la red.
  **Decidido por el usuario el 2026-10-31: se excluye el registro `JS13118`**, en E5 y en el protocolo (E6), por una regla general y fijada antes: se excluye todo archivo cuyo SHA-256 no coincida con el publicado (hoy, solo este). El criterio no usa la forma de la señal, ni etiquetas ni predicciones; la amplitud solo lo corrobora. El archivo no se borró ni se movió: la exclusión la aplica el constructor (E4) con una lista explícita, para que ningún escaneo de `dataset2021/` lo trate sin avisar. Quedan 45 151 registros: 10 247 de Chapman y 34 904 de Ningbo.
- **Historial de uso de C y D (para E6):** hoy se miró solo la estructura de archivos, los tamaños y las cabeceras (derivaciones, frecuencia, muestras, existencia de la línea `Dx`) y los hashes de los archivos; además se cargó `JS13118.mat` para ver su rango de valores (sin etiquetas ni predicciones). **No se leyeron ni se contaron códigos de diagnóstico.**
- **E1 (2026-10-31)** Se renombró `S23074.hea` a `JS23074.hea` (apuntaba a `JS23074.mat`; contenido intacto) y **se excluye `JS13118`** por la regla «SHA-256 distinto del publicado». Quedan 45 151 registros: 10 247 de Chapman y 34 904 de Ningbo.

### 2026-10-31: E2 y E3 hechas (solo cabeceras y documentación; sin señales ni predicciones)

**E2, auditoría** (`scripts/auditar_externa.py`; salidas en `evidencia/`: `auditoria_externa.csv`, `auditoria_externa_codigos.csv`, `auditoria_externa.json`). Con `JS13118` excluido:

| | Chapman (C) | Ningbo (D) |
|---|---|---|
| Registros | 10 247 | 34 904 |
| Sin ninguna de las 12 clases | 18 | 133 |
| Con más de una clase | 4 367 | 15 470 |
| Códigos distintos / sin clase del proyecto | 54 / 11 | 80 / 19 |

- Todas las cabeceras traen línea `Dx`. Positivos por clase en `auditoria_externa.csv`: `LVH` en Chapman tiene solo 21; el resto de las celdas pasa de 200.
- **Archivos `.mat` idénticos según los hashes publicados:** 87 grupos (174 registros), 71 de ellos entre Chapman y Ningbo y 16 dentro de un mismo origen. Para E5: no cambia la evaluación por origen, pero hay que contarlos, compararlos con los orígenes de 2020 y decidir su tratamiento en el protocolo; contarían doble en cualquier agregado de C y D.
- **Pacientes por ECG:** la página de `ecg-arrhythmia` da 45 152 pacientes y 45 152 ECG, pero no dice de forma explícita que cada paciente aporte uno solo, y los 87 grupos de señales idénticas muestran que una misma señal aparece con nombres distintos. Los IC siguen siendo por registro y se declara la suposición. El artículo de *Scientific Data* no se pudo leer (el sitio redirigió a un inicio de sesión), así que no se usa como respaldo de ninguna celda; conviene que el usuario lo abra y confirme el vocabulario de etiquetas de Chapman.

**E3, cobertura y clases evaluables** (`scripts/cobertura_externa.py`; salidas `cobertura_externa.csv` y `.json`; tabla de la documentación copiada como `ConditionNames_SNOMED-CT_ecg-arrhythmia_v1.0.0.csv`).
- La documentación de la base (Zheng, Guo y Chu 2022, `doi:10.13026/wgex-er52`) trae una tabla de 63 etiquetas que cubre **las 12 clases** del proyecto. Es una tabla de toda la base, no separa Chapman de Ningbo, así que la cobertura es «cubierta» a nivel de base para los dos orígenes. Quedan sin clase del proyecto 11 etiquetas de esa tabla (entre ellas `WPW`, `AVNRT`, `AVRT`, `CCR`, `CR`, `FQRS`, `PWC`, `VPE`, `LVQRSCL` y `LVQRSLL`).
- Etiquetado según la misma página: un médico etiqueta, otro valida y un médico sénior decide los desacuerdos; no nombra un estándar de etiquetado. La página del Challenge 2021 (`doi:10.13026/34va-7q14`) avisa de que la calidad de las etiquetas varía entre bases y no atribuye nada a estas dos.
- **Clases evaluables (regla de E0.4: fuente que la cubre y al menos 50 positivos):** Ningbo, las 12; Chapman, 11, porque `LVH` (21 positivos) queda fuera. El F1 macro titular de Chapman se calcula sobre esas 11 clases.
- Los recuentos de etiquetas por clase se leyeron para fijar esta regla: es información de la partición, aunque no sean predicciones, y va al historial de uso de E6.

### 2026-10-31: E4 escrita y E16 en marcha (por orden del usuario)

**E16 (semillas 105 a 109 de v1 y v2).** Configuraciones y SHA-256 registrados **antes** de entrenar (`protocolo_t19_registro.md`, «Etapa 3 ampliada (E16)») y desviación 5 anotada (`protocolo_t19_desviaciones.md`). Lanzada con `bash tesis/scripts/entrenar_e16.sh` a las 15:44 UTC; las 10 corridas van una tras otra (v1 y luego v2 de cada semilla), unas 8 h en total; se detiene si una falla y no se repite por su resultado. Salidas en `saved/t19/` y `runs/t19/logs_e16/`. Se entrena desde el árbol principal, cuyo código de entrenamiento no cambió desde la etapa 1. Faltan, al terminar: calibración, umbrales, ensembles y la evaluación única en A y B (como la etapa 3), y regenerar el análisis con 10 semillas.

**E4 (constructor de prueba externa).** Escrita en un `git worktree` aparte (`F:\Proyecto_Investigacion_e4`, rama `feat/prueba-externa`) para no tocar el código con que se entrena. `ecg.datasets.build_external_test` y `examples/cinc2020/build_external_test.py` (`--origin`, `--exclude-record`); escribe el HDF5, `<salida>.records.csv` y `<salida>.summary.json`. Mismo escaneo y preprocesamiento que `build_datasets`, sin reparto y sin exigir positivos en todas las clases; las exclusiones se cuentan y un nombre inexistente es un error. 7 pruebas nuevas (`tests/test_external_build.py`, todas pasan); documentación actualizada (`check_docs_commands.py`: 120 comandos, 0 problemas) y `CONSTRAINTS.md` (649 pruebas recolectadas). **Sin commit, sin push y sin PR**: esperan la orden del usuario, y antes de la PR hay que correr la suite completa. Todavía no se construyó ningún HDF5 con datos reales (eso es E5).

### 2026-11-01: E16 entrenada, evaluada y analizada (por orden del usuario)

Las 10 corridas (semillas 105 a 109 de v1 y v2) terminaron sin fallos (9 h 31 min de reloj). Calibración afín, umbrales F1 β = 1, evaluación única en A y B y ensembles con `evaluar_t19.sh 6`; análisis con 10 semillas con `analizar_t19.py --etapa 6` (salidas en `evidencia/t19_etapa6/`, hashes y plan previo en `protocolo_t19_registro.md`; la etapa 3 sigue saliendo idéntica byte a byte). Resultado: en la prueba A el ensemble supera a la mejor receta individual de su semilla en 10 de 10 en F1 macro (p = 0.0020), F1 ponderado, AUROC, AUPRC y Brier; en Georgia (B) solo en AUROC (9 de 10) y AUPRC (10 de 10), no en F1 macro (4 de 10, p = 0.754). Con esto la observación 3 pasa de «5 semillas, p mínimo 0.0625» a una prueba de signos que sí puede ser significativa. **Falta:** regenerar `calcular_t19.py` y el artículo con las cifras de 10 semillas (texto «cinco semillas»), el paquete, y la desviación 5 ya está registrada.

### 2026-11-01: E16 cerrada, con el artículo y el paquete actualizados (por orden del usuario)

`calcular_t19.py` lee ahora la etapa 6 para las semillas (macros nuevas `NSem`, `NSemProt`, `NSemExtra`, `PMinProt`, `PMinSem`; los `Tr*` de 105 a 109 salen de `t19_etapa6/entrenamiento.csv`; las ablaciones siguen en la etapa 3). Se reescribieron las menciones de «cinco semillas» en resumen (español e inglés), métodos (iv, estadística y la declaración de que las semillas 105 a 109 se añadieron después de ver A y B), resultados (texto, Tabla de semillas y ablaciones), discusión (ensemble, ablaciones, limitaciones y desviaciones) y conclusiones. El artículo compila en 16 páginas, sin errores de TeX ni referencias indefinidas, y `verificar_tex.py` da 0 errores. El paquete se rehízo con `armar_paquete_t19.py --rehacer` (etapa 6, `entrenar_e16.sh`, 27 pesos, 82 predicciones, 51 calibraciones, todo registrado); su verificación completa está en el registro. **Lectura honesta:** con 10 semillas el ensemble supera a la mejor receta individual en 10 de 10 en A (F1 macro, p = 0.00195) y no en F1 macro de B (4 de 10); la discusión dice que cinco semillas se añadieron después de ver las pruebas y que la consistencia describe la variabilidad entre entrenamientos, no la generalización. La tesis (`tesis/completa/`) NO se tocó: sigue con cinco semillas.

### 2026-11-01: E4 fusionada (por orden del usuario)

Suite completa en local (Windows, `PYTHONUTF8=1`): 648 pasan y 1 falla (`test_deploy_entrypoint.py::test_launcher_rejects_conflicting_or_impossible_options`), que falla igual en `main` sin el cambio (decodificación de la salida del lanzador en Windows); sin `PYTHONUTF8=1` también fallan varias de `test_cli_smoke.py::test_cli_help` por lo mismo. PR #37 abierta, CI (`pytest`, Linux) en verde en 6 min 41 s, fusionada con commit de fusión b468599; rama remota y local y el worktree `Proyecto_Investigacion_e4` borrados; `main` actualizado. **Siguiente: E5** (construir `test_c.h5` y `test_d.h5` con `--exclude-record JS13118`, duplicados contra entrenamiento, validación, A y B, y SHA-256 en `reparto_externo.json`); antes hay que decidir qué hacer con los 87 grupos de `.mat` idénticos, y luego E6 (protocolo con hash, que el usuario revisa) antes de cualquier predicción.

### 2026-11-01: E5 hecha y E6 escrita y sellada (por orden del usuario); PR #38 fusionada

PR #38 (descarga y verificación de Challenge 2021) fusionada (`fcf6f45`). **E5:** 87 grupos de señal idéntica (ninguno coincide con el Challenge 2020), un registro por grupo según la regla del usuario; 88 exclusiones con `JS13118`; `test_c.h5` con 10 234 registros y `test_d.h5` con 34 830; el constructor reproduce `test_b.h5` de Georgia; manifiesto `reparto_externo.json`. **Hallazgo:** en 26 de los 87 grupos las etiquetas difieren en las 12 clases; se mantiene la regla y se registra un análisis de sensibilidad. **E6:** `protocolo_externo_t19.md` sellado (SHA-256 `52b70fbd…`), con 37 sistemas, titular F1 macro de P3 por origen (C 11 clases, D 12), análisis exploratorios fijados de antemano y el historial de uso de C y D; registro en `protocolo_externo_t19_registro.md`. **Siguiente, solo con la orden y la revisión del usuario:** analizar y probar `analizar_t19.py --etapa 7` con datos sintéticos, añadir la etapa 7 a `evaluar_t19.sh` y ejecutar la evaluación única (E7). La etapa 6 de los scripts quedó ocupada por las 10 semillas, así que la evaluación externa es la etapa 7.

### 2026-11-01: E7 y E8 hechas (evaluación única y análisis de la etapa 7)

Protocolo aprobado por el usuario. 37 sistemas evaluados una sola vez en C (10 234 registros) y en D (34 830); la laptop se apagó con 34 de 37 completos y se reanudaron P1t, P2t y P3t (registrado). Análisis en `evidencia/t19_etapa7/`. **Resultado titular, P3, F1 macro sobre las clases evaluables:** C 0.491 (0.482 a 0.499), D 0.462 (0.457 a 0.467); AUROC macro 0.862 y 0.859. Cae unos 0.27 a 0.29 de F1 respecto de A y 0.03 a 0.04 respecto de B. **La mejora del ensemble sobre la mejor receta individual (10 de 10 en A) no se reproduce:** en C es peor en F1 macro (1 de 10, p = 0.021) y en D empata (5 de 10). Mejor F1 en C y D: las variantes con pérdida enmascarada (P3m 0.536 y 0.514). `SB` y `STach` tienen AUROC 0.97 a 0.99 pero sensibilidad 0.46 a 0.54: el umbral de validación deja falsos negativos. Detalle en `protocolo_externo_t19_registro.md`. **Siguiente, solo con orden:** E9 (cifras `calcular_t19.py` y figuras), E10 (artículo, con C y D como resultados primarios), E11 (paquete); y E13 (recalibración local, exploratoria, desviación 6), que es lo que podría subir el F1 y bajar FN y FP.

### 2026-11-01: E13 hecha (recalibración local, exploratoria, desviación 6)

Diseño sellado antes de ejecutar (`protocolo_externo_t19_desviaciones.md`, ítem 6). *Cross-fit* de dos mitades sobre las probabilidades finales de los 10 sistemas originales (solo CPU, 10 min). **P3, F1 macro: C 0.491 → 0.567 (umbrales) y 0.569 (calibración y umbrales); D 0.462 → 0.545 y 0.544**; los falsos negativos por 1 000 registros bajan de 758 a 385 (C) y de 836 a 401 (D) y los falsos positivos suben de 500 a 899 y de 518 a 1 019. `SB` pasa de F1 0.63 a 0.90 o 0.93 y `STach` de 0.65 a 0.83. Con 300 a 1 000 registros locales se recupera casi todo. El AUROC no cambia (0.86 frente a 0.96 en A): los umbrales no cierran la brecha, hace falta mejorar el modelo. No cambia el titular. Detalle en `protocolo_externo_t19_registro.md`.

### 2026-11-01: E9 y E10 hechas (cifras, figura y artículo con C y D como evaluación primaria)

**E9:** `calcular_t19.py` lee la etapa 7 y E13 y genera los identificadores de C y D (prefijos `X`, `RL`): 28 494 cifras, con 15 648 nuevas y ninguna de las anteriores cambiada; `hacer_figuras.py` añade `fig_externa` (F1 y sensibilidad por clase del ensemble, congelado frente a umbrales locales). **E10:** nuevas referencias verificadas en doi.org (`Zheng2020database`, `Zheng2022physionet`, `Reyna2022challenge`, `Reyna2021will`); en Métodos, la subsección «Evaluación Externa» con su tabla y el protocolo externo, y el análisis de recalibración local; en Resultados, tres bloques nuevos (evaluación externa con las Tablas VI y VII, recalibración local exploratoria con la Tabla VIII y la Fig. 2, y semillas en C y D) y A y B pasan a «Desarrollo»; Discusión, Resumen (español e inglés), Conclusiones, Introducción y Declaraciones reescritos para titular C y D como evaluación primaria, con la limitación de que el ensemble no se sostiene fuera de A y la distinción entre lo confirmatorio y lo exploratorio. Verificación: 20 de 20 páginas, `verificar_tex.py` 0 errores, `auditar_citas.py` OK, 0 desbordes mayores de 10 pt. **Falta:** el paquete (E11) y la tesis, que sigue con cinco semillas y sin C y D.
