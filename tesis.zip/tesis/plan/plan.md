# Plan: atender las revisiones externas del artículo IEEE

> **Nota (2026-11-01): reorganización de carpetas.** `tesis/ieee/` pasó a ser `tesis/` (la tesis completa y el artículo anterior se borraron por
> redundantes) y las rutas de este documento ya están corregidas. `hacer_docx.py`, `ajustar_flotantes.py`, `word_a_pdf.ps1`, `calcular_extra.py` y
> `manifiesto.py` están en `tesis/obsoleto/`: lo que se diga aquí de ellos es historial. Mapa vigente: `tesis/CONTEXT.md`.

> ## Cambio del 2026-10-26 (decisión del usuario): se retira la evaluación externa con el Challenge 2021
>
> La descarga desde PhysioNet va a 10 KB/s o menos y tardaría demasiado, y el usuario pidió no usar **nada** del Challenge 2021. Quedan **anuladas**
> la decisión D1 y las tareas T9 (protocolo externo), T10 (descarga) y T11 (evaluación única); también se retiró de la tabla de cobertura (T8) lo
> que se había añadido de Chapman-Shaoxing y Ningbo. Lo que sigue de esas secciones es historial y **no está vigente**.
> Consecuencias: (1) la prueba interna sigue siendo exploratoria y las observaciones 1 y 2 del asesor no tienen todavía una respuesta confirmatoria;
> (2) la CNN convencional y la ResNet reentrenada con todos los cambios se hacen **al final**, juntas, y no entran en ningún protocolo previo;
> (3) las alternativas para obtener independencia sin el Challenge 2021 están en la sección «Alternativas» de este archivo y esperan decisión.
>
> ## Reabierto el 2026-10-30: plan nuevo para Chapman-Shaoxing y Ningbo
>
> El usuario planea usar Chapman-Shaoxing y Ningbo. El plan vigente para ello es [`plan_externa.md`](plan_externa.md) (tareas E0 a E15, cada una ligada a la observación que sirve; lista en `todo.md`, Fase 7); sustituye a T9, T10 y T11. Cierra la Obs. 2, refuerza la 1 y la 4, cierra la 3 con 10 semillas y deja la 6 y la 17 con reserva (código en GitHub, sin DOI); protege la 7.
> **Decidido el 2026-10-30 (usuario): se levanta la prohibición de usar datos del Challenge 2021 solo para `chapman_shaoxing` y `ningbo`** (E0.1). No se levanta la regla de no calcular su métrica ni comparar con sus resultados.
> **Estado (2026-11-01): el plan se ejecutó hasta E14; E15 (archivo con DOI) se canceló y el código se declara solo con GitHub.** Resultados primarios = C y D (E0.7); 10 semillas (E0.8); el paquete completo queda en local (E0.9).


Estado: **solo planificación, nada implementado** (2026-10-22; revisado con las observaciones del asesor el mismo día).
Se trabaja en LaTeX y PDF; el Word ya no se mantiene.
Ubicación: esta carpeta está excluida de git (`/tesis/` en `.git/info/exclude`). El plan **no** va en `tasks/` porque esa carpeta
es versionada y su `plan.md`/`todo.md` pertenecen a otro trabajo (la demo), con tareas abiertas que no se deben tocar.

## Resumen

Dos revisiones externas coinciden en cinco obstáculos. Tres no se arreglan con redacción:

1. **La prueba influyó en el diseño** (receta v2, calibración afín, punto F1 y ensemble se compararon en prueba). Volver a evaluar
   con la misma partición no corrige el sesgo de selección: hace falta **datos que no hayan intervenido**.
2. **Solape de pacientes** (al menos 11.5 % de la prueba) y generalización entre instituciones sin medir.
3. **Clases no anotadas tratadas como negativas** (10 celdas origen-clase), sin cobertura documentada por origen.
4. **Una corrida por receta** → semillas múltiples (**aplazado por decisión del usuario**).
5. **Comparación débil**: falta una CNN 1D convencional y ablaciones controladas; y la Tabla VI mezcla puntos retrospectivos con umbrales de uso.

Idea central: una **evaluación confirmatoria externa con el sistema congelado** resuelve (1) y (2) a la vez y no exige reentrenar.

**Fuente de datos externa (comprobado en las fichas de PhysioNet el 2026-10-22):**
- Usar el **Challenge 2021, v1.0.3, carpetas de entrenamiento `chapman_shaoxing` (10 247 registros) y `ningbo` (34 905)**. La procedencia
  de cada registro es su carpeta, no un campo de la cabecera. Licencia **CC BY 4.0**. 500 Hz, 10 s, códigos SNOMED-CT. No están en los
  6 orígenes de 2020. (La página del proyecto da el nombre en prosa con guion; confirmar el nombre exacto de la carpeta al descargar.)
- **No** usar `ecg-arrhythmia` v1.0.0 como fuente: es la misma colección (45 152 ECG, 5.1 GB sin comprimir, 2.3 GB en zip, CC BY 4.0), pero
  su ficha **no indica la procedencia por registro**, así que no permite separar Chapman-Shaoxing de Ningbo. Que 10 247 + 34 905 = 45 152
  sugiere que son los mismos archivos; **no está verificado** (T10 lo comprueba con los SHA-256 de ambos proyectos).
- Ninguna ficha indica identificador de paciente. Los 45 152 ECG coinciden con 45 152 pacientes en `ecg-arrhythmia`, lo que sugiere un
  ECG por paciente, pero **no se afirma**: el intervalo de confianza se calcula por registro y se declara esa suposición.

## Decisiones de diseño y por qué

- **Independencia = datos nuevos, evaluados una sola vez.** Se preespecifica el protocolo y se guarda su hash **antes** de calificar. Se
  reporta el resultado aunque sea peor. Es la única forma de decir «confirmatorio».
- **Todo lo que se quiera llamar confirmatorio se congela antes de mirar los datos externos**: el modelo, el tratamiento de etiquetas
  desconocidas, la CNN de referencia y, si se quiere, el sistema enmascarado. Lo que se entrene o se decida después de ver el
  resultado externo es **exploratorio**, salvo que haya otra prueba independiente.
- **T6 es una auditoría interna, no una validación independiente.** Los pesos ya se seleccionaron con la validación (mejor época por
  pérdida o F1), así que partirla en pliegues no estima el rendimiento del procedimiento completo. La versión rigurosa (reentrenar dentro
  de cada pliegue) cuesta demasiado; se recomienda la económica, dejando claro lo que no demuestra.
- **Semillas al final.** Deben correr sobre la configuración definitiva; si antes cambia el entrenamiento, se repetirían.
- **Reparto agrupado por paciente: solo como análisis secundario.** Solo PTB-XL (`patient_id`; `strat_fold` ya separa pacientes) y PTB
  traen identificador. Excluir los 738 registros solapados **no convierte** la prueba interna en independiente: sigue siendo exploratoria.
- **Cambios en `ecg/` y `examples/` son versionados:** PR con la suite en verde (`CONSTRAINTS.md`), sin mencionar el artículo; los
  comandos nuevos en `.md` pasan `tools/check_docs_commands.py`. El resto (texto, evidencias, scripts de `tesis/`) queda local.
- **Cifras sin escribir a mano:** todo número nuevo entra por `scripts/calcular_extra.py`, regenerado desde predicciones y bootstrap
  (nunca agregando ceros a cifras ya redondeadas), y se comprueba con `verificar_tex.py`.

## Grafo de dependencias

```
T1 manifiesto ───────────────┐
T8 cobertura de etiquetas ───┼─> T9 protocolo (congela todo) ─> T13 CNN 1D ─┐
                             │                                              ├─> T11 evaluación única ──┐
                             └─> T10 datos externos auditados ───────────────┘                          │
T6 auditoría interna ─────────────────────────────────────────────────────────────────────────────────┤
T7 prueba sin solape ─────────────────────────────────────────────────────────────────────────────────┼─> T16 integración
T2 T3 T4 T5 (texto/forma) ────────────────────────────────────────────────────────────────────────────┤
T8 ─> T12 enmascarado (secundario) ─> T14 ablaciones ─> T15 semillas (aplazado) ──────────────────────┘
```

## Fase 0: forma y trazabilidad (sin cómputo)

### T1. Manifiesto de reproducibilidad (S)
**Descripción:** registrar con qué versión exacta se produjeron las tablas: commit evaluado y su diferencia con `main`
(`21afdb7..HEAD` solo toca documentación), SHA-256 de `predictions_test.csv` de cada sistema, `split_assignments.csv`,
`models/*.pt`, umbrales y calibración, versiones de Python/torch/sklearn, semillas y el comando que regenera cada tabla y figura.
**Aceptación:** `evidencia/manifiesto.json` y `.md` generados por un script; Declaraciones cita el manifiesto; cualquier hash se
recomprueba con un comando.
**Verificación:** `python tesis/scripts/manifiesto.py --verificar` sin diferencias; `verificar_tex.py` en 0 errores.
**Dependencias:** ninguna. **Archivos:** `scripts/manifiesto.py` (nuevo), `evidencia/manifiesto.*`, `capitulos/06_declaraciones.tex`.

### T2. Evidencia del enlace de Hannun (XS)
**Descripción:** guardar la prueba de que el conjunto de prueba de iRhythm ya no está: respuesta HTTP con fecha UTC y la consulta a la API
de disponibilidad de Wayback Machine (si hay captura, citarla).
**Aceptación:** `evidencia/hannun_enlace/` con la salida cruda y la fecha; la referencia [5] coincide con ella.
**Verificación:** releer los archivos y compararlos con [5]. **Dependencias:** ninguna. **Archivos:** evidencia, `references_extra.bib`.

### T3. Separar puntos retrospectivos de umbrales de uso (S)
**Descripción:** en la Tabla VI y su texto dejar claro que son puntos de la curva ROC de prueba (descripción), no una configuración
validada; añadir, con los umbrales fijados en validación, la sensibilidad y especificidad macro que se obtienen en prueba.
**Aceptación:** pie y texto distinguen ambos tipos; cifras nuevas salen de `calcular_extra.py`; la Discusión no sugiere despliegue con
esos puntos. **Verificación:** `calcular_extra.py` + `verificar_tex.py` + `compilar.sh`. **Dependencias:** ninguna.
**Archivos:** `03_resultados.tex`, `calcular_extra.py`.

### T4. Precisión numérica del F1 macro y su IC (S) — **decisión D4**
**Descripción:** el IC «0.75 a 0.76» sugiere falsa precisión. Tres decimales solo en el F1 macro principal y su IC (Resumen, Abstract,
Tabla V, IV-A), **regenerados desde las predicciones y el bootstrap**.
**Aceptación:** regla única documentada; los demás valores siguen a dos decimales. El skill de revisión exige dos decimales siempre; se
aplica lo que el usuario decida. **Verificación:** `verificar_tex.py`, lectura del PDF. **Dependencias:** D4.
**Archivos:** `calcular_extra.py` (nuevos ids), `00_resumen.tex`, `03_resultados.tex`.

### T5. Legibilidad al tamaño real (S)
**Descripción:** renderizar a 100 % y revisar las Tablas I, V y IX (pie `\footnotesize`, columnas `p{}`).
**Aceptación:** texto de tablas ≥ 7 pt efectivos, sin cortes ni desbordes; el artículo sigue ≤ 20 páginas.
**Verificación:** `compilar.sh` (0 Overfull > 10 pt) y revisión visual. **Dependencias:** ninguna. **Archivos:** `02_metodos.tex`, `03_resultados.tex`.

### Punto de control 0
- [ ] `verificar_tex.py` en 0 errores y `compilar.sh` ≤ 20 páginas
- [ ] Tablas I, V y IX legibles a tamaño real; el usuario confirma D4 y el texto de la Tabla VI

## Fase 1: auditoría interna con los datos que ya existen (sin reentrenar)

### T6. Auditoría de calibración y umbrales con modelos congelados (M)
**Descripción:** con `predictions_validation.csv`, validación cruzada de 5 pliegues **solo de la calibración y los umbrales** (ajustarlos
en 4 pliegues, evaluarlos en el quinto) para v1, v2 y ensemble. Los modelos quedan congelados: **no** estima el rendimiento del
procedimiento completo ni es una evaluación independiente, porque la validación ya eligió los pesos (mejor época). Tampoco sirve para
decidir qué sistema es mejor: v2 y el ensemble parten con ventaja en validación.
**Aceptación:** cifras o frase que muestran cuánto cambian la calibración y los umbrales fuera de muestra; el texto dice expresamente que
es una auditoría y lo que no demuestra. **Verificación:** `calcular_extra.py` reproduce las cifras con semilla fija.
**Dependencias:** ninguna. **Archivos:** `scripts/auditoria_calibracion.py` (nuevo), `03_resultados.tex`, `04_discusion.tex`.
*Opción rigurosa (descartada por costo):* repetir entrenamiento, selección de época, calibración y umbrales dentro de cada pliegue.

### T7. Prueba sin solape identificable (M) — descriptivo
**Descripción:** F1 y AUROC macro con IC en la prueba **sin** los 738 registros que comparten paciente, y aparte solo con los
registros identificables sin solape. **Ampliado (Obs. 7):** también sin los 24 registros sin clase (F1 micro, coincidencia exacta y
falsos positivos que generan), para separar el error del modelo de la ausencia de anotación. Hoy solo hay F1 con/sin solape por origen (PTB-XL, PTB) y un JSON agregado.
**Aceptación:** dos cifras nuevas con IC y su diferencia con la prueba completa; se aclara que es un análisis de sensibilidad (la prueba
sigue siendo exploratoria) y que los otros cuatro orígenes siguen sin identificador.
**Verificación:** el recuento de excluidos coincide con 738 (`solape_pacientes.json`); `calcular_extra.py` + verificador.
**Dependencias:** ninguna. **Archivos:** `scripts/` (listado por registro a partir de `tools/check_patient_overlap.py`), `03_resultados.tex`.

### T8. Cobertura de etiquetas por origen, documentada (M)
**Descripción:** tabla origen × clase (CPSC 2018, CPSC-Extra, INCART, PTB, PTB-XL, Georgia, Chapman-Shaoxing, Ningbo): «anotada», «no
anotada» o «sin documentar», con la cita de la fuente primaria; compararla con la inferida (≥ 1 positivo en entrenamiento). Define,
antes de evaluar, qué clases son evaluables en cada fuente y cómo se tratan las desconocidas (no cuentan como negativas).
**Aceptación:** `evidencia/cobertura_etiquetas.csv` con una cita por celda y una columna «documentada/inferida»; discrepancias listadas.
**Verificación:** cada cita se abre y respalda la celda; las 10 celdas inferidas hoy aparecen contrastadas. **Dependencias:** ninguna
(base de T9, T10 y T12). **Archivos:** evidencia, `references_extra.bib`, `02_metodos.tex`.

### Punto de control 1
- [ ] Toda cifra del artículo se regenera con scripts versionados; las diferencias con las cifras anteriores están explicadas
- [ ] Limitaciones de los análisis internos explícitas en el texto; revisión con el usuario antes de descargar datos externos

## Fase 2: evaluación confirmatoria externa (sin ajustar nada con ella)

### T9. Protocolo que congela el experimento completo (S)
**Descripción:** documento fechado, con SHA-256, escrito **antes** de calificar. Fija:

| Elemento | Qué queda fijado |
|---|---|
| Modelos | hash de los pesos y de la configuración del ensemble; la CNN de referencia (T13) y, si se quiere, el sistema enmascarado (T12) |
| Preprocesamiento | orden de derivaciones, unidades, remuestreo, filtro, ventana |
| Etiquetas | correspondencia SNOMED-CT → clase y tratamiento de las desconocidas (según T8) |
| Calibración y umbrales | parámetros por clase ya ajustados con validación |
| Métrica principal | F1 macro sobre las clases evaluables y su IC del 95 % por bootstrap |
| Secundarias | AUROC, AUPRC, Brier, ECE, y resultados por procedencia (Chapman-Shaoxing y Ningbo por separado y agregados); con y sin máscara |
| Exclusiones | registros inválidos, duplicados y etiquetas no evaluables |
| Reglas | una sola evaluación; se reporta el resultado sea cual sea; ningún ajuste posterior |

**Aceptación:** `evidencia/protocolo_externo.md` con hash y fecha registrados; ninguna cifra externa calculada aún.
**Verificación:** el hash guardado coincide con el archivo. **Dependencias:** T1, T8, decisiones D1, D2 y D6. **Archivos:** `evidencia/protocolo_externo.md`.

### T13. CNN 1D convencional como referencia (M, ≈ 0.5 h de GPU) — **antes de T11**
**Descripción:** `config_regular_cnn.json` ya existe y no hay modelo entrenado. Entrenar, calibrar (afín) y evaluar con el mismo β y la
misma calibración, **congelada en T9** para que entre en la evaluación externa como comparación confirmatoria. Si se entrenara
después de ver el resultado externo, su comparación sería exploratoria.
**Aceptación:** una fila nueva en la Tabla VII, su diferencia pareada con v1 y con el ensemble, y sus parámetros y tiempo de entrenamiento
junto a los de v1 y v2 (equivalencia de carga de trabajo, Obs. 4). **Verificación:** `compare_models.py`
acepta la comparación (exige mismo β y calibración). **Dependencias:** T9. **Archivos:** configs, `03_resultados.tex`.

### T10. Fuente exacta, descarga y auditoría del conjunto externo (M)
**Descripción:** bajar del Challenge 2021 v1.0.3 solo `training/chapman_shaoxing` y `training/ningbo`; comprobar con `SHA256SUMS.txt` que
coinciden con `ecg-arrhythmia` 1.0.0 (por si se quiere citar esa ficha); construir un HDF5 de solo prueba por procedencia con el esquema
actual (`infer_source_db` toma el nombre de carpeta); auditar códigos SNOMED sin clase, duplicados exactos y similares frente a
entrenamiento, validación y prueba, y si hay varios ECG por paciente (hoy no consta; si los hay, IC por clúster).
**Aceptación:** HDF5 en `data/` (ignorado por git), uno por procedencia; CSV de auditoría de códigos; recuento de duplicados y exclusiones
según las reglas de T9; licencia CC BY 4.0 citada. **Verificación:** nº de registros por carpeta = 10 247 y 34 905; ningún registro
sin cabecera. **Dependencias:** T9. **No** se mira ninguna predicción en esta tarea.
**Archivos:** `ecg/load.py` o `tools/` (solo si falta la opción de «solo prueba»), `tests/`.

### T11. Evaluación única con el sistema congelado (M)
**Descripción:** inferir con el ensemble afín (y la CNN de T13) con los umbrales de validación **sin tocar nada**, calcular las métricas
del protocolo por procedencia y agregadas, y guardar las predicciones por registro, la fecha y el hash de la salida.
**Aceptación:** una sola ejecución registrada; resultados reportados aunque sean peores; el archivo de predicciones queda conservado.
**Verificación:** repetir la inferencia da las mismas predicciones (bit a bit en CPU). **Dependencias:** T9, T10, T13.
**Archivos:** `examples/cinc2020/` (evaluación con `--test-h5` si no existe), `evidencia/`. La integración en el texto es T16.

### Punto de control 2
- [ ] Informe externo generado con pesos, calibración, umbrales y protocolo congelados; exclusiones aplicadas según reglas previas
- [ ] Predicciones por registro conservadas; el usuario revisa el resultado **antes** de decidir la Fase 3
- [ ] Criterio científico: el resultado **no** necesita alcanzar un F1 mínimo para ser válido; no se cambia el procedimiento tras verlo

## Fase 3: etiquetas desconocidas y análisis secundarios (reentrena; decisión D2)

*No se reutiliza la evaluación externa para elegir entre este sistema y el original, salvo que ambos estuvieran en el protocolo de T9.*

### T12a. Pérdida enmascarada (M)
**Descripción:** opción `mask_unannotated` que excluye de la pérdida las celdas origen-clase no anotadas (según T8) y recalcula
`pos_weight` solo con celdas anotadas. Requiere el identificador de origen en el dataset HDF5.
**Aceptación:** con el flag apagado, el resultado numérico es idéntico al actual; encendido, las celdas no anotadas no aportan gradiente.
**Verificación:** `tests/test_masked_loss.py` (nuevo) y `python -m pytest -q`. **Dependencias:** T8. **Archivos:** `ecg/train.py`,
`ecg/hdf5_dataset.py`, `ecg/datasets.py`, `tests/`, documentación del flag.

### T12b. Entrenar y evaluar enmascarado (M, GPU ≈ 3 h)
v1m y v2m con la misma partición y semillas que v1/v2; calibrar y evaluar de forma pareada. **Secundario y exploratorio** respecto de la
evaluación externa, salvo que se incluyera en T9. Si se adopta, regenerar `models/` y `deploy/` (regla del proyecto).
**Dependencias:** T12a, T11. **Aceptación:** tabla pareada enmascarado vs no enmascarado con diferencia e IC.

### T12c. Texto de Métodos y Limitaciones (S). **Dependencias:** T12b.

## Fase 4: ablaciones (reentrena; decisión D6)

### T14. Ablaciones dirigidas (M, GPU ≈ 4–6 h)
**Descripción:** partiendo de v1, quitar o añadir de uno en uno los componentes principales de v2: **aumentación, suavizado de etiquetas y
selección por F1**; la regularización solo si hay presupuesto. Una sola ejecución por variante: son **exploratorias y no miden la
variabilidad entre entrenamientos** (cuatro configuraciones no son cuatro semillas).
**Aceptación:** tabla de ablación con diferencias pareadas e IC de remuestreo y esa advertencia en el texto.
**Dependencias:** T13, T11 (no se usa la prueba externa para elegir configuraciones).

## Fase 5: aplazado por el usuario

### T15. Semillas múltiples sobre la configuración final (L, ≈ 10 h o más)
4 semillas por receta (y por variante adoptada), media y desviación entre corridas, comparación del ensemble frente a la mejor receta.
**Se hace al final**, cuando T12–T14 hayan fijado la configuración. Mientras tanto la ausencia de semillas se declara como limitación.

## Fase 6: integración

### T16. Integración final en el artículo (M)
Resumen, Introducción, Métodos, Resultados, Discusión y Conclusiones coherentes con lo medido; lenguaje «confirmatorio» solo donde
corresponda (evaluación externa congelada) y «exploratorio» en todo lo demás; presupuesto de páginas (hoy 12 de 20; la evaluación
externa, la fila de la CNN y la tabla de ablación suman ≈ 1.5 págs). La limitación «validación solo interna» se reescribe con lo medido.
**Aceptación:** `verificar_tex.py` en 0 errores, `compilar.sh` ≤ 20 págs, revisión con `manuscript-review` y aprobación del usuario.

### Punto de control final
- [ ] Comprobaciones técnicas superadas; manuscrito, código y resultados coinciden
- [ ] Ningún resultado exploratorio presentado como confirmatorio; semillas y ablaciones exhaustivas, si faltan, declaradas como limitación

## Segunda revisión del asesor (18 observaciones, 2026-10-23): clasificación

Contrastada con el texto y el código actuales. Estado: ✔ ya cubierta por el plan · ＋ nueva tarea o ampliación · ✖ no aplica al PDF actual · ⚠ decisión.

| Obs. | Resumen | Estado | Dónde |
|---|---|---|---|
| 1 | Reparto disjunto por paciente y rehacer todo | ⚠ choca con D3; solo PTB-XL y PTB tienen identificador | decisión D3 reabierta (abajo) |
| 2 | Partición confirmatoria nunca usada | ✔ | T9–T11 (evaluación externa) |
| 3 | Una corrida por receta | ✔ aplazado | T15 |
| 4 | Líneas base y comparación con el estado de la técnica | ＋ parcial; ⚠ regla del proyecto | T13/T14 amplían; comparación con resultados del Challenge: decisión D8 |
| 5 | La Ec. (3) usa log en vez de logit | ✖ el texto ya dice `logit` y el código promedia probabilidades calibradas y luego aplica la afín sobre su logit; aun así se aclara en el texto | T18 |
| 6 | Reproducibilidad parcial (DOI, entorno, reparto, semillas, predicciones, script) | ＋ | T1 (hecha) + T17 |
| 7 | Registros sin clase y auditoría de etiquetas | ＋ | T7 (métricas sin esos registros) + T8 |
| 8 | Definir $w_c$ | ＋ (en el código: negativos/positivos de entrenamiento) | T18 |
| 9 | Formato de la Tabla III | ＋ | T18 |
| 10 | Fig. 3: «AEct-J» y recuentos de fila | ✖ parcial: el pie ya define AEct-J; faltan los recuentos | T18 |
| 11 | «S.Tach» y «convulsión» | ✖ no aparecen en el texto ni en las figuras actuales | T18 (barrido de comprobación) |
| 12 | Unidades e incertidumbre en la Tabla X | ＋ | T18 |
| 13 | Fig. 6 ausente | ✖ está en el PDF actual (Apéndice A) | T18 (comprobar) |
| 14 | IC de AUROC, AUPRC y coincidencia exacta | ＋ | T18 (bootstrap en `calcular_extra.py`) |
| 15 | Definir «coincidencia exacta» | ＋ (hoy se llama *exact-match*) | T18 |
| 16 | Orden de cita de tablas y figuras | ＋ auditoría y arreglo | T18 |
| 17 | DOI y licencia archivados | ＋ la licencia consta; sin DOI (se descartó el archivo, 2026-11-01) | T17 |
| 18 | Legibilidad de la Tabla I | ✔ revisada a tamaño real (T5); se puede mejorar la alineación | T18 |

**D3 reabierta (Obs. 1).** La observación pide un reparto disjunto por paciente y rehacer los resultados primarios. Solo PTB-XL
(`patient_id`, `strat_fold`) y PTB permiten agrupar; en los otros cuatro orígenes el solape sigue sin medirse, de modo que el reparto
quedaría disjunto solo en parte. Opciones: **(a)** mantener la decisión (omitir) y apoyar la afirmación en la evaluación externa y en T7;
**(b)** reparto agrupado para PTB-XL y PTB y reentrenar v1 y v2 (≈ 2.5 h de GPU más código de partición), con todas las cifras nuevas.
Recomendación: (a), porque la evaluación externa es más fuerte y (b) deja cuatro orígenes sin cubrir; decide el usuario.

**D8 (nueva) — comparación con el Challenge 2020.** La Obs. 4 pide comparaciones «compatibles con Challenge 2020». La regla del proyecto
es no calcular su métrica ni comparar con sus resultados. Se mantiene la regla: las líneas base serán modelos entrenados
con la misma partición, métricas y protocolo (CNN 1D, T13, y ablaciones, T14), con parámetros y tiempo de entrenamiento en la tabla para
documentar la carga de trabajo. Si el usuario levanta la regla, se añade una tarea aparte.

### T17. Paquete de reproducibilidad archivable (M) — decisión D5, acción del usuario al final
**Descripción:** reunir lo que falta para regenerar los resultados: manifiesto de partición (`split_assignments.csv`, hoy en `data/`, ignorado
por git), predicciones por registro de los sistemas evaluados, semillas de aumentación (`aug_seed`), archivo de entorno (`constraints.txt` ya
fija las versiones), script que regenera las métricas y el manifiesto de T1; licencia explícita.
**Aceptación:** una carpeta o lanzamiento con esos archivos y un `LEEME` con los comandos; el script reproduce las cifras principales.
**Archivar con DOI se descartó el 2026-11-01** (la subida fallaba); el código se declara con la URL de GitHub. Antes se pensó citar el DOI en lugar de la rama y el commit.
**Dependencias:** T1, T11 (para incluir las predicciones externas).

### T18. Correcciones de manuscrito de la segunda revisión (M)
**Descripción:** Obs. 5, 8–16 y 18. Aclarar en la Ec. (3) que se promedian probabilidades calibradas y luego se aplica la afín al logit del
promedio; definir $w_c = N^-_c/N^+_c$ (negativos entre positivos de entrenamiento); alinear la Tabla III; añadir los recuentos de fila a la
Fig. 3; unidades (mV, ×, n) y nota de «un solo sorteo» en la Tabla X; IC de AUROC, AUPRC y coincidencia exacta en la Tabla VII;
«coincidencia exacta» definida en Métodos y usada en todo el texto; auditar que cada tabla y figura se cite antes de aparecer; barrido de
«S.Tach»/«convulsión»; confirmar la Fig. 6; mejorar la alineación de la Tabla I.
**Aceptación:** cada observación con su comprobación (las que no aplican, anotadas); `verificar_tex.py` en 0 errores; ≤ 20 págs.
**Dependencias:** ninguna (se puede hacer antes de T11). **Archivos:** `02_metodos.tex`, `03_resultados.tex`, `calcular_extra.py`, `hacer_figuras.py`.

## Alternativas para la independencia sin el Challenge 2021 (esperan decisión del usuario)

| Opción | Qué da | Costo | Límite |
|---|---|---|---|
| **A. Mantener exploratorio** y declararlo (ya está en Resumen, Limitaciones y Conclusiones) | honestidad completa | ninguno | las observaciones 1 y 2 quedan sin cerrar |
| **B. Dejar fuera un origen completo** de los seis de 2020 (p. ej. Georgia, 10 344 registros, de EE. UU.) al reentrenar al final: entrenar con cinco y evaluar en el sexto, con el protocolo escrito y hasheado **antes** | generalización entre instituciones medida | reentrenar (GPU), que de todos modos se hará al final | las decisiones de diseño ya se vieron con la prueba actual, que incluía parte de ese origen: independencia parcial |
| **C. Reparto agrupado por paciente** para PTB-XL (`strat_fold`) y PTB al reentrenar al final | reduce el solape medible (observación 1) | reentrenar (GPU) | cuatro orígenes siguen sin identificador |
| **D. Otro conjunto público ajeno al Challenge 2021** | datos nuevos | descarga y mapeo de etiquetas | no hay candidato claro; no se propone ninguno sin tu visto bueno |

**Decisión del usuario (2026-10-26): A ahora; B y C en el reentrenamiento final.**

### T19. Reentrenamiento final con todos los cambios (L, GPU; al final de todo)
Un solo ciclo de GPU que reúne lo que quedó pendiente: reparto nuevo (B y C), pérdida enmascarada (T12), CNN convencional (T13), ablaciones
(T14) y semillas (T15). Sustituye a las fases 2–5 anteriores.
- **Reparto nuevo:** Georgia completa queda fuera como **prueba B** (entrenar con cinco orígenes, evaluar en el sexto); en PTB-XL (`strat_fold`) y PTB el
  reparto se agrupa por paciente; CPSC, CPSC-Extra e INCART siguen por registro (sin identificador). La **prueba A** es la partición de prueba de los
  cinco orígenes. Se publica el manifiesto del reparto.
- **Protocolo antes de entrenar:** se escribe, se fecha y se calcula su hash **antes** de mirar la prueba A o la B: sistemas (recetas v1 y v2 sin cambios,
  ensemble afín, β = 1 como principal; enmascarado, CNN y ablaciones como secundarios), métricas, exclusiones y número de semillas. Una sola evaluación
  de cada sistema en A y en B; lo que se pruebe después es exploratorio.
- **Límite que debe declararse:** las recetas, la calibración y el punto de operación se eligieron mirando la prueba anterior, que incluía parte de
  Georgia; la prueba B es independiente solo en parte y la A no lo es en cuanto al diseño.
- **Subtareas:** (a) código y pruebas: reparto agrupado y por origen, pérdida enmascarada con `mask_unannotated` (cambios en `ecg/`, PR con la suite en verde,
  sin mencionar el artículo); (b) protocolo hasheado; (c) entrenamientos; (d) evaluación única y paquete de reproducibilidad (T17); (e) integración en el texto (T16).
- **Costo orientativo de GPU:** una pasada de v1 + v2 + CNN ≈ 3.5 h (v1 ≈ 30 min, v2 ≈ 118 min, CNN algo más de 1 h); cada semilla adicional repite eso;
  las variantes enmascaradas y las ablaciones suman varias horas. Se propone escalonar: primero 1 semilla de cada sistema, luego semillas, luego variantes.

Recomendación (adoptada): **A ahora, y B y C como parte del reentrenamiento final** (la ResNet reentrenada con todos los cambios): un solo ciclo de GPU para varias respuestas.

## Riesgos y mitigaciones

| Riesgo | Impacto | Mitigación |
|---|---|---|
| El rendimiento externo cae mucho (cambio de institución, anotación distinta) | Alto | Es un resultado válido; protocolo preespecificado, reporte completo, con y sin máscara |
| Chapman/Ningbo anotan sobre todo ritmos: pocas clases evaluables | Alto | T8 fija las clases evaluables antes; se declara el alcance y no se extrapola al resto |
| No poder separar procedencias si se usa `ecg-arrhythmia` | Medio | Usar las carpetas del Challenge 2021; verificar que son los mismos archivos |
| Duplicados, solape o varios ECG por paciente en el conjunto externo | Medio | Auditoría en T10; IC por clúster si hay identificador; exclusiones fijadas en T9 |
| «Mirar» el conjunto externo más de una vez invalida lo confirmatorio | Alto | Hash del protocolo, una sola ejecución, registro de fecha; nada se ajusta con él |
| Entrenar la CNN o el enmascarado después de ver el resultado externo | Alto | La CNN entra en T9 y se entrena antes de T11; el resto se declara exploratorio |
| T6 interpretada como validación independiente | Medio | Título, texto y límites explícitos (auditoría con modelos congelados) |
| El enmascarado cambia el significado de las salidas | Medio | Variante secundaria; si se adopta, regenerar el paquete y correr `tests/test_inference_bundle.py` |
| Más resultados no caben en 20 páginas | Medio | Tablas compactas; la Tabla I ya es la más densa (T5) |
| Cambios en `ecg/` rompen la CI o filtran menciones del artículo | Medio | PR con la suite en verde y revisión de texto antes de empujar |

## Decisiones abiertas

- **D1.** Evaluación externa con las carpetas `chapman_shaoxing` y `ningbo` del Challenge 2021 como prueba confirmatoria. **Recomendado: sí.**
- **D2.** Enmascarado en entrenamiento: sistema final o secundario. **Recomendado: secundario**, con las etiquetas desconocidas ya definidas en T9 para la evaluación externa.
- **D3.** Reparto agrupado por paciente. **Recomendado: omitir por ahora**; T7 queda como análisis descriptivo.
- **D4.** Tres decimales solo en el F1 macro y su IC, regenerados desde las predicciones. **Recomendado: sí.**
- **D5.** Publicar en el repositorio las predicciones por registro, las etiquetas evaluadas, los umbrales, las métricas y el manifiesto (sin redistribuir ECG). **Recomendado: sí**, pero afecta a GitHub: lo decide el usuario y exige revisar que no haya menciones del artículo.
- **D6.** Ablaciones: matriz mínima y dirigida (T14), sin factorial completo.
- **D7 (nueva).** ¿La CNN de referencia entra en el protocolo externo? **Recomendado: sí** (cuesta ≈ 0.5 h y se entrena antes de T11).

## Orden recomendado y tiempos

1. Fases 0 y 1 (T1–T8): sin GPU ni descargas. ≈ 2–3 días de trabajo.
2. Fase 2: T9 → T13 (≈ 0.5 h de GPU) → T10 (descarga ≈ 5 GB, a confirmar) → T11. Confirmar D1 y D7 antes.
3. Fases 3 y 4: solo si D2/D6 lo piden; ≈ 3 h (enmascarado) + 4–6 h (ablaciones) de GPU.
4. Fase 5 (semillas): al final, sobre la configuración que quede.

## Limpieza de versiones pasadas o inválidas (evaluación del 2026-10-26; no se ha borrado nada)

Criterio: se borra solo lo que (a) no respalda ninguna cifra, referencia ni comando vigente y (b) se puede regenerar o fue abandonado. Borrar algo citado en
`cifras.csv`, el manifiesto o un documento rompe `manifiesto.py --verificar` o `calcular_extra.py`.

| Candidato | Tamaño | Dependencias | Veredicto |
|---|---|---|---|
| `dataset2021/` (descarga parcial del Challenge 2021, del usuario) y `descargar_challenge2021.sh` | 166 MB | ninguna; el uso del Challenge 2021 está prohibido | **borrar con tu visto bueno** (son tuyos) |
| `saved/cinc2020/cinc2020_regular/…` (CNN incompleta, época 72/80) | 106 MB | ninguna; T19 la reentrena | **borrar con tu visto bueno** |
| `runs/eval/metrica-challenge-legacy27/` | pequeño | sin referencias | **borrar** (salida de una métrica que el proyecto retiró) |
| `runs/eval/metrica-challenge/` | pequeño | solo la nombra `tasks/analisis_mejoras.md` (versionado) | borrar y dejar esa mención como histórica, o conservar |
| Word: `articulo_ieee.docx`, `hacer_docx.py`, `ajustar_flotantes.py`, `word_a_pdf.ps1`, `flotantes.json` | < 1 MB | ninguna cifra; el .docx está desactualizado | conservar hasta decidir si la Escuela exige el Word; si no, **borrar** |
| `evidencia/protocolo_externo.*` (ANULADO) | pequeño | está en el manifiesto | conservar como registro (ya dice ANULADO) o borrar y regenerar el manifiesto |
| Archivos de compilación (`main.aux`, `.log`, `.out`, `build_*.txt`), `evidencia/vistas/`, `figuras/png/` | pocos MB | regenerables | borrar sin riesgo cuando quieras |
| Carpetas temporales de sesiones anteriores (`AppData/Local/Temp/…`) | variable | respaldos y borradores temporales | borrar sin riesgo al cerrar |

**No borrar:** `data/cinc2020_12/` (9.8 GB: reparto y HDF5 de todas las cifras actuales y del solape), `dataset2020/` (T19 reconstruye desde él), `runs/eval/` citado en
`cifras.csv` (`eval-resnet*`, `ensemble*`, `eval-v3-*`, `ensemble-nsr090`), `eval-abl-v2-*` (respaldan la «ablación 2×2» de `docs/resultados_finales.md`),
`saved/cinc2020/cinc2020_resnet` y `_resnet_v2` (origen del paquete y de la robustez), `models/`, `deploy/` y `data/externo/`.
**Después de T19e** (cuando las cifras del artículo salgan del reparto nuevo) se podrá archivar `data/cinc2020_12/` conservando `split_assignments.csv` y las predicciones;
hasta entonces respalda los resultados exploratorios que el artículo todavía cita.
