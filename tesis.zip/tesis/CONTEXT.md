# tesis/ — artículo IEEE (réplica metodológica de Hannun et al.)

Es lo único que queda de la tesis: el artículo IEEE de hasta 20 páginas (LaTeX y PDF; el Word se descartó). La tesis completa y el artículo
anterior se borraron el 2026-11-01 por redundantes. Esta carpeta **no se sube a GitHub** (`.git/info/exclude`); vive solo en esta copia local.
Comandos desde la raíz del repo. Documentación y mensajes en español. No nombrar herramientas de redacción automática fuera de Declaraciones.

## Dónde está cada cosa

| Ruta | Qué es |
|---|---|
| `main.tex`, `capitulos/*.tex` | El artículo. Las cifras entran como `\cf{ID}` desde `capitulos/cifras_t19.tex`; no se escriben a mano. |
| `references.bib`, `references_extra.bib` | Bibliografía (la segunda es la añadida con la evaluación externa). |
| `figuras/` | PDF de las figuras (versionables) y `tikz/` (diagrama de la red). `png/` son vistas previas, se regeneran. |
| `evidencia/` | Entradas y salidas del análisis, protocolos con SHA-256 (`protocolo_*.md` + `.sha256`: **no se editan**), registros y desviaciones. |
| `scripts/` | Cálculo de cifras, figuras, verificadores y auditorías. |
| `plan/` | Plan, lista de tareas y estado de las observaciones del asesor (`revision_observaciones.md`). Historial: no es contrato. |
| `obsoleto/` | `word/` (versión .docx y sus scripts), `reparto_anterior/` (cálculo del reparto aleatorio por registro), `apendice/` (apéndice y figura ROC de las 12 clases, retirados) y `paquete/` (constructor y verificador del paquete de reproducibilidad, retirado el 2026-11-11: sin Zenodo el artículo no lo cita). No ejecutar. |

## Flujo (el sistema congelado se evalúa una sola vez; no se reentrena por un resultado decepcionante)

1. Predicciones congeladas en `runs/t19/eval/` (las produce el repo, `ecg/` y `examples/cinc2020/`; no se versionan).
2. `scripts/analizar_t19.py` → `evidencia/t19_etapa*/`; `scripts/*_externa.py`, `reparto_externo.py`, `sistemas_congelados.py` → evaluación externa C y D; `limitaciones_cpu.py`, `limitaciones_gpu.py` (GPU) + `limitaciones_resumen_gpu.py` y `casi_duplicados_externa.py` → `evidencia/limitaciones/` (exploratorios, desviación 7: ECE corregido, sexo y edad, robustez de P3 con red de 50/60 Hz, varias ventanas, casi duplicados).
3. `python tesis/scripts/calcular_t19.py` → `evidencia/cifras_t19.csv` y `capitulos/cifras_t19.tex`.
4. `python tesis/scripts/hacer_figuras.py` → `figuras/*.pdf`.
5. `python tesis/scripts/verificar_tex.py` (0 errores) y `python tesis/scripts/auditar_citas.py` (OK).
6. `bash tesis/compilar.sh` → `main.pdf`; sale con 0 solo con ≤ 20 páginas, 0 errores de TeX y 0 citas indefinidas.
7. Respaldo: copiar `tesis/`, `runs/t19/` y `saved/t19/` fuera de este disco. Es lo único que no se recupera de GitHub (predicciones congeladas con su SHA-256, pesos de todas las semillas, protocolos y evidencia). Copia del 2026-11-11 en `respaldo/` de la raíz (excluida de git en `.git/info/exclude`; está en el mismo disco F:, así que no protege de una falla del disco).

## Estado (2026-11-01)

19 páginas desde el 2026-11-11 (análisis exploratorios de la desviación 7 integrados), 0 errores (el apéndice con la ROC de 12 clases se retiró el 2026-11-02 para ganar espacio). P3: F1 macro 0.752 en A, 0.500 en Georgia, 0.491 en Chapman-Shaoxing, 0.462 en Ningbo. Observaciones del asesor:
13 cumplidas, 4 con reserva (1, 2, 4, 6), la 17 descartada. Código solo en https://github.com/PatVela/Proyecto_Investigacion (sin DOI).

## Reglas

- `evidencia/cifras.csv` y `cifras_extra.csv` (y sus `.tex`) son entradas congeladas del reparto anterior que `calcular_t19.py` aún lee; no se regeneran.
- No editar `protocolo_t19.md`, `protocolo_externo_t19.md`, `protocolo_externo.md`: su hash está registrado.
- Si cambia un script o una ruta, actualiza los `.md` que lo citan.
- `main.pdf` y los `build_*.txt` se regeneran con `compilar.sh`.
