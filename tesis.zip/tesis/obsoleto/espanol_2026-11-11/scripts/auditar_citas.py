"""Auditoría del orden de cita de tablas y figuras (Obs. 16 de la segunda revisión): cada una debe citarse en el texto antes de aparecer.

Lee main.aux (página y número de cada ``\\label`` de tabla o figura) y el texto de cada página de main.pdf. Una tabla o figura se marca si no hay ninguna
mención en el texto en una página anterior a la suya ni en la suya (más allá de su propio rótulo). Aproximación: dentro de una misma página no mira si
la mención queda antes o después en la columna.
Uso, desde la raíz del repo, tras compilar:  python tesis/scripts/auditar_citas.py
"""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

IEEE = Path(__file__).resolve().parents[1]


def paginas_texto() -> list[str]:
    info = subprocess.run(["pdfinfo", str(IEEE / "main.pdf")], capture_output=True).stdout.decode("latin-1")   # pdfinfo escribe en la página de códigos de Windows
    n = int(re.search(r"Pages:\s+(\d+)", info).group(1))
    return [subprocess.run(["pdftotext", "-enc", "UTF-8", "-f", str(p), "-l", str(p), str(IEEE / "main.pdf"), "-"], capture_output=True).stdout.decode("utf-8", "replace")
            for p in range(1, n + 1)]


def main() -> int:
    aux = (IEEE / "main.aux").read_text(encoding="utf-8", errors="replace")
    etiquetas = {m.group(1): (m.group(2), int(m.group(3))) for m in re.finditer(r"\\newlabel\{((?:tab|fig):[^}]+)\}\{\{([^}]*)\}\{(\d+)\}", aux)}
    paginas = paginas_texto()
    malos = 0
    for et, (num, pag) in sorted(etiquetas.items(), key=lambda x: x[1][1]):
        if et.startswith("tab:"):
            patron = re.compile(r"\bTablas?\s+(?:[IVXL]+\s*(?:,|y)\s*)*" + re.escape(num) + r"\b")
        else:
            patron = re.compile(r"\bFigs?\.\s*(?:\d+\s*(?:,|y)\s*)*" + re.escape(num) + r"\b")
        antes = sum(len(patron.findall(paginas[p])) for p in range(pag - 1))
        en_pagina = len(patron.findall(paginas[pag - 1]))
        mismo_rotulo = 1 if et.startswith("fig:") else 0              # el rótulo de una figura repite «Fig. N»; el de una tabla va en mayúsculas
        ok = antes > 0 or en_pagina > mismo_rotulo
        malos += not ok
        print(f"{'OK ' if ok else 'NO '} {et:<22} {('Tabla' if et.startswith('tab:') else 'Fig.')} {num:<5} pág. {pag}  citas antes: {antes}, en su página: {en_pagina}")
    print(f"RESULTADO: {'OK' if not malos else str(malos) + ' sin cita previa'}")
    return 1 if malos else 0


if __name__ == "__main__":
    sys.exit(main())
