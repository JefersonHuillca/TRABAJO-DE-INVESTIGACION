"""Compara la probabilidad de la webapp (paquete deploy/) con predictions_test.csv de la evaluación del ensemble P3.

Uso, desde la raíz del repo:  python <este script> <predictions_test.csv> <n> <seed> <salida.json>
"""
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

REPO = Path.cwd()
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "tools"))
from build_examples import find_headers  # noqa: E402

pred_csv, n, seed, out = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), Path(sys.argv[4])
work = out.parent / "web_vs_eval_tmp"
for key in [k for k in os.environ if k.startswith("ECG_")]:
    del os.environ[key]
os.environ.update({"ECG_UPLOADS": str(work / "up"), "ECG_RESULTS": str(work / "res"), "ECG_RATE_LIMIT_MAX": "0"})
import webapp.wsgi as wsgi  # noqa: E402

client = wsgi.create_wsgi_app().test_client()
df = pd.read_csv(pred_csv)
classes = [c[len("prob_"):] for c in df.columns if c.startswith("prob_")]
sample = df.sample(n=min(n, len(df)), random_state=seed) if n > 0 else df
headers = find_headers(REPO / "dataset2020")
diffs, flips, rows, skipped, t0 = [], 0, [], [], time.time()
for _, r in sample.iterrows():
    hea = headers[r.record_name]
    with open(hea, "rb") as fh, open(hea.with_suffix(".mat"), "rb") as fm:
        body = client.post("/predict", data={"files": [(fh, hea.name), (fm, hea.with_suffix(".mat").name)]},
                           content_type="multipart/form-data").get_json()
    if body and not body.get("ok") and "5 MB" in str(body.get("error", "")):
        skipped.append(r.record_name)                       # la app rechaza por diseño subidas de más de 5 MB
        continue
    assert body and body.get("ok"), (r.record_name, body)
    probs = {p["class"]: p["probability"] for p in body["predictions"]}
    web_pos = {p["class"] for p in body["predictions"] if p["prediction"] == 1}
    d = [abs(probs[c] - float(r[f"prob_{c}"])) for c in classes]
    eval_pos = {c for c in classes if int(r[f"pred_{c}"]) == 1}
    flips += len(web_pos ^ eval_pos)
    diffs.extend(d)
    hdr = hea.read_text(encoding="utf-8", errors="replace").split()
    rows.append({"record": r.record_name, "max_diff": max(d), "diffs": d, "flips": len(web_pos ^ eval_pos),
                 "seconds_signal": int(hdr[3]) / float(hdr[2])})
res = {"records": len(rows), "values": len(diffs), "mean_abs_diff": float(np.mean(diffs)), "max_abs_diff": float(np.max(diffs)),
       "decision_flips": flips, "skipped_over_5mb": skipped, "seconds": round(time.time() - t0, 1), "pred_csv": str(pred_csv), "seed": seed,
       "worst": sorted(rows, key=lambda x: -x["max_diff"])[:5], "rows": rows}
for nombre, sel in (("10s", [x for x in rows if x["seconds_signal"] <= 10.5]), ("largos", [x for x in rows if x["seconds_signal"] > 10.5])):
    vals = [v for x in sel for v in x["diffs"]]
    res[nombre] = {"records": len(sel), "mean_abs_diff": float(np.mean(vals)) if vals else None,
                   "max_abs_diff": float(np.max(vals)) if vals else None, "decision_flips": sum(x["flips"] for x in sel)}
out.write_text(json.dumps(res, indent=2), encoding="utf-8")
print(json.dumps({k: v for k, v in res.items() if k != "worst"}))
