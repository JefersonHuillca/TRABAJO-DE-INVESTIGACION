#!/usr/bin/env bash
# E16: 5 semillas más (105 a 109) de v1 y v2, misma receta que la etapa 3.
# Se detiene si una corrida falla o si su carpeta ya existe (no se reentrena por el resultado).
# Uso (desde la raíz del repositorio): bash tesis/scripts/entrenar_e16.sh
set -euo pipefail
cd "${T19_RAIZ:-$(dirname "$0")/../../..}"
mkdir -p runs/t19/logs_e16
for s in 105 106 107 108 109; do
  for r in v1 v2; do
    e="t19_${r}_s${s}"
    if [ -d "saved/t19/${e}" ]; then
      echo "ya existe saved/t19/${e}: se detiene" >&2
      exit 1
    fi
    echo "$(date -u +%FT%TZ) inicio ${e}"
    python -X utf8 -m ecg.train "runs/t19/config/config_${e}.json" -e "${e}" > "runs/t19/logs_e16/${e}.log" 2>&1
    echo "$(date -u +%FT%TZ) fin ${e}"
  done
done
