"""Prueba sin solape de pacientes y sin registros sin clase (T7 del plan de revisión). Análisis descriptivo, no una evaluación independiente.

Con las predicciones de prueba del ensemble afín recalcula F1 macro y micro, coincidencia exacta y AUROC macro (con IC95 por bootstrap sobre
registros) en subconjuntos de la prueba:
  completa; sin los registros sin ninguna clase; sin los que comparten paciente con entrenamiento o validación; sin ambos; y solo
  los identificables sin solape (PTB-XL y PTB, los únicos orígenes con identificador de paciente).
Excluir registros no vuelve independiente la prueba: las decisiones de diseño siguen habiéndose tomado con ella. Los otros cuatro orígenes
no traen identificador, de modo que sus registros no se pueden clasificar como solapados o no.

Reutiliza la lógica de tools/check_patient_overlap.py (incluida su comprobación de la correspondencia de nombres) y necesita los archivos
externos que esa herramienta pide: data/externo/ptbxl_database.csv, data/externo/RECORDS y dataset2020/.
Escribe evidencia/prueba_sin_solape.csv. Uso, desde la raíz del repo:  python tesis/scripts/prueba_sin_solape.py
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

IEEE = Path(__file__).resolve().parents[1]
REPO = IEEE.parent
sys.path.insert(0, str(REPO / "tools"))
import check_patient_overlap as cpo  # noqa: E402

CLASES = ["NSR", "AxisDev", "MI", "TAb", "AF", "LVH", "VEctopy", "AVBlock", "STach", "BBB", "SB", "AEctopy_Junctional"]
PREDICCIONES = REPO / "runs" / "eval" / "ensemble-f1-platt" / "predictions_test.csv"
BOOTSTRAP, SEMILLA = 1000, 0
SALIDA = IEEE / "evidencia" / "prueba_sin_solape.csv"


def f1_macro_micro_exacta(y, yh):
    tp, fp, fn = (y * yh).sum(0), ((1 - y) * yh).sum(0), (y * (1 - yh)).sum(0)
    macro = float(np.mean(2 * tp / np.maximum(2 * tp + fp + fn, 1)))
    micro = float(2 * tp.sum() / max(2 * tp.sum() + fp.sum() + fn.sum(), 1))
    return macro, micro, float((y == yh).all(1).mean())


def auroc_macro(y, p):
    return float(np.mean([roc_auc_score(y[:, i], p[:, i]) for i in range(y.shape[1])]))


def solapados_y_conocidos() -> tuple[set[str], set[str]]:
    table, patients = cpo.ptbxl_table(REPO / "data" / "externo" / "ptbxl_database.csv"), cpo.ptb_patients(REPO / "data" / "externo" / "RECORDS")
    asignaciones = cpo.read_assignments(cpo.DEFAULT_SPLIT)
    cabeceras = {o: {p.stem: p for p in (cpo.DEFAULT_CHALLENGE / o).rglob("*.hea")} for o in cpo.ORIGINS}
    mapeo = {"ptb-xl": cpo.check_ptbxl_mapping(cabeceras["ptb-xl"], table), "ptb": cpo.check_ptb_mapping(cabeceras["ptb"], patients)}
    assert mapeo["ptb-xl"]["rate"] >= cpo.MIN_AGREEMENT and mapeo["ptb"]["sex_rate"] >= cpo.MIN_AGREEMENT, "la correspondencia de nombres no se verifica"

    def paciente(registro: str, origen: str):
        if origen == "ptb-xl":
            n = cpo.record_number(registro, "HR")
            return table[n][0] if n in table else None
        return patients.get(cpo.record_number(registro, "S"))

    conocidos, solapados = set(), set()
    for origen in cpo.ORIGINS:
        k, s = cpo.overlapped_test_records(asignaciones, paciente, origen)
        conocidos |= k
        solapados |= s
    return conocidos, solapados


def main() -> int:
    d = pd.read_csv(PREDICCIONES)
    nombres = d["record_name"].to_numpy()
    y = d[[f"true_{c}" for c in CLASES]].to_numpy(int)
    p = d[[f"prob_{c}" for c in CLASES]].to_numpy(float)
    yh = d[[f"pred_{c}" for c in CLASES]].to_numpy(int)
    conocidos, solapados = solapados_y_conocidos()
    assert len(solapados) == 738, f"se esperaban 738 registros solapados y hay {len(solapados)}"
    es_solapado = np.array([r in solapados for r in nombres])
    es_conocido = np.array([r in conocidos for r in nombres])
    sin_clase = y.sum(1) == 0
    assert sin_clase.sum() == 24, f"se esperaban 24 registros sin clase y hay {sin_clase.sum()}"

    subconjuntos = {
        "completa": np.ones(len(y), bool),
        "sin registros sin clase": ~sin_clase,
        "sin registros solapados": ~es_solapado,
        "sin solapados ni sin clase": ~es_solapado & ~sin_clase,
        "solo identificables sin solape": es_conocido & ~es_solapado,
    }
    rng = np.random.default_rng(SEMILLA)
    filas = []
    for nombre, sel in subconjuntos.items():
        ys, ps, yhs = y[sel], p[sel], yh[sel]
        macro, micro, exacta = f1_macro_micro_exacta(ys, yhs)
        auc = auroc_macro(ys, ps)
        idx = rng.integers(0, len(ys), size=(BOOTSTRAP, len(ys)))
        boot_f1 = np.array([f1_macro_micro_exacta(ys[b], yhs[b])[0] for b in idx])
        boot_auc = np.array([auroc_macro(ys[b], ps[b]) for b in idx if (ys[b].sum(0) > 0).all() and (ys[b].sum(0) < len(b)).all()])
        f1_lo, f1_hi = np.percentile(boot_f1, [2.5, 97.5])
        auc_lo, auc_hi = np.percentile(boot_auc, [2.5, 97.5])
        filas.append([nombre, int(sel.sum()), macro, f1_lo, f1_hi, micro, exacta, auc, auc_lo, auc_hi])
    fp_total = int(((1 - y) * yh).sum())
    fp_sin_clase = int(yh[sin_clase].sum())
    with SALIDA.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["subconjunto", "n", "f1_macro", "f1_macro_lo", "f1_macro_hi", "f1_micro", "coincidencia_exacta", "auroc_macro", "auroc_lo", "auroc_hi"])
        for f in filas:
            w.writerow([f[0], f[1]] + [f"{v:.6f}" for v in f[2:]])
        w.writerow([])
        w.writerow(["falsos_positivos_total", fp_total])
        w.writerow(["falsos_positivos_en_registros_sin_clase", fp_sin_clase])
        w.writerow(["registros_sin_clase_con_alguna_prediccion", int((yh[sin_clase].sum(1) > 0).sum())])
        w.writerow(["registros_solapados", int(es_solapado.sum())])
        w.writerow(["registros_identificables_de_prueba", int(es_conocido.sum())])
    for f in filas:
        print(f"{f[0]:<34} n={f[1]:>5}  F1 macro {f[2]:.3f} [{f[3]:.3f}; {f[4]:.3f}]  micro {f[5]:.3f}  exacta {f[6]:.3f}  AUROC {f[7]:.3f} [{f[8]:.3f}; {f[9]:.3f}]")
    print(f"falsos positivos: {fp_total} en total, {fp_sin_clase} en los 24 registros sin clase; identificables {int(es_conocido.sum())}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
