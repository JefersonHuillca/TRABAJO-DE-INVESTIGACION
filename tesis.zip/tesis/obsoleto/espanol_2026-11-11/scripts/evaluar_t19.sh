#!/bin/bash
# Calibración, umbrales y evaluación única de la etapa 1, 2 o 3 de T19 (protocolo_t19.md, apartados 4 y 5); las etapas 4 y 5 son exploratorias y no están en el protocolo.
# Desde la raíz del repo:  bash tesis/scripts/evaluar_t19.sh <1|2|3|4|5>
# Cada sistema se evalúa una sola vez en la prueba A y una vez en la B: si su carpeta de salida ya existe, el script se detiene sin tocar nada.
# La etapa 7 es la evaluación externa en Chapman-Shaoxing (C) y Ningbo (D) del protocolo_externo_t19.md: solo evalúa, con las calibraciones y los umbrales ya guardados.
# La etapa 1 ya está ejecutada (sus carpetas existen): se deja como documentación de lo que se corrió.
set -eu
cd "${T19_RAIZ:-$(dirname "$0")/../../..}"       # raíz con runs/, data/, saved/ y ecg/: el repositorio (por defecto) o el paquete de reproducibilidad
E=runs/t19/eval; C=runs/t19/config; H5=data/cinc2020_12_origen
PR="A B"      # pruebas que evalúan las funciones de abajo; la etapa 7 usa "C D"

py() {  # ejecuta python y muestra su salida sin las barras de progreso; si falla, muestra el final del registro y se detiene
  local log; log=$(mktemp)
  python -X utf8 "$@" > "$log" 2>&1 || { tr '\r' '\n' < "$log" | tail -n 30; echo "FALLÓ: python $*"; exit 1; }
  tr '\r' '\n' < "$log" | grep -avE 'it/s|^[[:space:]]*$' || true
  rm -f "$log"
}
ckpt() {  # un único best.pt por experimento, y solo si el entrenamiento terminó (training_summary.json se escribe al final)
  local r; r=$(ls saved/t19/"$1"/*/best.pt 2>/dev/null) || r=""
  [ -n "$r" ] && [ "$(echo "$r" | wc -l)" -eq 1 ] || { echo "se esperaba un solo best.pt en saved/t19/$1" >&2; exit 1; }
  [ -e "$(dirname "$r")/training_summary.json" ] || { echo "el entrenamiento de $1 no terminó" >&2; exit 1; }
  echo "$r"
}
nuevo() { [ ! -e "$1" ] || { echo "$1 ya existe: cada sistema se evalúa una sola vez"; exit 1; }; }
testb() {  # configuración de las pruebas B, C y D: la misma con test apuntando a su HDF5 (la A usa la configuración original)
  local p h5
  for p in $PR; do
    case $p in A) continue ;; B) h5=data/cinc2020_12_origen/test_b.h5 ;; C) h5=data/cinc2021_externo/test_c.h5 ;; D) h5=data/cinc2021_externo/test_d.h5 ;; esac
    [ -e "$C/$1_test$(echo "$p" | tr A-Z a-z).json" ] || py -c "import json; c = json.load(open('$C/$1.json', encoding='utf-8')); c['test'] = '$h5'; json.dump(c, open('$C/$1_test$(echo "$p" | tr A-Z a-z).json', 'w', encoding='utf-8'), indent=2, ensure_ascii=False)"
  done
}
config() { if [ "$2" = A ]; then echo "$C/$1.json"; else echo "$C/$1_test$(echo "$2" | tr A-Z a-z).json"; fi; }
calibrar() {  # nombre checkpoint
  nuevo "$E/$1"
  py examples/cinc2020/calibrate.py --method platt --checkpoint "$2" --val-h5 $H5/val.h5 --output-dir "$E/$1"
}
evaluar() {  # nombre configuración checkpoint
  testb "$2"
  for p in $PR; do
    nuevo "$E/$1_$p"
    py examples/cinc2020/evaluate.py "$(config "$2" $p)" "$3" --output-dir "$E/$1_$p" --platt "$E/$1/platt_validation.csv" --threshold-beta 1.0
  done
}
ensamble() {  # nombre configuración checkpoint_a checkpoint_b calibración_a calibración_b
  testb "$2"
  for p in $PR; do
    nuevo "$E/$1_$p"
    py examples/cinc2020/ensemble_evaluate.py "$(config "$2" $p)" "$3" "$4" --output-dir "$E/$1_$p" --alpha 0.5 --threshold-beta 1.0 \
      --platt-a "$E/$5/platt_validation.csv" --platt-b "$E/$6/platt_validation.csv" --recalibrate-ensemble
  done
}

calibrar_t() {  # nombre checkpoint: una temperatura por clase en validación (línea base de la calibración afín)
  nuevo "$E/$1"
  py examples/cinc2020/calibrate.py --method temperature --checkpoint "$2" --val-h5 $H5/val.h5 --output-dir "$E/$1"
}
evaluar_t() {  # nombre configuración checkpoint
  testb "$2"
  for p in $PR; do
    nuevo "$E/$1_$p"
    py examples/cinc2020/evaluate.py "$(config "$2" $p)" "$3" --output-dir "$E/$1_$p" --temperatures "$E/$1/temperatures_validation.csv" --threshold-beta 1.0
  done
}
ensamble_t() {  # nombre configuración checkpoint_a checkpoint_b calibración_a calibración_b: promedio de probabilidades con temperatura, sin recalibrar el promedio
  testb "$2"
  for p in $PR; do
    nuevo "$E/$1_$p"
    py examples/cinc2020/ensemble_evaluate.py "$(config "$2" $p)" "$3" "$4" --output-dir "$E/$1_$p" --alpha 0.5 --threshold-beta 1.0 \
      --temperatures-a "$E/$5/temperatures_validation.csv" --temperatures-b "$E/$6/temperatures_validation.csv"
  done
}

case "${1:-}" in
  1)  # P1 y P2 (recetas v1 y v2) y su ensemble P3
    V1=$(ckpt t19_v1); V2=$(ckpt t19_v2)
    calibrar p1 "$V1"; calibrar p2 "$V2"
    evaluar p1 config_t19_v1 "$V1"; evaluar p2 config_t19_v2 "$V2"
    ensamble p3 config_t19_v1 "$V1" "$V2" p1 p2 ;;
  2)  # CNN 1D (S2) y las variantes con pérdida enmascarada (S1): P1m, P2m y su ensemble P3m
    CN=$(ckpt t19_cnn); M1=$(ckpt t19_v1_mask); M2=$(ckpt t19_v2_mask)
    calibrar cnn "$CN"; calibrar p1m "$M1"; calibrar p2m "$M2"
    evaluar cnn config_t19_cnn "$CN"; evaluar p1m config_t19_v1_mask "$M1"; evaluar p2m config_t19_v2_mask "$M2"
    ensamble p3m config_t19_v1_mask "$M1" "$M2" p1m p2m ;;
  3)  # S4: semillas 101 a 104 de P1 y P2 con su ensemble; S3: ablaciones desde P1 (aug, ls, es, reg)
    for s in 101 102 103 104; do
      A=$(ckpt t19_v1_s$s); B=$(ckpt t19_v2_s$s)
      calibrar p1_s$s "$A"; calibrar p2_s$s "$B"
      evaluar p1_s$s config_t19_v1_s$s "$A"; evaluar p2_s$s config_t19_v2_s$s "$B"
      ensamble p3_s$s config_t19_v1_s$s "$A" "$B" p1_s$s p2_s$s
    done
    for a in aug ls es reg; do
      X=$(ckpt t19_abl_$a); calibrar abl_$a "$X"; evaluar abl_$a config_t19_abl_$a "$X"
    done ;;
  6)  # E16 (desviación 5): semillas 105 a 109 de P1 y P2 con su ensemble, igual que en la etapa 3; sin ablaciones
    for s in 105 106 107 108 109; do
      A=$(ckpt t19_v1_s$s); B=$(ckpt t19_v2_s$s)
      calibrar p1_s$s "$A"; calibrar p2_s$s "$B"
      evaluar p1_s$s config_t19_v1_s$s "$A"; evaluar p2_s$s config_t19_v2_s$s "$B"
      ensamble p3_s$s config_t19_v1_s$s "$A" "$B" p1_s$s p2_s$s
    done ;;
  7)  # Evaluación externa (protocolo_externo_t19.md): los 37 sistemas congelados en Chapman-Shaoxing (C) y Ningbo (D), una sola vez cada uno y sin calibrar ni ajustar nada
    PR="C D"
    PROT=tesis/evidencia/protocolo_externo_t19
    [ ! -e "$PROT.md" ] || [ "$(sha256sum "$PROT.md" | cut -d' ' -f1)" = "$(head -c 64 "$PROT.sha256")" ] || { echo "el protocolo externo cambió desde que se selló"; exit 1; }
    V1=$(ckpt t19_v1); V2=$(ckpt t19_v2)
    evaluar p1 config_t19_v1 "$V1"; evaluar p2 config_t19_v2 "$V2"
    ensamble p3 config_t19_v1 "$V1" "$V2" p1 p2
    for s in 101 102 103 104 105 106 107 108 109; do
      A=$(ckpt t19_v1_s$s); B=$(ckpt t19_v2_s$s)
      evaluar p1_s$s config_t19_v1_s$s "$A"; evaluar p2_s$s config_t19_v2_s$s "$B"
      ensamble p3_s$s config_t19_v1_s$s "$A" "$B" p1_s$s p2_s$s
    done
    CN=$(ckpt t19_cnn); M1=$(ckpt t19_v1_mask); M2=$(ckpt t19_v2_mask)
    evaluar cnn config_t19_cnn "$CN"; evaluar p1m config_t19_v1_mask "$M1"; evaluar p2m config_t19_v2_mask "$M2"
    ensamble p3m config_t19_v1_mask "$M1" "$M2" p1m p2m
    evaluar_t p1t config_t19_v1 "$V1"; evaluar_t p2t config_t19_v2 "$V2"
    ensamble_t p3t config_t19_v1 "$V1" "$V2" p1t p2t ;;
  4)  # EXPLORATORIO (no está en el protocolo): P1, P2 y su ensemble con calibración por temperatura en lugar de la afín, para medir la calibración afín frente a una línea base
    V1=$(ckpt t19_v1); V2=$(ckpt t19_v2)
    calibrar_t p1t "$V1"; calibrar_t p2t "$V2"
    evaluar_t p1t config_t19_v1 "$V1"; evaluar_t p2t config_t19_v2 "$V2"
    ensamble_t p3t config_t19_v1 "$V1" "$V2" p1t p2t ;;
  5)  # EXPLORATORIO (no está en el protocolo): robustez de P2 ante perturbaciones de la señal de las pruebas A y B, un sorteo por nivel, con su calibración afín y sus umbrales
    V2=$(ckpt t19_v2); R=runs/t19/robustez
    for p in A B; do
      nuevo "$R/p2_$p.csv"
      py examples/cinc2020/robustness.py "$V2" "$H5/$([ "$p" = B ] && echo test_b || echo test).h5" --platt "$E/p2/platt_validation.csv" \
        --thresholds "$E/p2_A/thresholds_validation.csv" --output "$R/p2_$p.csv" --seed 42
    done ;;
  *)  echo "uso: bash tesis/scripts/evaluar_t19.sh <1|2|3|4|5|6|7>"; exit 1 ;;
esac
if [ "${1:-}" = 7 ]; then sha256sum "$E"/*_[CD]/predictions_test.csv; else sha256sum "$E"/*_[AB]/predictions_test.csv; fi
