"""E6: tabla de los sistemas congelados que se evaluarán en Chapman-Shaoxing y Ningbo, con el SHA-256 de cada pieza.

Lee solo archivos ya guardados (configuraciones, pesos, calibraciones, umbrales y las predicciones de las pruebas A y B) y escribe
``evidencia/protocolo_externo_t19_sistemas.csv``. No evalúa nada. El protocolo externo cita el SHA-256 de ese CSV.
Uso, desde la raíz del repo:  python tesis/scripts/sistemas_congelados.py
"""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path

IEEE = Path(__file__).resolve().parents[1]
REPO = IEEE.parent
EVAL, CFG, SAVED = REPO / "runs/t19/eval", REPO / "runs/t19/config", REPO / "saved/t19"
SEMILLAS = tuple(str(s) for s in range(101, 110))


def sha(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def pesos(exp: str) -> Path:
    r = list(SAVED.glob(f"{exp}/*/best.pt"))
    assert len(r) == 1, exp
    return r[0]


def individual(sid, exp, cal, tipo):
    """cal: archivo de calibración dentro de runs/t19/eval/<sid de calibración>/."""
    return {"id": sid, "tipo": tipo, "miembros": exp, "calibracion": cal}


def sistemas():
    filas = []
    for p, e in (("P1", "t19_v1"), ("P2", "t19_v2")):
        filas.append({"id": p, "tipo": "individual", "miembros": [(e, p.lower())], "calibracion": [f"{p.lower()}/platt_validation.csv"], "eval": p.lower()})
    filas.append({"id": "P3", "tipo": "ensemble", "miembros": [("t19_v1", "p1"), ("t19_v2", "p2")], "calibracion": ["p3_A/platt_ensemble_validation.csv", "p1/platt_validation.csv", "p2/platt_validation.csv"], "eval": "p3"})
    for s in SEMILLAS:
        for r, e in (("1", f"t19_v1_s{s}"), ("2", f"t19_v2_s{s}")):
            filas.append({"id": f"P{r}_S{s}", "tipo": "individual", "miembros": [(e, f"p{r}_s{s}")], "calibracion": [f"p{r}_s{s}/platt_validation.csv"], "eval": f"p{r}_s{s}"})
        filas.append({"id": f"P3_S{s}", "tipo": "ensemble", "miembros": [(f"t19_v1_s{s}", f"p1_s{s}"), (f"t19_v2_s{s}", f"p2_s{s}")],
                      "calibracion": [f"p3_s{s}_A/platt_ensemble_validation.csv", f"p1_s{s}/platt_validation.csv", f"p2_s{s}/platt_validation.csv"], "eval": f"p3_s{s}"})
    for p, e in (("P1m", "t19_v1_mask"), ("P2m", "t19_v2_mask"), ("CNN", "t19_cnn")):
        filas.append({"id": p, "tipo": "individual", "miembros": [(e, p.lower())], "calibracion": [f"{p.lower()}/platt_validation.csv"], "eval": p.lower()})
    filas.append({"id": "P3m", "tipo": "ensemble", "miembros": [("t19_v1_mask", "p1m"), ("t19_v2_mask", "p2m")],
                  "calibracion": ["p3m_A/platt_ensemble_validation.csv", "p1m/platt_validation.csv", "p2m/platt_validation.csv"], "eval": "p3m"})
    for p, e in (("P1t", "t19_v1"), ("P2t", "t19_v2")):
        filas.append({"id": p, "tipo": "individual (temperatura)", "miembros": [(e, p.lower())], "calibracion": [f"{p.lower()}/temperatures_validation.csv"], "eval": p.lower()})
    filas.append({"id": "P3t", "tipo": "ensemble (temperatura)", "miembros": [("t19_v1", "p1t"), ("t19_v2", "p2t")],
                  "calibracion": ["p1t/temperatures_validation.csv", "p2t/temperatures_validation.csv"], "eval": "p3t"})
    return filas


def main() -> int:
    salida = []
    for f in sistemas():
        pt = [pesos(e) for e, _ in f["miembros"]]
        cfg = [CFG / f"config_{e}.json" for e, _ in f["miembros"]]
        thr_a, thr_b = EVAL / f"{f['eval']}_A/thresholds_validation.csv", EVAL / f"{f['eval']}_B/thresholds_validation.csv"
        assert sha(thr_a) == sha(thr_b), f"umbrales de A y B distintos: {f['id']}"
        cal = [EVAL / c for c in f["calibracion"]]
        pa, pb = EVAL / f"{f['eval']}_A/predictions_test.csv", EVAL / f"{f['eval']}_B/predictions_test.csv"
        salida.append({"sistema": f["id"], "tipo": f["tipo"], "experimentos": ";".join(e for e, _ in f["miembros"]),
                       "config_sha256": ";".join(sha(c) for c in cfg), "best_pt_sha256": ";".join(sha(p) for p in pt),
                       "calibracion": ";".join(c.relative_to(REPO).as_posix() for c in cal), "calibracion_sha256": ";".join(sha(c) for c in cal),
                       "umbrales_sha256": sha(thr_a), "predicciones_A_sha256": sha(pa), "predicciones_B_sha256": sha(pb)})
    ruta = IEEE / "evidencia" / "protocolo_externo_t19_sistemas.csv"
    with open(ruta, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(salida[0]), lineterminator="\n")
        w.writeheader()
        w.writerows(salida)
    print(f"{len(salida)} sistemas en {ruta.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
