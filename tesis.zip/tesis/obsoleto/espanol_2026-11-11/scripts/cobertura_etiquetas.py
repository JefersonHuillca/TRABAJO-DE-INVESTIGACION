"""Cobertura de etiquetas por origen y clase (T8 del plan de revisión): lo inferido del dato frente a lo documentado por cada fuente.

Para cada origen del Challenge 2020 y cada una de las 12 clases:
  - cobertura inferida: «anotada» si el origen tiene al menos un positivo de la clase en entrenamiento (la regla que usa hoy el artículo);
  - cobertura documentada: lo que dice la documentación pública del origen sobre su vocabulario de etiquetas:
      «cubierta»   la clase corresponde a algo del vocabulario documentado,
      «fuera»      la documentación lista su vocabulario y la clase no figura en él,
      «sin documentar» la fuente consultada no describe el vocabulario o lo hace de forma demasiado general.
Una clase «fuera» del vocabulario con cero positivos apoya que esa celda es «no anotada» y no «negativa confirmada».

Fuentes leídas el 2026-10-23 (ver la columna ``fuente``). Para PTB-XL se usa scp_statements.csv (71 enunciados SCP-ECG; el paso de enunciado a clase es del autor y está en este archivo).
Escribe evidencia/cobertura_etiquetas.csv. Uso, desde la raíz del repo:  python tesis/scripts/cobertura_etiquetas.py
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

IEEE = Path(__file__).resolve().parents[1]
REPO = IEEE.parent

CLASES = ["NSR", "AxisDev", "MI", "TAb", "AF", "LVH", "VEctopy", "AVBlock", "STach", "BBB", "SB", "AEctopy_Junctional"]
EVIDENCIA = IEEE / "evidencia"
SALIDA = EVIDENCIA / "cobertura_etiquetas.csv"

# Enunciados SCP-ECG de PTB-XL por clase (criterio del autor, por la descripción de cada enunciado en scp_statements.csv).
PTBXL = {
    "NSR": ["SR", "NORM", "SARRH"], "AxisDev": ["LAFB", "LPFB"], "MI": ["IMI", "AMI", "ASMI", "LMI", "ILMI", "ALMI", "PMI", "IPMI", "IPLMI"],
    "TAb": ["NDT", "NST_", "LNGQT", "STD_", "STE_", "NT_", "INVT", "TAB_", "LOWT", "DIG", "EL", "ISC_"], "AF": ["AFIB", "AFLT"],
    "LVH": ["LVH", "VCLVH", "SEHYP"], "VEctopy": ["PVC", "BIGU", "TRIGU"], "AVBlock": ["1AVB", "2AVB", "3AVB", "LPR"], "STach": ["STACH"],
    "BBB": ["CRBBB", "CLBBB", "IRBBB", "ILBBB", "IVCD"], "SB": ["SBRAD"], "AEctopy_Junctional": ["PAC", "SVARR", "SVTAC", "PSVT", "PACE", "PRC(S)"],
}

# Vocabulario documentado de los orígenes que listan tipos o diagnósticos. «cubierta» -> texto de la correspondencia.
CPSC = {"NSR": "Normal", "AF": "AF", "AVBlock": "I-AVB", "BBB": "LBBB, RBBB", "AEctopy_Junctional": "PAC", "VEctopy": "PVC", "TAb": "STD, STE"}
PTB = {"MI": "Myocardial infarction", "BBB": "Bundle branch block", "LVH": "Myocardial hypertrophy", "NSR": "Healthy controls (referencia sana)"}
PTB_GENERICA = {"AF", "VEctopy", "AVBlock", "STach", "SB", "AEctopy_Junctional"}     # caben en «Dysrhythmia», sin detalle
INCART = {"MI": "Acute MI / Prior MI", "SB": "Sinus node dysfunction", "AEctopy_Junctional": "Supraventricular ectopy", "AF": "Atrial fibrillation or SVTA",
          "AVBlock": "AV block", "BBB": "Bundle branch block"}

FUENTES = {
    "cpsc_2018": "Liu et al. 2018 (nueve tipos: normal, AF, I-AVB, LBBB, RBBB, PAC, PVC, STD, STE); resumen en https://www.biorxiv.org/content/10.1101/766022.full.pdf",
    "cpsc_2018_extra": "https://physionet.org/content/challenge-2020/1.0.2/ (solo dice «unused/extra data» de CPSC2018; no describe el vocabulario)",
    "georgia": "https://physionet.org/content/challenge-2020/1.0.2/ (no describe cómo se asignaron las etiquetas; advierte de etiquetas con errores o dudosas)",
    "ptb": "https://physionet.org/content/ptbdb/1.0.0/ (clases diagnósticas por sujeto; la «disritmia» no detalla el ritmo)",
    "ptb-xl": "https://physionet.org/content/ptb-xl/1.0.3/ y scp_statements.csv (71 enunciados diagnósticos, de forma y de ritmo; hasta dos cardiólogos)",
    "st_petersburg_incart": "https://physionet.org/content/incartdb/1.0.0/ (tabla de diagnósticos por paciente; anotaciones de latidos, no de ritmo)",
}


def positivos_entrenamiento() -> dict[str, dict[str, int]]:
    with (REPO / "data" / "cinc2020_12" / "split_assignments.csv").open(encoding="utf-8", newline="") as fh:
        filas = [r for r in csv.DictReader(fh) if r["split"] == "train"]
    origenes = sorted({r["source_db"] for r in filas})
    return {o: {c: sum(int(r[c]) for r in filas if r["source_db"] == o) for c in CLASES} for o in origenes}


def documentada(origen: str, clase: str, ptbxl_ok: set[str]) -> tuple[str, str]:
    if origen == "cpsc_2018":
        return ("cubierta", CPSC[clase]) if clase in CPSC else ("fuera", "no figura entre los nueve tipos")
    if origen in ("cpsc_2018_extra", "georgia"):
        return "sin documentar", "la fuente no describe el vocabulario"
    if origen == "ptb":
        if clase in PTB:
            return "cubierta", PTB[clase]
        if clase in PTB_GENERICA:
            return "sin documentar", "solo «Dysrhythmia», sin detallar el ritmo"
        return "fuera", "no figura entre las clases diagnósticas"
    if origen == "ptb-xl":
        return ("cubierta", ", ".join(PTBXL[clase])) if clase in ptbxl_ok else ("fuera", "sin enunciado SCP-ECG equivalente")
    if origen == "st_petersburg_incart":
        if clase in INCART:
            return "cubierta", INCART[clase]
        if clase == "VEctopy":
            return "sin documentar", "solo anotaciones de latidos, sin diagnóstico de ritmo"
        return "fuera", "no figura en la tabla de diagnósticos"
    raise ValueError(f"origen sin documentación: {origen}")


def main() -> int:
    with (EVIDENCIA / "cobertura" / "scp_statements_ptbxl.csv").open(encoding="utf-8", newline="") as fh:
        existentes = {r[""] for r in csv.DictReader(fh)}
    faltan = sorted({s for lista in PTBXL.values() for s in lista} - existentes)
    assert not faltan, f"enunciados que no existen en scp_statements.csv: {faltan}"
    ptbxl_ok = set(PTBXL)
    pos = positivos_entrenamiento()
    orden = list(pos)

    filas, resumen = [], {"confirmadas": 0, "sin_documentar": 0, "contradichas": 0, "inferidas_sin_anotar": 0}
    for origen in orden:
        for clase in CLASES:
            n = pos[origen][clase] if origen in pos else ""
            inferida = "" if n == "" else ("anotada" if n >= 1 else "no anotada")
            doc, detalle = documentada(origen, clase, ptbxl_ok)
            obs = ""
            if inferida == "no anotada":
                resumen["inferidas_sin_anotar"] += 1
                if doc == "fuera":
                    resumen["confirmadas"] += 1
                    obs = "celda no anotada confirmada: la clase no figura en el vocabulario documentado"
                elif doc == "sin documentar":
                    resumen["sin_documentar"] += 1
                    obs = "celda no anotada que la documentación no permite confirmar"
                else:
                    resumen["contradichas"] += 1
                    obs = "REVISAR: la documentación cubre la clase pero no hay positivos"
            elif inferida == "anotada" and doc == "fuera":
                obs = "REVISAR: hay positivos de una clase que el vocabulario documentado no incluye"
            elif inferida == "anotada" and isinstance(n, int) and n <= 2:
                obs = "anotada solo nominalmente (≤ 2 positivos en entrenamiento)"
            filas.append([origen, clase, n, inferida, doc, detalle, FUENTES[origen], obs])
    with SALIDA.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["origen", "clase", "positivos_entrenamiento", "cobertura_inferida", "cobertura_documentada", "documentacion", "fuente", "observacion"])
        w.writerows(filas)
    print(f"{len(filas)} celdas; inferidas sin anotar: {resumen['inferidas_sin_anotar']} -> confirmadas por la documentación: "
          f"{resumen['confirmadas']}, sin poder confirmar: {resumen['sin_documentar']}, contradichas: {resumen['contradichas']}")
    for f in filas:
        if f[7]:
            print(f"  {f[0]:<22}{f[1]:<20}{str(f[2]):>6}  {f[3]:<11}{f[4]:<15}{f[7]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
