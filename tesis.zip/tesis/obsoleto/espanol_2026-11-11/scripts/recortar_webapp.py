"""Figura de la aplicación web del artículo IEEE: recorta, a partir de los PDF de evidencia/webapp/, la pantalla de resultado y la
primera página del informe del registro E00014 y las guarda como PNG en tesis/figuras/.

La evidencia es del paquete del sistema evaluado (P3), generada el 2026-11-10: el informe PDF lo emitió la aplicación local y la
pantalla es una captura de página completa (interfaz en inglés, 1280 px de ancho, escala 2); este script no ejecuta la aplicación.
La evidencia del paquete anterior está en evidencia/webapp/anterior/.
Uso, desde la raíz del repo:  python tesis/scripts/recortar_webapp.py
"""

from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

from PIL import Image, ImageChops

IEEE = Path(__file__).resolve().parents[1]
EVIDENCIA = IEEE / "evidencia" / "webapp"
FIGURAS = IEEE / "figuras"
DPI = 220
MARGEN = 12  # píxeles de aire alrededor del contenido

PANELES = {
    "webapp_resultado.png": EVIDENCIA / "pantalla_resultado.png",
    "webapp_informe.png": EVIDENCIA / "informe_E00014.pdf",
}
# Pantalla de resultado: del recuadro de la clase principal al final del trazado, en píxeles de la captura
# (caja en CSS medida en la página, [327, 182, 1225, 1490], por la escala 2).
CAJA_RESULTADO = (654, 364, 2450, 2980)


def primera_pagina(pdf: Path, carpeta: Path) -> Image.Image:
    base = carpeta / pdf.stem
    subprocess.run(["pdftoppm", "-r", str(DPI), "-f", "1", "-l", "1", "-png", str(pdf), str(base)], check=True, capture_output=True)
    return Image.open(next(carpeta.glob(f"{pdf.stem}-*.png"))).convert("RGB")


def recortar(im: Image.Image) -> Image.Image:
    fondo = Image.new("RGB", im.size, (255, 255, 255))
    caja = ImageChops.difference(im, fondo).getbbox()
    x0, y0, x1, y1 = caja
    return im.crop((max(x0 - MARGEN, 0), max(y0 - MARGEN, 0), min(x1 + MARGEN, im.width), min(y1 + MARGEN, im.height)))


def main() -> None:
    FIGURAS.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        for salida, pdf in PANELES.items():
            if not pdf.exists():
                raise SystemExit(f"falta {pdf}")
            if pdf.suffix == ".png":
                im = recortar(Image.open(pdf).convert("RGB").crop(CAJA_RESULTADO))
            else:
                im = recortar(primera_pagina(pdf, Path(tmp)))
            im.save(FIGURAS / salida, optimize=True)
            print(f"{salida}: {im.width} x {im.height} px")


if __name__ == "__main__":
    main()
