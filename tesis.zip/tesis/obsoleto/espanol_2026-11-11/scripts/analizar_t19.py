"""Análisis de las etapas 1, 2 y 3 de T19 (apartado 5 del protocolo): IC bootstrap, diferencias pareadas, métricas por clase y por origen.

Lee solo las predicciones de prueba ya guardadas de cada sistema en la prueba A y en la prueba B (``runs/t19/eval/<sistema>_<A|B>/predictions_test.csv``,
con su SHA-256 comprobado contra el registro) y ``data/cinc2020_12_origen/split_assignments.csv``. No entrena, no evalúa y no ajusta nada.
Etapa 1: P1, P2 y P3. Etapa 2: esos tres más la línea base CNN y las variantes entrenadas con la pérdida enmascarada (P1m, P2m y P3m), todos juntos para que
compartan los remuestreos; sus comparaciones nuevas son pareadas con la variante sin enmascarar (y la CNN con P1 y P3).
Etapa 3: las cuatro semillas nuevas de P1 y P2 con sus ensembles (S4) y las cuatro ablaciones desde P1 (S3). De S4 salen la media y la desviación típica entre las
5 semillas de cada receta (la original más cuatro) y, por semilla, la diferencia entre el ensemble y la mejor receta individual con su prueba de signos exacta
(bilateral); de S3, las diferencias pareadas con P1. Una semilla o una ablación son una sola ejecución: sus IC miden el muestreo de registros, no la variabilidad entre entrenamientos.

Bootstrap de percentiles (95 %) sobre registros: 1 000 remuestreos con semilla 0, los mismos para todos los sistemas de cada subconjunto (de ahí que las
diferencias entre sistemas sean pareadas). Cada remuestreo se aplica como pesos de multiplicidad sobre los registros originales, lo que equivale a calcular
sobre las filas repetidas; ``comprobar`` lo verifica contra scikit-learn, ``ecg.calibration`` y las ``metrics_global.csv`` de la evaluación.
La diferencia entre la prueba A y la B no es pareada (registros distintos): su IC sale de todas las diferencias entre los remuestreos de una y de otra.
El ECE se informa sin IC (ni en sus diferencias): ver ``ic``. ``media_remuestreos`` deja a la vista ese sesgo en todas las métricas.

Subconjuntos: ``completa``; ``sin registros sin clase`` (los que no tienen ninguna de las 12 clases, que el protocolo mantiene como negativos);
y, solo en la prueba A, cada origen. En la prueba A se añade el F1 macro enmascarado (diagnóstico: cada clase se puntúa solo en los orígenes que la
anotan según el entrenamiento); la prueba B no lo lleva porque su cobertura de etiquetas no está documentada.

Escribe en evidencia/t19_etapa<N>/: metricas_globales.csv, metricas_por_clase.csv, diferencias_pareadas.csv, diferencia_A_menos_B.csv, por_origen_A.csv,
prevalencia.csv, entradas.json y resumen.md (la etapa 3 añade semillas.csv, semillas_resumen.csv, ensemble_vs_mejor.csv, ensemble_vs_mejor_resumen.csv y entrenamiento.csv).
Etapa 6 (E16, desviación 5): las semillas 105 a 109 de P1 y P2 con sus ensembles, que con las de la etapa 3 suman 10 semillas por receta; mismo análisis de semillas que la etapa 3, sin ablaciones.
Etapa 7 (E7): evaluación externa en Chapman-Shaoxing (C) y Ningbo (D) según protocolo_externo_t19.md; métricas agregadas sobre las clases evaluables de cada origen.
Uso, desde la raíz del repo:  python tesis/scripts/analizar_t19.py [--etapa 1|2|3|4|6|7]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binomtest
from sklearn.metrics import average_precision_score, f1_score, roc_auc_score

IEEE = Path(__file__).resolve().parents[1]
REPO = IEEE.parent
RAIZ = Path(os.environ.get("T19_RAIZ", REPO))            # raíz con runs/, data/, saved/ y ecg/: el repositorio o el paquete de reproducibilidad
SALIDA = Path(os.environ["T19_SALIDA"]) if "T19_SALIDA" in os.environ else IEEE / "evidencia"       # carpeta que recibe t19_etapa<N>/
sys.path.insert(0, str(RAIZ))
from ecg.calibration import brier_score, expected_calibration_error  # noqa: E402
from ecg.schema import CLASS_NAMES  # noqa: E402

warnings.simplefilter("ignore", RuntimeWarning)         # medias de conjuntos vacíos en los orígenes pequeños: son NaN a propósito

EVAL = RAIZ / "runs" / "t19" / "eval"
ASIGNACION = RAIZ / "data" / "cinc2020_12_origen" / "split_assignments.csv"
REMUESTREOS, SEMILLA, INTERVALOS, C = 1000, 0, 15, len(CLASS_NAMES)
SEMILLAS_S4 = (101, 102, 103, 104)
SEMILLAS = ("orig",) + tuple(str(s) for s in SEMILLAS_S4)               # «orig»: P1 con semilla 42 y P2 con 43 (etapa 1)
SEMILLAS_E16 = (105, 106, 107, 108, 109)                                # E16: cinco semillas más de P1 y P2
SEMILLAS10 = SEMILLAS + tuple(str(s) for s in SEMILLAS_E16)
SEMILLAS_ETAPA = {3: SEMILLAS, 6: SEMILLAS10}                           # semillas que resume cada etapa con análisis de semillas
ABLACIONES = {"ABL_AUG": "t19_abl_aug", "ABL_LS": "t19_abl_ls", "ABL_ES": "t19_abl_es", "ABL_REG": "t19_abl_reg"}      # S3, desde P1
EXPERIMENTOS = {"P1": "t19_v1", "P2": "t19_v2", **{f"P{r}_S{s}": f"t19_v{r}_s{s}" for s in SEMILLAS_S4 for r in (1, 2)}, **ABLACIONES}       # sistema entrenado -> carpeta en saved/t19
EXPERIMENTOS6 = {"P1": "t19_v1", "P2": "t19_v2", **{f"P{r}_S{s}": f"t19_v{r}_s{s}" for s in SEMILLAS_S4 + SEMILLAS_E16 for r in (1, 2)}}
EXPERIMENTOS_ETAPA = {3: EXPERIMENTOS, 6: EXPERIMENTOS6}
METRICAS_SEMILLAS = ("f1_macro", "f1_micro", "f1_ponderado", "exacta", "auroc_macro", "auprc_macro", "ece", "brier")
MENOR_ES_MEJOR = ("ece", "brier")


def nombre_sistema(receta: str, semilla: str) -> str:
    return receta if semilla == "orig" else f"{receta}_S{semilla}"


ETAPAS = {                                                              # sistemas de cada etapa, comparaciones (a, b) = "a menos b" y sistemas con tabla por clase en el resumen
    1: {"sistemas": ("P1", "P2", "P3"), "comparaciones": (("P3", "P1"), ("P3", "P2"), ("P2", "P1")), "por_clase": ("P3",)},
    2: {"sistemas": ("P1", "P2", "P3", "P1m", "P2m", "P3m", "CNN"),    # m: pérdida enmascarada (S1); CNN: línea base (S2)
        "comparaciones": (("P1m", "P1"), ("P2m", "P2"), ("P3m", "P3"), ("CNN", "P1"), ("CNN", "P3")), "por_clase": ("P3m", "CNN")},
    3: {"sistemas": tuple(nombre_sistema(r, s) for s in SEMILLAS for r in ("P1", "P2", "P3")) + tuple(ABLACIONES),
        "comparaciones": tuple((nombre_sistema("P3", s), nombre_sistema(r, s)) for s in SEMILLAS for r in ("P1", "P2")) + tuple((a, "P1") for a in ABLACIONES),
        "por_clase": ()},
    6: {"sistemas": tuple(nombre_sistema(r, s) for s in SEMILLAS10 for r in ("P1", "P2", "P3")),
        "comparaciones": tuple((nombre_sistema("P3", s), nombre_sistema(r, s)) for s in SEMILLAS10 for r in ("P1", "P2")), "por_clase": ()},
    4: {"sistemas": ("P1", "P2", "P3", "P1t", "P2t", "P3t"),            # EXPLORATORIO: t = calibración por temperatura (una T por clase) en lugar de la afín
        "comparaciones": (("P1", "P1t"), ("P2", "P2t"), ("P3", "P3t")), "por_clase": ()},         # afín menos temperatura
}
PRUEBAS = {"A": "test", "B": "test_b"}                                  # prueba -> partición de split_assignments.csv
SHA256 = {"P1_A": "4c0e0d43b3db35d935e7f7a93e6ebfc79fdcba02117cf86a6bed954b33d9c084", "P2_A": "86c576dafa8c42f95587d43ac4640a266a6d049113a67f6ef8815663a2bb0ecc",
          "P3_A": "22da6de901719872ab688de7e0a425c4947fd0e9a57dc6cb4c5f94a18b04121f", "P1_B": "9438615729e8afae520e974a4cb069907ec3ee118f0af83090622308cab37410",
          "P2_B": "acbb0f12112be3a92f27659e121ef70209890dc13ecc33036530c9636543c74f", "P3_B": "ce65a513052fb513f1e45a17b46b42ccdd4405daa334b7e78793b7996fbade51",
          "CNN_A": "7819e400fd516e72b5b25339d3610d4827fcb060e8841fdbe9dbcbd73add5097", "CNN_B": "3e7a8f41aaace159e9e0b165bd7a92fd2222d70c537d2f3ed04b19bb50a816cb",
          "P1m_A": "428836e65547cafc1444cae608e30b820126621808f8e3b087ff57aac7e7756e", "P1m_B": "954df61be06ee0c8e4a4b4edb4de4e53fdd90329a6ec727a11e61034cd6ac025",
          "P2m_A": "38f51602d26c94456189a0e68d9c8cfe2b5671ceb8fd4a6f1042542cca1d39af", "P2m_B": "63e7ffff730e17cec783c568103555a88cade447d860ab740eed25810c421946",
          "P3m_A": "638abdab2bd6c83017d2552363bbb4f4fe8b3a74ddbb8a4957adc89287fc84e1", "P3m_B": "04287fc63ccc2a2a0f35c4e7ad2e033d75c0803fdfaf064df011bf3f8fc23a2c",
          "P1_S101_A": "4bea5406086597589e7d710b303f7956747ba68a875573db8a5dc889d3d3f883", "P1_S101_B": "7d3d2021767cb7cfb810cb25b9129b7334d25479c0f83586ecc5bb5ecdf21832",
          "P2_S101_A": "c8cfb3b86fab70afe1fd9695a591ace36548ff9fc2d1cd072519049c03f4d43b", "P2_S101_B": "210f879b3a413d8829b652adcba6b7e614c4ec2819e336abfbb4e52f3230f8d5",
          "P3_S101_A": "e92284c92170ff456f6553ec54df78da969f3c1ef46adf953bfa9c5fffa7842d", "P3_S101_B": "f02d8cac88465449ff5a7099d8aa0c27899804df28e122de67587196e0e30d89",
          "P1_S102_A": "2a4c06652df420667c4557b25f5145c6d3b0a6314eff1e8ca6a9a429e322cb49", "P1_S102_B": "514202e858d23d0751ec75c11296f400f7847495bb8f835bb4271233a2da4105",
          "P2_S102_A": "f79186f6e4ce9816f6f4474c85b4fae282695f23e439b81db62ad8c4bec3ad9c", "P2_S102_B": "72b062a29b60e011877d7f30bcd5f87ee1a8ad557378ff8f717f694ba2d699cc",
          "P3_S102_A": "c8f8392275ec183f004b9a0ae0eb8c60da8e2ee264f21a27d35433f6cb535bed", "P3_S102_B": "59628deac64128cf29b64ed5620ec38f1e91a26294b5021d6e02f4fdb9497def",
          "P1_S103_A": "6b4e4f337c5111422f0045f1ca54e5b9217e78c5e4b8098de3577a79f4bde5fd", "P1_S103_B": "a65c2de338a0af851b2529912cc86ce3c0c8ff7e3527c02e2bfbf3b71fe01001",
          "P2_S103_A": "615e3f948e76f35c89abbdd980b5e1d2215aad0ce2770ffc9e85aeda0cecc494", "P2_S103_B": "8b09c0f23d44572694711490c18afe055127ffb4ae5b49b68bb9336c7fe8b09c",
          "P3_S103_A": "4e92b8efdd7c2a25458589f2269e1955b8c25b65739c45cda3a01f87c44d0f3a", "P3_S103_B": "689aa4c1bb411d52c85cee3404e3714ffe4b6ce93e334c50396ed7c2611bf7c5",
          "P1_S104_A": "94ea23e6d40226070f77cb4452ebd995792c80277699f233be8d997fb92f8b23", "P1_S104_B": "34fef324bbe0fd131d49fb15aa59719b9990e58603f678d6f97cf3203b6e7fa2",
          "P2_S104_A": "bf1def10e27154b72ecd933d34668168b0ecd1686297c1c91ba806d33db170df", "P2_S104_B": "03513ce7e00eee4af5b1e880b567798f32d5e18cbec6d27d9c7367fd7a4bc8d9",
          "P3_S104_A": "55d73488f4e3979ebbd88ce781a0ea95b29ba79006492d7ea06c7454eeb94c05", "P3_S104_B": "9f24b269bbc46803d3c7fc22e4553b77e70b6bfd7e737fc18c2c5abc30f23efc",
          "ABL_AUG_A": "9d8614e37b73f5b8941f42b02897b1201a30687e19874ef6ed4652af7869831b", "ABL_AUG_B": "b363d56ff714261a0cfe478ea331bcf06944d0ab21c49432dffe56354e93cb78",
          "ABL_LS_A": "1d92f2ad9f063a8ce0df7f026c32f19f701e90b06b359731281153bcfd70eac3", "ABL_LS_B": "314655ace4eda31fb1058d357d10317325253d099af3b189b220391f995f440d",
          "ABL_ES_A": "3e561bc14ff31d274aefa523d70338aedad607bed2e7a4d397d51d537fc8d765", "ABL_ES_B": "46392c6e74c749457cc1cd58b19e65c06677e2d0715258e3f7aadc2a1127d60b",
          "ABL_REG_A": "8dedd7ed6798b1e600c040a3cb13234a502c0bc5660dbbc4061ad14425b6218f", "ABL_REG_B": "6705918aea14a0caa5bb45731f633134bc20730bc2a581e15611fc88be63ec6c",
          "P1t_A": "c5802cb7a0446106562baa441655807d39a97bce1a6a85d4b783348afc904202", "P1t_B": "421e10fab866c4b8bf9a37dbe9ecae86adfdc70dcae88b013eef93aa35131b54",
          "P2t_A": "cf9024c95eb016fd3b9307825993a2413cb74af2c4c605335fbf613f93da7c86", "P2t_B": "62e7e7b7fb93d7fa4534b0769e23439fb82311c88aaedf39a28b22a319b4a143",
          "P3t_A": "c361ee20c754da7ef8be8f1e4f50aa36f251061c6b90a26e9b927cdfe6827c2c", "P3t_B": "2de14dec174b3c6b39541deb9b59673bd1cdc7b4352963b810534b461a4f0eb4",
          "P1_S105_A": "97be8b0d524bf7e430279b793dc2f5573ebc6b04659fddc7ebc9b724422ef43d", "P1_S105_B": "880145e7134c4bb02f84780ec6acad0d5cc326821b7b73489edbf425234c100a",
          "P2_S105_A": "f000959bafce1e721e854ce2106a510e31680b7a5c7e10cdeee2984603ee34a8", "P2_S105_B": "ffb76b98e77f0b1619c9edbd464e2d0c05c1f7602bd5cc21a66d030e00954028",
          "P3_S105_A": "053299998dd482aba9a628e4587d2399697f597d9c1f402eecd1f3b67e0bb562", "P3_S105_B": "fbaa91bdba0dd8c82052af9898e6ccc9a236552ef6c79ef1246767e4549ea90f",
          "P1_S106_A": "caa1056c57e24a7b6cf93fa40e08feb0bae743f81fb3b12d0c75579d7366ecae", "P1_S106_B": "a5f859adb294bd1f30e86b49558729b1e31ed741ade91ae43ee206ccb405fcaa",
          "P2_S106_A": "a0d71cf207e234a4d31ffae916c52a9837f4fee0ac8bf84bac96951ddad069e5", "P2_S106_B": "fe04473843e5c5a8819ce38a28c2cfe6b79bb410752c18b0516a3af587c383fe",
          "P3_S106_A": "2ef924b0eb29f47456c4f08b8843f5ab24af929452d2c25c1b16d28a574f3ee6", "P3_S106_B": "bf8928adf56856bdaccb829c429fb5abacebaa693aef250122f77ef86a3fd290",
          "P1_S107_A": "0ef8c230120891d0474600e94dab3d0237040bef19738af05ab11f965188722e", "P1_S107_B": "945f1736c0e86bb0de6b7062a4dd67928de14ac71de3ffe56de06d8605eeb056",
          "P2_S107_A": "2dcdc1e2725377be90e514d146d9154df8bfc1158f882f983cedd0ebb49f5ba8", "P2_S107_B": "2c8b6ba446d7a51c01a4c56483a24f06a84dcba670ee957acbc523beaf74e379",
          "P3_S107_A": "b95ee993b43ca835690666747cc9e27bea54afd9084ba2062787338d1f697ac6", "P3_S107_B": "ca9525f52981f728b08f05daf132caf0132a356ec5a12882d08bb7abdaa225c7",
          "P1_S108_A": "c89c70f53f90a7156dc1f874afcaf26a5e8d72e8bbefe53644ff61bc3382be45", "P1_S108_B": "d96dc661234f8eaff9868a03ea2e57bc13623a315d461406c9279758fe4bac19",
          "P2_S108_A": "13257d37916102c5e237b82b48d61fbe3301e02fb36e3fd32c1ac097728465b9", "P2_S108_B": "d48b8c46595236fa664632b675c9ba8c2fa2e8a38ce472e303cab667461be2ef",
          "P3_S108_A": "b2bba079cd5101c495adfb209ceee3e6d5c23ded946e4ad3317c53b4372c49ce", "P3_S108_B": "24d79763a10569e3896f94b841df3c83eabe9e49f273583ab5a41c18e55e3128",
          "P1_S109_A": "f2281e1687c4de65f30c032e1bdca8be6e96e7a304559062030977e4b5b40d62", "P1_S109_B": "3de9d56c26dfc7d4e745c4234fc81a861413723636127def17df21e576c70ba8",
          "P2_S109_A": "a7f070ff0be7c3a57d1b7f0f4f8d5551d5d57c96f46c1a000ae5e2a241c0cd59", "P2_S109_B": "0ccea18383b09521add3cd432316ab24218de8455cc93d9cbe30bc8a99e35271",
          "P3_S109_A": "59f078586404a474d8d2bdcff94b987fc744a0cf5bdcbb641b0b60dd1ad23654", "P3_S109_B": "29c56a7c35ff301e3de949409837d8f2afc1b4c7c5038121c48c54b1471e5a60"}
POR_CLASE = ("f1", "prec", "sens", "espec", "auroc", "auprc")
GLOBALES = ("f1_macro", "f1_micro", "f1_ponderado", "exacta", "auroc_macro", "auroc_ponderado", "auprc_macro", "ece", "brier",
            "prec_macro", "sens_macro", "espec_macro", "card_real", "card_pred")
ORIGEN = ("f1_macro", "f1_macro_anotadas", "f1_micro", "exacta", "auroc_macro", "auprc_macro", "ece", "brier")      # lo que se informa por origen
MIN_N_IC = 100                                                                                                      # por debajo, el IC por origen no informa


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


class Sistema:
    """Predicciones de un sistema sobre un conjunto de registros, con lo precalculado para evaluar cualquier remuestreo (pesos ``w``) sin reordenar."""

    def __init__(self, y: np.ndarray, p: np.ndarray, yh: np.ndarray, celdas: np.ndarray | None = None):
        y, p, yh = y.astype(float), p.astype(float), yh.astype(float)
        self.yt, self.pt = np.ascontiguousarray(y.T), np.ascontiguousarray(p.T)
        self.tp, self.fp, self.fn = y * yh, (1 - y) * yh, y * (1 - yh)
        self.cuad, self.exacta, self.card = (p - y) ** 2, (y == yh).all(1).astype(float), (y.sum(1), yh.sum(1))
        grupos = [np.unique(col, return_inverse=True) for col in self.pt]                                   # registros con la misma puntuación empatan
        self.ng, self.inv = [len(g[0]) for g in grupos], [g[1].ravel() for g in grupos]
        bordes = np.linspace(0, 1, INTERVALOS + 1)
        self.bin = [np.clip(np.digitize(col, bordes) - 1, 0, INTERVALOS - 1) for col in self.pt]
        self.enmascarado = None if celdas is None else tuple(m * celdas for m in (self.tp, self.fp, self.fn))


def cociente(num: np.ndarray, den: np.ndarray) -> np.ndarray:
    return np.divide(num, den, out=np.full(num.shape, np.nan), where=den > 0)


def f1_de(tp, fp, fn) -> np.ndarray:
    den = 2 * tp + fp + fn
    return np.divide(2 * tp, den, out=np.zeros(np.shape(den)), where=den > 0)


def auc_ap(inv: np.ndarray, ng: int, y: np.ndarray, w: np.ndarray) -> tuple[float, float]:
    """AUROC y precisión media de una clase con pesos de multiplicidad; NaN si falta algún positivo (AP) o algún negativo (AUROC)."""
    wp, wn = np.bincount(inv, w * y, ng), np.bincount(inv, w * (1 - y), ng)               # por grupo de puntuación, ascendente
    pos, neg = wp.sum(), wn.sum()
    if pos == 0:
        return np.nan, np.nan
    auc = float(((np.cumsum(wn) - wn / 2) * wp).sum() / (pos * neg)) if neg > 0 else np.nan
    wp_d, tp_d, fp_d = wp[::-1], np.cumsum(wp[::-1]), np.cumsum(wn[::-1])                   # descendente: umbrales de mayor a menor puntuación
    m = wp_d > 0
    return auc, float((wp_d[m] * tp_d[m] / (tp_d[m] + fp_d[m])).sum() / pos)


def estadisticas(s: Sistema, w: np.ndarray, anotadas: np.ndarray | None = None) -> dict:
    """Todas las métricas de un conjunto de registros ponderado por ``w``. Con ``w`` de unos son las métricas puntuales."""
    total, c = w.sum(), len(s.yt)                                                                          # c: columnas del sistema (las 12 clases, o las evaluables de un origen)
    tp, fp, fn = w @ s.tp, w @ s.fp, w @ s.fn
    soporte, tn = tp + fn, total - tp - fp - fn
    f1, prec = f1_de(tp, fp, fn), np.divide(tp, tp + fp, out=np.zeros(c), where=tp + fp > 0)
    pares = np.array([auc_ap(s.inv[i], s.ng[i], s.yt[i], w) for i in range(c)])
    auroc, auprc = pares[:, 0], pares[:, 1]
    sens, espec = cociente(tp, soporte), cociente(tn, tn + fp)
    ece = np.mean([np.abs(np.bincount(s.bin[i], w * s.yt[i], INTERVALOS) - np.bincount(s.bin[i], w * s.pt[i], INTERVALOS)).sum() / total for i in range(c)])
    r = {"f1_macro": f1.mean(), "f1_micro": float(f1_de(tp.sum(), fp.sum(), fn.sum())), "f1_ponderado": (soporte * f1).sum() / soporte.sum(),
         "exacta": w @ s.exacta / total, "auroc_macro": np.nanmean(auroc), "auroc_ponderado": np.nansum(soporte * auroc) / soporte[~np.isnan(auroc)].sum(),
         "auprc_macro": np.nanmean(auprc), "ece": ece, "brier": (w @ s.cuad).sum() / (total * c), "prec_macro": prec.mean(),
         "sens_macro": np.nanmean(sens), "espec_macro": np.nanmean(espec), "card_real": w @ s.card[0] / total, "card_pred": w @ s.card[1] / total,
         "pc_f1": f1, "pc_prec": prec, "pc_sens": sens, "pc_espec": espec, "pc_auroc": auroc, "pc_auprc": auprc}
    if anotadas is not None:
        r["f1_macro_anotadas"] = f1[anotadas].mean()
    if s.enmascarado is not None:
        r["f1_macro_enmascarado"] = f1_de(*(w @ m for m in s.enmascarado)).mean()
    return r


def apilar(lista: list[dict]) -> dict:
    return {k: np.array([d[k] for d in lista]) for k in lista[0]}


def ic(x: np.ndarray, metrica: str = "") -> tuple:
    """Percentiles 2.5 y 97.5. El ECE no lleva IC: con intervalos fijos su estimador sube al remuestrear (en la prueba A la media de los
    remuestreos queda un 30 % por encima del valor puntual, que cae fuera de su propio intervalo), así que el IC por percentiles no es válido."""
    if metrica == "ece":
        return np.nan, np.nan
    return tuple(np.nanpercentile(x, [2.5, 97.5], axis=0))


def analizar(sistemas: dict[str, Sistema], anotadas: np.ndarray | None = None) -> tuple[dict, dict]:
    """(estadísticas puntuales, estadísticas de los 1 000 remuestreos) de cada sistema; el mismo remuestreo para todos."""
    n = len(next(iter(sistemas.values())).exacta)
    puntual = {k: estadisticas(s, np.ones(n), anotadas) for k, s in sistemas.items()}
    idx = np.random.default_rng(SEMILLA).integers(0, n, size=(REMUESTREOS, n))
    boot = {k: [] for k in sistemas}
    for fila in idx:
        w = np.bincount(fila, minlength=n).astype(float)
        for k, s in sistemas.items():
            boot[k].append(estadisticas(s, w, anotadas))
    return puntual, {k: apilar(v) for k, v in boot.items()}


def comprobar(s: Sistema, y, p, yh, fila: np.ndarray, referencia: pd.Series, anotadas=None) -> None:
    """El cálculo con pesos coincide con scikit-learn y con ecg.calibration (muestra completa y un remuestreo) y con la evaluación original."""
    for sel in (np.arange(len(y)), fila):
        ys, ps, yhs = y[sel], p[sel], yh[sel]
        e = estadisticas(s, np.bincount(sel, minlength=len(y)).astype(float))
        auroc = [roc_auc_score(ys[:, i], ps[:, i]) for i in range(ys.shape[1])]
        auprc = [average_precision_score(ys[:, i], ps[:, i]) for i in range(ys.shape[1])]
        esperado = {"f1_macro": f1_score(ys, yhs, average="macro", zero_division=0), "f1_micro": f1_score(ys, yhs, average="micro", zero_division=0),
                    "f1_ponderado": f1_score(ys, yhs, average="weighted", zero_division=0), "exacta": (ys == yhs).all(1).mean(),
                    "auroc_macro": np.mean(auroc), "auprc_macro": np.mean(auprc), "ece": expected_calibration_error(ys, ps, INTERVALOS), "brier": brier_score(ys, ps),
                    "card_real": ys.sum(1).mean(), "card_pred": yhs.sum(1).mean()}
        for k, v in esperado.items():
            assert abs(e[k] - v) < 1e-9, f"{k}: {e[k]} frente a {v}"
        assert np.allclose(e["pc_auroc"], auroc, atol=1e-9) and np.allclose(e["pc_auprc"], auprc, atol=1e-9)
        assert np.allclose(e["pc_f1"], f1_score(ys, yhs, average=None, zero_division=0), atol=1e-9)
    e = estadisticas(s, np.ones(len(y)))
    for propio, original in (("f1_macro", "f1_macro"), ("f1_micro", "f1_micro"), ("prec_macro", "precision_macro"), ("sens_macro", "sensitivity_macro"),
                             ("espec_macro", "specificity_macro"), ("auroc_macro", "auroc_macro"), ("auprc_macro", "auprc_macro"), ("exacta", "exact_match_ratio")):
        # el CSV guarda las probabilidades con ~8 dígitos y la evaluación original las tenía en memoria: AUROC y AUPRC dependen de los empates y difieren
        # hasta ~1e-5 (en la calibración por temperatura, con más probabilidades casi nulas, 7e-6); las demás métricas coinciden a 1e-6
        tolerancia = 1e-5 if propio in ("auroc_macro", "auprc_macro") else 1e-6
        assert abs(e[propio] - referencia[original]) < tolerancia, f"{propio}: {e[propio]} frente a {referencia[original]} de la evaluación"


def cargar(sistemas: tuple[str, ...]) -> tuple[dict, pd.DataFrame, dict]:
    """Predicciones por prueba y sistema, ya alineadas, con las SHA-256 comprobadas."""
    asign = pd.read_csv(ASIGNACION)
    datos, hashes = {}, {}
    for prueba, particion in PRUEBAS.items():
        for k in sistemas:
            ruta = EVAL / f"{k.lower()}_{prueba}" / "predictions_test.csv"
            hashes[f"{k}_{prueba}"] = sha256(ruta)
            assert hashes[f"{k}_{prueba}"] == SHA256[f"{k}_{prueba}"], f"{ruta} no es la predicción registrada"
            d = pd.read_csv(ruta)
            datos[k, prueba] = (d["record_name"].to_numpy(), d[[f"true_{c}" for c in CLASS_NAMES]].to_numpy(np.uint8),
                                d[[f"prob_{c}" for c in CLASS_NAMES]].to_numpy(float), d[[f"pred_{c}" for c in CLASS_NAMES]].to_numpy(np.uint8))
        nombres, y = datos[sistemas[0], prueba][0], datos[sistemas[0], prueba][1]
        for k in sistemas:
            assert (datos[k, prueba][0] == nombres).all() and (datos[k, prueba][1] == y).all(), f"{k}/{prueba}: registros o etiquetas distintos"
        esperados = asign[asign["split"] == particion]
        assert set(nombres) == set(esperados["record_name"]) and len(nombres) == len(esperados), f"la prueba {prueba} no coincide con {particion}"
    return datos, asign, hashes


def construir(datos, prueba, sistemas, seleccion=None, celdas=None, columnas=None) -> dict[str, Sistema]:
    sel = slice(None) if seleccion is None else seleccion
    col = slice(None) if columnas is None else columnas
    return {k: Sistema(datos[k, prueba][1][sel][:, col], datos[k, prueba][2][sel][:, col], datos[k, prueba][3][sel][:, col], None if celdas is None else celdas[sel]) for k in sistemas}


def analisis_semillas(g: pd.DataFrame, SEMILLAS: tuple = SEMILLAS, PRUEBAS: tuple = tuple(PRUEBAS)) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """S4 sobre los valores puntuales de la muestra completa: valores por semilla, media y desviación típica (n - 1) entre las semillas de cada receta (5 en la etapa 3, 10 en la 6), y por semilla
    la mejora del ensemble sobre la mejor receta individual (positiva = el ensemble es mejor; en ECE y Brier, donde menos es mejor, es mejor individual menos ensemble)
    con el recuento de semillas positivas y la prueba de signos exacta bilateral (los empates no cuentan)."""
    v = {(r.sistema, r.prueba, r.metrica): r.valor for r in g[g.subconjunto == "completa"].itertuples()}
    valores, resumen_, mejoras, signos = [], [], [], []
    for prueba in PRUEBAS:
        for m in METRICAS_SEMILLAS:
            for receta in ("P1", "P2", "P3"):
                x = np.array([v[nombre_sistema(receta, s), prueba, m] for s in SEMILLAS])
                valores += [{"receta": receta, "semilla": s, "prueba": prueba, "metrica": m, "valor": val} for s, val in zip(SEMILLAS, x)]
                resumen_.append({"receta": receta, "prueba": prueba, "metrica": m, "semillas": len(x), "media": x.mean(), "desviacion": x.std(ddof=1), "min": x.min(), "max": x.max()})
            signo, mejora = (-1 if m in MENOR_ES_MEJOR else 1), []
            for s in SEMILLAS:
                p1, p2, ens = (v[nombre_sistema(r, s), prueba, m] for r in ("P1", "P2", "P3"))
                mejor, receta = (p1, "P1") if signo * p1 >= signo * p2 else (p2, "P2")
                mejora.append(signo * (ens - mejor))
                mejoras.append({"prueba": prueba, "metrica": m, "semilla": s, "ensemble": ens, "mejor_individual": mejor, "receta_mejor": receta, "mejora": mejora[-1]})
            mejora = np.array(mejora)
            pos, neg = int((mejora > 0).sum()), int((mejora < 0).sum())
            signos.append({"prueba": prueba, "metrica": m, "semillas": len(mejora), "positivas": pos, "negativas": neg, "empates": len(mejora) - pos - neg,
                           "p_signos_bilateral": binomtest(pos, pos + neg, 0.5).pvalue if pos + neg else np.nan, "mejora_media": mejora.mean(), "mejora_desviacion": mejora.std(ddof=1)})
    return tuple(pd.DataFrame(x) for x in (valores, resumen_, mejoras, signos))


def entrenamiento(experimentos: dict = EXPERIMENTOS) -> pd.DataFrame:
    """Parámetros, épocas, mejor época y minutos de cada sistema entrenado de la etapa 3 (y de P1 y P2), de su training_summary.json."""
    filas = []
    for k, exp in experimentos.items():
        rutas = sorted((RAIZ / "saved" / "t19" / exp).glob("*/training_summary.json"))
        assert len(rutas) == 1, f"se esperaba un solo training_summary.json en saved/t19/{exp}"
        s = json.loads(rutas[0].read_text(encoding="utf-8"))
        filas.append({"sistema": k, "experimento": exp, "parametros": s["num_parameters"]["trainable"], "epocas": s["epochs_completed"],
                      "mejor_epoca": [h for h in s["history"] if h["improved"]][-1]["epoch"], "minutos": round(s["total_seconds"] / 60, 1), "monitor": s["monitor"],
                      "best_pt_sha256": sha256(rutas[0].parent / "best.pt")})
    return pd.DataFrame(filas)


def fmt(v, lo=None, hi=None, d=3) -> str:
    texto = "—" if v is None or np.isnan(v) else f"{v:.{d}f}"
    return texto if lo is None or np.isnan(lo) else f"{texto} ({lo:.{d}f} a {hi:.{d}f})"


def main(etapa: int) -> int:
    if etapa == 7:
        return main_externo()
    sis, comparaciones = ETAPAS[etapa]["sistemas"], ETAPAS[etapa]["comparaciones"]
    salida = SALIDA / f"t19_etapa{etapa}"
    salida.mkdir(parents=True, exist_ok=True)
    datos, asign, hashes = cargar(sis)
    anotada = {o: (g[CLASS_NAMES].sum() >= 1).to_numpy() for o, g in asign[asign["split"] == "train"].groupby("source_db")}     # regla de compute_cell_mask
    origen_de = dict(zip(asign["record_name"], asign["source_db"]))
    globales, clases, difs, por_origen = [], [], [], []

    def registrar(destino, prueba, sub, puntual, boot, claves, n, extra=None):
        for k in sis:
            for m in claves:
                if m in puntual[k]:
                    lo, hi = ic(boot[k][m], m)
                    destino.append({"prueba": prueba, "subconjunto": sub, "sistema": k, "n": n, "metrica": m, "valor": puntual[k][m], "lo": lo, "hi": hi,
                                    "media_remuestreos": float(np.nanmean(boot[k][m])), **(extra or {})})
        for a, b in comparaciones:
            for m in claves:
                if m in puntual[a]:
                    d = boot[a][m] - boot[b][m]
                    lo, hi = ic(d, m)
                    difs.append({"prueba": prueba, "subconjunto": sub, "comparacion": f"{a} menos {b}", "metrica": m, "diferencia": puntual[a][m] - puntual[b][m],
                                 "lo": lo, "hi": hi, "prop_positiva": float(np.mean(d[~np.isnan(d)] > 0))})

    boots = {}
    for prueba in PRUEBAS:
        nombres, y = datos[sis[0], prueba][0], datos[sis[0], prueba][1]                                   # registros y etiquetas: iguales en todos los sistemas
        celdas = None
        if prueba == "A":
            origen = np.array([origen_de[r] for r in nombres])
            celdas = np.stack([anotada[o] for o in origen]).astype(float)
        sistemas = construir(datos, prueba, sis, celdas=celdas)
        for k in sis:
            r = pd.read_csv(EVAL / f"{k.lower()}_{prueba}" / "metrics_global.csv").query("split == 'test'").iloc[0]
            comprobar(sistemas[k], *(datos[k, prueba][i] for i in (1, 2, 3)), np.random.default_rng(SEMILLA).integers(0, len(y), size=len(y)), r)
        print(f"prueba {prueba}: el cálculo con pesos coincide con scikit-learn y con la evaluación original ({len(sis)} sistemas)")

        puntual, boot = analizar(sistemas)
        boots[prueba] = (puntual, boot)
        extra_claves = GLOBALES + (("f1_macro_enmascarado",) if prueba == "A" else ())
        registrar(globales, prueba, "completa", puntual, boot, extra_claves, len(y))
        for k in sis:                                                                                       # por clase, mismos remuestreos
            for m in POR_CLASE:
                lo, hi = ic(boot[k]["pc_" + m])
                for i, c in enumerate(CLASS_NAMES):
                    clases.append({"prueba": prueba, "sistema": k, "clase": c, "positivos": int(y[:, i].sum()), "prevalencia": y[:, i].mean(), "metrica": m,
                                   "valor": puntual[k]["pc_" + m][i], "lo": lo[i], "hi": hi[i]})
        for a, b in comparaciones:
            for m in POR_CLASE:
                d = boot[a]["pc_" + m] - boot[b]["pc_" + m]
                lo, hi = ic(d)
                for i, c in enumerate(CLASS_NAMES):
                    difs.append({"prueba": prueba, "subconjunto": "completa, por clase: " + c, "comparacion": f"{a} menos {b}", "metrica": m,
                                 "diferencia": puntual[a]["pc_" + m][i] - puntual[b]["pc_" + m][i], "lo": lo[i], "hi": hi[i], "prop_positiva": float(np.mean(d[:, i] > 0))})

        con_clase = y.sum(1) > 0                                                                           # sin los registros sin ninguna clase
        puntual_s, boot_s = analizar(construir(datos, prueba, sis, con_clase))
        registrar(globales, prueba, "sin registros sin clase", puntual_s, boot_s, GLOBALES, int(con_clase.sum()))

        if prueba == "A":
            for o in sorted(set(origen)):
                m_o = origen == o
                p_o, b_o = analizar(construir(datos, prueba, sis, m_o), anotada[o])
                registrar(por_origen, prueba, o, p_o, b_o, ORIGEN, int(m_o.sum()),
                          {"positivos": int(y[m_o].sum()), "clases_anotadas": int(anotada[o].sum()), "ic_informativo": bool(m_o.sum() >= MIN_N_IC)})

    # A menos B de cada sistema (registros distintos: IC con todas las diferencias entre remuestreos de una y otra)
    a_b = []
    for k in sis:
        for m in GLOBALES:
            sa, sb = boots["A"][1][k][m], boots["B"][1][k][m]
            lo, hi = ic(np.subtract.outer(sa, sb).ravel(), m)
            a_b.append({"sistema": k, "metrica": m, "valor_A": boots["A"][0][k][m], "valor_B": boots["B"][0][k][m], "diferencia": boots["A"][0][k][m] - boots["B"][0][k][m], "lo": lo, "hi": hi})

    por_split = asign.groupby("split")
    prev = [{"clase": c, "particion": s, "registros": len(g), "positivos": int(g[c].sum()), "prevalencia": g[c].mean()} for s, g in por_split for c in CLASS_NAMES]
    tablas = {"metricas_globales": globales, "metricas_por_clase": clases, "diferencias_pareadas": difs, "diferencia_A_menos_B": a_b, "por_origen_A": por_origen, "prevalencia": prev}
    if etapa in SEMILLAS_ETAPA:
        for nombre, df in zip(("semillas", "semillas_resumen", "ensemble_vs_mejor", "ensemble_vs_mejor_resumen"), analisis_semillas(pd.DataFrame(globales), SEMILLAS_ETAPA[etapa])):
            tablas[nombre] = df.to_dict("records")
        tablas["entrenamiento"] = entrenamiento(EXPERIMENTOS_ETAPA[etapa]).to_dict("records")
    for nombre, filas in tablas.items():
        pd.DataFrame(filas).to_csv(salida / f"{nombre}.csv", index=False, float_format="%.6f", encoding="utf-8", lineterminator="\n")
    (salida / "entradas.json").write_text(json.dumps({"predicciones_sha256": hashes, "split_assignments_sha256": sha256(ASIGNACION),
        "remuestreos": REMUESTREOS, "semilla": SEMILLA, "intervalos_ece": INTERVALOS, "numpy": np.__version__, "pandas": pd.__version__}, indent=2) + "\n", encoding="utf-8", newline="\n")
    (salida / "resumen.md").write_text(resumen(tablas, etapa), encoding="utf-8", newline="\n")
    print(f"escrito en {salida}")
    return 0


def resumen3(t: dict, etapa: int = 3) -> str:
    """Resumen de la etapa 3 (semillas S4 y ablaciones S3) o de la 6 (10 semillas, sin ablaciones); el detalle por sistema, clase y origen está en los CSV."""
    SEMILLAS, n_sem = SEMILLAS_ETAPA[etapa], len(SEMILLAS_ETAPA[etapa])
    g, d, sem, res, mej, sig, ent = (pd.DataFrame(t[k]) for k in ("metricas_globales", "diferencias_pareadas", "semillas", "semillas_resumen", "ensemble_vs_mejor",
                                                                  "ensemble_vs_mejor_resumen", "entrenamiento"))
    L = [f"# Etapa 3 de T19: semillas (S4) y ablaciones (S3)" if etapa == 3 else f"# Etapa 6 de T19 (E16): {n_sem} semillas de P1 y P2 y sus ensembles", "",
         f"Valores con tres decimales. Cada semilla y cada ablación es una sola ejecución de entrenamiento; los IC del 95 % (bootstrap de percentiles, {REMUESTREOS} remuestreos de registros, "
         f"semilla {SEMILLA}, los mismos para todos los sistemas) miden el muestreo de registros, no la variabilidad entre entrenamientos, que es lo que muestran las semillas. "
         "Generado por `scripts/analizar_t19.py`; el detalle por sistema, clase y origen está en los CSV de esta carpeta.", ""]
    nombres_prueba = {"A": "Prueba A", "B": "Prueba B (Georgia)"}
    otras = "las otras cuatro son 101 a 104" if etapa == 3 else "las otras nueve son 101 a 109"
    L += [f"## Semillas: media y desviación típica entre las {n_sem} semillas de cada receta", "",
          f"La original es la semilla 42 para P1 y la 43 para P2; {otras} en ambas. P3 es el ensemble de P1 y P2 de la misma semilla.", ""]
    for prueba in PRUEBAS:
        L += [f"### {nombres_prueba[prueba]}", "", "| Métrica | P1 | P2 | P3 (ensemble) |", "|---|---|---|---|"]
        for m in METRICAS_SEMILLAS:
            fila = [res[(res.prueba == prueba) & (res.metrica == m) & (res.receta == r)].iloc[0] for r in ("P1", "P2", "P3")]
            L.append(f"| {m} | " + " | ".join(f"{f.media:.3f} ± {f.desviacion:.3f} ({f['min']:.3f} a {f['max']:.3f})" for f in fila) + " |")
        L.append("")
    L += ["### F1 macro por semilla", "", "| Prueba | Semilla | P1 | P2 | P3 (ensemble) |", "|---|---|---|---|---|"]
    for prueba in PRUEBAS:
        for s in SEMILLAS:
            v = [sem[(sem.prueba == prueba) & (sem.metrica == "f1_macro") & (sem.semilla == s) & (sem.receta == r)].valor.iloc[0] for r in ("P1", "P2", "P3")]
            L.append(f"| {prueba} | {s} | " + " | ".join(f"{x:.3f}" for x in v) + " |")
    L += ["", "## Ensemble menos mejor receta individual, por semilla", "",
          "Positivo = el ensemble es mejor (en ECE y Brier, mejor individual menos ensemble). La prueba de signos es exacta y bilateral sobre las "
          f"{n_sem} semillas: con {n_sem} positivas de {n_sem} el valor p es {2 * 0.5 ** n_sem:.4f}, de modo que con este número de semillas no puede bajar de ese valor.", "",
          "| Prueba | Métrica | Semillas con mejora | Valor p | Mejora media ± desviación | " + " | ".join(f"Semilla {s}" for s in SEMILLAS) + " |", "|---|---|---|---|---|" + "---|" * len(SEMILLAS)]
    for _, f in sig.iterrows():
        por_semilla = [mej[(mej.prueba == f.prueba) & (mej.metrica == f.metrica) & (mej.semilla == s)].mejora.iloc[0] for s in SEMILLAS]
        L.append(f"| {f.prueba} | {f.metrica} | {f.positivas} de {f.semillas} | {fmt(f.p_signos_bilateral)} | {f.mejora_media:.3f} ± {f.mejora_desviacion:.3f} | "
                 + " | ".join(f"{x:+.3f}" for x in por_semilla) + " |")
    abl = tuple(ABLACIONES)
    if etapa != 3:
        L += ["", "## Carga de trabajo", "", "| Sistema | Parámetros entrenables | Épocas | Mejor época | Minutos | Monitor |", "|---|---|---|---|---|---|"]
        L += [f"| {f.sistema} | {f.parametros:,} | {f.epocas} | {f.mejor_epoca} | {f.minutos:.1f} | {f.monitor} |".replace(",", " ") for _, f in ent.iterrows()]
        return "\n".join(L) + "\n"
    L += ["", "## Ablaciones desde P1 (S3, una ejecución cada una, semilla 42)", "",
          "(a) `ABL_AUG`: aumentación (`augment`, `aug_seed` 123); (b) `ABL_LS`: suavizado de etiquetas 0.05; (c) `ABL_ES`: parada por `val_f1_macro`; (d) `ABL_REG`: regularización de v2 "
          "(`conv_dropout` 0.3, `weight_decay` 0.0003, `learning_rate` 0.0005, paciencias y épocas de v2).", ""]
    for prueba in PRUEBAS:
        L += [f"### {nombres_prueba[prueba]}", "", "| Métrica | P1 | " + " | ".join(abl) + " |", "|---|---|" + "---|" * len(abl)]
        s = g[(g.prueba == prueba) & (g.subconjunto == "completa")]
        for m in ("f1_macro", "f1_micro", "exacta", "auroc_macro", "auprc_macro", "ece", "brier"):
            fila = [s[(s.sistema == k) & (s.metrica == m)].iloc[0] for k in ("P1",) + abl]
            L.append(f"| {m} | " + " | ".join(fmt(f.valor, f.lo, f.hi) for f in fila) + " |")
        L.append("")
    L += ["### Diferencias pareadas con P1 (ablación menos P1)", "", "| Prueba | Comparación | Métrica | Diferencia (IC95) | Remuestreos con diferencia > 0 |", "|---|---|---|---|---|"]
    sel = d[(d.subconjunto == "completa") & d.comparacion.isin([f"{a} menos P1" for a in abl]) & d.metrica.isin(["f1_macro", "f1_micro", "exacta", "auroc_macro", "auprc_macro", "ece", "brier"])]
    for _, f in sel.iterrows():
        L.append(f"| {f.prueba} | {f.comparacion} | {f.metrica} | {fmt(f.diferencia, f.lo, f.hi)} | {f.prop_positiva:.3f} |")
    L += ["", "## Carga de trabajo", "", "| Sistema | Parámetros entrenables | Épocas | Mejor época | Minutos | Monitor |", "|---|---|---|---|---|---|"]
    for _, f in ent.iterrows():
        L.append(f"| {f.sistema} | {f.parametros:,} | {f.epocas} | {f.mejor_epoca} | {f.minutos:.1f} | {f.monitor} |".replace(",", " "))
    return "\n".join(L) + "\n"


def resumen(t: dict, etapa: int) -> str:
    if etapa in SEMILLAS_ETAPA:
        return resumen3(t, etapa)
    sis, por_clase_md = ETAPAS[etapa]["sistemas"], ETAPAS[etapa]["por_clase"]
    g, d, ab, o, c = (pd.DataFrame(t[k]) for k in ("metricas_globales", "diferencias_pareadas", "diferencia_A_menos_B", "por_origen_A", "metricas_por_clase"))
    L = [f"# Etapa {etapa} de T19: análisis ({', '.join(sis)})", "",
         f"IC del 95 % por bootstrap de percentiles ({REMUESTREOS} remuestreos de registros, semilla {SEMILLA}, los mismos para todos los sistemas). Valores con tres decimales. "
         "Las predicciones y los umbrales son los registrados en `protocolo_t19_registro.md`. Generado por `scripts/analizar_t19.py`. "
         "El ECE va sin IC: su estimador con intervalos fijos sube al remuestrear y el valor puntual cae fuera del IC por percentiles (ver `ic` en el script).", ""]

    def global_(prueba, sub, claves):
        s = g[(g.prueba == prueba) & (g.subconjunto == sub)]
        L.extend(["| Métrica | " + " | ".join(sis) + " |", "|---|" + "---|" * len(sis)])
        for m in claves:
            fila = [s[(s.sistema == k) & (s.metrica == m)].iloc[0] for k in sis]
            L.append(f"| {m} | " + " | ".join(fmt(f.valor, f.lo, f.hi) for f in fila) + " |")
        L.append("")

    for prueba, titulo in (("A", "Prueba A (n = 4 949)"), ("B", "Prueba B, Georgia (n = 10 344)")):
        L += [f"## {titulo}", ""]
        global_(prueba, "completa", GLOBALES + (("f1_macro_enmascarado",) if prueba == "A" else ()))
    for prueba in PRUEBAS:
        n = int(g[(g.prueba == prueba) & (g.subconjunto == "sin registros sin clase")].n.iloc[0])
        L += [f"## Prueba {prueba} sin los registros sin ninguna clase (n = {n})", ""]
        global_(prueba, "sin registros sin clase", ("f1_macro", "f1_micro", "exacta", "auroc_macro", "auprc_macro"))
    L += ["## Diferencias pareadas (a menos b), global", "", "| Prueba | Comparación | Métrica | Diferencia (IC95) | Remuestreos con diferencia > 0 |", "|---|---|---|---|---|"]
    for _, f in d[(d.subconjunto == "completa") & d.metrica.isin(["f1_macro", "f1_micro", "exacta", "auroc_macro", "auprc_macro", "ece", "brier"])].iterrows():
        L.append(f"| {f.prueba} | {f.comparacion} | {f.metrica} | {fmt(f.diferencia, f.lo, f.hi)} | {f.prop_positiva:.3f} |")
    L += ["", "## Prueba A menos prueba B (no pareada)", "", "| Sistema | Métrica | A | B | A menos B (IC95) |", "|---|---|---|---|---|"]
    for _, f in ab[ab.metrica.isin(["f1_macro", "f1_micro", "exacta", "auroc_macro", "auprc_macro", "ece", "brier", "sens_macro", "espec_macro", "prec_macro", "card_real", "card_pred"])].iterrows():
        L.append(f"| {f.sistema} | {f.metrica} | {fmt(f.valor_A)} | {fmt(f.valor_B)} | {fmt(f.diferencia, f.lo, f.hi)} |")
    L += ["", "## Por origen, prueba A", "", "Los orígenes con menos de 100 registros llevan IC que no informa.", "",
          "| Origen | n | Sistema | F1 macro | F1 macro (clases anotadas) | F1 micro | AUROC macro |", "|---|---|---|---|---|---|---|"]
    for origen in o.subconjunto.unique():
        for k in sis:
            fila = {m: o[(o.subconjunto == origen) & (o.sistema == k) & (o.metrica == m)].iloc[0] for m in ("f1_macro", "f1_macro_anotadas", "f1_micro", "auroc_macro")}
            n = int(fila["f1_macro"].n)
            L.append(f"| {origen} | {n} | {k} | " + " | ".join(fmt(f.valor, f.lo, f.hi) if n >= MIN_N_IC else fmt(f.valor) for f in fila.values()) + " |")
    for k in por_clase_md:
        for prueba in PRUEBAS:
            L += ["", f"## Por clase, {k}, prueba {prueba}", "", "| Clase | Positivos | F1 | Sensibilidad | Especificidad | AUROC | AUPRC |", "|---|---|---|---|---|---|---|"]
            s = c[(c.prueba == prueba) & (c.sistema == k)]
            for clase in CLASS_NAMES:
                f = {m: s[(s.clase == clase) & (s.metrica == m)].iloc[0] for m in ("f1", "sens", "espec", "auroc", "auprc")}
                L.append(f"| {clase} | {int(f['f1'].positivos)} | " + " | ".join(fmt(f[m].valor, f[m].lo, f[m].hi) for m in ("f1", "sens", "espec", "auroc", "auprc")) + " |")
    return "\n".join(L) + "\n"


# ---------------------------------------------------------------------------------------------------------------------------------------------
# Etapa 7: evaluación externa en Chapman-Shaoxing (C) y Ningbo (D), según evidencia/protocolo_externo_t19.md
# ---------------------------------------------------------------------------------------------------------------------------------------------
EXTERNOS = {"C": "test_c", "D": "test_d"}                              # prueba -> HDF5 de data/cinc2021_externo/
EXT = RAIZ / "data" / "cinc2021_externo"
ENTRADAS7 = Path(os.environ["T19_ENTRADAS"]) if "T19_ENTRADAS" in os.environ else IEEE / "evidencia"      # reparto_externo.json y duplicados_externa.csv
SHA256_EXT: dict[str, str] = {
    "P1_C": "cab4062868221bd4ad2a21a62b4166e1bc44cbfe0b64a1e0cd0c4e41518266aa",
    "P1_D": "67e712349d7f096cbb88dde6203c6b55b3b1abdb8472bcee25b74a90e269d330",
    "P2_C": "6e3021dd54a07ac2803a0bc999ae9d4faba2c8a2fcbc5f54be1e4377611be60e",
    "P2_D": "b7b639e60aa1206dd6488fdd6b33559c481084c410a9cfeb603e1e80d9ae7a1b",
    "P3_C": "10084272e3151f499316942e2c820f030567dc01395fe0f7535b638edf2b11a1",
    "P3_D": "07c61c1b987dfe99fae16a8f9d744052e8906d8779d550ff93ef7ea39e1c6fd8",
    "P1_S101_C": "0a1fd28c6aa77627aa28f20ac2027332b29a3259ac95d082cc9d2a4e9880d922",
    "P1_S101_D": "93e3fbf0af23afd15f4d36d4b427d86cf8de9fcd2a2e2c9ac26768a39dbd0dbd",
    "P2_S101_C": "f4450bd1f37b9e6fd23b8e14000975978dfb71b75fcfca928e8464dd8dddb003",
    "P2_S101_D": "d351530d3207bfcde0371dc01f896a360e82004d88ece35c83fa7882c5740575",
    "P3_S101_C": "9e0ebba5c3a8dad7ac907a7cce635615a5ca0a8bc852e21a2babfed50c91630a",
    "P3_S101_D": "f3bd320383d483037347c68c997b9bc7c6983801d93cf55c696e52c24ef9fd76",
    "P1_S102_C": "566e894b325889fb8208bbc5839ab59d9024c82a5e8e0171753847f49d6c17cb",
    "P1_S102_D": "0b9d39165af957173ddf2b3decff0fc9af632304ca0bdd956bbf82f3e68de613",
    "P2_S102_C": "170c572fc5e2e0a409ac28f8ab85decfd3bb10311854f5d106d73e9ff22d506b",
    "P2_S102_D": "339ff7f22044d4f9673641d1022c09c93948d6387ccdc38c9db387b9fa230f08",
    "P3_S102_C": "f17467eed3f79a89ac7732a115de6e123c125aaf15d811331f3015bdaf0c8a60",
    "P3_S102_D": "5bd43c23e9e1deb1b1b200bf5fc938bb66b4c7d8d79ebb9294da8deaa3502b01",
    "P1_S103_C": "ad0737551f4caacda85072927727b8cf001410a0be838a1cda18e0a0bf856736",
    "P1_S103_D": "500816269dfb1f928d0e0c4744b8972fe06d05f3abe75b28c1681011bcde3e05",
    "P2_S103_C": "659e5e58dbced81c2c5d9b30c500a39ed4b3e2aa5a151417edab67be85ba6fa9",
    "P2_S103_D": "6f8e7e8476b642567c0c0ac7e607a9ccc8d1349cf92a28ffbe5ccc686b787ef4",
    "P3_S103_C": "18ccb564f48d4d6fc63062967b2de1138059e21fc96f897c199ff9fc585f82c9",
    "P3_S103_D": "40c39921ddeede7b2f545cc19948d176d69238749c7688c9726214c05f5ab9f5",
    "P1_S104_C": "ff6c55c5cbc598edee4710b34d2fede737d2cb62f7379c58bbadb998f010b8e9",
    "P1_S104_D": "c388e8a94e377c9a275546d52c10da5b48a0214534d6d0f54fcccf578a668c0b",
    "P2_S104_C": "c0b9730f43a4ddba1a996daeb98aaaba0878d10c98cd5c6761d5e7c71e2656d5",
    "P2_S104_D": "86b004d5a6c98194dbc20937786776e781966d85c97832d0469238d92b58afd5",
    "P3_S104_C": "2b63a77c8587e1cdaaac5dd61f781f6641b5478d6b7312a5b7c2f62cae1920de",
    "P3_S104_D": "cad7fb476f47b73c2f3379a98a36e66dac248e8596e533cbc8ccb33db452c950",
    "P1_S105_C": "6982ab1b108a5ed221d0bf793dfbf5dfedaa98161013037456c34cd9ae2fe5ab",
    "P1_S105_D": "e5947d01c7482180cd5bf451190696aa606c2c9b81f963ce3cbeebc850c3ce32",
    "P2_S105_C": "72e42c0a8275c5e19c37434ff3e33c2ebb59817fbafa9b591f3e37db925ad76e",
    "P2_S105_D": "d3bae0b997d9cf6dc73f1b940cdc9e53cdefa84bcd6d7f3fad2bc6d57b5f33ef",
    "P3_S105_C": "0d481f2d32230c0a90f18c23363fef9f55d8ac1851987ef307aa1fa4c3dcf5fd",
    "P3_S105_D": "1a4f6b6fa3285522c309a0742c67c0dbaff2b199a5010e44bb3e96223817636f",
    "P1_S106_C": "caab21e5fb32fcf2f76da27ee24818d3bb983d0801a1e66c976d8a5ef9be1283",
    "P1_S106_D": "0a0369db0aab1039553c539b51d865dacaf5f2eb458d90c23297167565530a6a",
    "P2_S106_C": "8d275e2930f6a3c54f4ba48f352c4505efc95afc99feed23d53bfe080904adef",
    "P2_S106_D": "8ec858d218b75b9f0ff8fa0acde7be2d90b23a2136b2204ba1af361c41af1b5a",
    "P3_S106_C": "83f5741be721cab9bad2a88b7d717874bb92e3fbdea585fdbe9fd3ae05d40e90",
    "P3_S106_D": "9f482be9f17498d253cab597099dd5ce265fc5fc1805b9102f4b575936970244",
    "P1_S107_C": "e6de96e7c36cebe0b6ac64c02a8b6374db6c02f6ad9d23450b2f5b7b88d2fa27",
    "P1_S107_D": "9a251e1a2b333fc274d099912b0929c4d0a52335212f1f267913c01b7435e8aa",
    "P2_S107_C": "5b3d3ce7ae1a61f194528852b0ed2efbeca642b0bbb954a613449734f293ff90",
    "P2_S107_D": "e17783984776f579a9f8a26f092a3a57a4cac6a3500109adbc6af6cf5125b31c",
    "P3_S107_C": "d99ff1ca80be7a1951ba84ff590b2389dd8db2b6ea609a6bebcaab77067d6a2b",
    "P3_S107_D": "1d4b3181a79cb86932cd09ba514c0e9bb9596eb8bc960d727a2cb4ce912aaa62",
    "P1_S108_C": "3d5567157ca0c231afa7fff8c71e2c484802a549578f2868737cf11a49c9f11c",
    "P1_S108_D": "eba112df0fd4ffbaa113b8df940b48a210653d25d23db99c36a4aac370f5b3ee",
    "P2_S108_C": "569200afa5ac66787ab684a62cf97d9a78eadb7564bf90e35c569b84c04d46e1",
    "P2_S108_D": "1018019273b2f8889d2befb8ffc90e03faa43ea5d96ee9f67b8e9d9cdfff0be9",
    "P3_S108_C": "59dd02e94aa156d51cd2dea18cba73884473d5edfb3d05bf33da42abb594553a",
    "P3_S108_D": "537cb3adb3c1f7b01af1c11819c10963ff3140919b3d0b7e7b1d7eeaa651eea3",
    "P1_S109_C": "15efe0b2dbb9822345aad0a4b66f59b53d66e0aa52f3603084793e3c001f0e6d",
    "P1_S109_D": "aee29294faf5bcbadcc7de5832813af221a20e1c1c886f0e5f076e6345fe41d6",
    "P2_S109_C": "ef159e0d78bcc5a91b982b0d9088ff70cac959e7c899a9ee65a721064c505741",
    "P2_S109_D": "84615490d462fffd7acb6e8601a5dd5b0c2899d61c47f9110ac01af976d02641",
    "P3_S109_C": "1b6d608ad177557d8ec980c000ec15da724e7ca56f8b0bdfaafe0b688079be6a",
    "P3_S109_D": "670f9d13c640a3d9e00b54e08ae1e4abe600d902efc436660fc55af52ea3f680",
    "P1m_C": "cf752df3507a111f49207c1c5dd249b64adde7e3a17715eaba5f0b64b8eb7174",
    "P1m_D": "0a684baaad3ea348736b8206cb19faf88be17048f84e4e7c5bf428fdad7f3d40",
    "P2m_C": "efdd7f2bf699725f965b57e26d665722aa048a171a10e49c0946f306b647f0b7",
    "P2m_D": "2f6ccd7ff8035be372f8ab6684de71a7418670aa61dbb4d389c2ec85b93815af",
    "P3m_C": "fdcdd6356965a0f5885b4ebf6270f37c6b5fdbecdd142f2dae2cea9e4989f85a",
    "P3m_D": "18797499a49cdd11f8fccdfcc3d681fadb35a81a5d9d2ac44ed22219e30fcad1",
    "CNN_C": "d6d92db0877241568f3f030afa0936d95ebfd71fac53ac7d114911496bee2c8f",
    "CNN_D": "c0334e6f862b6db77a250cba140df03611b53cd45fd1043352001b8adbf1cb09",
    "P1t_C": "c9ffd0032eca56e02e8176dce3a6bf3041d6b130cc04359e6e83c95d221c5851",
    "P1t_D": "d7a7c08d5e183dcf7bcc0a8eb34b3248b991b0c9851e75a13a9ba66aa9cc8551",
    "P2t_C": "7276dc8921864aa2084efab6c5398cbfb9b424cbcdf25902e2bdd42ae7f617b1",
    "P2t_D": "58390c02d90748fe6cd221e8d95489dc1ca2f3d48b5d27b47f2c055297705167",
    "P3t_C": "1cb1c3c0dcbcb6a5fee92e429fcf0b57051090f44952de11c1e1685ad6ad13f4",
    "P3t_D": "878a8403e60509e41e9fa947c91f40ca986e2ba032713a7fe7d531b7532f5131",
}                                         # «<sistema>_<C|D>»: SHA-256 registrado de cada predicción, anotado antes de analizar
SISTEMAS7 = ETAPAS[6]["sistemas"] + ("P1m", "P2m", "P3m", "CNN", "P1t", "P2t", "P3t")
COMPARACIONES7 = ETAPAS[6]["comparaciones"] + (("P2", "P1"), ("CNN", "P1"), ("CNN", "P3"), ("P1m", "P1"), ("P2m", "P2"), ("P3m", "P3"),
                                               ("P1", "P1t"), ("P2", "P2t"), ("P3", "P3t"))
ETAPAS[7] = {"sistemas": SISTEMAS7, "comparaciones": COMPARACIONES7, "por_clase": ()}
CLAVES7 = ("f1_macro", "f1_micro", "f1_ponderado", "exacta", "auroc_macro", "auprc_macro", "ece", "brier", "prec_macro", "sens_macro", "espec_macro")
AB_CD = ("f1_macro", "f1_micro", "exacta", "auroc_macro", "auprc_macro", "ece", "brier")


def cargar_externo(sistemas: tuple[str, ...], reparto: dict) -> tuple[dict, dict, dict]:
    """Predicciones de C y D por sistema, con el SHA-256 contra el registro y los registros y etiquetas contra el HDF5 y su manifiesto."""
    import h5py
    datos, hashes, nombres_de = {}, {}, {}
    for prueba, base in EXTERNOS.items():
        for k in sistemas:
            ruta = EVAL / f"{k.lower()}_{prueba}" / "predictions_test.csv"
            clave = f"{k}_{prueba}"
            hashes[clave] = sha256(ruta)
            esperado = SHA256_EXT.get(clave)
            if esperado is None and os.environ.get("T19_SIN_HASH") != "1":
                raise AssertionError(f"{clave}: falta su SHA-256 registrado en SHA256_EXT")
            assert esperado is None or hashes[clave] == esperado, f"{ruta} no es la predicción registrada"
            d = pd.read_csv(ruta)
            datos[k, prueba] = (d["record_name"].to_numpy(), d[[f"true_{c}" for c in CLASS_NAMES]].to_numpy(np.uint8),
                                d[[f"prob_{c}" for c in CLASS_NAMES]].to_numpy(float), d[[f"pred_{c}" for c in CLASS_NAMES]].to_numpy(np.uint8))
        nombres, y = datos[sistemas[0], prueba][0], datos[sistemas[0], prueba][1]
        for k in sistemas:
            assert (datos[k, prueba][0] == nombres).all() and (datos[k, prueba][1] == y).all(), f"{k}/{prueba}: registros o etiquetas distintos"
        manifiesto = pd.read_csv(EXT / f"{base}.h5.records.csv")
        assert len(manifiesto) == reparto["origenes"][prueba]["registros"] == len(nombres), f"la prueba {prueba} no tiene los registros del reparto"
        assert list(manifiesto["record_name"]) == list(nombres), f"la prueba {prueba} no coincide con su manifiesto por registro"
        etiquetadas = manifiesto["matched_classes"].fillna("").str.split(";")
        assert all((y[:, i] == etiquetadas.apply(lambda L, c=c: c in L).to_numpy()).all() for i, c in enumerate(CLASS_NAMES)), f"las etiquetas de la prueba {prueba} no coinciden con su manifiesto"
        if (EXT / f"{base}.h5").is_file():                                                        # con los datos a mano, también contra el HDF5 construido
            with h5py.File(EXT / f"{base}.h5", "r") as f:
                h5_nombres = [n.decode() if isinstance(n, bytes) else n for n in f["record_names"][:]]
                h5_y = f["labels"][:]
            assert list(h5_nombres) == list(nombres) and (h5_y == y).all(), f"la prueba {prueba} no coincide con su HDF5"
        nombres_de[prueba] = manifiesto.set_index("record_name")["record_file"].to_dict()      # nombre de registro -> nombre de archivo
    return datos, hashes, nombres_de


def main_externo() -> int:
    sis, comparaciones = ETAPAS[7]["sistemas"], ETAPAS[7]["comparaciones"]
    salida = SALIDA / "t19_etapa7"
    salida.mkdir(parents=True, exist_ok=True)
    reparto = json.loads((ENTRADAS7 / "reparto_externo.json").read_text(encoding="utf-8"))
    datos, hashes, nombres_de = cargar_externo(sis, reparto)
    dup = pd.read_csv(ENTRADAS7 / "duplicados_externa.csv")
    discordantes = set(dup[(dup.clases12_discordantes) & (dup.decision == "conservado")].registro)
    globales, clases, difs, prev = [], [], [], []

    def registrar(destino, prueba, sub, sistemas, puntual, boot, claves, n):
        for k in sistemas:
            for m in claves:
                if m in puntual[k]:
                    lo, hi = ic(boot[k][m], m)
                    destino.append({"prueba": prueba, "subconjunto": sub, "sistema": k, "n": n, "metrica": m, "valor": puntual[k][m], "lo": lo, "hi": hi,
                                    "media_remuestreos": float(np.nanmean(boot[k][m]))})

    boots = {}
    for prueba in EXTERNOS:
        info = reparto["origenes"][prueba]
        nombres, y = datos[sis[0], prueba][0], datos[sis[0], prueba][1]
        ev = [CLASS_NAMES.index(c) for c in info["clases_evaluables"]]
        todas = len(ev) == len(CLASS_NAMES)
        fila = np.random.default_rng(SEMILLA).integers(0, len(y), size=len(y))
        completas = construir(datos, prueba, sis)                                                  # las 12 columnas: comprobación y diagnóstico
        for k in sis:
            r = pd.read_csv(EVAL / f"{k.lower()}_{prueba}" / "metrics_global.csv").query("split == 'test'").iloc[0]
            comprobar(completas[k], *(datos[k, prueba][i] for i in (1, 2, 3)), fila, r)
        print(f"prueba {prueba}: el cálculo con pesos coincide con scikit-learn y con la evaluación original ({len(sis)} sistemas)")
        puntual12, boot12 = analizar(completas)
        sistemas_ev = completas if todas else construir(datos, prueba, sis, columnas=ev)
        puntual, boot = (puntual12, boot12) if todas else analizar(sistemas_ev)                    # métricas agregadas solo sobre las clases evaluables (protocolo §3)
        boots[prueba] = (puntual, boot)
        registrar(globales, prueba, "completa", sis, puntual, boot, GLOBALES, len(y))
        if not todas:
            registrar(globales, prueba, "12 clases (diagnóstico)", sis, puntual12, boot12, GLOBALES, len(y))
        con_clase = y.sum(1) > 0                                                                   # sin los registros sin ninguna de las 12 clases
        p_s, b_s = analizar(construir(datos, prueba, sis, con_clase, columnas=ev))
        registrar(globales, prueba, "sin registros sin clase", sis, p_s, b_s, GLOBALES, int(con_clase.sum()))
        sin_disc = np.array([nombres_de[prueba][n] not in discordantes for n in nombres])                  # excluye los registros de grupos duplicados con etiquetas discordantes
        p_d, b_d = analizar(construir(datos, prueba, ("P3",), sin_disc, columnas=ev))
        registrar(globales, prueba, "sin duplicados discordantes", ("P3",), p_d, b_d, GLOBALES, int(sin_disc.sum()))
        for k in sis:                                                                              # por clase (las 12 columnas), mismos remuestreos
            for m in POR_CLASE:
                lo, hi = ic(boot12[k]["pc_" + m])
                for i, c in enumerate(CLASS_NAMES):
                    clases.append({"prueba": prueba, "sistema": k, "clase": c, "evaluable": c in info["clases_evaluables"], "positivos": int(y[:, i].sum()), "prevalencia": y[:, i].mean(),
                                   "metrica": m, "valor": puntual12[k]["pc_" + m][i], "lo": lo[i], "hi": hi[i]})
        for a, b in comparaciones:
            for m in CLAVES7:
                if m in puntual[a]:
                    d = boot[a][m] - boot[b][m]
                    lo, hi = ic(d, m)
                    difs.append({"prueba": prueba, "subconjunto": "completa", "comparacion": f"{a} menos {b}", "metrica": m, "diferencia": puntual[a][m] - puntual[b][m],
                                 "lo": lo, "hi": hi, "prop_positiva": float(np.mean(d[~np.isnan(d)] > 0))})
        for i, c in enumerate(CLASS_NAMES):
            prev.append({"prueba": prueba, "clase": c, "registros": len(y), "positivos": int(y[:, i].sum()), "prevalencia": y[:, i].mean(), "evaluable": c in info["clases_evaluables"]})

    # A y B frente a C y D (no pareadas; registros distintos), solo P3 y sobre las clases evaluables del origen externo
    ab_cd, ab = [], None
    if (EVAL / "p3_A").exists() and (EVAL / "p3_B").exists():
        datos_ab, _, _ = cargar(("P3",))
        for referencia in PRUEBAS:
            for prueba in EXTERNOS:
                ev = [CLASS_NAMES.index(c) for c in reparto["origenes"][prueba]["clases_evaluables"]]
                pa, ba = analizar(construir(datos_ab, referencia, ("P3",), columnas=ev))
                pe, be = boots[prueba][0]["P3"], boots[prueba][1]["P3"]
                for m in AB_CD:
                    lo, hi = ic(np.subtract.outer(ba["P3"][m], be[m]).ravel(), m)
                    ab_cd.append({"referencia": referencia, "externa": prueba, "metrica": m, "valor_referencia": pa["P3"][m], "valor_externa": pe[m],
                                  "diferencia": pa["P3"][m] - pe[m], "lo": lo, "hi": hi})
    else:
        print("AVISO: no existen p3_A y p3_B; se omite la comparación de A y B con C y D")

    tablas = {"metricas_globales": globales, "metricas_por_clase": clases, "diferencias_pareadas": difs, "diferencia_AB_menos_CD": ab_cd, "prevalencia": prev}
    for nombre, df in zip(("semillas", "semillas_resumen", "ensemble_vs_mejor", "ensemble_vs_mejor_resumen"),
                          analisis_semillas(pd.DataFrame(globales), SEMILLAS10, tuple(EXTERNOS))):
        tablas[nombre] = df.to_dict("records")
    for nombre, filas in tablas.items():
        pd.DataFrame(filas).to_csv(salida / f"{nombre}.csv", index=False, float_format="%.6f", encoding="utf-8", lineterminator="\n")
    (salida / "entradas.json").write_text(json.dumps({"predicciones_sha256": hashes, "reparto_externo_sha256": sha256(ENTRADAS7 / "reparto_externo.json"),
        "duplicados_externa_sha256": sha256(ENTRADAS7 / "duplicados_externa.csv"), "remuestreos": REMUESTREOS, "semilla": SEMILLA, "intervalos_ece": INTERVALOS,
        "numpy": np.__version__, "pandas": pd.__version__}, indent=2) + "\n", encoding="utf-8", newline="\n")
    (salida / "resumen.md").write_text(resumen7(tablas), encoding="utf-8", newline="\n")
    print(f"escrito en {salida}")
    return 0


def resumen7(t: dict) -> str:
    g, d, ab, sem, sig = (pd.DataFrame(t[k]) for k in ("metricas_globales", "diferencias_pareadas", "diferencia_AB_menos_CD", "semillas_resumen", "ensemble_vs_mejor_resumen"))
    nombres = {"C": "Chapman-Shaoxing (C)", "D": "Ningbo (D)"}
    L = ["# Etapa 7 de T19: evaluación externa en Chapman-Shaoxing y Ningbo", "",
         f"Según `protocolo_externo_t19.md`. IC del 95 % por bootstrap de percentiles ({REMUESTREOS} remuestreos de registros, semilla {SEMILLA}, los mismos para todos los sistemas de un origen); "
         "el ECE va sin IC. Las métricas agregadas se calculan solo sobre las clases evaluables de cada origen (C: 11, sin LVH; D: 12). Valores con tres decimales. "
         "Generado por `scripts/analizar_t19.py`; el detalle por sistema y clase está en los CSV de esta carpeta.", ""]
    for prueba in EXTERNOS:
        s = g[(g.prueba == prueba) & (g.subconjunto == "completa")]
        n = int(s.n.iloc[0])
        L += [f"## {nombres[prueba]} (n = {format(n, ',').replace(',', ' ')})", "", "| Sistema | F1 macro (IC95) | AUROC macro | AUPRC macro | ECE | Brier |", "|---|---|---|---|---|---|"]
        for k in ("P1", "P2", "P3", "P1m", "P2m", "P3m", "CNN", "P1t", "P2t", "P3t"):
            f = {m: s[(s.sistema == k) & (s.metrica == m)].iloc[0] for m in ("f1_macro", "auroc_macro", "auprc_macro", "ece", "brier")}
            L.append(f"| {k} | {fmt(f['f1_macro'].valor, f['f1_macro'].lo, f['f1_macro'].hi)} | {fmt(f['auroc_macro'].valor, f['auroc_macro'].lo, f['auroc_macro'].hi)} | "
                     f"{fmt(f['auprc_macro'].valor, f['auprc_macro'].lo, f['auprc_macro'].hi)} | {fmt(f['ece'].valor)} | {fmt(f['brier'].valor, f['brier'].lo, f['brier'].hi)} |")
        L.append("")
        for sub in ("sin registros sin clase", "12 clases (diagnóstico)", "sin duplicados discordantes"):
            x = g[(g.prueba == prueba) & (g.subconjunto == sub) & (g.sistema == "P3") & (g.metrica == "f1_macro")]
            if len(x):
                f = x.iloc[0]
                n_texto = format(int(f.n), ",").replace(",", " ")
                L.append(f"- P3, F1 macro, {sub} (n = {n_texto}): {fmt(f.valor, f.lo, f.hi)}")
        L.append("")
    L += ["## Semillas: media y desviación típica entre las 10 semillas de cada receta", "", "| Prueba | Métrica | P1 | P2 | P3 (ensemble) |", "|---|---|---|---|---|"]
    for prueba in EXTERNOS:
        for m in METRICAS_SEMILLAS:
            fila = [sem[(sem.prueba == prueba) & (sem.metrica == m) & (sem.receta == r)].iloc[0] for r in ("P1", "P2", "P3")]
            L.append(f"| {prueba} | {m} | " + " | ".join(f"{f.media:.3f} ± {f.desviacion:.3f} ({f['min']:.3f} a {f['max']:.3f})" for f in fila) + " |")
    L += ["", "## Ensemble menos mejor receta individual, por semilla", "",
          f"Positivo = el ensemble es mejor (en ECE y Brier, mejor individual menos ensemble). Prueba de signos exacta y bilateral sobre las {len(SEMILLAS10)} semillas "
          f"(p mínimo {2 * 0.5 ** len(SEMILLAS10):.4f}); sin corrección por comparaciones múltiples.", "",
          "| Prueba | Métrica | Semillas con mejora | Valor p | Mejora media ± desviación |", "|---|---|---|---|---|"]
    for _, f in sig.iterrows():
        L.append(f"| {f.prueba} | {f.metrica} | {f.positivas} de {f.semillas} | {fmt(f.p_signos_bilateral)} | {f.mejora_media:.3f} ± {f.mejora_desviacion:.3f} |")
    if len(ab):
        L += ["", "## P3: prueba de referencia (A o B) menos prueba externa (no pareada)", "", "| Referencia | Externa | Métrica | Referencia | Externa | Diferencia (IC95) |", "|---|---|---|---|---|---|"]
        for _, f in ab.iterrows():
            L.append(f"| {f.referencia} | {f.externa} | {f.metrica} | {fmt(f.valor_referencia)} | {fmt(f.valor_externa)} | {fmt(f.diferencia, f.lo, f.hi)} |")
    L += ["", "## Diferencias pareadas (a menos b), P3 y variantes", "", "| Prueba | Comparación | Métrica | Diferencia (IC95) | Remuestreos con diferencia > 0 |", "|---|---|---|---|---|"]
    sel = d[d.comparacion.isin(["P3 menos P1", "P3 menos P2", "P2 menos P1", "CNN menos P1", "CNN menos P3", "P1m menos P1", "P2m menos P2", "P3m menos P3", "P1 menos P1t", "P2 menos P2t", "P3 menos P3t"])
            & d.metrica.isin(["f1_macro", "f1_micro", "auroc_macro", "auprc_macro", "ece", "brier"])]
    for _, f in sel.iterrows():
        L.append(f"| {f.prueba} | {f.comparacion} | {f.metrica} | {fmt(f.diferencia, f.lo, f.hi)} | {f.prop_positiva:.3f} |")
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--etapa", type=int, choices=sorted(ETAPAS), default=1)
    sys.exit(main(parser.parse_args().etapa))
