"""Formato de las cifras del artículo y la lista de clases: lo comparten calcular_t19.py y verificar_tex.py.

Es lo que el artículo usaba de la tesis completa (descartada); se conserva idéntico para que las macros \\cf salgan igual.
"""

from __future__ import annotations

from decimal import Decimal

CLASSES = ["NSR", "AxisDev", "MI", "TAb", "AF", "LVH", "VEctopy", "AVBlock", "STach", "BBB", "SB", "AEctopy_Junctional"]
CK = {c: c.replace("_Junctional", "J") for c in CLASSES}                       # clave alfanumérica de cada clase


def redondear(valor, unidad: str) -> str:
    """Texto de una cifra: ≥ 0.1 -> 2 decimales; < 0.1 -> 3; porcentajes -> 1; recuentos enteros; hiperparámetros tal cual."""
    v = float(valor)
    if unidad == "n":
        s = f"{int(round(abs(v))):,}".replace(",", r"\,")
        return s
    if unidad == "pct":
        return f"{abs(v):.1f}"
    if unidad == "min":
        return f"{abs(v):.1f}"
    if unidad == "param":
        if v != 0 and abs(v) < 1e-3:                                                # 0.0005 -> 5×10^-4 (notación científica)
            mant, exp = f"{abs(v):.6e}".split("e")
            return rf"\ensuremath{{{Decimal(mant).normalize():f}\times10^{{{int(exp)}}}}}"
        return format(Decimal(repr(abs(v))).normalize(), "f")
    if unidad == "epoch":
        return str(int(round(abs(v))))
    decimals = 2 if abs(v) >= 0.1 else 3                                            # prop, diff
    return f"{abs(v):.{decimals}f}"


def con_signo(valor, unidad: str) -> str:
    text = redondear(valor, unidad)
    negativo = float(valor) < 0 and unidad != "param" and float(text.replace(r"\,", "")) != 0
    return (r"\ensuremath{-}" if negativo else r"\ensuremath{+}") + text


def natural(valor, unidad: str) -> str:
    text = redondear(valor, unidad)
    negativo = float(valor) < 0 and unidad != "param" and float(text.replace(r"\,", "")) != 0
    return (r"\ensuremath{-}" if negativo else "") + text
