"""Cifras del artículo IEEE a partir de la evidencia del reentrenamiento final (T19).

Lee, sin entrenar ni evaluar nada, lo que ya está fijado y hasheado:
  - evidencia/t19_etapa1|2|3/*.csv (los produce scripts/analizar_t19.py a partir de las predicciones registradas);
  - data/cinc2020_12_origen/split_assignments.csv y evidencia/reparto_t19.json (el reparto: tamaños, orígenes, positivos por clase);
  - las predicciones por registro del ensemble P3 en las pruebas A y B (runs/t19/eval/p3_A|p3_B, comprobadas contra su SHA-256 registrado),
    de las que salen la sensibilidad con la especificidad fijada y la matriz de confusión multietiqueta;
  - un puñado de valores que no dependen del reparto (arquitectura, hiperparámetros, preprocesamiento, literatura), copiados con su id
    de evidencia/cifras.csv y evidencia/cifras_extra.csv (``ESTATICAS``).

Escribe evidencia/cifras_t19.csv, capitulos/cifras_t19.tex y evidencia/matriz_confusion_{A,B}.csv. El artículo solo carga ``cifras_t19``:
una cifra del reparto anterior que se cuele en el texto da una macro indefinida, no un número viejo.

Uso, desde la raíz del repo:  python tesis/scripts/calcular_t19.py
"""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_curve

IEEE = Path(__file__).resolve().parents[1]
REPO = IEEE.parent
sys.path.insert(0, str(IEEE / "scripts"))
sys.path.insert(0, str(REPO))
from formato_cifras import CK, CLASSES, natural, redondear  # noqa: E402
import analizar_t19 as a19  # noqa: E402

EV = IEEE / "evidencia"
ETAPAS = {n: EV / f"t19_etapa{n}" for n in (1, 2, 3, 4, 6, 7)}       # la 6 (E16) son las 10 semillas de P1 y P2
EVAL = REPO / "runs" / "t19" / "eval"
FILAS: list[dict] = []
IDS: set[str] = set()
FIRMADAS: set[str] = set()                                    # ids cuya versión con signo (cfs) también se escribe

# Valores que no dependen del reparto ni de los resultados: mismas cifras de evidencia/cifras.csv y cifras_extra.csv.
# Qué tienen en común: describen la base, la red, el preprocesamiento, las recetas y la literatura citada.
ESTATICAS = (
    "HannunEcg", "HannunPac", "HannunClases", "WagnerRec", "ChalPublic", "ChalTotal", "ChalCaida", "HongTrab", "RibeiroExam",
    "LitHannunF1", "LitHannunAuc", "LitStrodAucAll", "LitStrodAucSuper", "LitZhouAucC", "LitZhouAucD", "LitZhouAucCin", "LitZhouAucDin",
    "LitLeinKfold", "LitLeinLso", "WebMuestra", "WebNLargos", "WebLargosDifMedia", "WebLargosDifMax", "WebLargosCambios",
    "NLeads", "NOrig", "NClasses", "RecTotal", "CodTotal", "ExclGroups", "ScanHeaders", "ScanKept", "Fs", "WinSec", "WinLen",
    "FsOrigCpsc", "FsOrigCpscExtra", "FsOrigGeorgia", "FsOrigPtb", "FsOrigPtbXl", "FsOrigIncart",
    "SrcCpsc", "SrcCpscExtra", "SrcGeorgia", "SrcPtb", "SrcPtbXl", "SrcIncart",
    "SrcAvgLabCpsc", "SrcAvgLabCpscExtra", "SrcAvgLabGeorgia", "SrcAvgLabPtb", "SrcAvgLabPtbXl", "SrcAvgLabIncart",
    "BpLo", "BpHi", "FiltroOrden", "ClipMv", "FiltroAten60", "ArqCapas", "ArqBloques", "ArqParams", "ArqCanalesFin", "ArqLongFin", "ArqRF", "ArqCanG1", "ArqCanG2", "ArqCanG3", "ArqCanG4",
    "HpKernel", "HpFilters0", "HpDropV1", "HpDropV2", "HpBatch", "HpLrV1", "HpLrV2", "HpRedFactor", "HpWdV1", "HpWdV2",
    "HpMaxEpV1", "HpMaxEpV2", "HpPatV1", "HpPatV2", "HpLs", "HpSeedV1", "HpSeedV2", "HpAugSeedV2", "GradClip", "Alpha", "BetaF1",
    "ThrGridN", "ThrGridLo", "ThrGridHi", "EceBins", "HwVramGb", "HwRamGb", "TrainWinMax",
    "WebE14Edad", "WebE14Dx1", "WebE14Dx2", "WebE14Dx3", "WebE14TAb", "WebE14TAbUmbral", "WebE14SB", "WebE14SBUmbral", "WebE14MI", "WebE14MIUmbral",
    "WebDifMedia", "WebDifMax", "WebRegLargos", "SmokePasan", "SmokeTotal", "WebVentanasMax", "SplitSeed", "ValFrac", "TestFrac",
    "CodNNSR", "CodNAxisDev", "CodNMI", "CodNTAb", "CodNAF", "CodNLVH", "CodNVEctopy", "CodNAVBlock", "CodNSTach", "CodNBBB", "CodNSB", "CodNAEctopyJ",
)

METRICA = {"f1_macro": "F1mac", "f1_micro": "F1mic", "f1_ponderado": "F1wt", "exacta": "Exact", "auroc_macro": "Auroc", "auroc_ponderado": "AurocWt",
           "auprc_macro": "Auprc", "ece": "Ece", "brier": "Brier", "prec_macro": "Prec", "sens_macro": "Sens", "espec_macro": "Spec",
           "card_real": "CardReal", "card_pred": "CardPred", "f1_macro_enmascarado": "F1macMask", "f1_macro_anotadas": "F1macAnot"}
POR_CLASE = {"f1": "F1", "prec": "Prec", "sens": "Sens", "espec": "Spec", "auroc": "Auroc", "auprc": "Auprc"}
TRES_DECIMALES = ("f1_macro", "f1_macro_enmascarado", "f1_macro_anotadas", "f1", "f1_micro", "f1_ponderado", "brier")   # F1 y Brier con tres decimales (a dos, sus IC colapsan)
ORIGEN = {"cpsc_2018": "Cpsc", "cpsc_2018_extra": "CpscExtra", "georgia": "Georgia", "ptb": "Ptb", "ptb-xl": "PtbXl", "st_petersburg_incart": "Incart"}
PARTICION = {"train": "Train", "val": "Val", "test": "A", "test_b": "B"}
SEMILLA = {"orig": "Orig", **{str(s): f"S{s}" for s in range(101, 110)}}
ESPEC = (0.90, 0.95)
SUBEXT = {"completa": "XG", "sin registros sin clase": "XGn", "12 clases (diagnóstico)": "XGd", "sin duplicados discordantes": "XGu"}      # subconjuntos de la etapa 7
SIS_PC_EXT = ("P1", "P2", "P3", "P3m", "CNN")                          # sistemas con cifras por clase en C y D
RLMET = {**METRICA, "fn_por_1000": "FN", "fp_por_1000": "FP"}
E13 = EV / "e13_recalibracion_local"


def sid(sistema: str) -> str:
    return sistema.replace("_", "")


def add(id_: str, concepto: str, valor, unidad: str, archivo: str, clave: str = "", firmada: bool = False) -> None:
    assert id_ not in IDS, f"id repetido: {id_}"
    IDS.add(id_)
    FILAS.append({"id": id_, "concepto": concepto, "valor": float(valor), "unidad": unidad, "archivo": archivo, "clave": clave})
    if firmada:
        FIRMADAS.add(id_)


def unidad(metrica: str) -> str:
    return "prop3" if metrica in TRES_DECIMALES else "prop"


def leer(nombre: str) -> pd.DataFrame:
    return pd.read_csv(nombre)


def estaticas() -> None:
    fuentes = {}
    for nombre in ("cifras.csv", "cifras_extra.csv"):
        with (EV / nombre).open(encoding="utf-8", newline="") as fh:
            for r in csv.DictReader(fh):
                fuentes.setdefault(r["id"], dict(r, archivo_origen=nombre))
    for id_ in ESTATICAS:
        r = fuentes[id_]
        add(id_, r["concepto"], r["valor"], r["unidad"], f"evidencia/{r['archivo_origen']}", "sin cambio respecto del reparto anterior")


def metricas_globales(etapa: int) -> None:
    arch = f"evidencia/t19_etapa{etapa}/metricas_globales.csv"
    for r in leer(ETAPAS[etapa] / "metricas_globales.csv").itertuples():
        pref = "G" if r.subconjunto == "completa" else "Gn"                  # Gn: sin los registros sin ninguna clase
        if (r.prueba, r.sistema, r.metrica, r.subconjunto) in SEEN:
            continue
        SEEN.add((r.prueba, r.sistema, r.metrica, r.subconjunto))
        base, u = f"{pref}{sid(r.sistema)}{r.prueba}{METRICA[r.metrica]}", unidad(r.metrica)
        desc = f"{r.metrica} de {r.sistema}, prueba {r.prueba} ({r.subconjunto})"
        add(base, desc, r.valor, u, arch, f"{r.prueba};{r.subconjunto}")
        if pd.notna(r.lo):
            add(base + "Lo", "IC95 inferior de " + desc, r.lo, u, arch, "bootstrap")
            add(base + "Hi", "IC95 superior de " + desc, r.hi, u, arch, "bootstrap")


def metricas_por_clase(etapa: int) -> None:
    arch = f"evidencia/t19_etapa{etapa}/metricas_por_clase.csv"
    for r in leer(ETAPAS[etapa] / "metricas_por_clase.csv").itertuples():
        if (r.prueba, r.sistema, r.clase, r.metrica) in SEEN_C:
            continue
        SEEN_C.add((r.prueba, r.sistema, r.clase, r.metrica))
        base, u = f"C{sid(r.sistema)}{r.prueba}{CK[r.clase]}{POR_CLASE[r.metrica]}", unidad(r.metrica)
        desc = f"{r.metrica} de {r.clase}, {r.sistema}, prueba {r.prueba}"
        add(base, desc, r.valor, u, arch, f"{r.prueba}")
        add(base + "Lo", "IC95 inferior de " + desc, r.lo, u, arch, "bootstrap")
        add(base + "Hi", "IC95 superior de " + desc, r.hi, u, arch, "bootstrap")


def diferencias(etapa: int) -> None:
    arch = f"evidencia/t19_etapa{etapa}/diferencias_pareadas.csv"
    for r in leer(ETAPAS[etapa] / "diferencias_pareadas.csv").itertuples():
        if r.subconjunto != "completa" or (r.prueba, r.comparacion, r.metrica) in SEEN_D:
            continue
        SEEN_D.add((r.prueba, r.comparacion, r.metrica))
        x, y = (sid(s) for s in r.comparacion.split(" menos "))
        base, u = f"D{x}{y}{r.prueba}{METRICA[r.metrica]}", "prop3"                  # toda diferencia pareada con tres decimales: a dos, los IC de AUROC colapsan
        desc = f"{r.metrica}, {r.comparacion}, prueba {r.prueba}"
        add(base, desc, r.diferencia, u, arch, "pareada", firmada=True)
        if pd.notna(r.lo):
            add(base + "Lo", "IC95 inferior de " + desc, r.lo, u, arch, "bootstrap pareado", firmada=True)
            add(base + "Hi", "IC95 superior de " + desc, r.hi, u, arch, "bootstrap pareado", firmada=True)
        add(base + "Pos", "proporción de remuestreos con diferencia positiva, " + desc, r.prop_positiva, "prop", arch, "remuestreos")


def a_menos_b(etapa: int) -> None:
    arch = f"evidencia/t19_etapa{etapa}/diferencia_A_menos_B.csv"
    for r in leer(ETAPAS[etapa] / "diferencia_A_menos_B.csv").itertuples():
        if (r.sistema, r.metrica) in SEEN_AB:
            continue
        SEEN_AB.add((r.sistema, r.metrica))
        base, u = f"AB{sid(r.sistema)}{METRICA[r.metrica]}", "prop3"
        desc = f"{r.metrica} de {r.sistema}: prueba A menos prueba B"
        add(base, desc, r.diferencia, u, arch, "no pareada", firmada=True)
        if pd.notna(r.lo):
            add(base + "Lo", "IC95 inferior de " + desc, r.lo, u, arch, "bootstrap", firmada=True)
            add(base + "Hi", "IC95 superior de " + desc, r.hi, u, arch, "bootstrap", firmada=True)


def por_origen(etapa: int) -> None:
    arch = f"evidencia/t19_etapa{etapa}/por_origen_A.csv"
    for r in leer(ETAPAS[etapa] / "por_origen_A.csv").itertuples():
        o = ORIGEN[r.subconjunto]
        if (r.sistema, o, r.metrica) in SEEN_O:
            continue
        SEEN_O.add((r.sistema, o, r.metrica))
        base, u = f"O{sid(r.sistema)}{o}{METRICA[r.metrica]}", unidad(r.metrica)
        if f"ON{o}" not in IDS:
            add(f"ON{o}", f"registros de la prueba A del origen {o}", r.n, "n", arch, "n")
            add(f"ONcl{o}", f"clases con positivos en entrenamiento del origen {o}", r.clases_anotadas, "n", arch, "clases anotadas")
        desc = f"{r.metrica}, {r.sistema}, origen {o}, prueba A"
        add(base, desc, r.valor, u, arch, "prueba A")
        if bool(r.ic_informativo) and pd.notna(r.lo):
            add(base + "Lo", "IC95 inferior de " + desc, r.lo, u, arch, "bootstrap")
            add(base + "Hi", "IC95 superior de " + desc, r.hi, u, arch, "bootstrap")


def semillas() -> None:
    d = ETAPAS[6]                                            # 10 semillas por receta (etapa 6); las ablaciones y el resto siguen en la etapa 3
    n_sem = len(a19.SEMILLAS10)
    add("NSem", "semillas por receta (la original y 101 a 109)", n_sem, "n", "scripts/analizar_t19.py", "SEMILLAS10")
    add("NSemProt", "semillas por receta del protocolo (la original y 101 a 104)", len(a19.SEMILLAS), "n", "scripts/analizar_t19.py", "SEMILLAS")
    add("NSemExtra", "semillas añadidas después de ver las pruebas A y B (105 a 109, desviación 5)", len(a19.SEMILLAS_E16), "n", "scripts/analizar_t19.py", "SEMILLAS_E16")
    add("PMinProt", "valor p mínimo de la prueba de signos exacta bilateral con las semillas del protocolo", 2 * 0.5 ** len(a19.SEMILLAS), "pval", "scripts/analizar_t19.py", "2*0.5^n")
    add("PMinSem", "valor p mínimo de la prueba de signos exacta bilateral con todas las semillas", 2 * 0.5 ** n_sem, "pval", "scripts/analizar_t19.py", "2*0.5^n")
    arch = "evidencia/t19_etapa6/semillas_resumen.csv"
    for r in leer(d / "semillas_resumen.csv").itertuples():
        base, u = f"{{}}{r.receta}{r.prueba}{METRICA[r.metrica]}", unidad(r.metrica)
        for pref, col, nombre in (("Sm", r.media, "media"), ("Sd", r.desviacion, "desviación típica (n-1)"), ("Mn", r.min, "mínimo"), ("Mx", r.max, "máximo")):
            add(base.format(pref), f"{nombre} entre las {n_sem} semillas de {r.receta}, {r.metrica}, prueba {r.prueba}", col, u if pref != "Sd" else "prop", arch, f"{n_sem} semillas")
    arch = "evidencia/t19_etapa6/semillas.csv"
    for r in leer(d / "semillas.csv").itertuples():
        add(f"Sv{r.receta}{r.prueba}{METRICA[r.metrica]}{SEMILLA[str(r.semilla)]}", f"{r.metrica} de {r.receta}, prueba {r.prueba}, semilla {r.semilla}", r.valor,
            unidad(r.metrica), arch, "una semilla")
    sv = leer(d / "semillas.csv")
    for prueba in ("A", "B"):                               # lectura descriptiva, sin prueba de hipótesis: en cuántas semillas v2 supera a v1 en F1 macro
        f1 = sv[(sv.prueba == prueba) & (sv.metrica == "f1_macro")].pivot(index="semilla", columns="receta", values="valor")
        add(f"SvP2MasP1{prueba}", f"semillas (de {len(f1)}) en que P2 supera a P1 en F1 macro, prueba {prueba}", int((f1["P2"] > f1["P1"]).sum()), "n", arch, "descriptivo")
    arch = "evidencia/t19_etapa6/ensemble_vs_mejor_resumen.csv"
    for r in leer(d / "ensemble_vs_mejor_resumen.csv").itertuples():
        base = f"Ev{r.prueba}{METRICA[r.metrica]}"
        desc = f"{r.metrica}, prueba {r.prueba}: ensemble menos la mejor receta individual de cada semilla"
        add(base + "Pos", "semillas con mejora, " + desc, r.positivas, "n", arch, "recuento")
        add(base + "Neg", "semillas sin mejora, " + desc, r.negativas, "n", arch, "recuento")
        add(base + "Pv", "valor p de la prueba de signos exacta bilateral, " + desc, r.p_signos_bilateral, "pval", arch, "binomial exacta")
        add(base + "Mean", "mejora media, " + desc, r.mejora_media, "prop3", arch, f"{n_sem} semillas", firmada=True)
        add(base + "Sd", "desviación típica de la mejora, " + desc, r.mejora_desviacion, "prop", arch, "n-1")
    arch = "evidencia/t19_etapa6/ensemble_vs_mejor.csv"
    for r in leer(d / "ensemble_vs_mejor.csv").itertuples():
        add(f"Es{r.prueba}{METRICA[r.metrica]}{SEMILLA[str(r.semilla)]}", f"mejora del ensemble, {r.metrica}, prueba {r.prueba}, semilla {r.semilla}", r.mejora, "prop3", arch,
            f"mejor individual: {r.receta_mejor}", firmada=True)


def externa() -> None:
    """Etapa 7: evaluación externa en Chapman-Shaoxing (C) y Ningbo (D); prefijo X."""
    d, arch = ETAPAS[7], "evidencia/t19_etapa7/"
    n_vistos = set()
    for r in leer(d / "metricas_globales.csv").itertuples():
        pref = SUBEXT[r.subconjunto]
        base, u = f"{pref}{sid(r.sistema)}{r.prueba}{METRICA[r.metrica]}", unidad(r.metrica)
        desc = f"{r.metrica} de {r.sistema}, prueba {r.prueba} ({r.subconjunto})"
        add(base, desc, r.valor, u, arch + "metricas_globales.csv", f"{r.prueba};{r.subconjunto}")
        if pd.notna(r.lo):
            add(base + "Lo", "IC95 inferior de " + desc, r.lo, u, arch + "metricas_globales.csv", "bootstrap")
            add(base + "Hi", "IC95 superior de " + desc, r.hi, u, arch + "metricas_globales.csv", "bootstrap")
        if (pref, r.prueba) not in n_vistos:
            n_vistos.add((pref, r.prueba))
            add(f"XN{pref[2:]}{r.prueba}", f"registros de la prueba {r.prueba} ({r.subconjunto})", r.n, "n", arch + "metricas_globales.csv", "n")
    for r in leer(d / "metricas_por_clase.csv").itertuples():
        if r.sistema not in SIS_PC_EXT:
            continue
        base, u = f"XC{sid(r.sistema)}{r.prueba}{CK[r.clase]}{POR_CLASE[r.metrica]}", unidad(r.metrica)
        desc = f"{r.metrica} de {r.clase}, {r.sistema}, prueba {r.prueba}"
        add(base, desc, r.valor, u, arch + "metricas_por_clase.csv", r.prueba)
        add(base + "Lo", "IC95 inferior de " + desc, r.lo, u, arch + "metricas_por_clase.csv", "bootstrap")
        add(base + "Hi", "IC95 superior de " + desc, r.hi, u, arch + "metricas_por_clase.csv", "bootstrap")
    for r in leer(d / "diferencias_pareadas.csv").itertuples():
        x, y = (sid(s) for s in r.comparacion.split(" menos "))
        base, u = f"XD{x}{y}{r.prueba}{METRICA[r.metrica]}", "prop3"
        desc = f"{r.metrica}, {r.comparacion}, prueba {r.prueba}"
        add(base, desc, r.diferencia, u, arch + "diferencias_pareadas.csv", "pareada", firmada=True)
        if pd.notna(r.lo):
            add(base + "Lo", "IC95 inferior de " + desc, r.lo, u, arch + "diferencias_pareadas.csv", "bootstrap pareado", firmada=True)
            add(base + "Hi", "IC95 superior de " + desc, r.hi, u, arch + "diferencias_pareadas.csv", "bootstrap pareado", firmada=True)
        add(base + "Pos", "proporción de remuestreos con diferencia positiva, " + desc, r.prop_positiva, "prop", arch + "diferencias_pareadas.csv", "remuestreos")
    for r in leer(d / "diferencia_AB_menos_CD.csv").itertuples():
        base, u = f"XAB{r.referencia}{r.externa}{METRICA[r.metrica]}", "prop3"
        desc = f"{r.metrica} de P3: prueba {r.referencia} menos prueba {r.externa}"
        add(base, desc, r.diferencia, u, arch + "diferencia_AB_menos_CD.csv", "no pareada", firmada=True)
        if pd.notna(r.lo):
            add(base + "Lo", "IC95 inferior de " + desc, r.lo, u, arch + "diferencia_AB_menos_CD.csv", "bootstrap", firmada=True)
            add(base + "Hi", "IC95 superior de " + desc, r.hi, u, arch + "diferencia_AB_menos_CD.csv", "bootstrap", firmada=True)
    # semillas en C y D
    for r in leer(d / "semillas_resumen.csv").itertuples():
        base, u = f"{{}}{r.receta}{r.prueba}{METRICA[r.metrica]}", unidad(r.metrica)
        for pref, col, nombre in (("XSm", r.media, "media"), ("XSd", r.desviacion, "desviación típica (n-1)"), ("XMn", r.min, "mínimo"), ("XMx", r.max, "máximo")):
            add(base.format(pref), f"{nombre} entre las 10 semillas de {r.receta}, {r.metrica}, prueba {r.prueba}", col, u if pref != "XSd" else "prop", arch + "semillas_resumen.csv", "10 semillas")
    sv = leer(d / "semillas.csv")
    for prueba in ("C", "D"):
        f1 = sv[(sv.prueba == prueba) & (sv.metrica == "f1_macro")].pivot(index="semilla", columns="receta", values="valor")
        add(f"XSvP2MasP1{prueba}", f"semillas (de {len(f1)}) en que P2 supera a P1 en F1 macro, prueba {prueba}", int((f1["P2"] > f1["P1"]).sum()), "n", arch + "semillas.csv", "descriptivo")
    for r in leer(d / "ensemble_vs_mejor_resumen.csv").itertuples():
        base = f"XEv{r.prueba}{METRICA[r.metrica]}"
        desc = f"{r.metrica}, prueba {r.prueba}: ensemble menos la mejor receta individual de cada semilla"
        add(base + "Pos", "semillas con mejora, " + desc, r.positivas, "n", arch + "ensemble_vs_mejor_resumen.csv", "recuento")
        add(base + "Neg", "semillas sin mejora, " + desc, r.negativas, "n", arch + "ensemble_vs_mejor_resumen.csv", "recuento")
        add(base + "Pv", "valor p de la prueba de signos exacta bilateral, " + desc, r.p_signos_bilateral, "pval", arch + "ensemble_vs_mejor_resumen.csv", "binomial exacta")
        add(base + "Mean", "mejora media, " + desc, r.mejora_media, "prop3", arch + "ensemble_vs_mejor_resumen.csv", "10 semillas", firmada=True)
        add(base + "Sd", "desviación típica de la mejora, " + desc, r.mejora_desviacion, "prop", arch + "ensemble_vs_mejor_resumen.csv", "n-1")
    # reparto externo y duplicados
    rep_ = json.loads((EV / "reparto_externo.json").read_text(encoding="utf-8"))
    dup = json.loads((EV / "duplicados_externa.json").read_text(encoding="utf-8"))
    aud = json.loads((EV / "auditoria_externa.json").read_text(encoding="utf-8"))
    ar = "evidencia/reparto_externo.json"
    for o, v in rep_["origenes"].items():
        add(f"XRp{o}", f"registros de la prueba {o}", v["registros"], "n", ar, "registros")
        add(f"XRpExcl{o}", f"registros excluidos del origen de la prueba {o}", v["excluidos_en_este_origen"], "n", ar, "excluidos")
        add(f"XRpSinClase{o}", f"registros sin ninguna de las 12 clases, prueba {o}", v["registros_sin_ninguna_clase"], "n", ar, "sin clase")
        add(f"XNEval{o}", f"clases evaluables de la prueba {o}", len(v["clases_evaluables"]), "n", ar, "evaluables")
        for c, k in v["positivos"].items():
            add(f"XRpPos{CK[c]}{o}", f"positivos de {c}, prueba {o}", k, "n", ar, "positivos")
    add("XRpTotalExcl", "registros excluidos de C y D (JS13118 y duplicados)", rep_["total_excluidos"], "n", ar, "total_excluidos")
    ad = "evidencia/duplicados_externa.json"
    add("XDupGrupos", "grupos de registros con señal idéntica en C y D", dup["grupos_de_senal_identica"], "n", ad, "grupos")
    add("XDupRegistros", "registros en grupos de señal idéntica", dup["registros_en_grupos"], "n", ad, "registros")
    add("XDupEntre", "grupos de señal idéntica entre C y D", dup["grupos_entre_origenes"], "n", ad, "entre orígenes")
    add("XDupDentro", "grupos de señal idéntica dentro de un mismo origen", dup["grupos_de_senal_identica"] - dup["grupos_entre_origenes"], "n", ad, "dentro de un origen")
    add("XDupDiscord", "grupos con etiquetas discordantes en las 12 clases", dup["grupos_con_clases_discordantes_en_las_12"], "n", ad, "discordantes")
    add("XDupConcord", "grupos con etiquetas concordantes en las 12 clases", dup["grupos_de_senal_identica"] - dup["grupos_con_clases_discordantes_en_las_12"], "n", ad, "concordantes")
    add("XDupDescartados", "registros descartados por duplicado", dup["descartados_por_duplicado"], "n", ad, "descartados")
    add("XDup2020", "registros de C y D que coinciden con el Challenge 2020", len(dup["coincidentes_con_el_challenge_2020"]), "n", ad, "coincidencias")
    add("XRegs2020", "registros del Challenge 2020 comparados", dup["registros_2020_leidos"], "n", ad, "registros 2020")
    aa = "evidencia/auditoria_externa.json"
    add("XRawC", "registros de Chapman-Shaoxing publicados", aud["chapman_shaoxing"]["esperado_sin_exclusiones"], "n", aa, "publicados")
    add("XRawD", "registros de Ningbo publicados", aud["ningbo"]["esperado_sin_exclusiones"], "n", aa, "publicados")
    add("XNSist", "sistemas congelados evaluados en C y D", len(a19.SISTEMAS7), "n", "scripts/analizar_t19.py", "SISTEMAS7")
    add("XRawTotal", "registros publicados de C y D", aud["chapman_shaoxing"]["esperado_sin_exclusiones"] + aud["ningbo"]["esperado_sin_exclusiones"], "n", aa, "publicados")


def recalibracion_local() -> None:
    """E13 (exploratoria, desviación 6): recalibración local en C y D; prefijo RL."""
    arch = "evidencia/e13_recalibracion_local/"
    for r in leer(E13 / "metricas_globales.csv").itertuples():
        base, u = f"RL{sid(r.sistema)}{r.prueba}{r.variante}{RLMET[r.metrica]}", ("n" if r.metrica.startswith(("fn_", "fp_")) else unidad(r.metrica))
        desc = f"{r.metrica} de {r.sistema} ({r.variante}), prueba {r.prueba}"
        add(base, desc, r.valor, u, arch + "metricas_globales.csv", f"{r.prueba};{r.variante}")
        if pd.notna(r.lo):
            add(base + "Lo", "IC95 inferior de " + desc, r.lo, u, arch + "metricas_globales.csv", "bootstrap")
            add(base + "Hi", "IC95 superior de " + desc, r.hi, u, arch + "metricas_globales.csv", "bootstrap")
    for r in leer(E13 / "diferencias_pareadas.csv").itertuples():
        v = r.comparacion.split(" ")[0]
        base = f"RLD{sid(r.sistema)}{r.prueba}{v}{RLMET[r.metrica]}"
        desc = f"{r.metrica}, {r.sistema}, {r.comparacion}, prueba {r.prueba}"
        add(base, desc, r.diferencia, "prop3", arch + "diferencias_pareadas.csv", "pareada", firmada=True)
        if pd.notna(r.lo):
            add(base + "Lo", "IC95 inferior de " + desc, r.lo, "prop3", arch + "diferencias_pareadas.csv", "bootstrap pareado", firmada=True)
            add(base + "Hi", "IC95 superior de " + desc, r.hi, "prop3", arch + "diferencias_pareadas.csv", "bootstrap pareado", firmada=True)
    est = leer(E13 / "estabilidad_particiones.csv")
    for (o, v), x in est[(est.sistema == "P3") & (est.metrica == "f1_macro")].groupby(["prueba", "variante"]):
        add(f"RLEstM{o}{v}", f"F1 macro de P3 ({v}), prueba {o}: media de 5 particiones", x.valor.mean(), "prop3", arch + "estabilidad_particiones.csv", "5 particiones")
        add(f"RLEstS{o}{v}", f"F1 macro de P3 ({v}), prueba {o}: desviación típica de 5 particiones", x.valor.std(ddof=1), "prop", arch + "estabilidad_particiones.csv", "n-1")
    cur = leer(E13 / "curva_etiquetas_locales.csv")
    for (o, v, n), x in cur.groupby(["prueba", "variante", "registros_de_ajuste"]):
        etiqueta = "All" if n == cur[cur.prueba == o].registros_de_ajuste.max() else str(int(n))
        if v == "V2":
            add(f"RLCurF1{o}{v}{etiqueta}", f"F1 macro de P3 ({v}) con {int(n)} registros de ajuste, prueba {o} (media de {len(x)})", x.f1_macro.mean(), "prop3", arch + "curva_etiquetas_locales.csv", "media")
            add(f"RLCurFN{o}{v}{etiqueta}", f"falsos negativos por 1000, P3 ({v}), {int(n)} registros de ajuste, prueba {o}", x.fn_por_1000.mean(), "n", arch + "curva_etiquetas_locales.csv", "media")
            add(f"RLCurFP{o}{v}{etiqueta}", f"falsos positivos por 1000, P3 ({v}), {int(n)} registros de ajuste, prueba {o}", x.fp_por_1000.mean(), "n", arch + "curva_etiquetas_locales.csv", "media")
        if etiqueta == "All" and v == "V2":
            add(f"RLCurN{o}", f"registros de la mitad de ajuste, prueba {o}", n, "n", arch + "curva_etiquetas_locales.csv", "mitad")
            add(f"RLCurV0{o}", f"F1 macro de P3 congelado en la mitad de medición, prueba {o}", x.f1_macro_V0_misma_mitad.iloc[0], "prop3", arch + "curva_etiquetas_locales.csv", "V0 misma mitad")
    for r in leer(E13 / "por_clase_P3.csv").itertuples():
        for m, nombre in (("f1", "F1"), ("sens", "Sens"), ("prec", "Prec")):
            add(f"RLC{r.prueba}{r.variante}{CK[r.clase]}{nombre}", f"{m} de {r.clase}, P3 ({r.variante}), prueba {r.prueba}", getattr(r, m), "prop3" if m == "f1" else "prop", arch + "por_clase_P3.csv", f"{r.prueba};{r.variante}")


def entrenamiento() -> None:
    arch = "evidencia/t19_etapa3/entrenamiento.csv"
    filas = [(arch, r) for r in leer(ETAPAS[3] / "entrenamiento.csv").itertuples()]
    vistos = {r.sistema for _, r in filas}
    filas += [("evidencia/t19_etapa6/entrenamiento.csv", r) for r in leer(ETAPAS[6] / "entrenamiento.csv").itertuples() if r.sistema not in vistos]
    for arch, r in filas:
        s = sid(r.sistema)
        add(f"Tr{s}Params", f"parámetros entrenables de {r.sistema}", r.parametros, "n", arch, "training_summary.json")
        add(f"Tr{s}Epocas", f"épocas completadas por {r.sistema}", r.epocas, "epoch", arch, "training_summary.json")
        add(f"Tr{s}Mejor", f"mejor época de {r.sistema}", r.mejor_epoca, "epoch", arch, "training_summary.json")
        add(f"Tr{s}Min", f"minutos de entrenamiento de {r.sistema}", r.minutos, "min", arch, "training_summary.json")
    # CNN y variantes enmascaradas (etapa 2): se leen de los training_summary.json guardados
    import glob
    for sistema, exp in (("CNN", "t19_cnn"), ("P1m", "t19_v1_mask"), ("P2m", "t19_v2_mask")):
        rutas = glob.glob(str(REPO / "saved" / "t19" / exp / "*" / "training_summary.json"))
        assert len(rutas) == 1, exp
        s = json.loads(Path(rutas[0]).read_text(encoding="utf-8"))
        mejor = [h for h in s["history"] if h["improved"]][-1]["epoch"]
        arch2 = f"saved/t19/{exp}/training_summary.json"
        add(f"Tr{sistema}Params", f"parámetros entrenables de {sistema}", s["num_parameters"]["trainable"], "n", arch2, "num_parameters")
        add(f"Tr{sistema}Epocas", f"épocas completadas por {sistema}", s["epochs_completed"], "epoch", arch2, "epochs_completed")
        add(f"Tr{sistema}Mejor", f"mejor época de {sistema}", mejor, "epoch", arch2, "history")
        add(f"Tr{sistema}Min", f"minutos de entrenamiento de {sistema}", s["total_seconds"] / 60, "min", arch2, "total_seconds")


def reparto() -> dict:
    """Tamaños, orígenes, positivos por clase y celdas origen-clase sin anotar del reparto nuevo (data/cinc2020_12_origen/split_assignments.csv)."""
    arch = "data/cinc2020_12_origen/split_assignments.csv"
    d = pd.read_csv(REPO / arch)
    meta = json.loads((EV / "reparto_t19.json").read_text(encoding="utf-8"))
    assert meta["split_assignments_sha256"] == a19.sha256(REPO / arch), "el reparto en disco no es el registrado"
    tam = d["split"].value_counts().to_dict()
    assert tam == meta["tamanos"], tam
    for k, nombre in PARTICION.items():
        add(f"Rp{nombre}", f"registros de la partición {k}", tam[k], "n", arch, f"split={k}")
    add("RpTrainVent", "ventanas de entrenamiento (un registro largo aporta varias)", meta["hdf5"]["train"]["muestras"], "n", "evidencia/reparto_t19.json", "hdf5.train.muestras")
    add("RpPacientesSolape", "pacientes con registros en más de una partición", meta["pacientes_en_mas_de_una_particion"], "n", "evidencia/reparto_t19.json", "verificación")
    for o, on in ORIGEN.items():
        for k, nombre in PARTICION.items():
            add(f"Rp{on}{nombre}", f"registros de {o} en {k}", int(((d.source_db == o) & (d["split"] == k)).sum()), "n", arch, f"{o};{k}")
    prevalencia_total = d[CLASSES].mean()
    for c in CLASSES:
        for k, nombre in PARTICION.items():
            add(f"RpPos{CK[c]}{nombre}", f"positivos de {c} en {k}", int(d.loc[d["split"] == k, c].sum()), "n", arch, f"{c};{k}")
        add(f"RpPrev{CK[c]}", f"prevalencia de {c} en los {len(d)} registros", 100 * prevalencia_total[c], "pct", arch, c)
    for k, nombre in PARTICION.items():
        add(f"RpPrevMedia{nombre}", f"prevalencia media por clase en {k}", d.loc[d["split"] == k, CLASSES].mean().mean(), "prop", arch, k)
    grupos = pd.read_csv(REPO / "data" / "externo" / "patient_groups.csv")
    assert meta["grupos_sha256"] == a19.sha256(REPO / "data" / "externo" / "patient_groups.csv"), "los grupos de paciente en disco no son los registrados"
    add("RpGrupos", "pacientes distintos entre los registros de PTB-XL y PTB que traen grupo", grupos.group_id.nunique(), "n", "data/externo/patient_groups.csv", "group_id")
    add("RpRegGrupo", "registros de PTB-XL y PTB con grupo de paciente", len(grupos), "n", "data/externo/patient_groups.csv", "filas")
    sin_id = d[(d["split"] == "test") & d.source_db.isin(["cpsc_2018", "cpsc_2018_extra", "st_petersburg_incart"])]
    add("RpASinId", "registros de la prueba A de orígenes sin identificador de paciente (CPSC 2018, su ampliación e INCART)", len(sin_id), "n", arch, "split=test")
    add("RpASinIdPct", "porcentaje de la prueba A que viene de orígenes sin identificador de paciente", 100 * len(sin_id) / tam["test"], "pct", arch, "split=test")
    sin_clase = d[CLASSES].sum(axis=1) == 0
    add("RpSinClase", "registros sin ninguna clase", int(sin_clase.sum()), "n", arch, "suma de clases = 0")
    for k, nombre in (("test", "A"), ("test_b", "B"), ("train", "Train"), ("val", "Val")):
        add(f"RpSinClase{nombre}", f"registros sin ninguna clase en {k}", int((sin_clase & (d["split"] == k)).sum()), "n", arch, k)
    add("RpSinClasePtb", "registros sin ninguna clase del origen PTB", int((sin_clase & (d.source_db == "ptb")).sum()), "n", arch, "ptb")
    # pos_weight del entrenamiento (negativos entre positivos por clase, sobre las ventanas de entrenamiento)
    from ecg.train import compute_pos_weight
    pw, _, _ = compute_pos_weight(REPO / "data" / "cinc2020_12_origen" / "train.h5", None)
    pw = pw.numpy() if hasattr(pw, "numpy") else np.asarray(pw)
    add("RpPosWeightMin", "peso de positivos mínimo (negativos/positivos en entrenamiento)", pw.min(), "prop", "data/cinc2020_12_origen/train.h5", "derivado de las etiquetas")
    add("RpPosWeightMax", "peso de positivos máximo (negativos/positivos en entrenamiento)", pw.max(), "prop", "data/cinc2020_12_origen/train.h5", "derivado de las etiquetas")
    # celdas origen-clase sin positivos en el entrenamiento nuevo y su cobertura documentada (evidencia/cobertura_etiquetas.csv)
    cob = pd.read_csv(EV / "cobertura_etiquetas.csv").set_index(["origen", "clase"])
    entren = d[d["split"] == "train"]
    sin = [(o, c) for o in sorted(entren.source_db.unique()) for c in CLASSES if entren.loc[entren.source_db == o, c].sum() == 0]
    estado = pd.Series([cob.loc[(o, c), "cobertura_documentada"] for o, c in sin]).value_counts().to_dict()
    assert estado.get("cubierta", 0) == 0, "hay celdas sin positivos cuya clase la documentación cubre: actualizar 02_metodos.tex (dice que no contradice ninguna)"
    add("RpCeldas", "celdas origen-clase de entrenamiento (5 orígenes x 12 clases)", entren.source_db.nunique() * len(CLASSES), "n", arch, "train")
    add("RpCeldasSinAnotar", "celdas origen-clase sin positivos en el entrenamiento", len(sin), "n", arch, "train")
    add("RpCobFuera", "celdas sin positivos que la documentación confirma como fuera del vocabulario", estado.get("fuera", 0), "n", "evidencia/cobertura_etiquetas.csv", "documentada=fuera")
    add("RpCobSinDoc", "celdas sin positivos que la documentación no permite confirmar", estado.get("sin documentar", 0), "n", "evidencia/cobertura_etiquetas.csv", "documentada=sin documentar")
    add("RpCobCubierta", "celdas sin positivos cuya clase la documentación sí cubre", estado.get("cubierta", 0), "n", "evidencia/cobertura_etiquetas.csv", "documentada=cubierta")
    fuera_con_pos = [(o, c) for (o, c), f in cob.iterrows()
                     if o in set(entren.source_db) and f["cobertura_documentada"] == "fuera" and entren.loc[entren.source_db == o, c].sum() > 0]
    add("RpCobFueraConPos", "celdas con positivos de una clase que el vocabulario documentado del origen no incluye", len(fuera_con_pos), "n", arch, "documentada=fuera con positivos")
    return {"sin": sin, "estado": estado, "fuera_con_pos": fuera_con_pos}


def sens_a_espec(y: np.ndarray, p: np.ndarray, espec: float) -> float:
    """Mayor sensibilidad con especificidad >= espec (punto de la curva ROC con fpr <= 1 - espec)."""
    fpr, tpr, _ = roc_curve(y, p)
    return float(tpr[fpr <= 1 - espec + 1e-12].max())


def predicciones(sistema: str, prueba: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    ruta = EVAL / f"{sistema.lower()}_{prueba}" / "predictions_test.csv"
    assert a19.sha256(ruta) == a19.SHA256[f"{sistema}_{prueba}"], f"{ruta} no es la predicción registrada"
    d = pd.read_csv(ruta)
    return (d[[f"true_{c}" for c in CLASSES]].to_numpy(np.uint8), d[[f"prob_{c}" for c in CLASSES]].to_numpy(float),
            d[[f"pred_{c}" for c in CLASSES]].to_numpy(np.uint8))


def desde_predicciones() -> dict:
    """Sensibilidad con la especificidad fijada y matriz de confusión multietiqueta de P3 en las pruebas A y B."""
    salida = {}
    for prueba in ("A", "B"):
        y, p, yhat = predicciones("P3", prueba)
        peso = y.sum(0) / y.sum()
        arch = f"runs/t19/eval/p3_{prueba}/predictions_test.csv"
        for esp in ESPEC:
            etq = f"{round(esp * 100)}"
            sens = np.array([sens_a_espec(y[:, i], p[:, i], esp) for i in range(len(CLASSES))])
            for i in range(len(CLASSES)):                    # comprobación independiente: umbral = (k+1)-ésimo mayor negativo, con k falsos positivos permitidos
                neg = np.sort(p[y[:, i] == 0, i])
                corte = neg[len(neg) - int((1 - esp) * len(neg) + 1e-9) - 1]
                assert abs(float((p[y[:, i] == 1, i] > corte).mean()) - sens[i]) < 2e-3, f"sensibilidad con especificidad fijada de {CLASSES[i]}"
            for i, c in enumerate(CLASSES):
                add(f"Sp{etq}{prueba}{CK[c]}", f"sensibilidad de {c} con especificidad fijada en {esp}, P3, prueba {prueba}", sens[i], "prop", arch, "derivado")
            add(f"Sp{etq}{prueba}Mac", f"sensibilidad macro con especificidad fijada en {esp}, P3, prueba {prueba}", sens.mean(), "prop", arch, "derivado")
            add(f"Sp{etq}{prueba}Wt", f"sensibilidad ponderada con especificidad fijada en {esp}, P3, prueba {prueba}", float((peso * sens).sum()), "prop", arch, "derivado")

        def celda(i: int, j: int) -> float:                  # diagonal: sensibilidad; fuera de ella, P(pred_j = 1 | true_i = 1, true_j = 0)
            sel = (y[:, i] == 1) if i == j else (y[:, i] == 1) & (y[:, j] == 0)
            return float(yhat[sel, j].mean())
        m = np.array([[celda(i, j) for j in range(len(CLASSES))] for i in range(len(CLASSES))])
        pd.DataFrame(m, index=CLASSES, columns=CLASSES).to_csv(EV / f"matriz_confusion_{prueba}.csv", float_format="%.6f", lineterminator="\n")
        fuera = sorted(((m[i, j], CLASSES[i], CLASSES[j]) for i in range(12) for j in range(12) if i != j), reverse=True)
        for k, (v, ci, cj) in enumerate(fuera[:3], start=1):
            add(f"ConfTop{prueba}{k}", f"mayor confusión fuera de la diagonal nº {k}, prueba {prueba}: registros con {ci} y sin {cj} en que se predice {cj}", v, "prop",
                f"evidencia/matriz_confusion_{prueba}.csv", f"{ci}->{cj}")
        add(f"ConfDiagMin{prueba}", f"menor valor de la diagonal, prueba {prueba}", np.diag(m).min(), "prop", f"evidencia/matriz_confusion_{prueba}.csv", "diagonal")
        esperado = {"A": [("LVH", "TAb"), ("STach", "TAb"), ("MI", "TAb")], "B": [("AxisDev", "MI"), ("LVH", "MI"), ("TAb", "MI")]}[prueba]
        assert [(ci, cj) for _, ci, cj in fuera[:3]] == esperado, f"cambiaron las mayores confusiones de la prueba {prueba}: actualizar 03_resultados.tex"
        assert (CLASSES[int(np.diag(m).argmin())], CLASSES[int(np.diag(m).argmax())]) == {"A": ("AEctopy_Junctional", "NSR"), "B": ("AxisDev", "AVBlock")}[prueba],             f"cambió la clase de menor o mayor sensibilidad de la prueba {prueba}: actualizar 03_resultados.tex"
        salida[prueba] = {"top": fuera[:3], "diag_min": CLASSES[int(np.diag(m).argmin())], "diag_max": CLASSES[int(np.diag(m).argmax())]}
    return salida


def calibracion_validacion() -> None:
    for s in ("p1", "p2"):
        arch = f"runs/t19/eval/{s}/calibration_report_platt.json"
        d = json.loads((REPO / arch).read_text(encoding="utf-8"))
        add(f"Cal{s.upper()}EceAntes", f"ECE de validación de {s.upper()} sin calibrar", d["ece_before"], "prop", arch, "ece_before")
        add(f"Cal{s.upper()}EceDesp", f"ECE de validación de {s.upper()} con calibración afín", d["ece_after"], "prop", arch, "ece_after")


def subconjunto_por_paciente() -> None:
    """P1, P2 y P3 en el subconjunto de la prueba A separado por paciente (PTB-XL y PTB): lectura descriptiva, con los mismos remuestreos del análisis."""
    sis = ("P1", "P2", "P3")
    datos, asign, _ = a19.cargar(sis)
    origen = asign.set_index("record_name").loc[datos["P3", "A"][0], "source_db"].to_numpy()
    sel = np.isin(origen, ("ptb-xl", "ptb"))
    puntual, boot = a19.analizar(a19.construir(datos, "A", sis, sel))
    arch = "runs/t19/eval/*_A/predictions_test.csv"
    add("PpN", "registros de la prueba A de PTB-XL y PTB, separados por paciente", int(sel.sum()), "n", arch, "source_db en ptb-xl y ptb")
    for k in sis:
        for m, nombre in (("f1_macro", "F1mac"), ("auroc_macro", "Auroc")):
            lo, hi = a19.ic(boot[k][m], m)
            u = unidad(m)
            desc = f"{m} de {k} en el subconjunto de la prueba A separado por paciente"
            add(f"Pp{k}{nombre}", desc, puntual[k][m], u, arch, "bootstrap, descriptivo")
            add(f"Pp{k}{nombre}Lo", "IC95 inferior de " + desc, lo, u, arch, "bootstrap")
            add(f"Pp{k}{nombre}Hi", "IC95 superior de " + desc, hi, u, arch, "bootstrap")


def robustez() -> None:
    """Robustez de P2 (exploratoria, un sorteo por nivel): F1 macro bajo cada perturbación y su cambio respecto de la señal sin perturbar, en las pruebas A y B."""
    n_esperado = {"A": "RpA", "B": "RpB"}
    for prueba in ("A", "B"):
        arch = f"runs/t19/robustez/p2_{prueba}.csv"
        d = pd.read_csv(REPO / arch)
        assert set(d["samples"]) == {int(next(r["valor"] for r in FILAS if r["id"] == n_esperado[prueba]))}, f"{arch}: no tiene los registros de la prueba {prueba}"
        base = float(d.loc[d["perturbation"] == "clean", "f1_macro"].iloc[0])
        add(f"Rob{prueba}Clean", f"F1 macro de P2 sin perturbar, prueba {prueba}", base, "prop3", arch, "clean")
        for r in d[d["perturbation"] != "clean"].itertuples():
            slug = r.perturbation.replace("_", "").capitalize() + str(float(r.level)).replace(".", "")
            if prueba == "A":
                add(f"RobLvl{slug}", f"nivel de la perturbación {r.perturbation}", r.level, "param", arch, r.perturbation)
            add(f"Rob{prueba}F1{slug}", f"F1 macro de P2 con {r.perturbation} {r.level}, prueba {prueba}", r.f1_macro, "prop3", arch, "un sorteo")
            add(f"Rob{prueba}Delta{slug}", f"cambio del F1 macro de P2 con {r.perturbation} {r.level}, prueba {prueba}", r.f1_macro - base, "prop3", arch, "un sorteo", firmada=True)


def escribir() -> None:
    with (EV / "cifras_t19.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["id", "concepto", "valor", "unidad", "archivo", "clave"], lineterminator="\n")
        w.writeheader()
        w.writerows(FILAS)
    lineas = ["% Generado por tesis/scripts/calcular_t19.py a partir de evidencia/cifras_t19.csv: NO editar a mano.",
              r"\newcommand{\cf}[1]{\csname cf:#1\endcsname}", r"\newcommand{\cfs}[1]{\csname cfs:#1\endcsname}"]
    for r in FILAS:
        v, u = r["valor"], r["unidad"]
        if u == "prop3":
            texto = (r"\ensuremath{-}" if v < 0 and round(abs(v), 3) != 0 else "") + f"{abs(v):.3f}"
            firmado = (r"\ensuremath{-}" if v < 0 and round(abs(v), 3) != 0 else r"\ensuremath{+}") + f"{abs(v):.3f}"
        elif u == "pval":
            texto = firmado = f"{v:.3g}"
        else:
            texto = natural(v, u)
            firmado = (r"\ensuremath{-}" if v < 0 and float(redondear(v, u).replace(r"\,", "")) != 0 else r"\ensuremath{+}") + redondear(v, u)
        lineas.append(r"\expandafter\gdef\csname cf:%s\endcsname{%s}" % (r["id"], texto))
        if r["id"] in FIRMADAS:
            lineas.append(r"\expandafter\gdef\csname cfs:%s\endcsname{%s}" % (r["id"], firmado))
    (IEEE / "capitulos" / "cifras_t19.tex").write_text("\n".join(lineas) + "\n", encoding="utf-8", newline="\n")


SEEN: set = set()
SEEN_C: set = set()
SEEN_D: set = set()
SEEN_AB: set = set()
SEEN_O: set = set()


def constantes_del_analisis() -> None:
    """Remuestreos, semilla del bootstrap y especificidades fijadas: las constantes con las que se calcularon los resultados, no copias que puedan desviarse."""
    add("NBoot", "remuestreos del bootstrap", a19.REMUESTREOS, "n", "scripts/analizar_t19.py", "REMUESTREOS")
    add("BootSeed", "semilla del bootstrap", a19.SEMILLA, "n", "scripts/analizar_t19.py", "SEMILLA")
    add("SpecFijaA", "especificidad fijada, nivel A", ESPEC[0], "prop", "scripts/calcular_t19.py", "ESPEC")
    add("SpecFijaB", "especificidad fijada, nivel B", ESPEC[1], "prop", "scripts/calcular_t19.py", "ESPEC")


def main() -> int:
    estaticas()
    constantes_del_analisis()
    info = reparto()
    for etapa in (1, 2, 3, 4):
        metricas_globales(etapa)
        diferencias(etapa)
        a_menos_b(etapa)
    for etapa in (1, 2):
        metricas_por_clase(etapa)
        por_origen(etapa)
    semillas()
    externa()
    recalibracion_local()
    entrenamiento()
    conf = desde_predicciones()
    calibracion_validacion()
    subconjunto_por_paciente()
    robustez()
    escribir()
    print(f"{len(FILAS)} cifras de T19 en evidencia/cifras_t19.csv y capitulos/cifras_t19.tex")
    print("celdas sin anotar en el entrenamiento:", info["sin"], info["estado"], "con positivos fuera del vocabulario:", info["fuera_con_pos"])
    print("confusiones:", {k: [(round(float(v), 3), i, j) for v, i, j in x["top"]] for k, x in conf.items()})
    print("diagonal: mínimo", {k: x["diag_min"] for k, x in conf.items()}, "máximo", {k: x["diag_max"] for k, x in conf.items()})
    return 0


if __name__ == "__main__":
    sys.exit(main())
