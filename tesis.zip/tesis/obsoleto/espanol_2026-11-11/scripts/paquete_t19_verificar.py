"""Verifica el paquete de reproducibilidad de T19 sin datos crudos, sin GPU y sin entrenar nada.

Pasos (todos se ejecutan; el código de salida es 0 solo si ninguno falla):
  1. hashes: cada archivo del paquete coincide con su SHA-256 de SHA256SUMS.txt y no sobra ninguno;
  2. partición: las predicciones de cada sistema cubren exactamente los registros de la prueba A (``test``) o de la B (``test_b``) de
     ``data/cinc2020_12_origen/split_assignments.csv``, con las mismas etiquetas;
  3. umbrales: los umbrales guardados salen de las predicciones de validación (malla de 0.01 a 0.99, F1, primer máximo) y las decisiones
     ``pred_`` de las pruebas son ``prob_ >= umbral``;
  4. métricas: F1 macro, micro y ponderado, coincidencia exacta, AUROC macro, AUPRC macro, ECE y Brier de cada sistema y prueba se recalculan
     desde las predicciones y coinciden (1e-6) con ``resultados/t19_etapa*/metricas_globales.csv``;
  5. evaluación externa (Chapman-Shaoxing, C, y Ningbo, D): las predicciones de cada sistema cubren exactamente los registros de
     ``data/cinc2021_externo/*.records.csv`` con sus etiquetas, los umbrales son los de la prueba A, las decisiones son ``prob_ >= umbral`` y las métricas
     sobre las clases evaluables de cada base se recalculan y coinciden (1e-6) con ``resultados/t19_etapa7/metricas_globales.csv``;
  6. con ``--completo``: se repite todo el análisis (``analisis/analizar_t19.py``, etapas 1 a 4, 6 y 7, y ``analisis/recalibracion_local.py``,
     1 000 remuestreos, semilla 0) y sus CSV deben salir byte a byte iguales a los de ``resultados/``.
Lo que no se puede recomputar aquí (la calibración afín, que parte de los logits de los pesos y de los datos crudos, ni los pesos) se
documenta en el LEEME.

Uso, desde la raíz del paquete:  python verificar_paquete.py [--completo]
Necesita numpy, pandas, scikit-learn y scipy (``constraints.txt``) y la carpeta ``ecg/`` del paquete, que importa sin PyTorch.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, f1_score, fbeta_score, roc_auc_score

RAIZ = Path(__file__).resolve().parent
sys.path.insert(0, str(RAIZ))
from ecg.calibration import brier_score, expected_calibration_error  # noqa: E402
from ecg.schema import CLASS_NAMES as CLASES  # noqa: E402

EVAL = RAIZ / "runs" / "t19" / "eval"
RESULTADOS = RAIZ / "resultados"
PARTICION = {"A": "test", "B": "test_b"}
ETAPAS = (1, 2, 3, 4, 6)                            # la 4 es exploratoria (calibración por temperatura); la 6 son las 10 semillas de P1 y P2
EXTERNAS = {"C": "test_c", "D": "test_d"}           # evaluación externa (etapa 7): Chapman-Shaoxing y Ningbo
ETAPAS_COMPLETO = ETAPAS + (7,)
TOLERANCIA = 1e-6                                   # los CSV guardan seis decimales
ERRORES: list[str] = []


def falla(texto: str) -> None:
    ERRORES.append(texto)
    print("  ERROR:", texto)


def sha256(ruta: Path) -> str:
    h = hashlib.sha256()
    with ruta.open("rb") as fh:
        for bloque in iter(lambda: fh.read(1 << 20), b""):
            h.update(bloque)
    return h.hexdigest()


def paso_hashes() -> None:
    print("1. Hashes de SHA256SUMS.txt")
    esperado = {}
    for linea in (RAIZ / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        h, ruta = linea.split("  ", 1)
        esperado[ruta] = h
    for ruta, h in esperado.items():
        archivo = RAIZ / ruta
        if not archivo.is_file():
            falla(f"falta {ruta}")
        elif sha256(archivo) != h:
            falla(f"cambió {ruta}")
    presentes = {p.relative_to(RAIZ).as_posix() for p in RAIZ.rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.name != "SHA256SUMS.txt"}
    for ruta in sorted(presentes - set(esperado)):
        falla(f"archivo sin hash en SHA256SUMS.txt: {ruta}")
    print(f"   {len(esperado)} archivos comprobados")


def predicciones(sistema: str, prueba: str, validacion: bool = False) -> pd.DataFrame:
    nombre = "predictions_validation.csv" if validacion else "predictions_test.csv"
    return pd.read_csv(EVAL / f"{sistema.lower()}_{prueba}" / nombre)


def sistemas_evaluados() -> list[str]:
    """Nombres de sistema (``P1``, ``P3_S101``, ``ABL_AUG``...) de todas las etapas, sin repetir."""
    vistos: list[str] = []
    for etapa in ETAPAS:
        for s in pd.read_csv(RESULTADOS / f"t19_etapa{etapa}" / "metricas_globales.csv")["sistema"]:
            if s not in vistos:
                vistos.append(s)
    return vistos


def paso_particion(sistemas: list[str]) -> None:
    print("2. Partición y etiquetas de las predicciones")
    asign = pd.read_csv(RAIZ / "data" / "cinc2020_12_origen" / "split_assignments.csv").set_index("record_name")
    for prueba, nombre in PARTICION.items():
        esperados = asign[asign["split"] == nombre]
        for s in sistemas:
            d = predicciones(s, prueba).set_index("record_name")
            if set(d.index) != set(esperados.index) or len(d) != len(esperados):
                falla(f"{s} prueba {prueba}: los registros no son los de la partición {nombre}")
                continue
            y = d[[f"true_{c}" for c in CLASES]].to_numpy()
            if not (y == esperados.loc[d.index, CLASES].to_numpy()).all():
                falla(f"{s} prueba {prueba}: las etiquetas no coinciden con split_assignments.csv")
    print(f"   {len(sistemas)} sistemas x 2 pruebas")


def umbrales_de_validacion(y: np.ndarray, p: np.ndarray) -> float:
    mejor_t, mejor = 0.5, -1.0
    for t in np.linspace(0.01, 0.99, 99):
        score = fbeta_score(y, (p >= t).astype(np.uint8), beta=1.0, zero_division=0)
        if score > mejor:
            mejor_t, mejor = float(t), float(score)
    return mejor_t


def paso_umbrales(sistemas: list[str]) -> None:
    print("3. Umbrales y decisiones")
    for s in sistemas:
        guardado = pd.read_csv(EVAL / f"{s.lower()}_A" / "thresholds_validation.csv").set_index("class")["threshold"]
        val = predicciones(s, "A", validacion=True)
        for c in CLASES:
            t = umbrales_de_validacion(val[f"true_{c}"].to_numpy().astype(np.uint8), val[f"prob_{c}"].to_numpy())
            if abs(t - float(guardado[c])) > 1e-6:
                falla(f"{s}: el umbral de {c} sale {t:.2f} de las predicciones de validación y está guardado {float(guardado[c]):.2f}")
        for prueba in PARTICION:
            d = predicciones(s, prueba)
            guardado_p = pd.read_csv(EVAL / f"{s.lower()}_{prueba}" / "thresholds_validation.csv").set_index("class")["threshold"]
            if not guardado_p.equals(guardado):
                falla(f"{s}: los umbrales de la prueba {prueba} difieren de los de la A")
            for c in CLASES:
                pred = (d[f"prob_{c}"].to_numpy() >= np.float32(guardado[c])).astype(int)
                if (pred != d[f"pred_{c}"].to_numpy()).any():
                    falla(f"{s} prueba {prueba}: la decisión de {c} no es prob >= umbral")
    print(f"   {len(sistemas)} sistemas")


def metricas(d: pd.DataFrame) -> dict[str, float]:
    y = d[[f"true_{c}" for c in CLASES]].to_numpy(np.uint8)
    p = d[[f"prob_{c}" for c in CLASES]].to_numpy(float)
    yh = d[[f"pred_{c}" for c in CLASES]].to_numpy(np.uint8)
    return {"f1_macro": f1_score(y, yh, average="macro", zero_division=0), "f1_micro": f1_score(y, yh, average="micro", zero_division=0),
            "f1_ponderado": f1_score(y, yh, average="weighted", zero_division=0), "exacta": float((y == yh).all(1).mean()),
            "auroc_macro": float(np.mean([roc_auc_score(y[:, i], p[:, i]) for i in range(len(CLASES))])),
            "auprc_macro": float(np.mean([average_precision_score(y[:, i], p[:, i]) for i in range(len(CLASES))])),
            "ece": expected_calibration_error(y, p, 15), "brier": brier_score(y, p)}


def paso_metricas(sistemas: list[str]) -> dict:
    print("4. Métricas recalculadas contra metricas_globales.csv")
    calculadas = {(s, pr): metricas(predicciones(s, pr)) for s in sistemas for pr in PARTICION}
    comprobadas = 0
    for etapa in ETAPAS:
        ref = pd.read_csv(RESULTADOS / f"t19_etapa{etapa}" / "metricas_globales.csv").query("subconjunto == 'completa'")
        for r in ref.itertuples():
            if r.metrica in calculadas[(r.sistema, r.prueba)]:
                dif = abs(calculadas[(r.sistema, r.prueba)][r.metrica] - r.valor)
                comprobadas += 1
                if dif > TOLERANCIA:
                    falla(f"etapa {etapa}, {r.sistema}, prueba {r.prueba}, {r.metrica}: recalculado {calculadas[(r.sistema, r.prueba)][r.metrica]:.6f}, guardado {r.valor:.6f}")
    print(f"   {comprobadas} valores comprobados (tolerancia {TOLERANCIA})")
    return calculadas


def sistemas_externos() -> list[str]:
    return list(pd.read_csv(RESULTADOS / "t19_etapa7" / "metricas_globales.csv")["sistema"].drop_duplicates())


def metricas_columnas(d: pd.DataFrame, columnas: list[int]) -> dict[str, float]:
    """Las métricas de ``metricas`` sobre las columnas dadas (las clases evaluables de la base)."""
    y = d[[f"true_{c}" for c in CLASES]].to_numpy(np.uint8)[:, columnas]
    p = d[[f"prob_{c}" for c in CLASES]].to_numpy(float)[:, columnas]
    yh = d[[f"pred_{c}" for c in CLASES]].to_numpy(np.uint8)[:, columnas]
    return {"f1_macro": f1_score(y, yh, average="macro", zero_division=0), "f1_micro": f1_score(y, yh, average="micro", zero_division=0),
            "f1_ponderado": f1_score(y, yh, average="weighted", zero_division=0), "exacta": float((y == yh).all(1).mean()),
            "auroc_macro": float(np.mean([roc_auc_score(y[:, i], p[:, i]) for i in range(y.shape[1])])),
            "auprc_macro": float(np.mean([average_precision_score(y[:, i], p[:, i]) for i in range(y.shape[1])])),
            "ece": expected_calibration_error(y, p, 15), "brier": brier_score(y, p)}


def paso_externo() -> dict:
    print("5. Evaluación externa (C y D): registros, etiquetas, umbrales, decisiones y métricas")
    reparto = json.loads((RAIZ / "protocolo" / "reparto_externo.json").read_text(encoding="utf-8"))
    ref = pd.read_csv(RESULTADOS / "t19_etapa7" / "metricas_globales.csv").query("subconjunto == 'completa'")
    sistemas = sistemas_externos()
    calculadas, comprobadas = {}, 0
    for prueba, base in EXTERNAS.items():
        manifiesto = pd.read_csv(RAIZ / "data" / "cinc2021_externo" / f"{base}.h5.records.csv").set_index("record_name")
        columnas = [CLASES.index(c) for c in reparto["origenes"][prueba]["clases_evaluables"]]
        etiquetadas = manifiesto["matched_classes"].fillna("").str.split(";")
        esperadas = pd.DataFrame({c: etiquetadas.apply(lambda L, c=c: c in L) for c in CLASES}).astype(int)
        for s in sistemas:
            d = predicciones(s, prueba)
            if len(d) != len(manifiesto) or set(d["record_name"]) != set(manifiesto.index):
                falla(f"{s} prueba {prueba}: los registros no son los de data/cinc2021_externo/{base}.h5.records.csv")
                continue
            y = d.set_index("record_name")[[f"true_{c}" for c in CLASES]]
            if not (y.to_numpy() == esperadas.loc[y.index].to_numpy()).all():
                falla(f"{s} prueba {prueba}: las etiquetas no coinciden con el manifiesto por registro")
            guardado = pd.read_csv(EVAL / f"{s.lower()}_A" / "thresholds_validation.csv").set_index("class")["threshold"]
            guardado_p = pd.read_csv(EVAL / f"{s.lower()}_{prueba}" / "thresholds_validation.csv").set_index("class")["threshold"]
            if not guardado_p.equals(guardado):
                falla(f"{s}: los umbrales de la prueba {prueba} difieren de los de la A")
            for c in CLASES:
                pred = (d[f"prob_{c}"].to_numpy() >= np.float32(guardado[c])).astype(int)
                if (pred != d[f"pred_{c}"].to_numpy()).any():
                    falla(f"{s} prueba {prueba}: la decisión de {c} no es prob >= umbral")
            calculadas[(s, prueba)] = metricas_columnas(d, columnas)
    for r in ref.itertuples():
        if (r.sistema, r.prueba) in calculadas and r.metrica in calculadas[(r.sistema, r.prueba)]:
            comprobadas += 1
            dif = abs(calculadas[(r.sistema, r.prueba)][r.metrica] - r.valor)
            if dif > TOLERANCIA:
                falla(f"etapa 7, {r.sistema}, prueba {r.prueba}, {r.metrica}: recalculado {calculadas[(r.sistema, r.prueba)][r.metrica]:.6f}, guardado {r.valor:.6f}")
    print(f"   {len(sistemas)} sistemas x 2 bases; {comprobadas} valores comprobados (tolerancia {TOLERANCIA})")
    return calculadas


def paso_completo() -> None:
    print("6. Análisis completo (bootstrap) frente a resultados/")
    with tempfile.TemporaryDirectory() as tmp:
        entorno = {**os.environ, "T19_RAIZ": str(RAIZ), "T19_SALIDA": tmp, "T19_ENTRADAS": str(RAIZ / "protocolo"), "T19_RESULTADOS": str(RESULTADOS)}
        for etapa in ETAPAS_COMPLETO:
            if etapa in (3, 6) and not list(RAIZ.glob("saved/t19/*/*/best.pt")):    # el análisis de las etapas 3 y 6 hashea los pesos de cada corrida
                print(f"   etapa {etapa} omitida: el paquete se armó sin los pesos (best.pt)")
                continue
            r = subprocess.run([sys.executable, "-X", "utf8", "-I", str(RAIZ / "analisis" / "analizar_t19.py"), "--etapa", str(etapa)], env=entorno,
                               capture_output=True, text=True)
            if r.returncode != 0:
                falla(f"analizar_t19.py --etapa {etapa} falló:\n{r.stdout[-600:]}{r.stderr[-600:]}")
                continue
            nuevos = Path(tmp) / f"t19_etapa{etapa}"
            for archivo in sorted(nuevos.iterdir()):
                guardado = RESULTADOS / f"t19_etapa{etapa}" / archivo.name
                if not guardado.is_file() or guardado.read_bytes() != archivo.read_bytes():
                    falla(f"etapa {etapa}: {archivo.name} no sale igual que el guardado")
            print(f"   etapa {etapa}: {len(list(nuevos.iterdir()))} archivos comparados")
        r = subprocess.run([sys.executable, "-X", "utf8", "-I", str(RAIZ / "analisis" / "recalibracion_local.py")], env=entorno, capture_output=True, text=True)
        if r.returncode != 0:
            falla(f"recalibracion_local.py falló:\n{r.stdout[-600:]}{r.stderr[-600:]}")
        else:
            nuevos = Path(tmp) / "e13_recalibracion_local"
            for archivo in sorted(nuevos.iterdir()):
                guardado = RESULTADOS / "e13_recalibracion_local" / archivo.name
                if not guardado.is_file() or guardado.read_bytes() != archivo.read_bytes():
                    falla(f"recalibración local: {archivo.name} no sale igual que el guardado")
            print(f"   recalibración local (E13): {len(list(nuevos.iterdir()))} archivos comparados")


def principal(calculadas: dict, externas: dict) -> None:
    print("Resultado principal (sistema P3, ensemble) recalculado desde las predicciones:")
    for pr, nombre in (("A", "prueba A"), ("B", "prueba B, Georgia")):
        m = calculadas[("P3", pr)]
        print(f"   {nombre}: F1 macro {m['f1_macro']:.3f}, F1 ponderado {m['f1_ponderado']:.3f}, AUROC macro {m['auroc_macro']:.3f}, ECE {m['ece']:.3f}")
    for pr, nombre in (("C", "Chapman-Shaoxing (C), clases evaluables"), ("D", "Ningbo (D), clases evaluables")):
        m = externas[("P3", pr)]
        print(f"   {nombre}: F1 macro {m['f1_macro']:.3f}, F1 ponderado {m['f1_ponderado']:.3f}, AUROC macro {m['auroc_macro']:.3f}, ECE {m['ece']:.3f}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--completo", action="store_true", help="repetir también el análisis con bootstrap (unos minutos)")
    args = parser.parse_args()
    paso_hashes()
    sistemas = sistemas_evaluados()
    paso_particion(sistemas)
    paso_umbrales(sistemas)
    calculadas = paso_metricas(sistemas)
    externas = paso_externo()
    if args.completo:
        paso_completo()
    principal(calculadas, externas)
    print(f"RESULTADO: {'OK' if not ERRORES else str(len(ERRORES)) + ' error(es)'}")
    return 1 if ERRORES else 0


if __name__ == "__main__":
    sys.exit(main())
