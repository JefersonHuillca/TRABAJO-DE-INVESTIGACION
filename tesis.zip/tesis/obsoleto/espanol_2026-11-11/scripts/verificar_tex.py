"""Verificación estática del artículo IEEE (main.tex, capitulos/*.tex y figuras/tikz/*.tex), previa a la compilación.

Comprueba: llaves y entornos balanceados; caracteres de control; todo \\cite existe en references.bib o references_extra.bib; \\ref y
\\label pareados; los \\includegraphics y \\input existen; & # _ sin escapar en el texto; toda macro \\cf/\\cfs usa un id de
evidencia/cifras_t19.csv; todo número con decimales o de 4 o más dígitos que quede escrito a mano existe en esas cifras; cuenta de
\\TODO; sin rutas absolutas de Windows. Sale con 0 si no hay errores (los \\TODO se cuentan, no se esconden).

Las cifras del reentrenamiento final están en evidencia/cifras_t19.csv (calcular_t19.py).

Uso, desde la raíz del repositorio:  python tesis/scripts/verificar_tex.py
"""


from __future__ import annotations

import csv
import re
import sys
from pathlib import Path

from formato_cifras import redondear

IEEE = Path(__file__).resolve().parents[1]

PRINCIPAL = ["main.tex"]
CAPITULOS = sorted(p.name for p in (IEEE / "capitulos").glob("*.tex") if not p.name.startswith("cifras"))
DIAGRAMAS = sorted(p.name for p in (IEEE / "figuras" / "tikz").glob("*.tex"))
ARCHIVOS = PRINCIPAL + [f"capitulos/{n}" for n in CAPITULOS] + [f"figuras/tikz/{n}" for n in DIAGRAMAS]
ERRORES: list[str] = []
AVISOS: list[str] = []


def err(msg: str) -> None:
    ERRORES.append(msg)


def quitar_comentarios(text: str) -> str:
    return "\n".join(re.sub(r"(?<!\\)%.*", "", linea) for linea in text.split("\n"))


def balance(text: str, nombre: str) -> None:
    prof = 0
    for i, ch in enumerate(re.sub(r"\\[{}]", "", text)):
        prof += (ch == "{") - (ch == "}")
        if prof < 0:
            err(f"{nombre}: llave de cierre sin abrir (posición {i})")
            return
    if prof != 0:
        err(f"{nombre}: {prof} llave(s) sin cerrar")
    pila = []
    for m in re.finditer(r"\\(begin|end)\{([^}]+)\}", text):
        if m.group(1) == "begin":
            pila.append(m.group(2))
        elif not pila or pila.pop() != m.group(2):
            err(f"{nombre}: \\end{{{m.group(2)}}} no corresponde con su \\begin")
    if pila:
        err(f"{nombre}: entornos sin cerrar: {pila}")


def cargar_cifras() -> dict:
    with (IEEE / "evidencia" / "cifras_t19.csv").open(encoding="utf-8", newline="") as fh:
        return {r["id"]: r for r in csv.DictReader(fh)}


def claves_bib() -> set[str]:
    texto = "".join((IEEE / n).read_text(encoding="utf-8") for n in ("references.bib", "references_extra.bib"))
    return set(re.findall(r"^@\w+\{([^,\s]+),", texto, flags=re.M))


def texto_plano(text: str) -> str:
    """Quita lo que no es prosa: macros de cifras (ya validadas), TODO, citas, etiquetas, rutas y matemáticas."""
    t = re.sub(r"\\TODO\{(?:[^{}]|\{(?:[^{}]|\{[^{}]*\})*\})*\}", " ", text)
    t = re.sub(r"\\cfs?\{[A-Za-z0-9]+\}", " ", t)
    t = re.sub(r"\\(cite|ref|label|input|bibliography|bibliographystyle|includegraphics|usepackage|documentclass|hyphenation|markboth|newcommand|renewcommand|setlength|expandafter|entradaformula|lstinputlisting|lstset|captionsetup)(\[[^\]]*\])?(\{[^{}]*\})*", " ", t)
    t = t.replace("CC BY 4.0", " ")                                   # licencia de los datos: no es una cifra del estudio
    t = re.sub(r"\$[^$]*\$", " ", t)
    t = re.sub(r"\\begin\{(equation|align|gather)\*?\}.*?\\end\{\1\*?\}", " ", t, flags=re.S)
    t = re.sub(r"\\begin\{(lstlisting|verbatim)\}.*?\\end\{\1\}", " ", t, flags=re.S)
    t = re.sub(r"\\texttt\{(?:[^{}]|\{[^{}]*\})*\}", " ", t)
    t = re.sub(r"\\path\{[^{}]*\}", " ", t)
    t = re.sub(r"\\begin\{(tikzpicture|circuitikz)\}.*?\\end\{\1\}", " ", t, flags=re.S)
    return t


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    cifras = cargar_cifras()
    bib = claves_bib()
    permitidos = {redondear(r["valor"], r["unidad"]).replace(r"\,", "") for r in cifras.values()}
    permitidos |= {str(r["valor"]).replace(r"\,", "") for r in cifras.values()}
    permitidos |= {redondear(r["valor"], r["unidad"]).replace(r"\,", " ") for r in cifras.values()}
    citados, usados_cf, todos = set(), set(), 0
    labels, refs, palabras = set(), set(), 0
    for rel in ARCHIVOS:
        path = IEEE / rel
        raw = path.read_bytes()
        if re.search(rb"[\x00-\x08\x0b-\x1f]", raw):
            err(f"{rel}: caracteres de control (p. ej. un retorno de carro suelto)")
        text = raw.decode("utf-8")
        if re.search(r"(?<![A-Za-z])[A-Za-z]:[\\/]", text):                 # C:\... o C:/...; las URL (https://) no cuentan
            err(f"{rel}: ruta absoluta de Windows")
        sin = quitar_comentarios(text)
        balance(sin, rel)
        for m in re.finditer(r"\\cite\{([^}]*)\}", sin):
            for k in m.group(1).split(","):
                citados.add(k.strip())
        for m in re.finditer(r"\\cfs?\{([^}]*)\}", sin):
            usados_cf.add(m.group(1))
            if m.group(1) not in cifras:
                err(f"{rel}: \\cf con id inexistente: {m.group(1)}")
        labels |= set(re.findall(r"\\label\{([^}]*)\}", sin))
        refs |= set(re.findall(r"\\(?:ref|pageref)\{([^}]*)\}", sin))
        todos += len(re.findall(r"\\TODO\{", sin))
        for m in re.finditer(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]*)\}", sin):
            if not any((IEEE / (m.group(1) + ext)).exists() for ext in ("", ".pdf", ".png")):
                err(f"{rel}: figura inexistente: {m.group(1)}")
        for m in re.finditer(r"\\input\{([^}]*)\}", sin):
            if not any((IEEE / (m.group(1) + ext)).exists() for ext in ("", ".tex")):
                err(f"{rel}: \\input inexistente: {m.group(1)}")
        plano = texto_plano(sin)
        for env in re.finditer(r"\\begin\{(tabular\*?|tabularx|longtable)\}.*?\\end\{\1\}", plano, flags=re.S):
            plano = plano.replace(env.group(0), " ")                      # los & de las tablas son separadores
        if rel.startswith("capitulos/"):
            limpio = re.sub(r"\\[A-Za-z]+\{[^{}]*\}", " ", plano)
            for m in re.finditer(r"(?<!\\)([&#_])", limpio):
                err(f"{rel}: '{m.group(1)}' sin escapar cerca de «{limpio[max(0, m.start() - 25):m.end() + 25].strip()!r}»")
        # números escritos a mano (con decimales o de 4 o más cifras): deben salir de las cifras
        for m in re.finditer(r"(?<![\w.\\])(\d{1,3}(?:[ \u00a0\u202f]\d{3})+|\d+\.\d+|\d{4,})(?![\w])", plano):
            valor = re.sub(r"[ \u00a0\u202f]", "", m.group(1))
            if re.fullmatch(r"(19|20)\d\d", valor) or valor == "3050":
                continue                                                  # años; 3050 = modelo de GPU declarado por los autores
            if valor not in permitidos and m.group(1) not in permitidos:
                err(f"{rel}: número escrito a mano que no está en las cifras: {m.group(1)}")
        if rel.startswith("capitulos/"):
            palabras += len(re.findall(r"[A-Za-zÁÉÍÓÚáéíóúñÑüÜ]{2,}", plano))
    for k in sorted(citados - bib):
        err(f"cita sin entrada en references.bib: {k}")
    for k in sorted(refs - labels):
        err(f"\\ref sin \\label: {k}")
    for k in sorted(labels - refs):
        AVISOS.append(f"\\label sin \\ref: {k}")
    sin_citar = sorted(bib - citados)
    if sin_citar:
        AVISOS.append(f"entradas de references.bib sin citar: {sin_citar}")
    print(f"archivos revisados: {len(ARCHIVOS)} | citas distintas: {len(citados)} | macros de cifras usadas: {len(usados_cf)} de {len(cifras)} | \\TODO: {todos}")
    print(f"palabras de prosa (sin cifras, citas ni fórmulas) ≈ {palabras}")
    for a in AVISOS:
        print("AVISO:", a)
    for e in ERRORES:
        print("ERROR:", e)
    print("RESULTADO:", "OK (0 errores)" if not ERRORES else f"{len(ERRORES)} error(es)")
    return 1 if ERRORES else 0


if __name__ == "__main__":
    sys.exit(main())
