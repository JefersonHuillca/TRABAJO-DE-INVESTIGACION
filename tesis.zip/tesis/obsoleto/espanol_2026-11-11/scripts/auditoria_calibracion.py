"""Auditoría de la calibración afín y de los umbrales del sistema final con modelos congelados (T6 del plan de revisión).

Qué hace: con las predicciones de validación del ensemble afín (``runs/eval/ensemble-f1-platt``), repite validación cruzada de 5 pliegues
(5 repeticiones, semillas 0 a 4) SOLO de la última etapa: ajusta por clase la calibración afín y el umbral de F1 en 4 pliegues y los evalúa
en el quinto. Como la salida guardada ya es sigmoide(a·logit(p̄)+b), reajustar una afín sobre su logit equivale a ajustar la del ensemble
(la composición de afines es afín). Resultado: cuánto optimismo tiene la validación y qué tan estables son los parámetros.

Qué NO es: no estima el rendimiento del procedimiento completo ni es una evaluación independiente. Los pesos de las redes ya se eligieron con
la validación (mejor época) y las calibraciones de v1 y v2 anteriores al promedio no se reajustan. Tampoco sirve para decidir qué sistema es
mejor. No usa la partición de prueba.

Escribe evidencia/auditoria_calibracion.csv. Uso, desde la raíz del repo:  python tesis/scripts/auditoria_calibracion.py
"""

from __future__ import annotations

import csv
import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score
from sklearn.model_selection import KFold

IEEE = Path(__file__).resolve().parents[1]
REPO = IEEE.parent
sys.path.insert(0, str(REPO))
from ecg.calibration import apply_platt_logits, brier_score, expected_calibration_error, fit_platt_per_class, to_logits  # noqa: E402

CLASES = ["NSR", "AxisDev", "MI", "TAb", "AF", "LVH", "VEctopy", "AVBlock", "STach", "BBB", "SB", "AEctopy_Junctional"]
DIRECTORIO = REPO / "runs" / "eval" / "ensemble-f1-platt"
PLIEGUES, REPETICIONES = 5, 5
SALIDA = IEEE / "evidencia" / "auditoria_calibracion.csv"


def cargar_evaluate():
    """Carga examples/cinc2020/evaluate.py por ruta (el nombre ``evaluate`` choca con paquetes de terceros)."""
    spec = importlib.util.spec_from_file_location("evaluate_cinc2020", REPO / "examples" / "cinc2020" / "evaluate.py")
    modulo = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(REPO / "examples" / "cinc2020"))
    spec.loader.exec_module(modulo)
    return modulo


def umbrales(ev, y, p):
    return np.array([ev.best_threshold_f1(y[:, i].astype(np.uint8), p[:, i])[0] for i in range(y.shape[1])])


def metricas(y, p, pred):
    return (f1_score(y, pred, average="macro", zero_division=0), expected_calibration_error(y.astype(float), p, 15), brier_score(y.astype(float), p))


def main() -> int:
    ev = cargar_evaluate()
    d = pd.read_csv(DIRECTORIO / "predictions_validation.csv")
    y = d[[f"true_{c}" for c in CLASES]].to_numpy(int)
    p = d[[f"prob_{c}" for c in CLASES]].to_numpy(float)
    z = to_logits(p)
    n = len(y)

    # referencia dentro de muestra: umbrales ajustados y evaluados con la misma validación (lo que se informa como F1 de validación)
    thr_in = umbrales(ev, y, p)
    f1_in, ece_in, brier_in = metricas(y, p, (p >= thr_in).astype(int))
    guardado = pd.read_csv(DIRECTORIO / "metrics_global.csv").set_index("split").loc["validation"]
    assert abs(f1_in - float(guardado["f1_macro"])) < 1e-6, "no se reproduce el F1 macro de validación guardado"

    por_rep, umbrales_pliegue, dev_a, dev_b = [], [], [], []
    for semilla in range(REPETICIONES):
        p_oof, pred_oof = np.zeros_like(p), np.zeros_like(y)
        for tr, ho in KFold(PLIEGUES, shuffle=True, random_state=semilla).split(np.arange(n)):
            a, b = fit_platt_per_class(y[tr], z[tr])
            p_tr, p_ho = apply_platt_logits(z[tr], a, b), apply_platt_logits(z[ho], a, b)
            thr = umbrales(ev, y[tr], p_tr)
            p_oof[ho], pred_oof[ho] = p_ho, (p_ho >= thr).astype(int)
            umbrales_pliegue.append(thr)
            dev_a.append(np.abs(a - 1.0))
            dev_b.append(np.abs(b))
        por_rep.append(metricas(y, p_oof, pred_oof))
    f1_oof, ece_oof, brier_oof = (np.array([r[k] for r in por_rep]) for k in range(3))
    sd_thr = np.array(umbrales_pliegue).std(axis=0, ddof=1)
    clase_max = CLASES[int(sd_thr.argmax())]

    filas = [
        ("F1 macro en validación, dentro de muestra", f1_in, 0.0, "prop", "umbrales y calibración ajustados y evaluados con toda la validación"),
        ("F1 macro en validación, fuera de pliegue", f1_oof.mean(), f1_oof.std(ddof=1), "prop", f"{PLIEGUES} pliegues x {REPETICIONES} repeticiones"),
        ("ECE en validación, dentro de muestra", ece_in, 0.0, "prop", "15 intervalos, promedio entre clases"),
        ("ECE en validación, fuera de pliegue", ece_oof.mean(), ece_oof.std(ddof=1), "prop", "15 intervalos, promedio entre clases"),
        ("Brier en validación, dentro de muestra", brier_in, 0.0, "prop", "promedio entre clases"),
        ("Brier en validación, fuera de pliegue", brier_oof.mean(), brier_oof.std(ddof=1), "prop", "promedio entre clases"),
        ("Desviación típica máxima del umbral entre ajustes", sd_thr.max(), 0.0, "prop", f"clase {clase_max}; {PLIEGUES * REPETICIONES} ajustes por clase"),
        ("Desviación típica media del umbral entre ajustes", sd_thr.mean(), 0.0, "prop", "promedio entre las 12 clases"),
        ("Mayor |a-1| de la afín reajustada", np.max(dev_a), 0.0, "prop", "0 = la calibración ya guardada no cambia"),
        ("Mayor |b| de la afín reajustada", np.max(dev_b), 0.0, "prop", "0 = la calibración ya guardada no cambia"),
    ]
    with SALIDA.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["metrica", "valor", "desviacion", "unidad", "detalle"])
        for fila in filas:
            w.writerow([fila[0], f"{fila[1]:.6f}", f"{fila[2]:.6f}", fila[3], fila[4]])
    for fila in filas:
        print(f"{fila[0]:<55} {fila[1]:.4f}  (sd {fila[2]:.4f})  {fila[4]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
