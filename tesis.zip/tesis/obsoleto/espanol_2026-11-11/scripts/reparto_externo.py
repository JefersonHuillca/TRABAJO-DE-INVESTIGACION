"""E5 (parte 2): manifiesto de los HDF5 de Chapman-Shaoxing (C) y Ningbo (D) con tamaños, exclusiones, positivos y SHA-256.

Lee los HDF5 que escribió ``examples/cinc2020/build_external_test.py`` (``data/cinc2021_externo/test_c.h5`` y ``test_d.h5``), sus ``.records.csv`` y
``.summary.json``, la auditoría de duplicados y la cobertura de E3. Comprueba que lo escrito coincide con lo esperado (registros, nombres, etiquetas del
manifiesto frente a las del HDF5, exclusiones aplicadas, ningún registro excluido dentro) y escribe ``evidencia/reparto_externo.json``.
No usa ningún modelo ni predicción.
Uso, desde la raíz del repo:  python tesis/scripts/reparto_externo.py
"""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path

import h5py
import numpy as np

IEEE = Path(__file__).resolve().parents[1]
REPO = IEEE.parent
sys.path.insert(0, str(REPO))
from ecg.schema import CLASS_NAMES  # noqa: E402

EV = IEEE / "evidencia"
DIR = REPO / "data" / "cinc2021_externo"
ORIGENES = {"C": ("chapman_shaoxing", "test_c"), "D": ("ningbo", "test_d")}
MIN_POSITIVOS = 50                                                  # E0.4: una clase es evaluable si la fuente la cubre y hay al menos 50 positivos
BASE21 = REPO / "dataset2021" / "physionet.org" / "files" / "challenge-2021" / "1.0.3"


def sha256(ruta: Path) -> str:
    h = hashlib.sha256()
    with ruta.open("rb") as fh:
        for bloque in iter(lambda: fh.read(1 << 24), b""):
            h.update(bloque)
    return h.hexdigest()


def main() -> int:
    excluir = [l.strip() for l in (EV / "exclusiones_externa.txt").read_text(encoding="utf-8").splitlines() if l.strip()]
    cobertura = json.loads((EV / "cobertura_externa.json").read_text(encoding="utf-8"))
    salida = {"version_challenge": "2021 v1.0.3", "sha256sums_txt": sha256(BASE21 / "SHA256SUMS.txt"), "min_positivos": MIN_POSITIVOS,
              "exclusiones_externa_txt_sha256": sha256(EV / "exclusiones_externa.txt"), "duplicados_externa_csv_sha256": sha256(EV / "duplicados_externa.csv"),
              "total_excluidos": len(excluir), "comando": "python examples/cinc2020/build_external_test.py --data-dir dataset2021/physionet.org/files/challenge-2021/1.0.3 "
              "--origin <origen> --output data/cinc2021_externo/<test_c|test_d>.h5 --workers 8 $(sed 's/^/--exclude-record /' exclusiones_externa.txt)", "origenes": {}}
    for clave, (origen, base) in ORIGENES.items():
        h5 = DIR / f"{base}.h5"
        resumen = json.loads((DIR / f"{base}.h5.summary.json").read_text(encoding="utf-8"))
        with open(DIR / f"{base}.h5.records.csv", newline="", encoding="utf-8") as f:
            manifiesto = list(csv.DictReader(f))
        with h5py.File(h5, "r") as f:
            nombres = [n.decode() if isinstance(n, bytes) else n for n in f["record_names"][:]]
            etiquetas = f["labels"][:]
            forma = f["signals"].shape
        assert resumen["origin"] == origen and resumen["processing"]["errors"] == 0, base
        assert len(nombres) == len(manifiesto) == resumen["records"] == forma[0], base
        assert not set(excluir) & {r["record_file"] for r in manifiesto}, f"un registro excluido quedó en {base}"
        assert set(resumen["excluded"]) <= set(excluir)
        assert all(r["source_db"] == origen for r in manifiesto), base
        pos = {c: int(etiquetas[:, i].sum()) for i, c in enumerate(CLASS_NAMES)}
        assert pos == resumen["positives"], f"los positivos del HDF5 no coinciden con el resumen en {base}"
        assert etiquetas.shape[1] == len(CLASS_NAMES) and set(np.unique(etiquetas)) <= {0, 1}
        evaluables = [c for c in CLASS_NAMES if pos[c] >= MIN_POSITIVOS]                                 # todas las clases están cubiertas por la tabla de la base (E3)
        salida["origenes"][clave] = {
            "origen": origen, "archivo": h5.relative_to(REPO).as_posix(), "registros": len(nombres), "forma_senales": list(forma),
            "excluidos_en_este_origen": len(resumen["excluded"]), "registros_sin_ninguna_clase": resumen["records_without_any_class"],
            "positivos": pos, "clases_evaluables": evaluables, "clases_no_evaluables": [c for c in CLASS_NAMES if c not in evaluables],
            "cobertura_documentada": cobertura, "sha256_h5": sha256(h5), "sha256_records_csv": sha256(DIR / f"{base}.h5.records.csv"),
            "sha256_summary_json": sha256(DIR / f"{base}.h5.summary.json")}
        print(clave, len(nombres), "evaluables:", len(evaluables))
    (EV / "reparto_externo.json").write_text(json.dumps(salida, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print("escrito evidencia/reparto_externo.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
