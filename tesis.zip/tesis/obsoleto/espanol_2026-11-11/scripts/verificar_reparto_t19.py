"""Comprueba el reparto nuevo (T19) contra el apartado 2 del protocolo antes de entrenar y registra sus hashes.

Comprueba: tamaños esperados por partición (en registros, no en ventanas), que Georgia esté solo en ``test_b``, que ningún grupo de paciente
aparezca en dos particiones, que los HDF5 tengan los registros escritos que dice el reparto y ningún error de procesamiento, y que el
CSV de grupos sea el del protocolo. Escribe evidencia/reparto_t19.json con los SHA-256 de ``split_assignments.csv``, de los grupos y de los HDF5.

Uso, desde la raíz del repo:  python tesis/scripts/verificar_reparto_t19.py
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

import h5py

IEEE = Path(__file__).resolve().parents[1]
REPO = Path(os.environ.get("T19_RAIZ", IEEE.parent))       # raíz con data/: el repositorio (por defecto) o el paquete de reproducibilidad
DIRECTORIO = REPO / "data" / "cinc2020_12_origen"
GRUPOS = REPO / "data" / "externo" / "patient_groups.csv"
ESPERADO = {"train": 22895, "val": 4913, "test": 4949, "test_b": 10344}                                   # protocolo_t19.md, apartado 2
HASH_GRUPOS = "93380f479662b3417ff5c502f0a639109809ff98f628735aac00e0b59c6daa46"                           # idem
SALIDA = Path(os.environ["T19_SALIDA"]) / "reparto_t19.json" if "T19_SALIDA" in os.environ else IEEE / "evidencia" / "reparto_t19.json"


def sha256(ruta: Path) -> str:
    h = hashlib.sha256()
    with ruta.open("rb") as fh:
        for bloque in iter(lambda: fh.read(1 << 22), b""):
            h.update(bloque)
    return h.hexdigest()


def main() -> int:
    problemas: list[str] = []
    with (DIRECTORIO / "split_assignments.csv").open(encoding="utf-8", newline="") as fh:
        filas = list(csv.DictReader(fh))
    tamanos = {s: sum(r["split"] == s for r in filas) for s in ESPERADO}
    if tamanos != ESPERADO:
        problemas.append(f"tamaños {tamanos} distintos de los esperados {ESPERADO}")
    if {r["split"] for r in filas} != set(ESPERADO):
        problemas.append(f"particiones inesperadas: {sorted({r['split'] for r in filas})}")
    georgia = {r["split"] for r in filas if r["source_db"] == "georgia"}
    if georgia != {"test_b"}:
        problemas.append(f"Georgia no está solo en test_b: {sorted(georgia)}")
    if any(r["source_db"] != "georgia" for r in filas if r["split"] == "test_b"):
        problemas.append("test_b contiene registros que no son de Georgia")
    if sha256(GRUPOS) != HASH_GRUPOS:
        problemas.append("el CSV de grupos no es el del protocolo")
    with GRUPOS.open(encoding="utf-8", newline="") as fh:
        grupo = {r["record_name"]: r["group_id"] for r in csv.DictReader(fh)}
    donde = defaultdict(set)
    for r in filas:
        if r["record_name"] in grupo:
            donde[grupo[r["record_name"]]].add(r["split"])
    repartidos = {g: sorted(s) for g, s in donde.items() if len(s) > 1}
    if repartidos:
        problemas.append(f"{len(repartidos)} pacientes en más de una partición, p. ej. {dict(list(repartidos.items())[:3])}")

    hdf5 = {}
    for nombre in ESPERADO:
        ruta = DIRECTORIO / f"{nombre}.h5"
        with h5py.File(ruta, "r") as h5:
            escritos, errores, ventanas = int(h5.attrs["written_records"]), int(h5.attrs["signal_processing_errors"]), int(h5["signals"].shape[0])
        if errores:
            problemas.append(f"{nombre}.h5: {errores} errores de procesamiento")
        if nombre != "train" and ventanas != ESPERADO[nombre]:
            problemas.append(f"{nombre}.h5 tiene {ventanas} muestras y se esperaban {ESPERADO[nombre]}")
        if nombre == "train" and ventanas < ESPERADO[nombre]:
            problemas.append(f"train.h5 tiene {ventanas} ventanas, menos que los {ESPERADO[nombre]} registros")
        hdf5[nombre] = {"muestras": ventanas, "registros_escritos": escritos, "errores": errores, "sha256": sha256(ruta)}

    registro = {"tamanos": tamanos, "pacientes_en_mas_de_una_particion": len(repartidos), "grupos_sha256": HASH_GRUPOS,
                "split_assignments_sha256": sha256(DIRECTORIO / "split_assignments.csv"), "hdf5": hdf5, "problemas": problemas}
    SALIDA.write_text(json.dumps(registro, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({k: v for k, v in registro.items() if k != "hdf5"}, indent=2, ensure_ascii=False))
    print("hdf5:", {k: (v["muestras"], v["errores"]) for k, v in hdf5.items()})
    print("RESULTADO:", "OK" if not problemas else f"{len(problemas)} problema(s)")
    return 1 if problemas else 0


if __name__ == "__main__":
    sys.exit(main())
