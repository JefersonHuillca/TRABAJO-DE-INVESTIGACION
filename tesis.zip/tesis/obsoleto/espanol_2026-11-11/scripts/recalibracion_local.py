"""E13: recalibración local en Chapman-Shaoxing (C) y Ningbo (D), EXPLORATORIA (desviación 6 de protocolo_externo_t19_desviaciones.md).

Parte de las probabilidades finales ya guardadas de los 10 sistemas originales de la etapa 7 (sin GPU, sin reentrenar) y mide cuánto F1 se recupera con etiquetas locales:
V0 sistema congelado; V1 solo umbrales por clase reajustados (F1, β = 1); V2 calibración afín por clase + umbrales. Ajuste y medición sobre registros distintos (cross-fit de dos mitades).
Las métricas son las de la etapa 7 (solo clases evaluables de cada origen). Escribe en evidencia/e13_recalibracion_local/. No cambia ningún resultado confirmatorio.
Uso, desde la raíz del repo:  python tesis/scripts/recalibracion_local.py
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

AQUI = Path(__file__).resolve().parent
IEEE = AQUI.parent
sys.path.insert(0, str(AQUI))                                          # analizar_t19.py está en la misma carpeta, en el repositorio y en el paquete
sys.path.insert(0, str(Path(os.environ.get("T19_RAIZ", IEEE.parent))))
import analizar_t19 as a19  # noqa: E402
from ecg.calibration import apply_platt_logits, fit_platt_per_class, to_logits  # noqa: E402
from ecg.schema import CLASS_NAMES  # noqa: E402

EV = Path(os.environ["T19_ENTRADAS"]) if "T19_ENTRADAS" in os.environ else IEEE / "evidencia"                 # reparto_externo.json y el protocolo de las desviaciones
RESULTADOS = Path(os.environ["T19_RESULTADOS"]) if "T19_RESULTADOS" in os.environ else IEEE / "evidencia"      # t19_etapa7/
SALIDA = (Path(os.environ["T19_SALIDA"]) if "T19_SALIDA" in os.environ else IEEE / "evidencia") / "e13_recalibracion_local"
SISTEMAS = ("P1", "P2", "P3", "P1m", "P2m", "P3m", "CNN", "P1t", "P2t", "P3t")
VARIANTES = ("V0", "V1", "V2")
ORIGENES = ("C", "D")
MIN_FIT = 10                                                           # positivos y negativos mínimos de una clase en el ajuste; si no, conserva lo congelado
SEMILLAS_PARTICION = (0, 1, 2, 3, 4)
TAMANOS = (100, 300, 1000, 3000)
MALLA = np.linspace(0.01, 0.99, 99)                                    # la misma malla de umbrales del proyecto
CLAVES = ("f1_macro", "f1_micro", "f1_ponderado", "prec_macro", "sens_macro", "auroc_macro", "auprc_macro", "ece", "brier", "exacta")


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def mejor_umbral(y: np.ndarray, p: np.ndarray) -> float:
    """Igual que ``evaluate.best_threshold_fbeta`` con β = 1: el primer umbral de la malla que maximiza el F1 (0.5 si la clase no tiene positivos)."""
    if y.sum() == 0:
        return 0.5
    pred = p[:, None] >= MALLA[None, :]
    tp = (pred & (y[:, None] == 1)).sum(0)
    fp = (pred & (y[:, None] == 0)).sum(0)
    fn = y.sum() - tp
    den = 2 * tp + fp + fn
    f1 = np.divide(2 * tp, den, out=np.zeros(len(MALLA)), where=den > 0)
    return float(MALLA[int(np.argmax(f1))])


def ajustar(y: np.ndarray, p: np.ndarray, variante: str) -> dict:
    """Parámetros locales por clase a partir de un conjunto de ajuste; una clase con pocos positivos o negativos conserva lo congelado."""
    ok = (y.sum(0) >= MIN_FIT) & ((1 - y).sum(0) >= MIN_FIT)
    a, b, umbral = np.ones(y.shape[1]), np.zeros(y.shape[1]), np.zeros(y.shape[1])
    pa = p.copy()
    if variante == "V2" and ok.any():
        a[ok], b[ok] = fit_platt_per_class(y[:, ok], to_logits(p[:, ok]))
        pa[:, ok] = apply_platt_logits(to_logits(p[:, ok]), a[ok], b[ok])
    for i in np.flatnonzero(ok):
        umbral[i] = mejor_umbral(y[:, i], pa[:, i])
    return {"ok": ok, "a": a, "b": b, "umbral": umbral, "variante": variante}


def aplicar(par: dict, p: np.ndarray, yh: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """(probabilidades, decisiones) de un conjunto nuevo; las clases sin ajuste local conservan las originales."""
    ok = par["ok"]
    pn, yn = p.copy(), yh.copy()
    if par["variante"] == "V2" and ok.any():
        pn[:, ok] = apply_platt_logits(to_logits(p[:, ok]), par["a"][ok], par["b"][ok])
    yn[:, ok] = (pn[:, ok] >= par["umbral"][ok]).astype(yh.dtype)
    return pn, yn


def cross_fit(y: np.ndarray, p: np.ndarray, yh: np.ndarray, variante: str, semilla: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Dos mitades al azar: ajusta con una y predice la otra, y a la inversa; cada registro se predice una vez fuera de muestra."""
    n = len(y)
    perm = np.random.default_rng(semilla).permutation(n)
    mitades = (perm[: n // 2], perm[n // 2:])
    pn, yn, fuera = p.copy(), yh.copy(), np.zeros(n, dtype=int)
    for fit, test in (mitades, mitades[::-1]):
        pp, yy = aplicar(ajustar(y[fit], p[fit], variante), p[test], yh[test])
        pn[test], yn[test] = pp, yy
        fuera[test] += 1
    assert (fuera == 1).all(), "cada registro debe quedar fuera de muestra exactamente una vez"
    return pn, yn, mitades


def errores(y: np.ndarray, yh: np.ndarray) -> tuple[float, float]:
    """(falsos negativos, falsos positivos) por cada 1 000 registros, sumados sobre las columnas dadas."""
    n = len(y)
    return float((y * (1 - yh)).sum() / n * 1000), float(((1 - y) * yh).sum() / n * 1000)


def main() -> int:
    reparto = json.loads((EV / "reparto_externo.json").read_text(encoding="utf-8"))
    etapa7 = pd.read_csv(RESULTADOS / "t19_etapa7" / "metricas_globales.csv")
    SALIDA.mkdir(parents=True, exist_ok=True)
    glob, difs, estab, curva, por_clase, hashes = [], [], [], [], [], {}
    for o in ORIGENES:
        ev = [CLASS_NAMES.index(c) for c in reparto["origenes"][o]["clases_evaluables"]]
        d0 = {}
        for k in SISTEMAS:
            ruta = a19.EVAL / f"{k.lower()}_{o}" / "predictions_test.csv"
            h = sha256(ruta)
            assert h == a19.SHA256_EXT[f"{k}_{o}"], f"{ruta} no es la predicción registrada"
            hashes[f"{k}_{o}"] = h
            d = pd.read_csv(ruta)
            d0[k] = (d["record_name"].to_numpy(), d[[f"true_{c}" for c in CLASS_NAMES]].to_numpy(np.uint8), d[[f"prob_{c}" for c in CLASS_NAMES]].to_numpy(float),
                     d[[f"pred_{c}" for c in CLASS_NAMES]].to_numpy(np.uint8))
        nombres, y = d0[SISTEMAS[0]][0], d0[SISTEMAS[0]][1]
        assert all((d0[k][0] == nombres).all() and (d0[k][1] == y).all() for k in SISTEMAS)

        # --- partición de semilla 0, con bootstrap
        sistemas, pred_v = {}, {}
        for k in SISTEMAS:
            _, _, p, yh = d0[k]
            for v in VARIANTES:
                if v == "V0":
                    pn, yn = p, yh
                else:
                    pn, yn, _ = cross_fit(y, p, yh, v, 0)
                pred_v[k, v] = (pn, yn)
                sistemas[f"{k}|{v}"] = a19.Sistema(y[:, ev], pn[:, ev], yn[:, ev])
        puntual, boot = a19.analizar(sistemas)
        for k in SISTEMAS:                                             # V0 debe reproducir la etapa 7
            e7 = etapa7[(etapa7.prueba == o) & (etapa7.subconjunto == "completa") & (etapa7.sistema == k)].set_index("metrica").valor
            for m in ("f1_macro", "f1_micro", "auroc_macro", "auprc_macro", "ece", "brier", "exacta"):
                assert abs(puntual[f"{k}|V0"][m] - e7[m]) < 2e-6, f"V0 no reproduce la etapa 7: {o} {k} {m}: {puntual[f'{k}|V0'][m]} frente a {e7[m]}"
        print(f"{o}: V0 reproduce la etapa 7 en los {len(SISTEMAS)} sistemas")
        for k in SISTEMAS:
            for v in VARIANTES:
                s = f"{k}|{v}"
                fn, fp = errores(y[:, ev], pred_v[k, v][1][:, ev])
                for m in CLAVES:
                    lo, hi = a19.ic(boot[s][m], m)
                    glob.append({"prueba": o, "sistema": k, "variante": v, "n": len(y), "metrica": m, "valor": puntual[s][m], "lo": lo, "hi": hi})
                glob.append({"prueba": o, "sistema": k, "variante": v, "n": len(y), "metrica": "fn_por_1000", "valor": fn, "lo": np.nan, "hi": np.nan})
                glob.append({"prueba": o, "sistema": k, "variante": v, "n": len(y), "metrica": "fp_por_1000", "valor": fp, "lo": np.nan, "hi": np.nan})
            for v in ("V1", "V2"):
                for m in CLAVES:
                    dif = boot[f"{k}|{v}"][m] - boot[f"{k}|V0"][m]
                    lo, hi = a19.ic(dif, m)
                    difs.append({"prueba": o, "sistema": k, "comparacion": f"{v} menos V0", "metrica": m, "diferencia": puntual[f"{k}|{v}"][m] - puntual[f"{k}|V0"][m], "lo": lo, "hi": hi})
        p3 = {v: puntual[f"P3|{v}"] for v in VARIANTES}
        for j, c in enumerate(reparto["origenes"][o]["clases_evaluables"]):
            for v in VARIANTES:
                por_clase.append({"prueba": o, "clase": c, "variante": v, "f1": p3[v]["pc_f1"][j], "sens": p3[v]["pc_sens"][j], "prec": p3[v]["pc_prec"][j],
                                  "espec": p3[v]["pc_espec"][j], "positivos": int(y[:, CLASS_NAMES.index(c)].sum())})

        # --- estabilidad con otras cuatro particiones (valores puntuales)
        for sem in SEMILLAS_PARTICION:
            for k in SISTEMAS:
                _, _, p, yh = d0[k]
                for v in ("V1", "V2"):
                    pn, yn, _ = cross_fit(y, p, yh, v, sem)
                    e = a19.estadisticas(a19.Sistema(y[:, ev], pn[:, ev], yn[:, ev]), np.ones(len(y)))
                    for m in ("f1_macro", "sens_macro", "prec_macro"):
                        estab.append({"prueba": o, "sistema": k, "variante": v, "particion": sem, "metrica": m, "valor": e[m]})

        # --- curva de etiquetas locales (P3, V2, partición de semilla 0): ajuste con n registros de la mitad X, medición sobre la mitad Y completa
        _, _, p, yh = d0["P3"]
        perm = np.random.default_rng(0).permutation(len(y))
        X, Y = perm[: len(y) // 2], perm[len(y) // 2:]
        base = a19.estadisticas(a19.Sistema(y[Y][:, ev], p[Y][:, ev], yh[Y][:, ev]), np.ones(len(Y)))
        for n_fit in TAMANOS + (len(X),):
            for rep in (SEMILLAS_PARTICION if n_fit < len(X) else (0,)):
                sub = X if n_fit == len(X) else np.random.default_rng(100 + rep).choice(X, size=n_fit, replace=False)
                for v in ("V1", "V2"):
                    pn, yn = aplicar(ajustar(y[sub], p[sub], v), p[Y], yh[Y])
                    e = a19.estadisticas(a19.Sistema(y[Y][:, ev], pn[:, ev], yn[:, ev]), np.ones(len(Y)))
                    fn, fp = errores(y[Y][:, ev], yn[:, ev])
                    curva.append({"prueba": o, "variante": v, "registros_de_ajuste": int(n_fit), "repeticion": rep, "f1_macro": e["f1_macro"], "sens_macro": e["sens_macro"],
                                  "prec_macro": e["prec_macro"], "fn_por_1000": fn, "fp_por_1000": fp, "f1_macro_V0_misma_mitad": base["f1_macro"]})

    tablas = {"metricas_globales": glob, "diferencias_pareadas": difs, "estabilidad_particiones": estab, "curva_etiquetas_locales": curva, "por_clase_P3": por_clase}
    for nombre, filas in tablas.items():
        pd.DataFrame(filas).to_csv(SALIDA / f"{nombre}.csv", index=False, float_format="%.6f", encoding="utf-8", lineterminator="\n")
    (SALIDA / "entradas.json").write_text(json.dumps({"predicciones_sha256": hashes, "desviaciones_sha256": sha256(EV / "protocolo_externo_t19_desviaciones.md"),
        "reparto_externo_sha256": sha256(EV / "reparto_externo.json"), "remuestreos": a19.REMUESTREOS, "semilla": a19.SEMILLA, "min_ajuste": MIN_FIT,
        "numpy": np.__version__, "pandas": pd.__version__}, indent=2) + "\n", encoding="utf-8", newline="\n")
    (SALIDA / "resumen.md").write_text(resumen(tablas), encoding="utf-8", newline="\n")
    print(f"escrito en {SALIDA}")
    return 0


def resumen(t: dict) -> str:
    g, d, es, cu, pc = (pd.DataFrame(t[k]) for k in ("metricas_globales", "diferencias_pareadas", "estabilidad_particiones", "curva_etiquetas_locales", "por_clase_P3"))
    nombre = {"C": "Chapman-Shaoxing (C)", "D": "Ningbo (D)"}
    L = ["# E13: recalibración local en Chapman-Shaoxing y Ningbo (EXPLORATORIA, desviación 6)", "",
         "Ajuste y medición sobre registros distintos (*cross-fit* de dos mitades, partición de semilla 0). V0: sistema congelado (etapa 7); V1: solo umbrales por clase; V2: calibración afín y umbrales. "
         "Solo clases evaluables. IC del 95 % por bootstrap (1 000 remuestreos, semilla 0). **Se ajusta con etiquetas de la propia institución: no es una evaluación independiente y no cambia el resultado confirmatorio.**", ""]
    for o in ORIGENES:
        L += [f"## {nombre[o]}", "", "| Sistema | Variante | F1 macro (IC95) | Sensibilidad macro | Precisión macro | FN por 1000 | FP por 1000 | ECE | Brier |", "|---|---|---|---|---|---|---|---|---|"]
        s = g[g.prueba == o]
        for k in SISTEMAS:
            for v in VARIANTES:
                f = {m: s[(s.sistema == k) & (s.variante == v) & (s.metrica == m)].iloc[0] for m in ("f1_macro", "sens_macro", "prec_macro", "fn_por_1000", "fp_por_1000", "ece", "brier")}
                L.append(f"| {k} | {v} | {a19.fmt(f['f1_macro'].valor, f['f1_macro'].lo, f['f1_macro'].hi)} | {a19.fmt(f['sens_macro'].valor)} | {a19.fmt(f['prec_macro'].valor)} | "
                         f"{f['fn_por_1000'].valor:.0f} | {f['fp_por_1000'].valor:.0f} | {a19.fmt(f['ece'].valor)} | {a19.fmt(f['brier'].valor)} |")
        L.append("")
        L += [f"### {o}: diferencias pareadas con el sistema congelado, F1 macro", "", "| Sistema | Comparación | Diferencia (IC95) |", "|---|---|---|"]
        for _, f in d[(d.prueba == o) & (d.metrica == "f1_macro")].iterrows():
            L.append(f"| {f.sistema} | {f.comparacion} | {a19.fmt(f.diferencia, f.lo, f.hi)} |")
        L += ["", f"### {o}: estabilidad con 5 particiones al azar (F1 macro, media ± desviación típica)", "", "| Sistema | V1 | V2 |", "|---|---|---|"]
        for k in SISTEMAS:
            fila = [es[(es.prueba == o) & (es.sistema == k) & (es.variante == v) & (es.metrica == "f1_macro")].valor for v in ("V1", "V2")]
            L.append(f"| {k} | " + " | ".join(f"{x.mean():.3f} ± {x.std(ddof=1):.3f}" for x in fila) + " |")
        L += ["", f"### {o}: P3, cuántas etiquetas locales hacen falta (ajuste con n registros, medición en la otra mitad; media ± desviación típica de 5 muestras)", "",
              "| Registros de ajuste | Variante | F1 macro | FN por 1000 | FP por 1000 |", "|---|---|---|---|---|"]
        c = cu[cu.prueba == o]
        for n_fit in sorted(c.registros_de_ajuste.unique()):
            for v in ("V1", "V2"):
                x = c[(c.registros_de_ajuste == n_fit) & (c.variante == v)]
                sd = lambda col: f"{x[col].std(ddof=1):.3f}" if len(x) > 1 else "—"
                L.append(f"| {n_fit} | {v} | {x.f1_macro.mean():.3f} ± {sd('f1_macro')} | {x.fn_por_1000.mean():.0f} | {x.fp_por_1000.mean():.0f} |")
        L.append(f"\nF1 macro de V0 en esa misma mitad: {c.f1_macro_V0_misma_mitad.iloc[0]:.3f}.\n")
        L += [f"### {o}: P3 por clase (F1 / sensibilidad / precisión)", "", "| Clase | Positivos | V0 | V1 | V2 |", "|---|---|---|---|---|"]
        for cl in pc[pc.prueba == o].clase.unique():
            x = pc[(pc.prueba == o) & (pc.clase == cl)].set_index("variante")
            L.append(f"| {cl} | {int(x.positivos.iloc[0])} | " + " | ".join(f"{x.loc[v, 'f1']:.2f} / {x.loc[v, 'sens']:.2f} / {x.loc[v, 'prec']:.2f}" for v in VARIANTES) + " |")
        L.append("")
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    sys.exit(main())
