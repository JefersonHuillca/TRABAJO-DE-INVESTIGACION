"""E2: auditoría de cabeceras y códigos de Chapman-Shaoxing (C) y Ningbo (D).

Solo lee cabeceras (.hea) y la lista de hashes publicada. No lee señales, no hay
predicciones. Cuenta, por origen y clase, los registros positivos con el esquema
de 12 clases del proyecto; lista los códigos sin clase, los registros sin ninguna
clase y los archivos .mat idénticos (mismo SHA-256 publicado) dentro de un origen
y entre ambos.

Uso (desde la raíz del repositorio):
    python -I tesis/scripts/auditar_externa.py
"""
import collections
import csv
import json
import os
import re
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(RAIZ))

from ecg.schema import CLASS_NAMES, CODE_TO_CLASS_NAME, codes_to_vector, parse_dx_field  # noqa: E402

BASE = RAIZ / "dataset2021" / "physionet.org" / "files" / "challenge-2021" / "1.0.3"
TRAINING = BASE / "training"
SALIDA = RAIZ / "tesis" / "ieee" / "evidencia"
ORIGENES = {"chapman_shaoxing": 10247, "ningbo": 34905}
# Regla fijada el 2026-10-31: se excluye todo archivo cuyo SHA-256 no coincide con el publicado.
EXCLUIDOS = {"JS13118"}
DX = re.compile(r"^#\s*Dx\s*:\s*(.*?)\s*$")


def oficiales():
    ruta = RAIZ / "examples" / "cinc2020" / "official" / "dx_mapping_scored.csv"
    with open(ruta, newline="", encoding="utf-8") as f:
        return {r["SNOMED CT Code"].strip(): r["Abbreviation"].strip() for r in csv.DictReader(f) if r["SNOMED CT Code"].strip()}


def hashes_mat():
    """nombre de registro -> hash publicado de su .mat, por origen."""
    res = collections.defaultdict(dict)
    for linea in open(BASE / "SHA256SUMS.txt", encoding="utf-8"):
        h, ruta = linea.split(maxsplit=1)
        ruta = ruta.strip()
        m = re.match(r"training/(chapman_shaoxing|ningbo)/g\d+/(\w+)\.mat$", ruta)
        if m:
            res[m.group(1)][m.group(2)] = h
    return res


def main():
    off = oficiales()
    pub = hashes_mat()
    n_clases = len(CLASS_NAMES)
    codigos = {o: collections.Counter() for o in ORIGENES}
    pos = {o: collections.Counter() for o in ORIGENES}
    resumen = {}
    for o, esperado in ORIGENES.items():
        n = sin_dx = sin_clase = multi = 0
        etiquetas_por_registro = collections.Counter()
        for d, _, fs in os.walk(TRAINING / o):
            for f in sorted(fs):
                if not f.endswith(".hea"):
                    continue
                if f[:-4] in EXCLUIDOS:
                    continue
                n += 1
                cods = []
                for linea in (Path(d) / f).read_text(encoding="utf-8", errors="replace").splitlines():
                    m = DX.match(linea)
                    if m:
                        cods = parse_dx_field(m.group(1))
                if not cods:
                    sin_dx += 1
                codigos[o].update(set(cods))
                v = codes_to_vector(cods)
                if v.sum() == 0:
                    sin_clase += 1
                if v.sum() > 1:
                    multi += 1
                etiquetas_por_registro[int(v.sum())] += 1
                for i, c in enumerate(CLASS_NAMES):
                    if v[i]:
                        pos[o][c] += 1
        resumen[o] = {
            "registros_tras_exclusiones": n,
            "esperado_sin_exclusiones": esperado,
            "sin_linea_dx": sin_dx,
            "sin_ninguna_de_las_12_clases": sin_clase,
            "con_mas_de_una_clase": multi,
            "clases_por_registro": dict(sorted(etiquetas_por_registro.items())),
        }

    # duplicados exactos de .mat según los hashes publicados
    todos = collections.defaultdict(list)
    for o in ORIGENES:
        for r, h in pub[o].items():
            if r not in EXCLUIDOS:
                todos[h].append((o, r))
    dup = [v for v in todos.values() if len(v) > 1]
    resumen["mat_identicos_publicados"] = {
        "grupos": len(dup),
        "registros_afectados": sum(len(v) for v in dup),
        "entre_origenes": sum(1 for v in dup if len({o for o, _ in v}) > 1),
        "ejemplos": [v for v in dup[:5]],
    }

    with open(SALIDA / "auditoria_externa.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["origen", "clase", "registros", "positivos", "prevalencia"])
        for o in ORIGENES:
            n = resumen[o]["registros_tras_exclusiones"]
            for c in CLASS_NAMES:
                w.writerow([o, c, n, pos[o][c], f"{pos[o][c] / n:.4f}"])
    with open(SALIDA / "auditoria_externa_codigos.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["origen", "codigo_snomed", "registros", "clase_asignada", "abreviatura_oficial"])
        for o in ORIGENES:
            for c, k in codigos[o].most_common():
                w.writerow([o, c, k, CODE_TO_CLASS_NAME.get(c, "SIN_CLASE"), off.get(c, "")])
    resumen["codigos_distintos"] = {o: len(codigos[o]) for o in ORIGENES}
    resumen["codigos_sin_clase_distintos"] = {
        o: sum(1 for c in codigos[o] if c not in CODE_TO_CLASS_NAME) for o in ORIGENES
    }
    with open(SALIDA / "auditoria_externa.json", "w", encoding="utf-8", newline="\n") as f:
        json.dump(resumen, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(json.dumps(resumen, ensure_ascii=False, indent=1)[:3000])


if __name__ == "__main__":
    main()
