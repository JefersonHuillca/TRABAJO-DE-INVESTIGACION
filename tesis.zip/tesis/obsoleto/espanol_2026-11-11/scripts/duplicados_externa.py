"""E5 (parte 1): duplicados de Chapman-Shaoxing y Ningbo, entre sí y frente a los registros del Challenge 2020.

Regla fijada antes de mirar ninguna predicción: de cada grupo de registros con la señal idéntica se conserva uno solo, el primero por
(origen, nombre de registro) con Chapman-Shaoxing antes que Ningbo; los demás se excluyen de la evaluación. Un registro que además coincide
con alguno del Challenge 2020 (entrenamiento, validación, prueba A o B) se excluye siempre. JS13118 se excluye por tener un hash distinto del publicado.

Lee solo señales y encabezados (``.mat``/``.hea``); no usa ningún modelo ni predicción. Los grupos salen de dos fuentes que se contrastan: los SHA-256
publicados de los ``.mat`` (``SHA256SUMS.txt``) y el contenido de la señal leído de cada archivo (que también encuentra duplicados con bytes distintos).

Escribe en evidencia/: duplicados_externa.csv (un registro por fila de cada grupo), duplicados_externa.json (resumen) y exclusiones_externa.txt
(los nombres que ``build_external_test.py --exclude-record`` debe apartar, uno por línea).
Uso, desde la raíz del repo:  python tesis/scripts/duplicados_externa.py
"""

from __future__ import annotations

import collections
import csv
import hashlib
import json
import re
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import scipy.io
import sys

IEEE = Path(__file__).resolve().parents[1]
REPO = IEEE.parent
sys.path.insert(0, str(REPO))
from ecg.schema import CODE_TO_CLASS_NAME  # noqa: E402
EV = IEEE / "evidencia"
BASE21 = REPO / "dataset2021" / "physionet.org" / "files" / "challenge-2021" / "1.0.3"
RAIZ20 = REPO / "dataset2020"
ORIGENES = ("chapman_shaoxing", "ningbo")                       # el orden decide cuál se conserva de cada grupo
HASH_DISTINTO = {"JS13118"}                                      # el servidor sirve bytes distintos de los publicados (E1)


def contenido(ruta: str) -> tuple[str, str]:
    """(ruta, SHA-256 de la señal ``val`` con su forma y tipo)."""
    v = scipy.io.loadmat(ruta)["val"]
    return ruta, hashlib.sha256(f"{v.shape}{v.dtype}".encode() + np.ascontiguousarray(v).tobytes()).hexdigest()


def hashes_contenido(rutas: list[Path]) -> dict[str, str]:
    with ProcessPoolExecutor() as ex:
        return dict(ex.map(contenido, map(str, rutas), chunksize=64))


def dx_de(hea: Path) -> frozenset[str]:
    for linea in hea.read_text(encoding="utf-8", errors="ignore").splitlines():
        m = re.match(r"#\s*Dx:\s*(.*)", linea)
        if m:
            return frozenset(c.strip() for c in m.group(1).split(",") if c.strip())
    return frozenset()


def main() -> int:
    registros = {}                                                # nombre -> (origen, ruta .mat)
    for o in ORIGENES:
        for mat in sorted((BASE21 / "training" / o).rglob("*.mat")):
            assert mat.stem not in registros, f"nombre repetido: {mat.stem}"
            registros[mat.stem] = (o, mat)
    print(f"registros de Chapman-Shaoxing y Ningbo: {len(registros)}")

    publicados = {}
    for linea in open(BASE21 / "SHA256SUMS.txt", encoding="utf-8"):
        h, ruta = linea.split(maxsplit=1)
        m = re.match(r"training/(?:chapman_shaoxing|ningbo)/g\d+/(\w+)\.mat$", ruta.strip())
        if m:
            publicados[m.group(1)] = h
    assert set(publicados) == set(registros), "los .mat locales no coinciden con SHA256SUMS.txt"

    print("leyendo la señal de cada .mat externo...")
    sig_ext = hashes_contenido([r[1] for r in registros.values()])
    sig_de = {n: sig_ext[str(r[1])] for n, r in registros.items()}
    mats20 = sorted(RAIZ20.rglob("*.mat"))
    print(f"leyendo la señal de {len(mats20)} .mat del Challenge 2020...")
    sig20 = collections.defaultdict(list)
    for ruta, h in hashes_contenido(mats20).items():
        sig20[h].append(Path(ruta).stem)

    activos = {n: r for n, r in registros.items() if n not in HASH_DISTINTO}
    por_pub, por_sig = collections.defaultdict(list), collections.defaultdict(list)
    for n, (o, _) in activos.items():
        por_pub[publicados[n]].append(n)
        por_sig[sig_de[n]].append(n)

    def clave(n):
        return (ORIGENES.index(registros[n][0]), n)

    grupos = [sorted(v, key=clave) for v in por_sig.values() if len(v) > 1]
    grupos.sort(key=lambda v: clave(v[0]))
    grupos_pub = {frozenset(v) for v in por_pub.values() if len(v) > 1}
    coinciden = grupos_pub == {frozenset(g) for g in grupos}

    contra20 = {n for n in activos if sig_de[n] in sig20}
    excluir = set(HASH_DISTINTO) | contra20
    def clases12(n):
        return frozenset(CODE_TO_CLASS_NAME[c] for c in dx_de(registros[n][1].with_suffix(".hea")) if c in CODE_TO_CLASS_NAME)

    filas = []
    discordantes = 0
    for i, g in enumerate(grupos, 1):
        discordante = len({clases12(n) for n in g}) > 1
        discordantes += discordante
        for j, n in enumerate(g):
            descartado = j > 0
            if descartado:
                excluir.add(n)
            filas.append({"grupo": i, "registro": n, "origen": registros[n][0], "decision": "descartado" if descartado else "conservado",
                          "sha256_publicado": publicados[n], "dx": ";".join(sorted(dx_de(registros[n][1].with_suffix(".hea")))),
                          "clases12": ";".join(sorted(clases12(n))), "clases12_discordantes": discordante})

    mismo_dx = sum(1 for g in grupos if len({dx_de(registros[n][1].with_suffix(".hea")) for n in g}) == 1)
    resumen = {
        "regla": "un registro por grupo de señal idéntica (el primero por origen —Chapman-Shaoxing antes que Ningbo— y nombre); los coincidentes con el Challenge 2020 y JS13118 se excluyen siempre",
        "registros_leidos": len(registros),
        "grupos_de_senal_identica": len(grupos),
        "registros_en_grupos": sum(len(g) for g in grupos),
        "grupos_entre_origenes": sum(1 for g in grupos if len({registros[n][0] for n in g}) > 1),
        "grupos_con_mas_de_dos": sum(1 for g in grupos if len(g) > 2),
        "grupos_con_el_mismo_dx": mismo_dx,
        "grupos_con_clases_discordantes_en_las_12": discordantes,
        "grupos_por_hash_publicado_iguales_a_los_de_senal": coinciden,
        "descartados_por_duplicado": sum(len(g) - 1 for g in grupos),
        "coincidentes_con_el_challenge_2020": sorted(contra20),
        "excluidos_por_hash_distinto": sorted(HASH_DISTINTO),
        "total_excluidos": len(excluir),
        "restantes": {o: sum(1 for n, r in registros.items() if r[0] == o and n not in excluir) for o in ORIGENES},
        "registros_2020_leidos": len(mats20),
    }
    with open(EV / "duplicados_externa.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["grupo", "registro", "origen", "decision", "sha256_publicado", "dx", "clases12", "clases12_discordantes"], lineterminator="\n")
        w.writeheader()
        w.writerows(filas)
    (EV / "duplicados_externa.json").write_text(json.dumps(resumen, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    (EV / "exclusiones_externa.txt").write_text("".join(f"{n}\n" for n in sorted(excluir)), encoding="utf-8", newline="\n")
    print(json.dumps(resumen, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
