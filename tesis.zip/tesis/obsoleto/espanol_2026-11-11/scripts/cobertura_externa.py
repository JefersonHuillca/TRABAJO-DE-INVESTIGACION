"""E3: cobertura documentada y clases evaluables de Chapman-Shaoxing (C) y Ningbo (D).

Entradas: la auditoría de E2 (positivos por clase y origen, solo cabeceras) y la
tabla de etiquetas que publica la documentación de la base (ConditionNames_SNOMED-CT,
ecg-arrhythmia v1.0.0, 63 filas). Sin señales ni predicciones.

Regla fijada en E0.4 (2026-10-30): una clase es evaluable en un origen si la
documentación de la fuente la cubre y hay al menos 50 positivos en ese origen.

Uso (desde la raíz del repositorio):
    python -I tesis/scripts/cobertura_externa.py <ConditionNames_SNOMED-CT.csv>
"""
import csv
import json
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(RAIZ))

from ecg.schema import CLASS_NAMES, CODE_TO_CLASS_NAME  # noqa: E402

EVID = RAIZ / "tesis" / "ieee" / "evidencia"
MIN_POSITIVOS = 50
ORIGENES = ("chapman_shaoxing", "ningbo")
FUENTE = ("Zheng, Guo y Chu 2022, ecg-arrhythmia v1.0.0, tabla ConditionNames_SNOMED-CT "
          "(https://physionet.org/files/ecg-arrhythmia/1.0.0/ConditionNames_SNOMED-CT.csv), "
          "doi:10.13026/wgex-er52; Reyna et al. 2022, Challenge 2021 v1.0.3, doi:10.13026/34va-7q14")


def leer_tabla(ruta):
    """Devuelve [(acronimo, nombre, codigo)] de la tabla de la documentación."""
    texto = Path(ruta).read_bytes().decode("utf-8-sig", errors="replace")
    filas = list(csv.reader(texto.splitlines()))
    out = []
    for f in filas[1:]:
        f = [c.strip() for c in f]
        if len(f) >= 3 and f[-1].isdigit():
            out.append((f[0], f[1], f[-1]))
    return out


def main():
    tabla = leer_tabla(sys.argv[1])
    por_clase = {c: [] for c in CLASS_NAMES}
    sin_clase = []
    for acr, nombre, codigo in tabla:
        clase = CODE_TO_CLASS_NAME.get(codigo)
        (por_clase[clase] if clase else sin_clase).append(acr)
    aud = {(r["origen"], r["clase"]): int(r["positivos"]) for r in csv.DictReader(open(EVID / "auditoria_externa.csv", encoding="utf-8"))}
    reg = {r["origen"]: int(r["registros"]) for r in csv.DictReader(open(EVID / "auditoria_externa.csv", encoding="utf-8"))}
    filas = []
    for o in ORIGENES:
        for c in CLASS_NAMES:
            doc = por_clase[c]
            cubierta = "cubierta" if doc else "sin documentar"
            pos = aud[(o, c)]
            evaluable = bool(doc) and pos >= MIN_POSITIVOS
            motivo = "" if evaluable else ("menos de 50 positivos" if doc else "la documentación no la cubre")
            filas.append({
                "origen": o, "clase": c, "registros": reg[o], "positivos": pos,
                "cobertura_documentada": cubierta,
                "etiquetas_de_la_documentacion": " ".join(doc),
                "evaluable": "si" if evaluable else "no", "motivo_si_no": motivo, "fuente": FUENTE,
            })
    with open(EVID / "cobertura_externa.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(filas[0]), lineterminator="\n")
        w.writeheader()
        w.writerows(filas)
    resumen = {
        "filas_de_la_tabla_de_la_documentacion": len(tabla),
        "etiquetas_de_la_documentacion_sin_clase_del_proyecto": sin_clase,
        "minimo_positivos": MIN_POSITIVOS,
        "evaluables": {o: [r["clase"] for r in filas if r["origen"] == o and r["evaluable"] == "si"] for o in ORIGENES},
        "no_evaluables": {o: [(r["clase"], r["motivo_si_no"], r["positivos"]) for r in filas if r["origen"] == o and r["evaluable"] == "no"] for o in ORIGENES},
    }
    with open(EVID / "cobertura_externa.json", "w", encoding="utf-8", newline="\n") as f:
        json.dump(resumen, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(json.dumps(resumen, ensure_ascii=False, indent=1))
    for c in CLASS_NAMES:
        print(f"{c:20s} {' '.join(por_clase[c])}")


if __name__ == "__main__":
    main()
