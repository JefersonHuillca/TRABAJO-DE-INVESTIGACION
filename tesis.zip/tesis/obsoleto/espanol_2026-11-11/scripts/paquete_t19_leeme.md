# Paquete de reproducibilidad: reentrenamiento final de una ResNet 1D para ECG de 12 derivaciones

Estado: preparado para archivar el @@FECHA@@; sin DOI y sin publicar. Código del experimento: commit `@@COMMIT@@`. El código incluido es el del repositorio publicado en el commit `@@CODIGO@@`, que añade al del experimento el constructor de HDF5 externos, la descarga y la verificación de Chapman-Shaoxing y Ningbo (los archivos cambiados están en `manifiesto.json`).

## Qué es

Réplica metodológica de Hannun et al. (2019) con la base pública del PhysioNet/CinC Challenge 2020: clasificador multietiqueta de 12 clases
sobre ECG de 12 derivaciones. Este paquete reúne lo necesario para comprobar los resultados del reentrenamiento final: un protocolo escrito y con
hash antes de entrenar, un reparto por origen y por paciente con Georgia retenida como prueba B, los pesos entrenados, la calibración, los umbrales,
las predicciones por registro de @@N_SISTEMAS@@ sistemas en las pruebas A y B y de @@N_EXTERNOS@@ de ellos en dos bases externas (Chapman-Shaoxing y Ningbo, la evaluación primaria), y el análisis estadístico. Es una superposición del repositorio en el
commit del experimento: las rutas de datos, configuraciones, pesos y evaluaciones son las de los comandos del registro, de modo que se ejecutan desde esta carpeta. Los scripts de análisis
(`analizar_t19.py`, `evaluar_t19.sh`, `verificar_reparto_t19.py`) están en `analisis/`; donde el registro o sus propias cabeceras dicen `scripts/` con otro prefijo, es esa carpeta.

## Resultados principales

@@RESULTADOS@@

Todos con calibración afín por clase y umbrales de F1 fijados en la validación. Las filas de Chapman-Shaoxing y Ningbo son la **evaluación primaria**: sistemas congelados, una sola evaluación en cada base, métricas sobre las clases evaluables de cada una
(`protocolo/protocolo_externo_t19.md`, sellado antes de ejecutar ningún modelo sobre ellas); las pruebas A y B son el desarrollo. Un análisis exploratorio con etiquetas locales (`resultados/e13_recalibracion_local/`, desviación 6) ajusta con etiquetas de la propia base y no cambia ese resultado.
El detalle (otros sistemas, IC, diferencias pareadas, semillas, ablaciones) está
en `resultados/t19_etapa1/`, `t19_etapa2/`, `t19_etapa3/`, `t19_etapa6/` y `t19_etapa7/` (`resumen.md` de cada una es la lectura rápida). La variabilidad entre entrenamientos se mide con 10 semillas por receta
(la original y 101 a 109; `t19_etapa6/`); la etapa 3 conserva el análisis de las 5 semillas del protocolo y las ablaciones. Las semillas 105 a 109 se añadieron después de ver las pruebas A y B de las cinco primeras
(`protocolo/protocolo_t19_desviaciones.md`, desviación 5) y se informan todas.

## Contenido

| Ruta | Qué es |
|---|---|
| `protocolo/` | Protocolo (`protocolo_t19.md` y su SHA-256), registro cronológico con los hashes de cada paso, desviaciones, manifiesto del reparto (`reparto_t19.json`) y cobertura de etiquetas; y los del protocolo externo (`protocolo_externo_t19*`), el manifiesto de las bases externas (`reparto_externo.json`), las exclusiones y los duplicados, la auditoría de cabeceras y la cobertura de etiquetas de Chapman-Shaoxing y Ningbo |
| `data/cinc2020_12_origen/split_assignments.csv` | Reparto: partición de cada uno de los 43 101 registros (`train`, `val`, `test` = prueba A, `test_b` = prueba B) y sus etiquetas |
| `data/externo/patient_groups.csv` | Grupos de paciente de PTB-XL y PTB usados para repartir por paciente |
| `data/cinc2021_externo/` | Manifiesto por registro (`test_c.h5.records.csv` y `test_d.h5.records.csv`: registro, origen, clases) y resumen de cada base externa; los HDF5 no se redistribuyen |
| `runs/t19/config/` | Configuración de cada experimento (`config_t19_*.json`) y las de las pruebas B, C y D (`*_testb.json`, `*_testc.json`, `*_testd.json`) |
| `saved/t19/` | Por experimento: pesos `best.pt` (@@PESOS@@), `training_summary.json`, `history.csv` y `config_used.json` |
| `runs/t19/eval/` | Por sistema: calibración (afín, `platt_*.csv`; por temperatura en los sistemas `p1t`, `p2t` y `p3t`, exploratorios), umbrales, predicciones de validación y de prueba (A, B, C y D) y las métricas de la evaluación |
| `runs/t19/robustez/` | Robustez exploratoria de P2 ante perturbaciones de la señal de las pruebas A y B (`p2_A.csv`, `p2_B.csv`) |
| `resultados/` | Salidas del análisis (`t19_etapa*/`; la 7 es la evaluación externa), la recalibración local exploratoria (`e13_recalibracion_local/`), cifras del artículo (`cifras_t19.csv`) y matrices de confusión |
| `analisis/` | `analizar_t19.py` (análisis con *bootstrap*), `evaluar_t19.sh` (calibración, umbrales y evaluación única), `verificar_reparto_t19.py`, `entrenar_e16.sh` (semillas 105 a 109), `recalibracion_local.py` (E13) y, de la preparación de las bases externas, `duplicados_externa.py`, `reparto_externo.py` y `sistemas_congelados.py` (necesitan los datos crudos) |
| `ecg/`, `examples/`, `tools/`, `tests/` | Código del repositorio en el commit indicado arriba. Sin `webapp/`, `models/` ni `deploy/`: la aplicación web y sus pesos son de otro entrenamiento y no intervienen en los resultados; las pruebas de `tests/` que dependen de ellas no aplican a este paquete |
| `README.md`, `CONTEXT.md`, `docs/` | Documentación general del repositorio; describe el reparto aleatorio por registro y los resultados anteriores a este protocolo, que no son los de este paquete |
| `constraints.txt`, `requirements*.txt`, `manifiesto.json` | Versiones fijadas de las dependencias; entorno del entrenamiento, semillas y comandos |
| `SHA256SUMS.txt`, `verificar_paquete.py` | Suma de verificación de todos los archivos y verificador |

## Verificación sin datos crudos ni GPU

Con las dependencias de `constraints.txt` instaladas (`python -m pip install -r requirements.txt -c constraints.txt`), desde esta carpeta:

```bash
python verificar_paquete.py
python verificar_paquete.py --completo
```

El primero comprueba (1) los SHA-256 de todos los archivos, (2) que las predicciones cubren exactamente los registros y las etiquetas de la prueba A y de la B del reparto,
(3) que los umbrales guardados salen de las predicciones de validación y que las decisiones de prueba son `probabilidad >= umbral`, y (4) que F1 macro, micro y ponderado,
coincidencia exacta, AUROC macro, AUPRC macro, ECE y Brier de cada sistema, recalculados desde las predicciones, coinciden con `resultados/t19_etapa*/metricas_globales.csv`.
El paso (5) hace lo mismo con las bases externas: las predicciones de C y D cubren los registros y las etiquetas del manifiesto por registro, los umbrales son los de la prueba A y las métricas sobre las clases evaluables de cada base coinciden con `resultados/t19_etapa7/`.
Con `--completo` repite además el análisis con *bootstrap* (1 000 remuestreos, semilla 0; etapas 1 a 4, 6 y 7 y la recalibración local) y exige que sus CSV salgan byte a byte iguales a los de `resultados/`.

## Reproducción completa (datos y GPU)

1. Entorno: Python con las versiones de `constraints.txt` (los paquetes y la GPU del entrenamiento están en `manifiesto.json`).
2. Datos: `bash descargar_datos_2020.sh` baja los seis subconjuntos de `training/` del Challenge 2020 a `dataset2020/`. Para los grupos de paciente hacen falta, de PhysioNet,
   `ptbxl_database.csv` de PTB-XL 1.0.3 y `RECORDS` de PTB 1.0.0 en `data/externo/`; sus SHA-256 están en `manifiesto.json` y los grupos resultantes se regeneran con
   `python tools/make_patient_groups.py --ptbxl-database data/externo/ptbxl_database.csv --ptb-records data/externo/RECORDS`.
3. Reparto y HDF5 (unos 10 GB, no incluidos):

   ```bash
   python examples/cinc2020/build_datasets.py --data-dir dataset2020 --output-dir data/cinc2020_12_origen --holdout-origin georgia --groups-csv data/externo/patient_groups.csv --workers 8 --norm-mode physical --train-windows-max 4 --val-frac 0.15 --test-frac 0.15 --random-state 42
   T19_RAIZ=. T19_SALIDA=regenerado python analisis/verificar_reparto_t19.py
   ```

   El segundo comando comprueba los tamaños, que ningún paciente esté en dos particiones y que Georgia esté solo en la prueba B, y calcula los SHA-256 que se comparan con `protocolo/reparto_t19.json`.
4. Entrenamiento (una corrida por experimento; experimentos: @@EXPERIMENTOS@@):

   ```bash
   python -X utf8 -m ecg.train runs/t19/config/config_<experimento>.json -e <experimento>
   ```

5. Calibración, umbrales y evaluación única, en una carpeta `runs/t19/eval/` limpia (el script se detiene si la carpeta de un sistema ya existe, para respetar «una sola evaluación»):

   ```bash
   T19_RAIZ=. bash analisis/evaluar_t19.sh 1
   T19_RAIZ=. bash analisis/evaluar_t19.sh 2
   T19_RAIZ=. bash analisis/evaluar_t19.sh 3
   T19_RAIZ=. bash analisis/evaluar_t19.sh 6   # semillas 105 a 109 de P1 y P2 (ampliación a 10 semillas)
   T19_RAIZ=. bash analisis/evaluar_t19.sh 4   # exploratoria: calibración por temperatura
   T19_RAIZ=. bash analisis/evaluar_t19.sh 5   # exploratoria: robustez de P2
   ```

6. Análisis: `T19_RAIZ=. T19_SALIDA=regenerado python analisis/analizar_t19.py --etapa <1|2|3|4|6>` (la 4 es la exploratoria de la temperatura; la 6 es el análisis con 10 semillas).
7. Evaluación externa: `bash descargar_challenge2021.sh` baja `chapman_shaoxing` y `ningbo` del Challenge 2021 v1.0.3 a `dataset2021/` y `python tools/verificar_challenge2021.py` comprueba que estén completas (el SHA-256 del `SHA256SUMS.txt` de la descarga consta en `protocolo/protocolo_externo_t19.md`, §2). Los HDF5 de solo prueba (`data/cinc2021_externo/test_c.h5` y `test_d.h5`) se construyen con `build_external_test.py` y la lista de `protocolo/exclusiones_externa.txt`
   (comando en `manifiesto.json`, clave `construir_externas`); después `T19_RAIZ=. bash analisis/evaluar_t19.sh 7` evalúa los 37 sistemas, una sola vez en cada base, y `T19_RAIZ=. T19_ENTRADAS=protocolo T19_SALIDA=regenerado python analisis/analizar_t19.py --etapa 7` hace el análisis. La recalibración local exploratoria: `T19_RAIZ=. T19_ENTRADAS=protocolo T19_RESULTADOS=resultados T19_SALIDA=regenerado python analisis/recalibracion_local.py`.

## Qué se reproduce y qué no

- **Se recomputa exactamente** (pasos de verificación de arriba): decisiones, umbrales, métricas e intervalos a partir de las predicciones del paquete.
- **La calibración (afín o por temperatura)** se ajusta con los logits de validación, que salen de los pesos y de los datos crudos: se rehace con los pasos 3 y 5, no con `verificar_paquete.py`. Lo mismo vale para la robustez (`runs/t19/robustez/`), que exige los pesos y los HDF5.
- **Lo exploratorio**: los sistemas con temperatura (`p1t`, `p2t`, `p3t`) y la robustez no están en el protocolo; se hicieron después de ver las pruebas A y B (`protocolo/protocolo_t19_desviaciones.md`, desviación 4).
- **El entrenamiento no es reproducible bit a bit**: la GPU no lo garantiza y todo se ejecutó en un solo equipo. Las semillas están fijadas (`manifiesto.json`), pero una reproducción da
  resultados cercanos, no idénticos; por eso el paquete conserva los pesos y las predicciones de referencia. Las semillas 101 a 109 y las ablaciones documentan cuánto varía.
- **Los HDF5 no se redistribuyen**; sus hashes están en `protocolo/reparto_t19.json` y pueden diferir si cambian las versiones de las bibliotecas.
- **Preespecificado y no**: lo fijado antes de entrenar está en `protocolo/protocolo_t19.md`; lo añadido después, con fecha y motivo, en `protocolo/protocolo_t19_desviaciones.md`.
  Las recetas, la calibración y el punto de operación se eligieron mirando una prueba anterior: la prueba B es independiente del entrenamiento y la validación pero no del diseño.
- **Etiquetas**: provienen de los códigos de cada institución; no fueron revisadas por cardiólogos.

## Integridad y registro

`SHA256SUMS.txt` lista todos los archivos. `protocolo/protocolo_t19_registro.md` es el registro cronológico, con los hashes de predicciones, pesos y configuraciones tal como se anotaron
en cada etapa; `manifiesto.json` resume cuántos de ellos aparecen allí completos o abreviados. Las rutas `evidencia/...` del protocolo y del registro corresponden aquí a `protocolo/` y a `resultados/`;
el registro cita además `calcular_t19.py` (genera las cifras del artículo) y `armar_paquete_t19.py` (arma este paquete), que no se incluyen.

El código del experimento es el commit `@@COMMIT@@`. La rama que se publica añade solo cambios de comentarios, de documentación y de la lista de carpetas que revisa `tools/check_docs_commands.py`;
los archivos de código afectados están en `manifiesto.json` (`codigo_cambiado_desde_el_experimento`).

## Licencia y cita

Ver `LICENCIA.md`: el código es GPL v3 y todo lo demás, incluido lo derivado de las bases del Challenge 2020 y de Chapman-Shaoxing y Ningbo, CC BY 4.0. Al usar los datos o este paquete hay que citar los trabajos de PhysioNet que figuran en `LICENCIA.md` (tres del Challenge 2020 y de PhysioNet, y cuatro de las bases externas). El paquete no tiene DOI todavía.
