# Licencias y citas

Estado: preparado el @@FECHA@@.

| Parte | Licencia |
|---|---|
| Código del repositorio (`ecg/`, `examples/`, `tools/`, `tests/`) | GNU GPL v3: es el archivo `LICENSE`, incluido en este paquete |
| `analisis/` y `verificar_paquete.py` | GNU GPL v3, la misma del código |
| Protocolo, registro, reparto, configuraciones, predicciones, calibraciones, umbrales, resultados y pesos entrenados | Creative Commons Attribution 4.0 International (CC BY 4.0) |
| Datos de origen (señales y cabeceras) | No se redistribuyen; PhysioNet los distribuye bajo CC BY 4.0 (Challenge 2020 y, del Challenge 2021, las carpetas `chapman_shaoxing` y `ningbo`) |

Todo lo derivado de las bases del Challenge 2020 y de Chapman-Shaoxing y Ningbo (las etiquetas de `split_assignments.csv`, de `data/cinc2021_externo/*.records.csv` y de las columnas `true_*`, las predicciones y los pesos) se publica con la misma licencia que los datos de origen, CC BY 4.0, que permite compartir y adaptar con atribución. La atribución consiste en citar los trabajos siguientes.

## Citas obligatorias

When using this resource, please cite:

- Perez Alday, E. A., Gu, A., Shah, A., Liu, C., Sharma, A., Seyedi, S., Bahrami Rad, A., Reyna, M., & Clifford, G. (2022). Classification of 12-lead ECGs: The PhysioNet/Computing in Cardiology Challenge 2020 (version 1.0.2). PhysioNet. RRID:SCR_007345. https://doi.org/10.13026/dvyd-kd57

Additionally, please cite the original publication:

- Perez Alday EA, Gu A, Shah AJ, Robichaux C, Wong AI, Liu C, Liu F, Rad AB, Elola A, Seyedi S, Li Q, Sharma A, Clifford GD, Reyna MA. Classification of 12-lead ECGs: the PhysioNet/Computing in Cardiology Challenge 2020. Physiol Meas. 2020 Nov 11. http://doi.org/10.1088/1361-6579/abc960

Please include the standard citation for PhysioNet:

- Pollard, T., Moody, B. E., Lehman, L., Gow, B., Fernandes, C., Xie, C., Johnson, A., Mark, R. G., & Heldt, T. (2026). PhysioNet as a global platform for biomedical research. Nature Health. https://doi.org/10.1038/s44360-026-00096-z

## Citas de las bases externas (Chapman-Shaoxing y Ningbo)

- Zheng, J., Guo, H., & Chu, H. (2022). A large scale 12-lead electrocardiogram database for arrhythmia study. PhysioNet. RRID:SCR_007345. https://doi.org/10.13026/wgex-er52
- Zheng, J., Zhang, J., Danioko, S., Yao, H., Guo, H., & Rakovski, C. (2020). A 12-lead electrocardiogram database for arrhythmia research covering more than 10,000 patients. Scientific Data, 7(1). https://doi.org/10.1038/s41597-020-0386-x
- Reyna, M., Sadr, N., Gu, A., Perez Alday, E. A., Liu, C., Seyedi, S., Shah, A., & Clifford, G. (2022). Will two do? Varying dimensions in electrocardiography: The PhysioNet/Computing in Cardiology Challenge 2021 (version 1.0.3). PhysioNet. RRID:SCR_007345. https://doi.org/10.13026/34va-7q14
- Reyna, M. A., Sadr, N., Perez Alday, E. A., Gu, A., Shah, A. J., Robichaux, C., Bahrami Rad, A., Elola, A., Seyedi, S., Ansari, S., Ghanbari, H., Li, Q., Sharma, A., & Clifford, G. D. (2021). Will two do? Varying dimensions in electrocardiography: The PhysioNet/Computing in Cardiology Challenge 2021. 2021 Computing in Cardiology (CinC), 1-4. https://doi.org/10.23919/CinC53138.2021.9662687

De estas dos bases solo se usan las carpetas de datos: no se calcula la métrica del Challenge 2021 ni se comparan cifras con sus resultados.
