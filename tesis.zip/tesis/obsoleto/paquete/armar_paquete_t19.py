"""Arma el paquete de reproducibilidad del reentrenamiento final (T19) en tesis/paquete_t19/.

El paquete es una superposición del repositorio en el commit del experimento: el código (``git archive`` sin la aplicación web, sus pesos
ni los archivos de trabajo), el reparto, el protocolo con su registro, las configuraciones, los pesos entrenados, las
calibraciones, los umbrales, las predicciones por registro de todos los sistemas evaluados en las pruebas A y B, y los resultados del análisis, en las
mismas rutas relativas que usan los comandos del registro. Lleva un LEEME, el manifiesto, SHA256SUMS.txt y ``verificar_paquete.py``, que
comprueba hashes, partición, umbrales y métricas sin datos crudos ni GPU. No entrena ni evalúa nada, no sube nada y no lo archiva con DOI.

Uso, desde la raíz del repo:
    python tesis/scripts/armar_paquete_t19.py [--sin-pesos] [--rehacer]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import tarfile
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path

import pandas as pd

IEEE = Path(__file__).resolve().parents[1]
REPO = IEEE.parent
SCRIPTS = IEEE / "scripts"
EV = IEEE / "evidencia"
sys.path.insert(0, str(SCRIPTS))
import analizar_t19 as a19  # noqa: E402

DESTINO = IEEE / "paquete_t19"
MARCA = ".paquete_t19"
COMMIT = "303d4b3"
INCLUIR_DEL_CODIGO = ("ecg", "examples", "tools", "tests", "docs", "images", ".github", "setup.sh", "descargar_datos_2020.sh", "descargar_challenge2021.sh", "requirements.txt",
                      "requirements-cuda.txt", "requirements-dev.txt", "constraints.txt", "README.md", "CONTEXT.md", "CONSTRAINTS.md", "CITATION.cff", "LICENSE", ".gitignore")
                                                                       # lista cerrada: quedan fuera la aplicación web y sus pesos (otro entrenamiento, no intervienen en los resultados) y los archivos de trabajo
ARCHIVOS_DE_EVALUACION = ("predictions_test.csv", "predictions_validation.csv", "thresholds_validation.csv", "metrics_global.csv", "metrics_per_class.csv",
                          "evaluation_summary.json", "platt_validation.csv", "platt_ensemble_validation.csv", "calibration_report_platt.json",
                          "temperatures_validation.csv", "calibration_report.json")
ARCHIVOS_DE_ENTRENAMIENTO = ("best.pt", "training_summary.json", "history.csv", "config_used.json")
PAQUETES = ["numpy", "pandas", "scikit-learn", "scipy", "torch", "h5py", "matplotlib"]
COMANDOS = {
    "verificar": ["python verificar_paquete.py", "python verificar_paquete.py --completo"],
    "grupos": "python tools/make_patient_groups.py --ptbxl-database data/externo/ptbxl_database.csv --ptb-records data/externo/RECORDS",
    "reparto": ("python examples/cinc2020/build_datasets.py --data-dir dataset2020 --output-dir data/cinc2020_12_origen --holdout-origin georgia "
                "--groups-csv data/externo/patient_groups.csv --workers 8 --norm-mode physical --train-windows-max 4 --val-frac 0.15 --test-frac 0.15 --random-state 42"),
    "entrenar": "python -X utf8 -m ecg.train runs/t19/config/config_<experimento>.json -e <experimento>",
    "evaluar": "bash analisis/evaluar_t19.sh <1|2|3|6|7>",
    "descargar_externas": "bash descargar_challenge2021.sh && python tools/verificar_challenge2021.py",
    "construir_externas": "python examples/cinc2020/build_external_test.py --data-dir dataset2021/physionet.org/files/challenge-2021/1.0.3 --origin <chapman_shaoxing|ningbo> --output data/cinc2021_externo/<test_c|test_d>.h5 --workers 8 $(sed 's/^/--exclude-record /' protocolo/exclusiones_externa.txt)",
    "recalibracion_local": "T19_RAIZ=. T19_ENTRADAS=protocolo T19_RESULTADOS=resultados T19_SALIDA=regenerado python analisis/recalibracion_local.py",
    "analizar": "T19_RAIZ=. T19_ENTRADAS=protocolo T19_SALIDA=regenerado python analisis/analizar_t19.py --etapa <1|2|3|4|6|7>",
}


# Los documentos y los scripts de análisis se escribieron con las rutas del árbol de trabajo; en el paquete se reescriben a las del paquete.
RUTAS_A_PAQUETE = ((re.compile(r"tesis/scripts/(analizar_t19\.py|evaluar_t19\.sh|verificar_reparto_t19\.py|entrenar_e16\.sh|recalibracion_local\.py|duplicados_externa\.py|reparto_externo\.py|sistemas_congelados\.py|limitaciones_cpu\.py|limitaciones_gpu\.py|limitaciones_resumen_gpu\.py|casi_duplicados_externa\.py)"), r"analisis/\1"),
                   (re.compile(r"tesis/evidencia/(e13_recalibracion_local|limitaciones)/"), r"resultados/\1/"),
                   (re.compile(r"tesis/evidencia/(protocolo_externo_t19\w*|reparto_externo|exclusiones_externa|duplicados_externa|auditoria_externa\w*|cobertura_externa)(?=[.\"\s]|$)"), r"protocolo/\1"),
                   (re.compile(r"tesis/scripts/(calcular_t19\.py|armar_paquete_t19\.py)"), r"\1"),
                   (re.compile(r"tesis/evidencia/(t19_etapa\d)/"), r"resultados/\1/"),
                   (re.compile(r"tesis/paquete_t19/"), "paquete_t19/"))
PROHIBIDO = re.compile(r"(?<![A-Za-zÀ-ÿ])tesis(?![A-Za-zÀ-ÿ])|claude|anthropic", re.IGNORECASE)      # no debe quedar en lo que se publica
SIN_REVISAR = ("runs", "saved", "data")                                                                    # predicciones, pesos y reparto: datos, no texto


def sha256(ruta: Path) -> str:
    h = hashlib.sha256()
    with ruta.open("rb") as fh:
        for bloque in iter(lambda: fh.read(1 << 22), b""):
            h.update(bloque)
    return h.hexdigest()


def git(*args: str) -> str:
    return subprocess.run(["git", *args], cwd=REPO, check=True, capture_output=True, text=True).stdout.strip()


def comprobar_codigo() -> str:
    """El código del paquete sale de ``git archive`` del commit del experimento, así que HEAD puede haber avanzado: solo hace falta que el commit exista."""
    try:
        return git("rev-parse", "--verify", f"{COMMIT}^{{commit}}")
    except subprocess.CalledProcessError:
        sys.exit(f"el commit {COMMIT} del experimento no existe en este repositorio")


def commit_del_codigo() -> str:
    """El código del paquete es el del repositorio publicado (rama principal en GitHub): añade al del experimento el constructor de HDF5 externos y la descarga y verificación de Challenge 2021."""
    head = git("rev-parse", "HEAD")
    try:
        git("fetch", "origin", "main", "--quiet")
        git("merge-base", "--is-ancestor", head, "origin/main")
    except subprocess.CalledProcessError:
        sys.exit("el commit actual no está en origin/main: el código del paquete debe ser el publicado")
    return head


def copiar(origen: Path, destino: Path) -> None:
    destino.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(origen, destino)


def limpiar_rutas() -> None:
    """Reescribe a rutas del paquete las de los documentos y scripts copiados; no toca un archivo sin coincidencias (el protocolo conserva su hash)."""
    for ruta in [*DESTINO.glob("protocolo/*.md"), *DESTINO.glob("analisis/*")]:
        original = ruta.read_text(encoding="utf-8")
        nuevo = original
        for patron, sustituto in RUTAS_A_PAQUETE:
            nuevo = patron.sub(sustituto, nuevo)
        if nuevo != original:
            ruta.write_text(nuevo, encoding="utf-8", newline="\n")


def comprobar_limpieza() -> None:
    hallazgos = []
    for ruta in sorted(DESTINO.rglob("*")):
        relativa = ruta.relative_to(DESTINO)
        if ruta.is_file() and relativa.parts[0] not in SIN_REVISAR and ruta.suffix in (".md", ".py", ".sh", ".json", ".csv", ".txt", ".cff", ".yml", ".html", ".tex", ""):
            hallazgos += [f"{relativa.as_posix()}:{n}" for n, linea in enumerate(ruta.read_text(encoding="utf-8", errors="ignore").splitlines(), 1) if PROHIBIDO.search(linea)]
    if hallazgos:
        sys.exit("quedan menciones que no deben publicarse:\n  " + "\n  ".join(hallazgos[:20]))


def copiar_codigo(commit: str) -> None:
    proc = subprocess.Popen(["git", "archive", "--format=tar", commit, "--", *INCLUIR_DEL_CODIGO], cwd=REPO, stdout=subprocess.PIPE)
    with tarfile.open(fileobj=proc.stdout, mode="r|") as tar:
        tar.extractall(DESTINO, filter="data")
    if proc.wait() != 0:
        sys.exit("git archive falló")


def copiar_artefactos(con_pesos: bool) -> dict:
    eval_dirs = sorted(p for p in (REPO / "runs" / "t19" / "eval").iterdir() if p.is_dir())
    for d in eval_dirs:
        for nombre in ARCHIVOS_DE_EVALUACION:
            if (d / nombre).is_file():
                copiar(d / nombre, DESTINO / "runs" / "t19" / "eval" / d.name / nombre)
    for c in sorted((REPO / "runs" / "t19" / "config").glob("*.json")):
        copiar(c, DESTINO / "runs" / "t19" / "config" / c.name)
    for r in sorted((REPO / "runs" / "t19" / "robustez").glob("*.csv")):
        copiar(r, DESTINO / "runs" / "t19" / "robustez" / r.name)
    experimentos = sorted(p.name for p in (REPO / "saved" / "t19").iterdir() if p.is_dir())
    for exp in experimentos:
        corridas = [p for p in (REPO / "saved" / "t19" / exp).iterdir() if p.is_dir()]
        assert len(corridas) == 1, f"saved/t19/{exp} debe tener una sola corrida"
        for nombre in ARCHIVOS_DE_ENTRENAMIENTO:
            if nombre == "best.pt" and not con_pesos:
                continue
            copiar(corridas[0] / nombre, DESTINO / "saved" / "t19" / exp / corridas[0].name / nombre)
    copiar(REPO / "data" / "cinc2020_12_origen" / "split_assignments.csv", DESTINO / "data" / "cinc2020_12_origen" / "split_assignments.csv")
    copiar(REPO / "data" / "externo" / "patient_groups.csv", DESTINO / "data" / "externo" / "patient_groups.csv")
    for nombre in ("protocolo_t19.md", "protocolo_t19.sha256", "protocolo_t19_desviaciones.md", "protocolo_t19_registro.md", "reparto_t19.json", "cobertura_etiquetas.csv"):
        copiar(EV / nombre, DESTINO / "protocolo" / nombre)
    for etapa in (1, 2, 3, 4, 6, 7):
        for f in sorted((EV / f"t19_etapa{etapa}").iterdir()):
            copiar(f, DESTINO / "resultados" / f"t19_etapa{etapa}" / f.name)
    for f in sorted((EV / "e13_recalibracion_local").iterdir()):
        copiar(f, DESTINO / "resultados" / "e13_recalibracion_local" / f.name)
    for f in sorted((EV / "limitaciones").iterdir()):
        copiar(f, DESTINO / "resultados" / "limitaciones" / f.name)
    for nombre in ("protocolo_externo_t19.md", "protocolo_externo_t19.sha256", "protocolo_externo_t19_registro.md", "protocolo_externo_t19_desviaciones.md",
                   "protocolo_externo_t19_sistemas.csv", "reparto_externo.json", "exclusiones_externa.txt", "duplicados_externa.csv", "duplicados_externa.json",
                   "auditoria_externa.csv", "auditoria_externa.json", "auditoria_externa_codigos.csv", "cobertura_externa.csv", "cobertura_externa.json"):
        copiar(EV / nombre, DESTINO / "protocolo" / nombre)
    for origen in ("test_c", "test_d"):                                          # el manifiesto por registro y el resumen; los HDF5 no se redistribuyen
        for sufijo in (".h5.records.csv", ".h5.summary.json"):
            copiar(REPO / "data" / "cinc2021_externo" / f"{origen}{sufijo}", DESTINO / "data" / "cinc2021_externo" / f"{origen}{sufijo}")
    for nombre in ("cifras_t19.csv", "matriz_confusion_A.csv", "matriz_confusion_B.csv"):
        copiar(EV / nombre, DESTINO / "resultados" / nombre)
    for nombre in ("analizar_t19.py", "evaluar_t19.sh", "verificar_reparto_t19.py", "entrenar_e16.sh", "recalibracion_local.py", "duplicados_externa.py", "reparto_externo.py", "sistemas_congelados.py",
                   "limitaciones_cpu.py", "limitaciones_gpu.py", "limitaciones_resumen_gpu.py", "casi_duplicados_externa.py"):
        copiar(SCRIPTS / nombre, DESTINO / "analisis" / nombre)
    copiar(SCRIPTS / "paquete_t19_verificar.py", DESTINO / "verificar_paquete.py")
    return {"experimentos": experimentos, "sistemas_evaluados": sorted(d.name for d in eval_dirs if d.name.endswith(("_A", "_B"))),
            "sistemas_externos": sorted(d.name for d in eval_dirs if d.name.endswith(("_C", "_D")))}


def entorno() -> dict:
    info = {"python": sys.version.split()[0], "plataforma": platform.platform(), **{p: metadata.version(p) for p in PAQUETES}}
    try:
        import torch
        info["cuda_de_torch"] = torch.version.cuda
        info["gpu_del_entrenamiento"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    except Exception as e:                                       # el paquete se arma aunque no haya GPU en este momento
        info["gpu_del_entrenamiento"] = f"no disponible al armar el paquete ({type(e).__name__})"
    return info


def registro_de(h: str, texto: str) -> str:
    return "completo" if h in texto else "abreviado" if h[:8] in texto else "no registrado"


def estado_de_hashes() -> dict:
    """Cuántos de los hashes de los archivos clave aparecen en el registro previo (completos, abreviados) y cuántos no."""
    texto = "".join((EV / n).read_text(encoding="utf-8") for n in ("protocolo_t19_registro.md", "protocolo_externo_t19_registro.md"))
    categorias = {"predicciones de prueba": sorted(DESTINO.glob("runs/t19/eval/*_[ABCD]/predictions_test.csv")),
                  "pesos (best.pt)": sorted(DESTINO.glob("saved/t19/*/*/best.pt")),
                  "configuraciones": sorted(DESTINO.glob("runs/t19/config/config_t19_*.json")),
                  "calibraciones": sorted(DESTINO.glob("runs/t19/eval/*/platt_*validation.csv")) + sorted(DESTINO.glob("runs/t19/eval/*/temperatures_validation.csv")),
                  "umbrales": sorted(DESTINO.glob("runs/t19/eval/*_A/thresholds_validation.csv")),
                  "robustez": sorted(DESTINO.glob("runs/t19/robustez/*.csv"))}
    salida = {}
    for nombre, rutas in categorias.items():
        cuentas = {"completo": 0, "abreviado": 0, "no registrado": 0}
        for r in rutas:
            cuentas[registro_de(sha256(r), texto)] += 1
        salida[nombre] = {"archivos": len(rutas), **cuentas}
    return salida


def comprobar_predicciones() -> None:
    for clave, esperado in a19.SHA256.items():
        sistema, prueba = clave.rsplit("_", 1)
        ruta = DESTINO / "runs" / "t19" / "eval" / f"{sistema.lower()}_{prueba}" / "predictions_test.csv"
        if sha256(ruta) != esperado:
            sys.exit(f"{ruta} no coincide con el SHA-256 registrado de {clave}")
    for clave, esperado in a19.SHA256_EXT.items():
        sistema, prueba = clave.rsplit("_", 1)
        ruta = DESTINO / "runs" / "t19" / "eval" / f"{sistema.lower()}_{prueba}" / "predictions_test.csv"
        if sha256(ruta) != esperado:
            sys.exit(f"{ruta} no coincide con el SHA-256 registrado de {clave}")


def tabla_de_resultados() -> str:
    g = pd.read_csv(DESTINO / "resultados" / "t19_etapa1" / "metricas_globales.csv").query("subconjunto == 'completa'")
    filas = ["| Sistema | Prueba | F1 macro (IC 95 %) | AUROC macro |", "|---|---|---|---|"]
    for s, nombre in (("P1", "P1 (ResNet v1)"), ("P2", "P2 (ResNet v2)"), ("P3", "P3 (ensemble, principal)")):
        for prueba, p in (("A", "A (n = 4 949)"), ("B", "B, Georgia (n = 10 344)")):
            f1 = g[(g.sistema == s) & (g.prueba == prueba) & (g.metrica == "f1_macro")].iloc[0]
            au = g[(g.sistema == s) & (g.prueba == prueba) & (g.metrica == "auroc_macro")].iloc[0]
            filas.append(f"| {nombre} | {p} | {f1.valor:.3f} ({f1.lo:.3f} a {f1.hi:.3f}) | {au.valor:.3f} |")
    g7 = pd.read_csv(DESTINO / "resultados" / "t19_etapa7" / "metricas_globales.csv").query("subconjunto == 'completa' and sistema == 'P3'")
    for prueba, nombre in (("C", "Chapman-Shaoxing, C (n = 10 234; 11 clases evaluables)"), ("D", "Ningbo, D (n = 34 830; 12 clases)")):
        f1 = g7[(g7.prueba == prueba) & (g7.metrica == "f1_macro")].iloc[0]
        au = g7[(g7.prueba == prueba) & (g7.metrica == "auroc_macro")].iloc[0]
        filas.append(f"| P3 (ensemble, principal) | **Externa** {nombre} | {f1.valor:.3f} ({f1.lo:.3f} a {f1.hi:.3f}) | {au.valor:.3f} |")
    return "\n".join(filas)


def escribir_documentos(datos: dict, completo: str, con_pesos: bool, codigo: str) -> None:
    ahora = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    for nombre, destino in (("paquete_t19_leeme.md", "LEEME.md"), ("paquete_t19_licencia.md", "LICENCIA.md")):
        t = (SCRIPTS / nombre).read_text(encoding="utf-8")
        for token, valor in {"@@COMMIT@@": completo, "@@CODIGO@@": codigo, "@@N_EXTERNOS@@": str(len(datos["sistemas_externos"]) // 2), "@@FECHA@@": ahora, "@@RESULTADOS@@": tabla_de_resultados(),
                             "@@EXPERIMENTOS@@": " ".join(datos["experimentos"]), "@@N_SISTEMAS@@": str(len(datos["sistemas_evaluados"]) // 2),
                             "@@PESOS@@": f"incluidos en `saved/t19/` ({len(datos['experimentos'])} archivos `best.pt`)" if con_pesos else "no incluidos (`--sin-pesos`); sus SHA-256 están en `protocolo/protocolo_t19_registro.md`"}.items():
            t = t.replace(token, valor)
        (DESTINO / destino).write_text(t, encoding="utf-8", newline="\n")


def escribir_manifiesto(datos: dict, completo: str, hashes: dict, codigo: str) -> None:
    configs = {c.name: json.loads(c.read_text(encoding="utf-8")) for c in sorted((DESTINO / "runs" / "t19" / "config").glob("config_t19_*.json")) if "_testb" not in c.name}
    manifiesto = {
        "generado_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "commit_del_experimento": completo, "commit_del_codigo": codigo, "rama": git("rev-parse", "--abbrev-ref", "HEAD"), "publicado": False,
        "head_al_armar": git("rev-parse", "HEAD"),
        "codigo_cambiado_desde_el_experimento": git("diff", "--name-only", COMMIT, codigo, "--", "ecg", "examples", "tools", "tests", "constraints.txt", "requirements.txt", "descargar_challenge2021.sh").splitlines(),
        "entorno": entorno(), "experimentos": datos["experimentos"],
        "semillas": {"reparto": 42, "bootstrap": a19.SEMILLA, "remuestreos": a19.REMUESTREOS,
                     "entrenamiento": {n: {"seed": c.get("seed"), "aug_seed": c.get("aug_seed")} for n, c in configs.items()}},
        "hashes_frente_al_registro_previo": hashes,
        "entradas_externas_no_incluidas": {
            "dataset2020/": "PhysioNet/CinC Challenge 2020 v1.0.2, subconjuntos de training/ (descargar_datos_2020.sh)",
            "data/externo/ptbxl_database.csv": {"origen": "PTB-XL 1.0.3 (PhysioNet)", "sha256": sha256(REPO / "data" / "externo" / "ptbxl_database.csv")},
            "data/externo/RECORDS": {"origen": "PTB 1.0.0 (PhysioNet)", "sha256": sha256(REPO / "data" / "externo" / "RECORDS")}},
        "comandos": COMANDOS,
    }
    (DESTINO / "manifiesto.json").write_text(json.dumps(manifiesto, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")


def escribir_sumas() -> int:
    archivos = sorted(p for p in DESTINO.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt" and "__pycache__" not in p.parts)
    lineas = [f"{sha256(p)}  {p.relative_to(DESTINO).as_posix()}" for p in archivos]
    (DESTINO / "SHA256SUMS.txt").write_text("\n".join(lineas) + "\n", encoding="utf-8", newline="\n")
    return len(lineas)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--sin-pesos", action="store_true", help="no copiar los best.pt (unos 1 000 MB)")
    parser.add_argument("--rehacer", action="store_true", help="borrar un paquete anterior de este script y armarlo de nuevo")
    args = parser.parse_args()
    completo = comprobar_codigo()
    codigo = commit_del_codigo()
    if DESTINO.exists() and any(DESTINO.iterdir()):
        if not (args.rehacer and (DESTINO / MARCA).exists()):
            sys.exit(f"{DESTINO} ya existe; usa --rehacer para borrarlo (solo se borra si lo armó este script)")
        shutil.rmtree(DESTINO, onerror=lambda f, ruta, _: (os.chmod(ruta, stat.S_IWRITE), f(ruta)))      # en Windows los archivos de solo lectura impiden borrar
    DESTINO.mkdir(parents=True, exist_ok=True)
    (DESTINO / MARCA).write_text("Paquete armado por armar_paquete_t19.py; se puede borrar y rehacer.\n", encoding="utf-8", newline="\n")
    copiar_codigo(codigo)
    datos = copiar_artefactos(not args.sin_pesos)
    limpiar_rutas()
    comprobar_predicciones()
    hashes = estado_de_hashes()
    escribir_documentos(datos, completo, not args.sin_pesos, codigo)
    escribir_manifiesto(datos, completo, hashes, codigo)
    comprobar_limpieza()
    n = escribir_sumas()
    print(f"paquete en {DESTINO}: {n} archivos, {len(datos['sistemas_evaluados']) // 2} sistemas en A y B y {len(datos['sistemas_externos']) // 2} en C y D, experimento {completo[:7]}, código {codigo[:7]}")
    print("hashes frente al registro previo:", json.dumps(hashes, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
