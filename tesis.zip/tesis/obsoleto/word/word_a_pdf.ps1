# Exporta un .docx a PDF con el propio Word (automatización COM), para ver cómo lo pagina. Uso:
#   powershell -NoProfile -ExecutionPolicy Bypass -File tesis/ieee/scripts/word_a_pdf.ps1 -Docx <ruta absoluta .docx> -Pdf <ruta absoluta .pdf>
# Imprime «paginas: N» y «exportado: True». Se usa ExportAsFixedFormat: SaveAs2 a PDF se cuelga en algunas instalaciones.
param([string]$Docx, [string]$Pdf)
$ErrorActionPreference = "Stop"
if (Test-Path $Pdf) { Remove-Item $Pdf -Force }
$w = New-Object -ComObject Word.Application
$w.Visible = $false
$w.DisplayAlerts = 0
try {
  $d = $w.Documents.Open($Docx, $false, $true)
  $d.Repaginate()
  "paginas: " + $d.ComputeStatistics(2)
  $d.ExportAsFixedFormat($Pdf, 17)
  $d.Close($false)
  "exportado: " + (Test-Path $Pdf)
} catch { "ERROR: " + $_.Exception.Message }
finally { $w.Quit() }
