"""Busca dónde colocar cada tabla y figura ancha del Word (articulo_ieee.docx) para que no queden huecos en las páginas.

En LaTeX esos elementos (table*, figure*) flotan arriba de la página; en Word, sin motor de flotantes, rompen las columnas con un salto
de sección y, si no caben en lo que queda de la página, pasan a la siguiente y dejan un hueco. Este script, para cada uno en orden,
prueba desplazarlo uno, dos... párrafos antes o después de donde está en la fuente; reconstruye el Word, lo exporta a PDF con el propio
Word (word_a_pdf.ps1), mide el hueco al pie de las columnas de las páginas vecinas y se queda con el primer desplazamiento que no deja
un hueco mayor de HUECO_MAX_PT (o el mejor que encuentre). Escribe scripts/flotantes.json, que hacer_docx.py lee.

Necesita Word instalado en Windows. Tarda unos minutos (una exportación por intento). Uso, desde la raíz del repositorio:
    python tesis/ieee/scripts/ajustar_flotantes.py [--rehacer]
Sin --rehacer conserva lo ya decidido en flotantes.json y solo resuelve lo que falte. Con --rehacer empieza de cero: úsese si cambia el
texto o el tamaño de las tablas, porque el resultado depende de la paginación de Word.
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
import unicodedata
from pathlib import Path

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
import hacer_docx as hd  # noqa: E402

TRABAJO = hd.IEEE / "evidencia" / "vistas" / "ajuste"             # carpeta ignorada por git (evidencia/vistas/)
PS1 = Path(__file__).with_name("word_a_pdf.ps1")
DPI = 40
BORDE_INFERIOR_PT = 72                                             # margen inferior de la plantilla: 25.4 mm
HUECO_MAX_PT = 40                                                  # unas tres líneas
INTENTOS = [0, 1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6, 8, -8, 10, -10, 12, -12]


def exportar(docx: Path, pdf: Path) -> None:
    r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(PS1), "-Docx", str(docx), "-Pdf", str(pdf)],
                       capture_output=True, text=True, timeout=180)
    if "exportado: True" not in r.stdout:
        sys.exit(f"Word no exportó el PDF:\n{r.stdout}\n{r.stderr}")


def normalizar(s: str) -> str:
    """Sin acentos, en mayúsculas y con los espacios unificados: el PDF de Word puede separar las tildes de sus letras."""
    sin = "".join(c for c in unicodedata.normalize("NFD", s) if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", sin).upper()


def paginas(pdf: Path) -> list[str]:
    texto = subprocess.run(["pdftotext", "-enc", "UTF-8", "-layout", str(pdf), "-"], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout
    return [normalizar(p) for p in texto.split("\f")[:-1]]


def huecos(pdf: Path) -> list[float]:
    """Hueco (pt) al pie de cada página: el mayor de los de sus dos mitades. La última página no cuenta."""
    base = TRABAJO / "p"
    subprocess.run(["pdftoppm", "-r", str(DPI), "-png", str(pdf), str(base)], check=True, capture_output=True)
    out = []
    archivos = sorted(TRABAJO.glob("p-*.png"), key=lambda p: int(p.stem.split("-")[1]))
    for f in archivos:
        im = Image.open(f).convert("L")
        w, h = im.size
        limite = h - BORDE_INFERIOR_PT * DPI / 72
        peor = 0.0
        for x0, x1 in ((0, w // 2), (w // 2, w)):
            mitad = im.crop((x0, 0, x1, int(limite)))
            caja = mitad.point(lambda v: 255 if v < 200 else 0).getbbox()
            peor = max(peor, (limite - (caja[3] if caja else 0)) * 72 / DPI)
        out.append(peor)
        f.unlink()
    out[-1] = 0.0
    return out


def pagina_de(textos: list[str], clave: str) -> int | None:
    return next((i for i, t in enumerate(textos) if normalizar(clave) in t), None)


def main() -> int:
    TRABAJO.mkdir(parents=True, exist_ok=True)
    desplazamientos = json.loads(hd.FLOTANTES.read_text(encoding="utf-8")) if hd.FLOTANTES.exists() else {}
    prueba, pdf = TRABAJO / "prueba.docx", TRABAJO / "prueba.pdf"
    claves = hd.construir({}, prueba)                              # una pasada para conocer las tablas y figuras anchas y su orden
    rehacer = "--rehacer" in sys.argv
    if rehacer:
        desplazamientos = {}
    for etiqueta in claves:
        if etiqueta in desplazamientos:                            # ya decidida en una corrida anterior (las posteriores no cambian las páginas previas)
            continue
        mejor = None
        for off in INTENTOS:
            desplazamientos[etiqueta] = off
            hd.construir(desplazamientos, prueba)
            exportar(prueba, pdf)
            textos, g = paginas(pdf), huecos(pdf)
            p = pagina_de(textos, claves[etiqueta])
            if p is None:
                print(f"  {etiqueta}: no se encontró su leyenda en el PDF ({claves[etiqueta]!r})")
                continue
            local = max(g[i] for i in (p - 1, p, p + 1) if 0 <= i < len(g))
            print(f"  {etiqueta}: desplazamiento {off:+d} -> página {p + 1}, hueco {local:.0f} pt, {len(g)} páginas")
            if mejor is None or local < mejor[0]:
                mejor = (local, off)
            if local <= HUECO_MAX_PT:
                break
        desplazamientos[etiqueta] = mejor[1] if mejor else 0
        print(f"{etiqueta}: se queda con {desplazamientos[etiqueta]:+d}" + (f" (hueco {mejor[0]:.0f} pt)" if mejor else ""))
    hd.FLOTANTES.write_text(json.dumps(dict(sorted(desplazamientos.items())), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    hd.construir(desplazamientos)
    print(f"escrito {hd.FLOTANTES.relative_to(hd.IEEE.parents[1])} y {hd.SALIDA.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
