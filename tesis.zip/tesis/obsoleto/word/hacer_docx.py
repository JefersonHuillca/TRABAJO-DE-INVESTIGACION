"""Genera tesis/ieee/articulo_ieee.docx: el mismo artículo de main.tex en la plantilla Word de formato IEEE de la Escuela.

Lee las fuentes LaTeX (capitulos/*.tex), sustituye cada \\cf{ID} por su cifra (las mismas cifras y el mismo redondeo que el PDF),
numera secciones, tablas, figuras, ecuaciones y citas como lo hace IEEEtran, y escribe el Word con el formato de la plantilla
(plantilla/Formato IEEE.docx): Times New Roman, cuerpo de 9 pt, tablas y leyendas de 8 pt, dos columnas, carta, sin encabezado ni
número de página. Conserva de la plantilla sus estilos, su tema y su configuración; reemplaza el contenido.

Subconjunto de LaTeX que entiende: las órdenes que usa el artículo (ver ORDENES_IGNORADAS y el despacho de inline()). Si aparece una
orden desconocida se avisa por pantalla; no se descarta en silencio.

Uso, desde la raíz del repositorio:  python tesis/ieee/scripts/hacer_docx.py
"""

from __future__ import annotations

import csv
import json
import re
import shutil
import subprocess
import sys
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass, replace
from pathlib import Path
from xml.sax.saxutils import escape

from PIL import Image, ImageFont

IEEE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(IEEE.parent / "completa" / "scripts"))
from extraer_cifras import con_signo, natural  # noqa: E402

PLANTILLA = IEEE / "plantilla" / "Formato IEEE.docx"
SALIDA = IEEE / "articulo_ieee.docx"
FLOTANTES = IEEE / "scripts" / "flotantes.json"                    # desplazamiento de cada tabla o figura ancha (lo escribe ajustar_flotantes.py)
PNG = IEEE / "figuras" / "png"
FUENTES = ["01_introduccion", "01b_relacionados", "02_metodos", "03_resultados", "04_discusion", "05_conclusiones", "05b_apendice", "06_declaraciones"]
TITULO = "Clasificación Multietiqueta de Electrocardiogramas de 12 Derivaciones con Redes Residuales 1D Calibradas"
AUTORES = "Jefferson Junior Huillca Nuñez y Juergen Patrick Diaz Velarde"
AFILIACION = ["Escuela Profesional de Ingeniería Electrónica, Facultad de Ingeniería de Producción y Servicios, Universidad Nacional de San Agustín de Arequipa",
              "Arequipa, Perú", "Asesor: German Alberto Echaiz Espinoza"]

# --- geometría de la plantilla (carta; márgenes y separación entre columnas de la sección III.A de la plantilla), en twips
PAG_W, PAG_H = 12240, 15840
MARG_SUP, MARG_INF, MARG_LAT, ESPACIO = 1077, 1440, 981, 239
ANCHO_TEXTO = PAG_W - 2 * MARG_LAT
ANCHO_COL = (ANCHO_TEXTO - ESPACIO) // 2
EMU_POR_TWIP = 635

SZ_CUERPO, SZ_TABLA, SZ_SUBT, SZ_TIT = 18, 16, 20, 48          # medios puntos: 9, 8, 10 y 24 pt
NBSP, FINA = "\u00a0", "\u00a0"                                  # espacio fino de los miles: espacio duro (la fuente lo tiene)
ORDENES_IGNORADAS = {"centering", "footnotesize", "scriptsize", "smallskip", "par", "noindent", "label", "hline", "relax", "newblock",
                     "BIBentryALTinterwordspacing", "BIBentrySTDinterwordspacing", "selectlanguage", "pagestyle", "thispagestyle", "textwidth"}
FUENTE_TNR = Path("C:/Windows/Fonts/times.ttf")                   # para medir el texto de las tablas; si falta, se estima por car\u00e1cter
FUENTES_DEPENDIENTES = [IEEE / "figuras" / "tikz" / "d_arquitectura.tex", IEEE / "capitulos" / "cifras.tex", IEEE / "capitulos" / "cifras_extra.tex"]

CIF: dict[str, tuple[float, str]] = {}
ETIQUETAS: dict[str, str] = {}
CITAS: dict[str, int] = {}
AVISOS: set[str] = set()


@dataclass(frozen=True)
class R:
    """Un tramo de texto con su formato."""
    t: str
    b: bool = False
    i: bool = False
    sup: bool = False
    sub: bool = False
    mono: bool = False
    rojo: bool = False


# --------------------------------------------------------------------------- lectura de cifras y de la bibliografía
def cargar_cifras() -> None:
    for nombre in ("cifras.csv", "cifras_extra.csv"):
        with (IEEE / "evidencia" / nombre).open(encoding="utf-8", newline="") as fh:
            for fila in csv.DictReader(fh):
                CIF[fila["id"]] = (float(fila["valor"]), fila["unidad"])


def expandir_cifras(t: str) -> str:
    def sustituye(m: re.Match) -> str:
        valor, unidad = CIF[m.group(2)]
        return natural(valor, unidad) if m.group(1) == "cf" else con_signo(valor, unidad)
    return re.sub(r"\\(cfs?)\{([A-Za-z0-9]+)\}", sustituye, t)


def sin_comentarios(t: str) -> str:
    return re.sub(r"(?<!\\)%.*", "", t)


def romano(n: int) -> str:
    out = ""
    for v, s in ((10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")):
        while n >= v:
            out, n = out + s, n - v
    return out


# --------------------------------------------------------------------------- análisis de LaTeX en línea
ACENTOS = {"'": "\u0301", "`": "\u0300", '"': "\u0308", "^": "\u0302", "~": "\u0303"}
GRIEGO = {"alpha": "α", "beta": "β", "varepsilon": "ε", "epsilon": "ε", "sigma": "σ", "tau": "τ", "mu": "μ", "lambda": "λ"}
SIMBOLOS = {"times": "×", "cdot": "·", "ge": "≥", "geq": "≥", "le": "≤", "leq": "≤", "approx": "≈", "pm": "±", "sum": "Σ", "ldots": "…", "cdots": "…"}
FUNCIONES = {"log", "ln", "arg", "max", "min", "exp"}


def grupo(s: str, i: int) -> tuple[str, int]:
    """Lee un argumento entre llaves que empieza en s[i] (tras espacios). Devuelve (contenido, índice siguiente)."""
    while i < len(s) and s[i] in " \n\t":
        i += 1
    if i >= len(s) or s[i] != "{":
        raise ValueError(f"se esperaba '{{' en «{s[max(0, i - 30):i + 30]}»")
    prof, j = 0, i
    while j < len(s):
        c = s[j]
        if c == "\\":
            j += 2
            continue
        if c == "{":
            prof += 1
        elif c == "}":
            prof -= 1
            if prof == 0:
                return s[i + 1:j], j + 1
        j += 1
    raise ValueError("llave sin cerrar")


def fusionar(runs: list[R]) -> list[R]:
    out: list[R] = []
    for r in runs:
        if not r.t:
            continue
        if out and replace(out[-1], t="") == replace(r, t=""):
            out[-1] = replace(out[-1], t=out[-1].t + r.t)
        else:
            out.append(r)
    return out


def acento(s: str, i: int) -> tuple[str, int]:
    """Orden de acento \\' \\` \\\" \\^ \\~ en s[i] (la barra ya está en s[i-1]); devuelve (carácter acentuado, índice siguiente)."""
    marca = ACENTOS[s[i]]
    j = i + 1
    if s[j] == "{":
        base, j = grupo(s, j)
    elif s[j] == "\\":
        m = re.match(r"\\([A-Za-z]+)", s[j:])
        base, j = ("i" if m.group(1) == "i" else m.group(1)), j + m.end()
    else:
        base, j = s[j], j + 1
    base = base.strip("{}")
    return unicodedata.normalize("NFC", base[:1] + marca) + base[1:], j


def matematica(s: str, st: R) -> list[R]:
    """Fórmulas: letras en cursiva, números y funciones rectos, sub y superíndices, griegas y fracciones lineales."""
    out: list[R] = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == "\\":
            m = re.match(r"\\([A-Za-z]+)", s[i:])
            if m:
                n, j = m.group(1), i + m.end()
                if n in GRIEGO:
                    out.append(replace(st, t=GRIEGO[n], i=True))
                elif n in SIMBOLOS:
                    out.append(replace(st, t=SIMBOLOS[n]))
                elif n in FUNCIONES:
                    out.append(replace(st, t=n + FINA))
                elif n in ("hat", "bar", "tilde"):
                    a, j = grupo(s, j)
                    marca = {"hat": "\u0302", "bar": "\u0304", "tilde": "\u0303"}[n]
                    out += [replace(st, t=ch + marca, i=True) for ch in a]
                elif n in ("operatorname", "mathrm", "text"):
                    a, j = grupo(s, j)
                    out.append(replace(st, t=a))
                elif n == "mathcal":
                    a, j = grupo(s, j)
                    out.append(replace(st, t=a, i=True))
                elif n == "frac":
                    a, j = grupo(s, j)
                    b, j = grupo(s, j)
                    den = matematica(b, st)
                    par = len("".join(r.t for r in den)) > 1             # el denominador de un solo signo no lleva paréntesis
                    out += matematica(a, st) + [replace(st, t="/" + ("(" if par else ""))] + den + ([replace(st, t=")")] if par else [])
                elif n in ("qquad", "quad"):
                    out.append(replace(st, t=NBSP * 3))
                elif n in ("left", "right", "Big", "big", "Bigg", "bigg"):
                    pass
                elif n == "ensuremath":
                    a, j = grupo(s, j)
                    out += matematica(a, st)
                else:
                    AVISOS.add(f"orden matemática no soportada: \\{n}")
                i = j
                continue
            nxt = s[i + 1]
            out.append(replace(st, t={",": FINA, ";": " ", "!": "", "{": "{", "}": "}", "|": "|"}.get(nxt, nxt)))
            i += 2
            continue
        if c in "_^":
            if s[i + 1] == "{":
                a, j = grupo(s, i + 1)
            elif s[i + 1] == "\\":                                  # F_\beta: el argumento es la orden completa
                m = re.match(r"\\([A-Za-z]+|.)", s[i + 1:])
                a, j = m.group(0), i + 1 + m.end()
            else:
                a, j = s[i + 1], i + 2
            marca = replace(st, sup=(c == "^"), sub=(c == "_"))
            out += matematica(a, marca)
            i = j
            continue
        if c == "{":
            a, j = grupo(s, i)
            out += matematica(a, st)
            i = j
            continue
        if c.isalpha():
            out.append(replace(st, t=c, i=True))
        elif c == "-":
            out.append(replace(st, t="−"))
        elif c == "'":
            out.append(replace(st, t="′"))
        elif c == " ":
            pass
        else:
            out.append(replace(st, t=c))
        i += 1
    return out


MENORES = {"a", "al", "de", "del", "el", "la", "las", "los", "en", "y", "o", "u", "e", "con", "por", "para", "sin", "sobre", "un", "una", "como",
           "desde", "frente", "ante", "entre", "hacia", "según"}


def mayusculas_iniciales(runs: list[R]) -> list[R]:
    """Regla de la plantilla para los subtítulos: cada palabra inicia con mayúscula, salvo las palabras menores (excepto la primera)."""
    primera = [True]

    def palabra(m: re.Match) -> str:
        w = m.group(0)
        if not primera[0] and w.lower() in MENORES:
            return w.lower()
        primera[0] = False
        return w if any(ch.isupper() for ch in w[1:]) else w[0].upper() + w[1:]
    return [replace(r, t=re.sub(r"[^\W\d_]+", palabra, r.t)) for r in runs]


def citas_texto(claves: list[str]) -> str:
    nums = sorted(CITAS[k] for k in claves)
    partes, k = [], 0
    while k < len(nums):
        j = k
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
            j += 1
        partes.append(f"[{nums[k]}]–[{nums[j]}]" if j - k >= 2 else ", ".join(f"[{n}]" for n in nums[k:j + 1]))
        k = j + 1
    return ", ".join(partes)


def inline(s: str, st: R | None = None) -> list[R]:
    """Texto con órdenes LaTeX en línea -> tramos con formato."""
    st = st or R("")
    out: list[R] = []
    buf: list[str] = []

    def vaciar() -> None:
        if buf:
            out.append(replace(st, t="".join(buf)))
            buf.clear()

    i = 0
    while i < len(s):
        c = s[i]
        if c == "\\":
            m = re.match(r"\\([A-Za-z]+\*?)", s[i:])
            if not m:
                nxt = s[i + 1]
                if nxt in ACENTOS:
                    txt, i = acento(s, i + 1)
                    buf.append(txt)
                    continue
                if nxt == "\\":
                    buf.append("\n")
                elif nxt == ",":
                    buf.append(FINA)
                elif nxt in "%&_#$":
                    buf.append(nxt)
                elif nxt in "{}":
                    buf.append(nxt)
                elif nxt in " ;":
                    buf.append(" ")
                elif nxt not in "!@/":
                    AVISOS.add(f"orden no soportada: \\{nxt}")
                i += 2
                continue
            n, j = m.group(1), i + m.end()
            if n in ("textit", "emph"):
                a, j = grupo(s, j)
                vaciar()
                out += inline(a, replace(st, i=True))
            elif n == "em":
                vaciar()
                out += inline(s[j:], replace(st, i=True))
                return fusionar(out)
            elif n == "textbf":
                a, j = grupo(s, j)
                vaciar()
                out += inline(a, replace(st, b=True))
            elif n in ("texttt", "url"):
                a, j = grupo(s, j)
                vaciar()
                out.append(replace(st, t=a.replace("\\_", "_").replace("\\%", "%"), mono=(n == "texttt")))   # las direcciones, en la fuente normal (plantilla)
            elif n == "textsuperscript":
                a, j = grupo(s, j)
                vaciar()
                out += inline(a, replace(st, sup=True))
            elif n == "ensuremath":
                a, j = grupo(s, j)
                vaciar()
                out += matematica(a, st)
            elif n == "cite":
                a, j = grupo(s, j)
                buf.append(citas_texto([k.strip() for k in a.split(",")]))
            elif n == "ref":
                a, j = grupo(s, j)
                buf.append(f"\x01{a}\x01")
            elif n == "TODO":
                a, j = grupo(s, j)
                vaciar()
                out.append(replace(st, t=f"[TODO: {a}]", b=True, rojo=True))
            elif n == "hskip":
                j += re.match(r"[^\\]*(\\relax)?", s[j:]).end()
                buf.append(" ")
            elif n in ORDENES_IGNORADAS:
                if n == "selectlanguage":
                    _, j = grupo(s, j)
            else:
                AVISOS.add(f"orden no soportada: \\{n}")
            i = j
            continue
        if c == "$":
            k = i + 1
            while s[k] != "$" or s[k - 1] == "\\":
                k += 1
            vaciar()
            out += matematica(s[i + 1:k], st)
            i = k + 1
            continue
        if c == "{":
            a, j = grupo(s, i)
            vaciar()
            out += inline(a, st)
            i = j
            continue
        if c == "}":
            i += 1
            continue
        if c == "~":
            buf.append(NBSP)
        elif s.startswith("---", i):
            buf.append("—")
            i += 2
        elif s.startswith("--", i):
            buf.append("–")
            i += 1
        elif s.startswith("``", i):
            buf.append("“")
            i += 1
        elif s.startswith("''", i):
            buf.append("”")
            i += 1
        elif c == "\n":
            buf.append(" ")
        else:
            buf.append(c)
        i += 1
    vaciar()
    out = fusionar(out)
    return [replace(r, t=re.sub(r" {2,}", " ", r.t)) for r in out]


# --------------------------------------------------------------------------- bloques
@dataclass
class Bloque:
    tipo: str                       # h1 h2 p eq lista fig tab ref abstract
    runs: list[R] | None = None
    datos: dict | None = None


class Contadores:
    sec = sub = subsub = fig = tab = eq = 0
    apendice = False
    pendiente_h3: list[R] | None = None


def registrar(etiqueta: str | None, numero: str) -> None:
    if etiqueta:
        ETIQUETAS[etiqueta] = numero


def parse_tabular(cuerpo: str) -> dict:
    spec, fin_spec = grupo(cuerpo, 0)
    resto = cuerpo[fin_spec:]
    cols, k = [], 0
    while k < len(spec):
        ch = spec[k]
        if ch in "lcr":
            cols.append((ch, None))
            k += 1
        elif ch == "p":
            ancho, k2 = grupo(spec, k + 1)
            cols.append(("l", float(ancho.replace("cm", ""))))
            k = k2
        elif ch == "@":
            _, k = grupo(spec, k + 1)
        else:
            k += 1
    filas, reglas = [], {}
    segmentos = re.split(r"(?<!\\)\\\\", resto)
    for idx, seg in enumerate(segmentos):
        seg = seg.strip()
        rs = []
        while True:
            mm = re.match(r"\\(toprule|midrule|bottomrule)\s*", seg)
            if mm:
                rs.append(mm.group(1))
                seg = seg[mm.end():]
                continue
            mm = re.match(r"\\cmidrule\([a-z]*\)\{(\d+)-(\d+)\}\s*", seg)
            if mm:
                rs.append(("cmid", int(mm.group(1)), int(mm.group(2))))
                seg = seg[mm.end():]
                continue
            break
        reglas[idx] = rs
        if not seg:
            continue
        celdas = []
        for cell in re.split(r"(?<!\\)&", seg):
            cell = cell.strip()
            mc = re.match(r"\\multicolumn\{(\d+)\}\{([lcr])\}\{(.*)\}$", cell, flags=re.S)
            if mc:
                celdas.append({"span": int(mc.group(1)), "al": mc.group(2), "runs": inline(mc.group(3))})
            else:
                celdas.append({"span": 1, "al": None, "runs": inline(cell)})
        filas.append((idx, celdas))
    return {"cols": cols, "filas": filas, "reglas": reglas}


def parse_entorno(nombre: str, cuerpo: str, c: Contadores) -> Bloque:
    etiqueta = (re.search(r"\\label\{([^}]+)\}", cuerpo) or [None, None])[1]
    if nombre.startswith("equation"):
        c.eq += 1
        registrar(etiqueta, str(c.eq))
        formula = re.sub(r"\\label\{[^}]*\}", "", cuerpo).strip()
        return Bloque("eq", None, {"num": c.eq, "tex": formula})
    if nombre.startswith(("figure",)):
        c.fig += 1
        registrar(etiqueta, str(c.fig))
        ancho = nombre.endswith("*")
        cap, _ = grupo(cuerpo, cuerpo.index("\\caption") + len("\\caption"))
        mi = re.search(r"\\includegraphics\[width=([0-9.]*)\\(textwidth|columnwidth)\]\{([^}]+)\}", cuerpo)
        if mi:
            ruta, rel = mi.group(3), float(mi.group(1) or 1)
        else:
            ruta, rel = "figuras/arquitectura", 1.0
        return Bloque("fig", inline(cap), {"num": c.fig, "ruta": ruta, "ancho": ancho, "rel": rel, "etiqueta": etiqueta})
    if nombre.startswith("table"):
        c.tab += 1
        registrar(etiqueta, romano(c.tab))
        ancho = nombre.endswith("*")
        cap, _ = grupo(cuerpo, cuerpo.index("\\caption") + len("\\caption"))
        ini = cuerpo.index("\\begin{tabular}") + len("\\begin{tabular}")
        fin = cuerpo.index("\\end{tabular}")
        tabla = parse_tabular(cuerpo[ini:fin])
        nota = cuerpo[fin + len("\\end{tabular}"):]
        nota = re.sub(r"\\(par|smallskip|footnotesize)\b", "", nota).strip()
        return Bloque("tab", inline(cap), {"num": c.tab, "ancho": ancho, "nota": inline(nota) if nota else None, "etiqueta": etiqueta, **tabla})
    if nombre == "enumerate":
        items = [x.strip() for x in re.split(r"\\item\b", cuerpo)[1:]]
        return Bloque("lista", None, {"items": [inline(x) for x in items]})
    raise ValueError(nombre)


ENTORNOS = r"(figure\*?|table\*?|equation|enumerate)"


def parse_fuente(texto: str, c: Contadores) -> list[Bloque]:
    bloques: list[Bloque] = []
    marcadores: list[Bloque] = []

    def guarda(m: re.Match) -> str:
        marcadores.append(parse_entorno(m.group(1), m.group(2), c))
        return f"\n\x02{len(marcadores) - 1}\x02\n"

    # los entornos se numeran en orden de aparición, así que se extraen antes de leer los encabezados que los preceden
    texto = re.sub(rf"\\begin\{{{ENTORNOS}\}}(.*?)\\end\{{\1\}}", guarda, texto, flags=re.S)
    texto = texto.replace("\\appendices", "\x03APENDICE\x03")
    for trozo in re.split(r"\n\s*\n", texto):
        trozo = trozo.strip()
        if not trozo:
            continue
        for parte in re.split(r"(\x02\d+\x02)", trozo):
            parte = parte.strip()
            if not parte:
                continue
            mk = re.fullmatch(r"\x02(\d+)\x02", parte)
            if mk:
                bloques.append(marcadores[int(mk.group(1))])
                continue
            if parte.startswith("\x03APENDICE\x03"):
                c.apendice, c.sec = True, 0
                parte = parte.replace("\x03APENDICE\x03", "").strip()
                if not parte:
                    continue
            mh = re.match(r"\\(section\*?|subsection|subsubsection)(?=\{)", parte)
            if mh:
                nivel = mh.group(1)
                titulo, k = grupo(parte, mh.end())
                resto = parte[k:]
                ml = re.match(r"\s*\\label\{([^}]+)\}", resto)
                etiqueta = ml.group(1) if ml else None
                resto = resto[ml.end():] if ml else resto
                runs = inline(titulo)
                if nivel == "section*":
                    bloques.append(Bloque("h1", [replace(r, t=r.t.upper()) for r in runs], {"num": None}))
                elif nivel == "section":
                    c.sec, c.sub, c.subsub = c.sec + 1, 0, 0
                    numero = f"APÉNDICE {chr(64 + c.sec)}" if c.apendice else romano(c.sec)
                    registrar(etiqueta, chr(64 + c.sec) if c.apendice else numero)
                    bloques.append(Bloque("h1", [replace(r, t=r.t.upper()) for r in runs], {"num": numero, "apendice": c.apendice}))
                elif nivel == "subsection":
                    c.sub, c.subsub = c.sub + 1, 0
                    letra = chr(64 + c.sub)
                    registrar(etiqueta, f"{romano(c.sec)}-{letra}" if not c.apendice else f"{chr(64 + c.sec)}-{letra}")
                    bloques.append(Bloque("h2", mayusculas_iniciales(runs), {"letra": letra}))
                else:
                    c.subsub += 1
                    registrar(etiqueta, f"{romano(c.sec)}-{chr(64 + c.sub)}{c.subsub}")
                    c.pendiente_h3 = [R(f"{c.subsub}) ", i=True)] + [replace(r, i=True) for r in mayusculas_iniciales(runs)] + [R(": ", i=True)]          # «1) Primer Nivel:» (plantilla)
                if resto.strip():
                    bloques.append(Bloque("p", inline(resto.strip()), {"h3": c.pendiente_h3, "cont": False}))
                    c.pendiente_h3 = None
                continue
            bloques.append(Bloque("p", inline(parte), {"h3": c.pendiente_h3, "cont": bool(bloques and bloques[-1].tipo == "eq")}))
            c.pendiente_h3 = None
    return bloques


# --------------------------------------------------------------------------- resumen y palabras clave
def parse_resumen(texto: str) -> list[Bloque]:
    bloques = []
    for k, m in enumerate(re.finditer(r"\\begin\{abstract\}(.*?)\\end\{abstract\}.*?\\begin\{IEEEkeywords\}(.*?)\\end\{IEEEkeywords\}", texto, flags=re.S)):
        etiqueta, claves = ("Resumen", "Palabras clave") if k == 0 else ("Abstract", "Index Terms")
        bloques.append(Bloque("abstract", inline(m.group(1).strip()), {"etiqueta": etiqueta}))
        bloques.append(Bloque("abstract", inline(m.group(2).strip()), {"etiqueta": claves, "claves": True}))
    return bloques


# --------------------------------------------------------------------------- bibliografía (de main.bbl, en el orden de citación)
def leer_bbl() -> list[list[R]]:
    t = (IEEE / "main.bbl").read_text(encoding="utf-8")
    entradas = re.findall(r"\\bibitem\{([^}]+)\}\s*(.*?)(?=\\bibitem|\\end\{thebibliography\})", t, flags=re.S)
    refs = []
    for n, (clave, texto) in enumerate(entradas, start=1):
        CITAS[clave] = n
        refs.append(inline(re.sub(r"\s+", " ", texto).strip()))
    return refs


# --------------------------------------------------------------------------- XML
def tipo(r: R) -> str:
    return "Courier New" if r.mono else "Times New Roman"


def rpr(r: R, sz: int) -> str:
    f = tipo(r)
    x = f'<w:rFonts w:ascii="{f}" w:hAnsi="{f}" w:cs="{f}" w:eastAsia="{f}"/>'
    x += '<w:b w:val="1"/><w:bCs w:val="1"/>' if r.b else ""
    x += '<w:i w:val="1"/><w:iCs w:val="1"/>' if r.i else ""
    x += '<w:color w:val="C00000"/>' if r.rojo else ""
    x += f'<w:sz w:val="{sz}"/><w:szCs w:val="{sz}"/>'
    x += '<w:vertAlign w:val="superscript"/>' if r.sup else '<w:vertAlign w:val="subscript"/>' if r.sub else ""
    return f"<w:rPr>{x}</w:rPr>"


def run_xml(r: R, sz: int) -> str:
    partes = re.split(r"(\n|\t)", r.t)
    x = ""
    for p in partes:
        if p == "\n":
            x += "<w:br/>"
        elif p == "\t":
            x += "<w:tab/>"
        elif p:
            x += f'<w:t xml:space="preserve">{escape(p)}</w:t>'
    return f"<w:r>{rpr(r, sz)}{x}</w:r>"


def resolver(runs: list[R]) -> list[R]:
    def r(m: re.Match) -> str:
        if m.group(1) not in ETIQUETAS:
            AVISOS.add(f"referencia sin etiqueta: {m.group(1)}")
            return "??"
        return ETIQUETAS[m.group(1)]
    return [replace(x, t=re.sub(r"\x01([^\x01]+)\x01", r, x.t)) for x in runs]


def parrafo(runs: list[R], sz: int = SZ_CUERPO, jc: str = "both", sangria: int = 0, colgante: int = 0, antes: int = 0, despues: int = 0,
            sig: bool = False, tabs: str = "", extra: str = "") -> str:
    ppr = '<w:keepNext w:val="1"/>' if sig else ""
    ppr += f"<w:tabs>{tabs}</w:tabs>" if tabs else ""
    ppr += f'<w:spacing w:before="{antes}" w:after="{despues}" w:line="240" w:lineRule="auto"/>'
    ppr += f'<w:ind w:left="{colgante}" w:hanging="{colgante}"/>' if colgante else f'<w:ind w:left="0" w:firstLine="{sangria}"/>' if sangria else ""
    ppr += f'<w:jc w:val="{jc}"/>{extra}'
    return f"<w:p><w:pPr>{ppr}</w:pPr>{''.join(run_xml(r, sz) for r in resolver(runs))}</w:p>"


def sect(cols: int, continua: bool) -> str:
    c = f'<w:cols w:equalWidth="0" w:num="2" w:space="{ESPACIO}"><w:col w:w="{ANCHO_COL}" w:space="{ESPACIO}"/><w:col w:w="{ANCHO_COL}"/></w:cols>' if cols == 2 else ""
    t = '<w:type w:val="continuous"/>' if continua else ""
    return (f'<w:sectPr>{t}<w:pgSz w:w="{PAG_W}" w:h="{PAG_H}" w:orient="portrait"/>'
            f'<w:pgMar w:top="{MARG_SUP}" w:right="{MARG_LAT}" w:bottom="{MARG_INF}" w:left="{MARG_LAT}" w:header="0" w:footer="720" w:gutter="0"/>{c}</w:sectPr>')


def cierre_seccion(cols: int, continua: bool) -> str:
    return (f'<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="20" w:lineRule="exact"/><w:rPr><w:sz w:val="2"/></w:rPr>{sect(cols, continua)}</w:pPr></w:p>')


def borde(lado: str, grueso: bool) -> str:
    return f'<w:{lado} w:val="single" w:sz="{8 if grueso else 4}" w:space="0" w:color="000000"/>'


_FUENTE: list = []


def ancho_twips(texto: str, medios_pt: int = SZ_TABLA) -> int:
    """Ancho de una línea de texto en Times New Roman, en twips; con 6 % de holgura por las negritas y las cursivas."""
    if not _FUENTE:
        _FUENTE.append(ImageFont.truetype(str(FUENTE_TNR), 100) if FUENTE_TNR.exists() else None)
    pt = medios_pt / 2
    if _FUENTE[0] is None:
        return int(len(texto) * pt * 0.5 * 20)
    return int(_FUENTE[0].getlength(texto) * pt / 100 * 20 * 1.06)


def anchos_columnas(cols: list, filas: list, disponible: int) -> list[int]:
    """Ancho de cada columna (twips): el del texto sin partir, o el de p{..cm}; si no cabe, se reparte el exceso entre las columnas
    que pueden estrecharse, sin bajar del ancho de su palabra más larga (así «AUROC» no se parte)."""
    n = len(cols)
    relleno = 90 + 30                                                # márgenes de celda (45 + 45) y holgura
    minimo, preferido = [0] * n, [0] * n
    for _, celdas in filas:
        pos = 0
        for ce in celdas:
            if ce["span"] == 1:
                texto = "".join(r.t for r in ce["runs"])
                palabra = max((ancho_twips(x) for x in re.split(r"\s+", texto) if x), default=0)
                linea = max((ancho_twips(x) for x in texto.split("\n")), default=0)
                minimo[pos] = max(minimo[pos], palabra + relleno)
                preferido[pos] = max(preferido[pos], linea + relleno)
            pos += ce["span"]
    for k, (_, w) in enumerate(cols):
        if w:                                                        # p{..cm}: ese ancho, o el de su palabra más larga si esta no cabe (AEctopy_Junctional)
            preferido[k] = max(int(w * 567), minimo[k])
            minimo[k] = min(minimo[k], preferido[k])
    minimo = [min(m, p) for m, p in zip(minimo, preferido)]
    if sum(preferido) <= disponible:
        return preferido
    if sum(minimo) >= disponible:                                    # ni con los mínimos cabe: se escala todo
        return [max(300, int(m * disponible / sum(minimo))) for m in minimo]
    f = (disponible - sum(minimo)) / (sum(preferido) - sum(minimo))
    return [int(m + (p - m) * f) for m, p in zip(minimo, preferido)]


def tabla_xml(b: Bloque, disponible: int) -> str:
    d = b.datos
    cols = d["cols"]
    anchos = anchos_columnas(cols, d["filas"], disponible)
    rows = ""
    reglas = d["reglas"]
    for n, (idx, celdas) in enumerate(d["filas"]):
        antes_r, despues_r = reglas.get(idx, []), reglas.get(idx + 1, [])
        mantener = n < len(d["filas"]) - 1 or bool(d["nota"])       # la tabla no se parte entre columnas ni páginas, y su nota va con ella
        celdas_xml, pos = "", 0
        for ce in celdas:
            span = ce["span"]
            ancho = sum(anchos[pos:pos + span])
            al = {"l": "left", "c": "center", "r": "right"}[ce["al"] or cols[pos][0]]
            # booktabs: toprule es el borde superior grueso de la primera fila; midrule, bottomrule y cmidrule son bordes inferiores
            # de la fila que los precede (así una regla entre dos filas se dibuja una sola vez)
            bs = borde("top", True) if "toprule" in antes_r else ""
            inferior = None
            for rr in despues_r:
                if rr == "bottomrule":
                    inferior = True
                elif rr == "midrule":
                    inferior = inferior or False
                elif isinstance(rr, tuple) and pos <= rr[2] - 1 and pos + span - 1 >= rr[1] - 1:
                    inferior = inferior or False
            if inferior is not None:
                bs += borde("bottom", inferior)
            grid = f'<w:gridSpan w:val="{span}"/>' if span > 1 else ""
            celdas_xml += (f'<w:tc><w:tcPr><w:tcW w:w="{ancho}" w:type="dxa"/>{grid}<w:tcBorders>{bs}</w:tcBorders>'
                           f'<w:vAlign w:val="center"/></w:tcPr>{parrafo(ce["runs"], SZ_TABLA, al, sig=mantener)}</w:tc>')
            pos += span
        rows += f'<w:tr><w:trPr><w:cantSplit/></w:trPr>{celdas_xml}</w:tr>'
    grid = "".join(f'<w:gridCol w:w="{a}"/>' for a in anchos)
    return (f'<w:tbl><w:tblPr><w:tblW w:w="{sum(anchos)}" w:type="dxa"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/>'
            f'<w:tblCellMar><w:top w:w="15" w:type="dxa"/><w:left w:w="45" w:type="dxa"/><w:bottom w:w="15" w:type="dxa"/><w:right w:w="45" w:type="dxa"/></w:tblCellMar></w:tblPr>'
            f'<w:tblGrid>{grid}</w:tblGrid>{rows}</w:tbl>')


class Medios:
    def __init__(self) -> None:
        self.rels: list[tuple[str, str]] = []
        self.archivos: dict[str, Path] = {}

    def agregar(self, png: Path) -> str:
        rid = f"rIdImg{len(self.rels) + 1}"
        self.rels.append((rid, f"media/{png.name}"))
        self.archivos[f"word/media/{png.name}"] = png
        return rid


def convertir_pdf(ruta: str) -> Path:
    PNG.mkdir(exist_ok=True)
    pdf = IEEE / f"{ruta}.pdf"
    destino = PNG / f"{pdf.stem}.png"
    if not pdf.exists():
        raise FileNotFoundError(f"falta {pdf}: compila la figura antes")
    if pdf.stem == "arquitectura" and pdf.stat().st_mtime < max(p.stat().st_mtime for p in FUENTES_DEPENDIENTES):
        sys.exit(f"{pdf.relative_to(IEEE.parents[1])} es anterior a d_arquitectura.tex o a las cifras: ejecuta antes bash tesis/ieee/compilar.sh")
    if destino.exists() and destino.stat().st_mtime >= pdf.stat().st_mtime:      # ya convertida (el ajuste de flotantes reconstruye el Word muchas veces)
        return destino
    subprocess.run(["pdftoppm", "-r", "300", "-png", "-singlefile", str(pdf), str(destino.with_suffix(""))], check=True)
    if pdf.stem == "arquitectura":                                  # la figura se compila en una página: se recortan los márgenes
        im = Image.open(destino).convert("RGB")
        caja = Image.eval(im, lambda p: 255 - p).getbbox()
        margen = 12
        im.crop((max(0, caja[0] - margen), max(0, caja[1] - margen), caja[2] + margen, caja[3] + margen)).save(destino)
    return destino


def figura_xml(b: Bloque, medios: Medios, n_doc: int) -> str:
    d = b.datos
    png = convertir_pdf(d["ruta"])
    w_px, h_px = Image.open(png).size
    natural_twips = w_px / 300 * 1440
    limite = ANCHO_TEXTO if d["ancho"] else ANCHO_COL
    ancho = min(natural_twips, limite * (d["rel"] if d["rel"] <= 1 else 1))
    cx, cy = int(ancho * EMU_POR_TWIP), int(ancho * h_px / w_px * EMU_POR_TWIP)
    rid = medios.agregar(png)
    alt = escape("".join(r.t for r in b.runs)[:200])
    dibujo = (f'<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/>'
              f'<wp:docPr id="{n_doc}" name="Figura {d["num"]}" descr="{alt}"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
              f'<pic:pic><pic:nvPicPr><pic:cNvPr id="{n_doc}" name="{png.name}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="{rid}"/>'
              f'<a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
              f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>')
    img = f'<w:p><w:pPr><w:keepNext w:val="1"/><w:spacing w:before="60" w:after="40" w:line="240" w:lineRule="auto"/><w:jc w:val="center"/></w:pPr>{dibujo}</w:p>'
    leyenda = parrafo([R(f"Fig. {d['num']} ")] + b.runs, SZ_TABLA, "both", despues=120)           # como en la plantilla: «Fig. 1 texto»
    return img + leyenda


# --------------------------------------------------------------------------- ecuaciones: LaTeX -> OMML (ecuaciones nativas de Word)
M_FUENTE = f'<w:sz w:val="{SZ_CUERPO}"/><w:szCs w:val="{SZ_CUERPO}"/>'
M_RPR = f'<w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math"/>{M_FUENTE}</w:rPr>'
M_RPR_TEXTO = f'<w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman"/>{M_FUENTE}</w:rPr>'
M_ACENTOS = {"hat": "\u0302", "bar": "\u0305", "tilde": "\u0303"}
M_FUNCIONES = {"log", "ln", "arg", "max", "min", "exp"}
FINO = "\u2009"                                                      # espacio fino


def m_run(t: str, texto: bool = False) -> str:
    """Un tramo de la ecuación; `texto` lo deja recto y en la fuente del documento (nombres de funciones y palabras)."""
    if texto:
        return f'<m:r><m:rPr><m:nor/></m:rPr>{M_RPR_TEXTO}<m:t xml:space="preserve">{escape(t)}</m:t></m:r>'
    return f'<m:r>{M_RPR}<m:t xml:space="preserve">{escape(t)}</m:t></m:r>'


def m_arg(s: str, i: int) -> tuple[str, int]:
    """Argumento de _ o ^: un grupo entre llaves, una orden o un solo carácter."""
    while s[i] == " ":
        i += 1
    if s[i] == "{":
        a, j = grupo(s, i)
        return "".join(m_leer(a)[0]), j
    m = re.match(r"\\([A-Za-z]+|.)", s[i:])
    if m:
        return "".join(m_leer(m.group(0))[0]), i + m.end()
    return m_run(s[i]), i + 1


def m_scripts(s: str, i: int, base: str) -> tuple[str, int]:
    """Índices y exponentes (y la tilde de y') que siguen a `base`."""
    sub = sup = None
    while True:
        k = i
        while k < len(s) and s[k] == " ":
            k += 1
        if k < len(s) and s[k] in "_^":
            a, i = m_arg(s, k + 1)
            if s[k] == "_":
                sub = a
            else:
                sup = a
        elif k < len(s) and s[k] == "'":
            sup = (sup or "") + m_run("′")
            i = k + 1
        else:
            break
    if sub is not None and sup is not None:
        return f"<m:sSubSup><m:e>{base}</m:e><m:sub>{sub}</m:sub><m:sup>{sup}</m:sup></m:sSubSup>", i
    if sub is not None:
        return f"<m:sSub><m:e>{base}</m:e><m:sub>{sub}</m:sub></m:sSub>", i
    if sup is not None:
        return f"<m:sSup><m:e>{base}</m:e><m:sup>{sup}</m:sup></m:sSup>", i
    return base, i


def m_leer(s: str, i: int = 0, cierre: str | None = None, uno: bool = False) -> tuple[list[str], int]:
    """Subconjunto de LaTeX matemático que usan las ecuaciones del artículo -> nodos OMML (fracciones, sumas, acentos, delimitadores, índices)."""
    nodos: list[str] = []
    while i < len(s):
        c = s[i]
        if c in " \n\t}":
            i += 1
            continue
        nodo = ""
        con_scripts = True
        mb = re.match(r"\\(?:Bigg|bigg|Big|big|left|right)\s*([()\[\]|.])", s[i:])
        if mb:
            d = mb.group(1)
            if d in ")]" and cierre:
                return nodos, i + mb.end()
            i += mb.end()
            if d in "([":
                fin = ")" if d == "(" else "]"
                interior, i = m_leer(s, i, fin)
                nodo = f'<m:d><m:dPr><m:begChr m:val="{d}"/><m:endChr m:val="{fin}"/></m:dPr><m:e>{"".join(interior)}</m:e></m:d>'
            elif d != ".":
                nodo = m_run(d)
        elif c == "\\":
            m = re.match(r"\\([A-Za-z]+|.)", s[i:])
            n, i = m.group(1), i + m.end()
            if n == "frac":
                a, i = grupo(s, i)
                b, i = grupo(s, i)
                nodo = f"<m:f><m:num>{''.join(m_leer(a)[0])}</m:num><m:den>{''.join(m_leer(b)[0])}</m:den></m:f>"
            elif n in M_ACENTOS:
                a, i = grupo(s, i)
                nodo = f'<m:acc><m:accPr><m:chr m:val="{M_ACENTOS[n]}"/></m:accPr><m:e>{"".join(m_leer(a)[0])}</m:e></m:acc>'
            elif n in ("operatorname", "mathrm", "text"):
                a, i = grupo(s, i)
                nodo = m_run(a, True) + (m_run(FINO, True) if n == "operatorname" else "")
            elif n == "mathcal":
                a, i = grupo(s, i)
                nodo = m_run({"L": "ℒ"}.get(a, a))
            elif n in M_FUNCIONES:
                k = i
                while k < len(s) and s[k] == " ":
                    k += 1
                if n in ("max", "min") and k < len(s) and s[k] == "_":      # el índice de max va debajo
                    a, i = m_arg(s, k + 1)
                    nodo = f"<m:limLow><m:e>{m_run(n, True)}</m:e><m:lim>{a}</m:lim></m:limLow>"
                else:
                    nodo = m_run(n, True) + m_run(FINO, True)
                con_scripts = False
            elif n == "sum":
                sub = sup = ""
                while i < len(s) and s[i] in "_^":
                    a, j = m_arg(s, i + 1)
                    sub, sup = (a, sup) if s[i] == "_" else (sub, a)
                    i = j
                cuerpo, i = m_leer(s, i, uno=True)
                nodo = (f'<m:nary><m:naryPr><m:chr m:val="∑"/><m:limLoc m:val="undOvr"/></m:naryPr>'
                        f'<m:sub>{sub}</m:sub><m:sup>{sup}</m:sup><m:e>{"".join(cuerpo)}</m:e></m:nary>')
                con_scripts = False
            elif n in GRIEGO:
                nodo = m_run(GRIEGO[n])
            elif n in SIMBOLOS:
                nodo = m_run(SIMBOLOS[n])
            elif n == "qquad":
                nodo, con_scripts = m_run("\u2003\u2003", True), False
            elif n == "quad":
                nodo, con_scripts = m_run("\u2003", True), False
            elif n in ",;:":
                nodo, con_scripts = m_run(FINO, True), False
            elif n != "!":
                AVISOS.add(f"orden de ecuación no soportada: \\{n}")
        elif c == "{":
            a, i = grupo(s, i)
            nodo = "".join(m_leer(a)[0])
        else:
            nodo = m_run("−" if c == "-" else c)
            i += 1
        if nodo and con_scripts:
            nodo, i = m_scripts(s, i, nodo)
        if nodo:
            nodos.append(nodo)
            if uno:
                break
    return nodos, i


def ecuacion_xml(b: Bloque) -> str:
    """Ecuación en modo de visualización, con el número a la derecha: Word numera con «expresión#(n)» dentro de un eqArr con maxDist=1."""
    numero = f'<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>{m_run(str(b.datos["num"]))}</m:e></m:d>'
    ecuacion = ('<m:oMathPara><m:oMathParaPr><m:jc m:val="center"/></m:oMathParaPr><m:oMath><m:eqArr><m:eqArrPr><m:maxDist m:val="1"/></m:eqArrPr>'
                f'<m:e>{"".join(m_leer(b.datos["tex"])[0])}{m_run("#")}{numero}</m:e></m:eqArr></m:oMath></m:oMathPara>')
    return f'<w:p><w:pPr><w:spacing w:before="60" w:after="60" w:line="240" w:lineRule="auto"/></w:pPr>{ecuacion}</w:p>'


def tabla_completa_xml(b: Bloque, disponible: int) -> str:
    d = b.datos
    leyenda = (parrafo([R(f"TABLA {romano(d['num'])}")], SZ_TABLA, "center", antes=80, sig=True)
               + parrafo([replace(r, t=r.t.upper()) for r in b.runs], SZ_TABLA, "center", despues=40, sig=True))
    nota = parrafo(d["nota"], SZ_TABLA, "both", antes=40) if d["nota"] else ""
    return leyenda + tabla_xml(b, disponible) + nota + parrafo([R("")], 4, "left")


def es_ancho(b: Bloque) -> bool:
    return b.tipo in ("fig", "tab") and b.datos["ancho"]


def colocar_anchos(bloques: list[Bloque], desplazamientos: dict[str, int]) -> list[Bloque]:
    """Las tablas y figuras de dos columnas (table*, figure*) rompen las columnas con un salto de sección continuo; si no caben en lo que
    queda de la página, Word las pasa a la siguiente y deja un hueco. LaTeX las flota; aquí se desplaza cada una, en posiciones de
    párrafo, respecto de donde está en la fuente (scripts/flotantes.json, que calcula ajustar_flotantes.py midiendo el Word)."""
    resto = [b for b in bloques if not es_ancho(b)]
    permitidas = [i for i in range(len(resto) + 1) if i == 0 or resto[i - 1].tipo not in ("h1", "h2", "eq")]   # no tras un encabezado ni una ecuación
    colocar, previos = [], 0
    for b in bloques:
        if not es_ancho(b):
            previos += 1
            continue
        k = min(range(len(permitidas)), key=lambda j: abs(permitidas[j] - previos))
        k = max(0, min(len(permitidas) - 1, k + desplazamientos.get(b.datos["etiqueta"], 0)))
        colocar.append((permitidas[k], len(colocar), b))
    salida = list(resto)
    for pos, _, b in sorted(colocar, key=lambda x: (x[0], x[1]), reverse=True):
        salida.insert(pos, b)
    return salida


def clave_leyenda(b: Bloque) -> str:
    """Los primeros caracteres de la leyenda tal como salen en el PDF (para localizar la página de una tabla o figura ancha)."""
    titulo = "".join(r.t for r in b.runs)
    return re.sub(r"\s+", " ", f"Fig. {b.datos['num']} {titulo[:24]}" if b.tipo == "fig" else titulo[:30].upper())


def construir(desplazamientos: dict[str, int] | None = None, salida: Path = SALIDA) -> dict[str, str]:
    """Escribe el Word y devuelve, en orden, las tablas y figuras anchas: etiqueta -> clave de su leyenda."""
    cargar_cifras()
    referencias = leer_bbl()
    contadores = Contadores()
    bloques: list[Bloque] = []
    resumen = parse_resumen(expandir_cifras(sin_comentarios((IEEE / "capitulos" / "00_resumen.tex").read_text(encoding="utf-8"))))
    for nombre in FUENTES:
        t = expandir_cifras(sin_comentarios((IEEE / "capitulos" / f"{nombre}.tex").read_text(encoding="utf-8")))
        bloques += parse_fuente(t, contadores)
    anchos = {b.datos["etiqueta"]: clave_leyenda(b) for b in bloques if es_ancho(b)}
    bloques = colocar_anchos(bloques, desplazamientos or {})
    medios = Medios()
    cuerpo = []
    # --- bloque de título (una columna)
    cuerpo.append(parrafo([R(TITULO)], SZ_TIT, "center", despues=120))
    cuerpo.append(parrafo([R(AUTORES)], 22, "center", despues=60))
    cuerpo += [parrafo([R(a, i=True)], SZ_SUBT, "center") for a in AFILIACION]
    cuerpo.append(cierre_seccion(1, False))
    # --- resumen y palabras clave (dos columnas)
    for b in resumen:
        runs = [R(b.datos["etiqueta"], b=True, i=True), R("— ", b=True)] + [replace(r, b=True, i=r.i or b.datos.get("claves", False)) for r in b.runs]
        cuerpo.append(parrafo(runs, SZ_CUERPO, "both", despues=60))
    n_doc = 1
    for b in bloques:
        if b.tipo == "h1":
            n = b.datos["num"]
            texto = ([R(f"{n}{'. ' if not b.datos.get('apendice') else ': '}")] if n else []) + b.runs
            cuerpo.append(parrafo(texto, SZ_SUBT, "center", antes=200, despues=60, sig=True))
        elif b.tipo == "h2":
            cuerpo.append(parrafo([R(f"{b.datos['letra']}. ", i=True)] + [replace(r, i=True) for r in b.runs], SZ_SUBT, "left", antes=100, despues=40, sig=True))
        elif b.tipo == "p":
            prefijo = b.datos.get("h3") or []
            cuerpo.append(parrafo(prefijo + b.runs, SZ_CUERPO, "both", sangria=0 if b.datos.get("cont") else 283))
        elif b.tipo == "lista":
            for k, it in enumerate(b.datos["items"], start=1):
                cuerpo.append(parrafo([R(f"{k}) ")] + it, SZ_CUERPO, "both", colgante=283))
        elif b.tipo == "eq":
            cuerpo.append(ecuacion_xml(b))
        elif b.tipo in ("fig", "tab"):
            ancho = b.datos["ancho"]
            if ancho:
                cuerpo.append(cierre_seccion(2, True))
            if b.tipo == "fig":
                cuerpo.append(figura_xml(b, medios, n_doc))
                n_doc += 1
            else:
                cuerpo.append(tabla_completa_xml(b, ANCHO_TEXTO if ancho else ANCHO_COL))
            if ancho:
                cuerpo.append(cierre_seccion(1, True))
    # --- referencias
    cuerpo.append(parrafo([R("REFERENCIAS")], SZ_SUBT, "center", antes=200, despues=60, sig=True))
    for n, r in enumerate(referencias, start=1):
        cuerpo.append(parrafo([R(f"[{n}]\t")] + r, SZ_TABLA, "both", colgante=340, tabs='<w:tab w:val="left" w:pos="340"/>'))
    cuerpo.append(sect(2, True))
    empaquetar("".join(cuerpo), medios, salida)
    for a in sorted(AVISOS):
        print("AVISO:", a)
    print(f"{salida.name}: {len(bloques)} bloques, {len(referencias)} referencias, {len(medios.rels)} imágenes")
    return anchos


def verificar_docx(documento: str) -> None:
    """Autocomprobación: el XML está bien formado (con todos sus prefijos declarados) y no quedó LaTeX sin convertir en el texto."""
    ET.fromstring(documento)
    texto = "".join(re.findall(r"<(?:w|m):t[^>]*>([^<]*)</(?:w|m):t>", documento))
    restos = re.findall(r"\\[A-Za-z]+|[{}$~]|\?\?|[\x01-\x03]", texto)
    if restos:
        sys.exit(f"quedó LaTeX sin convertir en el texto del Word: {sorted(set(restos))}")


def empaquetar(cuerpo: str, medios: Medios, salida: Path) -> None:
    with zipfile.ZipFile(PLANTILLA) as z:
        piezas = {n: z.read(n) for n in z.namelist()}
    documento = piezas["word/document.xml"].decode("utf-8")
    raiz = documento[:documento.index("<w:body>")]                  # declara los espacios de nombres que usa el cuerpo (w, m, wp, a, pic, r)
    nuevo = f"{raiz}<w:body>{cuerpo}</w:body></w:document>"
    verificar_docx(nuevo)
    estilos = piezas["word/styles.xml"].decode("utf-8")
    estilos = estilos.replace('<w:rFonts w:ascii="Arial" w:cs="Arial" w:eastAsia="Arial" w:hAnsi="Arial"/><w:sz w:val="22"/><w:szCs w:val="22"/>',
                              '<w:rFonts w:ascii="Times New Roman" w:cs="Times New Roman" w:eastAsia="Times New Roman" w:hAnsi="Times New Roman"/>'
                              f'<w:sz w:val="{SZ_CUERPO}"/><w:szCs w:val="{SZ_CUERPO}"/>', 1)
    rels = piezas["word/_rels/document.xml.rels"].decode("utf-8")
    rels = re.sub(r'<Relationship Id="rId[6789]"[^>]*/>', "", rels)                  # encabezado y figuras de ejemplo de la plantilla
    rels = rels.replace("</Relationships>", "".join(
        f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="{destino}"/>'
        for rid, destino in medios.rels) + "</Relationships>")
    tipos = piezas["[Content_Types].xml"].decode("utf-8")
    tipos = re.sub(r'<Override[^>]*PartName="/word/header1.xml"/>', "", tipos)
    with zipfile.ZipFile(salida, "w", zipfile.ZIP_DEFLATED) as z:
        for nombre, datos in piezas.items():
            if nombre in ("word/document.xml", "word/styles.xml", "word/_rels/document.xml.rels", "[Content_Types].xml"):
                continue
            if nombre.startswith("word/media/") or nombre.startswith("word/header1") or nombre.startswith("word/_rels/header1"):
                continue
            z.writestr(nombre, datos)
        z.writestr("[Content_Types].xml", tipos)
        z.writestr("word/document.xml", nuevo)
        z.writestr("word/styles.xml", estilos)
        z.writestr("word/_rels/document.xml.rels", rels)
        for nombre, ruta in medios.archivos.items():
            z.write(ruta, nombre)


if __name__ == "__main__":
    if not shutil.which("pdftoppm"):
        sys.exit("Falta pdftoppm en el PATH")
    construir(json.loads(FLOTANTES.read_text(encoding="utf-8")) if FLOTANTES.exists() else {})
