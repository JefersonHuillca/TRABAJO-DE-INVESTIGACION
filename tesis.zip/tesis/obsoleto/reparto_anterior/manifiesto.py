"""Manifiesto de reproducibilidad del artículo IEEE: con qué versión exacta se produjeron sus cifras.

Registra el commit evaluado y si el código cambió desde entonces, el SHA-256 de cada archivo que alimenta las tablas (predicciones,
asignación de particiones, pesos, calibración, umbrales, configuraciones y cifras), las versiones de las bibliotecas, las semillas
y los comandos que regeneran todo. No entrena ni evalúa nada.

Uso, desde la raíz del repo:
    python tesis/ieee/scripts/manifiesto.py              escribe evidencia/manifiesto.json y evidencia/manifiesto.md
    python tesis/ieee/scripts/manifiesto.py --verificar  recalcula los hashes y avisa de cualquier diferencia (código 1 si la hay)
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path

IEEE = Path(__file__).resolve().parents[1]
REPO = IEEE.parents[1]
SALIDA_JSON = IEEE / "evidencia" / "manifiesto.json"
SALIDA_MD = IEEE / "evidencia" / "manifiesto.md"

COMMIT_EVALUADO = "21afdb7"   # el que cita la sección de Declaraciones; cambiarlo aquí y allí si se reevalúa
SISTEMAS = ["eval-resnet-f1", "eval-resnet-platt-f1", "eval-resnet-v2-f1", "eval-resnet-v2-platt-f1", "ensemble-f1", "ensemble-f1-platt"]
CONFIGS = ["examples/cinc2020/config.json", "examples/cinc2020/config_resnet_v2.json", "examples/cinc2020/config_regular_cnn.json"]
PAQUETES = ["numpy", "pandas", "scikit-learn", "scipy", "torch", "matplotlib"]
COMANDOS = [
    "python tesis/ieee/scripts/calcular_extra.py",
    "python tesis/ieee/scripts/hacer_figuras.py",
    "python tesis/ieee/scripts/recortar_webapp.py",
    "python tesis/ieee/scripts/verificar_tex.py",
    "bash tesis/ieee/compilar.sh",
    "python tesis/ieee/scripts/manifiesto.py --verificar",
]


def sha256(ruta: Path) -> str:
    h = hashlib.sha256()
    with ruta.open("rb") as fh:
        for bloque in iter(lambda: fh.read(1 << 20), b""):
            h.update(bloque)
    return h.hexdigest()


def git(*args: str) -> str:
    return subprocess.run(["git", *args], cwd=REPO, check=True, capture_output=True, text=True).stdout.strip()


def archivos() -> list[Path]:
    rutas: list[Path] = []
    for s in SISTEMAS:
        for nombre in ("predictions_test.csv", "predictions_validation.csv", "thresholds_validation.csv"):
            rutas.append(REPO / "runs" / "eval" / s / nombre)
    rutas += [REPO / "data" / "cinc2020_12" / "split_assignments.csv"]
    rutas += sorted((REPO / "models").glob("*.pt"))
    rutas += [REPO / "deploy" / "manifest.json", REPO / "deploy" / "ensemble.env"] + sorted((REPO / "deploy").glob("platt_*.csv"))
    rutas += [REPO / c for c in CONFIGS]
    rutas += [IEEE / "evidencia" / "cifras.csv", IEEE / "evidencia" / "cifras_extra.csv", IEEE / "evidencia" / "webapp" / "informe_E00014.pdf",
              IEEE / "evidencia" / "auditoria_calibracion.csv", IEEE / "evidencia" / "prueba_sin_solape.csv", IEEE / "evidencia" / "cobertura_etiquetas.csv",
              IEEE / "evidencia" / "protocolo_externo.md", IEEE / "evidencia" / "protocolo_t19.md", IEEE / "evidencia" / "reparto_t19.json", REPO / "data" / "cinc2020_12_origen" / "split_assignments.csv", REPO / "data" / "externo" / "patient_groups.csv", REPO / "deploy" / "results" / "ensemble-f1-platt" / "thresholds_validation.csv"]
    faltan = [str(r) for r in rutas if not r.is_file()]
    if faltan:
        raise SystemExit("faltan archivos del manifiesto:\n  " + "\n  ".join(faltan))
    return rutas


def rel(ruta: Path) -> str:
    return ruta.relative_to(REPO).as_posix()


# Cambios de código posteriores al commit evaluado que no alteran los resultados ya citados: el motivo va aquí y el manifiesto los distingue de los no aceptados.
CAMBIOS_ACEPTADOS = {
    "ecg/datasets.py": "T19a: reparto por origen y paciente (opciones nuevas; el reparto por defecto no cambia)",
    "ecg/hdf5_dataset.py": "T19a: máscara de celdas opcional (sin ella, el dataset devuelve lo mismo que antes)",
    "ecg/train.py": "T19a: pérdida enmascarada opcional (apagada por defecto; mismo objeto de pérdida)",
    "tests/test_grouped_split.py": "T19a: pruebas nuevas", "tests/test_masked_loss.py": "T19a: pruebas nuevas",
    "tools/make_patient_groups.py": "T19a: herramienta nueva",
}


def cambios_desde_commit() -> dict:
    cambiados = [c for c in git("diff", "--name-only", COMMIT_EVALUADO, "HEAD").splitlines() if c]
    codigo = [c for c in cambiados if not c.endswith(".md")]
    no_aceptados = [c for c in codigo if c not in CAMBIOS_ACEPTADOS]
    return {"archivos_cambiados": cambiados, "archivos_que_no_son_documentacion": codigo, "solo_documentacion": not codigo,
            "cambios_de_codigo_aceptados": {c: CAMBIOS_ACEPTADOS[c] for c in codigo if c in CAMBIOS_ACEPTADOS},
            "cambios_de_codigo_no_aceptados": no_aceptados}


def construir() -> dict:
    base = {r["id"]: r["valor"] for r in csv.DictReader((IEEE / "evidencia" / "cifras.csv").open(encoding="utf-8"))}
    semillas = {c: json.loads((REPO / c).read_text(encoding="utf-8")).get("seed") for c in CONFIGS}
    return {
        "generado_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "commit_evaluado": git("rev-parse", COMMIT_EVALUADO),
        "commit_actual": git("rev-parse", "HEAD"),
        "cambios_desde_el_commit_evaluado": cambios_desde_commit(),
        "versiones": {"python": sys.version.split()[0], **{p: metadata.version(p) for p in PAQUETES}},
        "semillas": {"configuraciones": semillas, "reparto": base["SplitSeed"], "bootstrap": base["BootSeed"], "remuestreos": base["NBoot"]},
        "comandos": COMANDOS,
        "sha256": {rel(r): sha256(r) for r in archivos()},
    }


def a_markdown(m: dict) -> str:
    c = m["cambios_desde_el_commit_evaluado"]
    lineas = [
        "# Manifiesto de reproducibilidad", "",
        f"Generado (UTC): {m['generado_utc']}", "",
        f"- Commit evaluado: `{m['commit_evaluado']}`; commit actual: `{m['commit_actual']}`.",
        f"- Cambios desde el commit evaluado: {len(c['archivos_cambiados'])} archivo(s); solo documentación: **{'sí' if c['solo_documentacion'] else 'NO'}**; cambios de código aceptados: {len(c['cambios_de_codigo_aceptados'])}, sin justificar: {len(c['cambios_de_codigo_no_aceptados'])}.",
        f"- Semillas: configuraciones {m['semillas']['configuraciones']}; reparto {m['semillas']['reparto']}; bootstrap {m['semillas']['bootstrap']} (B = {m['semillas']['remuestreos']}).",
        "- Versiones: " + ", ".join(f"{k} {v}" for k, v in m["versiones"].items()) + ".", "",
        "## Comandos", "", "```", *m["comandos"], "```", "",
        "## SHA-256", "", "| Archivo | SHA-256 |", "|---|---|",
        *[f"| `{k}` | `{v}` |" for k, v in m["sha256"].items()],
    ]
    return "\n".join(lineas) + "\n"


def verificar() -> int:
    guardado = json.loads(SALIDA_JSON.read_text(encoding="utf-8"))
    problemas = []
    for ruta, hash_guardado in guardado["sha256"].items():
        archivo = REPO / ruta
        if not archivo.is_file():
            problemas.append(f"falta {ruta}")
        elif sha256(archivo) != hash_guardado:
            problemas.append(f"cambió {ruta}")
    no_aceptados = cambios_desde_commit()["cambios_de_codigo_no_aceptados"]
    if no_aceptados:
        problemas.append(f"el código cambió desde {COMMIT_EVALUADO} sin justificación en CAMBIOS_ACEPTADOS: {no_aceptados}")
    for p in problemas:
        print("DIFERENCIA:", p)
    print(f"RESULTADO: {'OK' if not problemas else str(len(problemas)) + ' diferencia(s)'} ({len(guardado['sha256'])} archivos comprobados)")
    return 1 if problemas else 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--verificar", action="store_true", help="comparar con el manifiesto guardado en vez de escribirlo")
    if parser.parse_args().verificar:
        return verificar()
    m = construir()
    SALIDA_JSON.write_text(json.dumps(m, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    SALIDA_MD.write_text(a_markdown(m), encoding="utf-8", newline="\n")
    print(f"manifiesto escrito: {len(m['sha256'])} archivos; commit evaluado {m['commit_evaluado'][:7]}, solo documentación desde entonces: "
          f"{m['cambios_desde_el_commit_evaluado']['solo_documentacion']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
