# Manifiesto de reproducibilidad

Generado (UTC): 2026-10-27T01:44:28Z

- Commit evaluado: `21afdb77fdd0cf3f56cad232fcb25aee5c628d96`; commit actual: `303d4b346e0df89f5ab447fa547d31d7b943d396`.
- Cambios desde el commit evaluado: 10 archivo(s); solo documentación: **NO**; cambios de código aceptados: 6, sin justificar: 0.
- Semillas: configuraciones {'examples/cinc2020/config.json': 42, 'examples/cinc2020/config_resnet_v2.json': 43, 'examples/cinc2020/config_regular_cnn.json': 42}; reparto 42; bootstrap 0 (B = 1000).
- Versiones: python 3.13.15, numpy 2.3.3, pandas 2.3.2, scikit-learn 1.7.2, scipy 1.16.2, torch 2.14.0+cu130, matplotlib 3.10.6.

## Comandos

```
python tesis/ieee/scripts/calcular_extra.py
python tesis/ieee/scripts/hacer_figuras.py
python tesis/ieee/scripts/recortar_webapp.py
python tesis/ieee/scripts/verificar_tex.py
bash tesis/ieee/compilar.sh
python tesis/ieee/scripts/manifiesto.py --verificar
```

## SHA-256

| Archivo | SHA-256 |
|---|---|
| `runs/eval/eval-resnet-f1/predictions_test.csv` | `706521671c83b661b58a0a7ab3332871eff9cfba973d45ca69e50d60a448cd91` |
| `runs/eval/eval-resnet-f1/predictions_validation.csv` | `6898c448af4f94d63284e09cd2cc9b41ce7bb8f81cf993acd398f11c8707e256` |
| `runs/eval/eval-resnet-f1/thresholds_validation.csv` | `21ee242b878821dd4464e43667c0d6be390a9e24b4165709aaae08de791bd6c9` |
| `runs/eval/eval-resnet-platt-f1/predictions_test.csv` | `37caa237a312f3b9d1c62a5f9b8d2441cc1508bd15ec9d40e8740d56c4aa1dbc` |
| `runs/eval/eval-resnet-platt-f1/predictions_validation.csv` | `253ff808586a66775e9802e1d3e5b5f246ff65f203c03ca07d7dfb72f11de91a` |
| `runs/eval/eval-resnet-platt-f1/thresholds_validation.csv` | `1148c2bb3f0b10f4fee34291479eef0bafabcc16edb65ec4eab430a587dff6d1` |
| `runs/eval/eval-resnet-v2-f1/predictions_test.csv` | `265f0c97712980e3162e3f01b717bb46c36ea32c073ab55509244363e23139ed` |
| `runs/eval/eval-resnet-v2-f1/predictions_validation.csv` | `188729364cb8526c3a506e6aaf0c08cf22807bbb64e3ba2ffde418ea969ba532` |
| `runs/eval/eval-resnet-v2-f1/thresholds_validation.csv` | `beb10992b0b773ab75bc855f1f2d061d2f3abd0ba0265440d3807262a9cb47fe` |
| `runs/eval/eval-resnet-v2-platt-f1/predictions_test.csv` | `8096ac4f77a88a932ec17d8da49d99952c892ff06b9b7d3cc0ee381de4d1ef2f` |
| `runs/eval/eval-resnet-v2-platt-f1/predictions_validation.csv` | `4f70bbc2592d2b51480337ad961d9c4d7c315224bd632af8b1bef4c418e29d94` |
| `runs/eval/eval-resnet-v2-platt-f1/thresholds_validation.csv` | `8057cc282277cd509fd85e82e6da40ce8ed32d12877015ddc9a16a4aeb026de8` |
| `runs/eval/ensemble-f1/predictions_test.csv` | `ebe2cfc505517cb4e5ef4dddad4fa0051c8cde9a3ab718347f13f9382cfc7274` |
| `runs/eval/ensemble-f1/predictions_validation.csv` | `dfe17ebe044120360eddd5fb006af77a3ee620d9ebeaac1197541af9b7364d4d` |
| `runs/eval/ensemble-f1/thresholds_validation.csv` | `16c93dc7477c1d9b1612170516d7b7785a6a7c8a7f674d5f0b29da7ed18c93ee` |
| `runs/eval/ensemble-f1-platt/predictions_test.csv` | `73716f3fd030e9d683c6da0589058186b6aa4126c0934a479afea668b8deb502` |
| `runs/eval/ensemble-f1-platt/predictions_validation.csv` | `e2ec1e8595ac9c3e0ea5e8b76569bdcd10d28c706771514683199e42a5288929` |
| `runs/eval/ensemble-f1-platt/thresholds_validation.csv` | `502b7976ae0dff56fa2b061614085e02177a8924f526c2a149a9a4e2378d3eec` |
| `data/cinc2020_12/split_assignments.csv` | `c8a49782a3bd69dbe2275236b92d27aa12707c979c96ad5b2bfd7afb42dd0110` |
| `models/resnet34_v1.pt` | `91bec18eefb8f00234fe2ff742ea772b02739fd142edea768161d14502f05cbb` |
| `models/resnet34_v2.pt` | `dbb6c208ce9cf047dcb292bfb0792e7d6d60c8053d61d7a182444f07a21d94ee` |
| `deploy/manifest.json` | `acaa7442ce75eb3859cd33f1e5e0a85a8db88dd8bf51817174ce9ca9599cc379` |
| `deploy/ensemble.env` | `e3e62e8515ef45af376a826ea244b875a6b18f25e0f7e9aae324cd64dfaa0eea` |
| `deploy/platt_a.csv` | `673f8c8d8ad0960012d0ac32a9bfa2676138493447e512d6a77ecf71752293ae` |
| `deploy/platt_b.csv` | `7f41fd4e19764dda5d2526e5079ded95b48d1eab40629302a761c76701975c4a` |
| `deploy/platt_ensemble.csv` | `95550fd16ba44ecf10cffcb8d16ef83809f7b688cdd9809a10695451bb37b42f` |
| `examples/cinc2020/config.json` | `ccae4b3ae4a58242aea00b721fe9197a49c92f63adaa8cd7875a62cd8c6237fb` |
| `examples/cinc2020/config_resnet_v2.json` | `c5df3a4e44c748d3259a1f1849ea8de0812819e766b02ee4a6ecff26e488998a` |
| `examples/cinc2020/config_regular_cnn.json` | `b2b87ae357b04f6192d09da75e1d81d3431d2d6ac3fcdf693b75f658fe48dae4` |
| `tesis/ieee/evidencia/cifras.csv` | `be50b7f1f706b411a598fd6838019997ac1fd9c94fe6a2913fca8049d0776280` |
| `tesis/ieee/evidencia/cifras_extra.csv` | `b555d34b6ee36a19bc0df3c5b8e14b8056237e8ded92ef2e3c5f26ca16495db4` |
| `tesis/ieee/evidencia/webapp/informe_E00014.pdf` | `40480fb8bee577c26d10e39589666b6d5f8d3e7b95cdd30c8ca804a0f752bfec` |
| `tesis/ieee/evidencia/auditoria_calibracion.csv` | `bb9f23ce42acf9c25b967a313e728b85cf5bd5bd0dc85cc6ca106ea964e99f05` |
| `tesis/ieee/evidencia/prueba_sin_solape.csv` | `15d662e0024cee133b4a6dc26e980a3ecf4e3258b4fc5deae5286d65fdf88f40` |
| `tesis/ieee/evidencia/cobertura_etiquetas.csv` | `c2aa441ae3b3ddb48cc195de06a0752f705714f2ebccecb0758ffe0c7744c280` |
| `tesis/ieee/evidencia/protocolo_externo.md` | `2001297b7b9ec77d886a716eff09c683d539eb515f689f20adef6b5309c4fe00` |
| `tesis/ieee/evidencia/protocolo_t19.md` | `e74e28f5cd4c561568646b3985db7efd86f77cb33a3e9a3d1e118587e68f5790` |
| `tesis/ieee/evidencia/reparto_t19.json` | `d3d597440d75d6dab7ef91351577ded6c92d5f58dae48ec90b604dd95ebcb072` |
| `data/cinc2020_12_origen/split_assignments.csv` | `e43579d0fcf3024bcae97a5cf811bd6f41e7f8b25121e99809289a583e8f9d86` |
| `data/externo/patient_groups.csv` | `93380f479662b3417ff5c502f0a639109809ff98f628735aac00e0b59c6daa46` |
| `deploy/results/ensemble-f1-platt/thresholds_validation.csv` | `502b7976ae0dff56fa2b061614085e02177a8924f526c2a149a9a4e2378d3eec` |
