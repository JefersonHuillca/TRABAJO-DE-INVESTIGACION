"""OBSOLETO desde T19e: el artículo carga capitulos/cifras_t19.tex (scripts/calcular_t19.py), que sale del reparto nuevo; este script describe el
reparto anterior y sus resultados ya no se citan. No se ejecuta.

Cifras adicionales del artículo IEEE (réplica metodológica del enfoque de Hannun et al.).

Copia las cifras de la tesis (tesis/completa) y calcula, solo con las predicciones ya guardadas en runs/eval/ (no se entrena ni se
evalúa ningún modelo ni se escribe en runs/), lo que la réplica necesita y la tesis no traía:
  - AUROC por clase con IC del 95 % por bootstrap sobre registros (como la Tabla 1a del trabajo original);
  - promedios ponderados por la frecuencia de cada clase de F1 y AUROC (la medida agregada del trabajo original);
  - sensibilidad con la especificidad fijada en 0.90 y 0.95 (el análogo de su Tabla 2, sin cardiólogos);
  - matriz de confusión multietiqueta: de los registros con la clase i, fracción en que el sistema predice la clase j;
  - ECE y Brier por clase del ensemble, y cuántos de los registros sin ninguna clase son de PTB;
  - cifras del registro E00014 que muestra la aplicación web, leídas de evidencia/webapp/informe_E00014.pdf (no se ejecuta la aplicación).

Escribe evidencia/cifras.csv y capitulos/cifras.tex (copias de la tesis), evidencia/cifras_extra.csv y capitulos/cifras_extra.tex.

Uso, desde la raíz del repo:  python tesis/ieee/scripts/calcular_extra.py
"""

from __future__ import annotations

import csv
import re
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, f1_score, roc_auc_score, roc_curve

IEEE = Path(__file__).resolve().parents[1]
COMPLETA = IEEE.parent / "completa"
REPO = IEEE.parents[1]
sys.path.insert(0, str(COMPLETA / "scripts"))
sys.path.insert(0, str(REPO))
from ecg.calibration import brier_score, expected_calibration_error  # noqa: E402
from extraer_cifras import CK, CLASSES, con_signo, natural, redondear  # noqa: E402

EVAL = REPO / "runs" / "eval"
# sistema -> directorio de evaluación (todos con threshold_beta = 1.0): v1 y v2 con temperatura, ensemble con temperatura y afín
SISTEMAS = {"V1": "eval-resnet-f1", "V1Af": "eval-resnet-platt-f1", "V2": "eval-resnet-v2-f1", "V2Af": "eval-resnet-v2-platt-f1",
            "EnsTe": "ensemble-f1", "EnsAf": "ensemble-f1-platt"}
ESPEC_A, ESPEC_B = 0.90, 0.95                              # especificidades fijadas de la tabla de sensibilidad
FILAS: list[dict] = []
IDS: set[str] = set()


def add(id_: str, concepto: str, valor, unidad: str, archivo: str, clave: str) -> None:
    assert id_ not in IDS, f"id repetido: {id_}"
    IDS.add(id_)
    FILAS.append({"id": id_, "concepto": concepto, "valor": float(valor), "unidad": unidad, "archivo": archivo, "clave": clave})


def leer(directorio: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    d = pd.read_csv(EVAL / directorio / "predictions_test.csv")
    return (d[[f"true_{c}" for c in CLASSES]].to_numpy(np.uint8), d[[f"prob_{c}" for c in CLASSES]].to_numpy(float),
            d[[f"pred_{c}" for c in CLASSES]].to_numpy(np.uint8))


def sens_a_espec(y: np.ndarray, p: np.ndarray, espec: float) -> float:
    """Mayor sensibilidad con especificidad >= espec (punto de la curva ROC con fpr <= 1 - espec)."""
    fpr, tpr, _ = roc_curve(y, p)
    return float(tpr[fpr <= 1 - espec + 1e-12].max())


def cifras_calibracion_por_clase() -> None:
    """ECE (15 intervalos) y Brier por clase del ensemble afín y con temperatura, con las funciones de ecg/calibration.py."""
    arch = "runs/eval/*/predictions_test.csv"
    # las clases con menor y mayor valor se nombran en el texto del artículo: si cambian, hay que actualizarlo
    esperado = {"Af": ("STach", "TAb"), "Te": ("NSR", "LVH")}
    for etiqueta, directorio in (("Af", "ensemble-f1-platt"), ("Te", "ensemble-f1")):
        y, p, _ = leer(directorio)
        y = y.astype(float)
        ece = np.array([expected_calibration_error(y[:, [i]], p[:, [i]], 15) for i in range(len(CLASSES))])
        brier = np.array([brier_score(y[:, [i]], p[:, [i]]) for i in range(len(CLASSES))])
        assert (CLASSES[int(ece.argmin())], CLASSES[int(ece.argmax())]) == esperado[etiqueta], f"cambió la clase de menor o mayor ECE ({etiqueta}): actualizar 03_resultados.tex"
        add(f"EceClsMin{etiqueta}", f"menor ECE por clase, ensemble {etiqueta}, test ({CLASSES[int(ece.argmin())]})", ece.min(), "prop", arch, "15 intervalos")
        add(f"EceClsMax{etiqueta}", f"mayor ECE por clase, ensemble {etiqueta}, test ({CLASSES[int(ece.argmax())]})", ece.max(), "prop", arch, "15 intervalos")
        if etiqueta == "Af":
            assert (CLASSES[int(brier.argmin())], CLASSES[int(brier.argmax())]) == ("STach", "TAb"), "cambió la clase de menor o mayor Brier: actualizar 03_resultados.tex"
            add("BrierClsMinAf", f"menor Brier por clase, ensemble afín, test ({CLASSES[int(brier.argmin())]})", brier.min(), "prop", arch, "por clase")
            add("BrierClsMaxAf", f"mayor Brier por clase, ensemble afín, test ({CLASSES[int(brier.argmax())]})", brier.max(), "prop", arch, "por clase")


def ic_sistemas(datos: dict, idx: np.ndarray, n_boot: int, semilla: int) -> None:
    """IC95 por bootstrap (mismos remuestreos que el resto) del AUROC macro, el AUPRC macro y la coincidencia exacta de cada sistema de la Tabla VII."""
    arch = "runs/eval/*/predictions_test.csv"
    for s in ("V1", "V2", "EnsTe", "EnsAf"):
        y, p, yh = datos[s]
        auroc, auprc, exacta = [], [], []
        for b in idx:
            yb = y[b]
            if not ((yb.sum(0) > 0).all() and (yb.sum(0) < len(b)).all()):
                continue
            pb = p[b]
            auroc.append(np.mean([roc_auc_score(yb[:, i], pb[:, i]) for i in range(yb.shape[1])]))
            auprc.append(np.mean([average_precision_score(yb[:, i], pb[:, i]) for i in range(yb.shape[1])]))
            exacta.append((yh[b] == yb).all(1).mean())
        for nombre, vals in (("Auroc", auroc), ("Auprc", auprc), ("Exact", exacta)):
            lo, hi = np.percentile(vals, [2.5, 97.5])
            add(f"Ic{nombre}{s}Lo", f"IC95 inferior de {nombre} macro, sistema {s}, test", lo, "prop", arch, f"bootstrap B={n_boot};seed={semilla}")
            add(f"Ic{nombre}{s}Hi", f"IC95 superior de {nombre} macro, sistema {s}, test", hi, "prop", arch, f"bootstrap B={n_boot};seed={semilla}")


def cifras_configuracion() -> None:
    """Semilla de aumentación de la receta v2 (``aug_seed`` de su configuración), que el artículo declara en la Tabla IV."""
    import json
    arch = "examples/cinc2020/config_resnet_v2.json"
    add("HpAugSeedV2", "semilla del generador aleatorio de la aumentación, receta v2", json.loads((REPO / arch).read_text(encoding="utf-8"))["aug_seed"], "param", arch, "aug_seed")


def cifras_tres_decimales(base: dict) -> None:
    """F1 macro del sistema final y su IC con tres decimales (regla: solo esta cifra principal; el resto va a dos).

    Se toman de los valores sin redondear de la tesis (``cifras.csv``), no del texto ya redondeado."""
    arch = "evidencia/cifras.csv"
    for nuevo, origen, concepto in (("F1macEnsAfTest3", "F1macEnsAfTest", "F1 macro del sistema final en prueba"),
                                    ("F1AfTeSysLo3", "F1AfTeSysLo", "límite inferior del IC95 del F1 macro del sistema final"),
                                    ("F1AfTeSysHi3", "F1AfTeSysHi", "límite superior del IC95 del F1 macro del sistema final")):
        add(nuevo, concepto + " (tres decimales)", base[origen], "prop3", arch, f"copia sin redondear de {origen}")


def cifras_auditoria_y_solape() -> None:
    """Cifras de T6 (auditoría de calibración y umbrales, ``evidencia/auditoria_calibracion.csv``) y T7 (prueba sin solape y sin registros
    sin clase, ``evidencia/prueba_sin_solape.csv``). Las producen ``auditoria_calibracion.py`` y ``prueba_sin_solape.py``; aquí solo se leen."""
    arch = "evidencia/auditoria_calibracion.csv"
    with (IEEE / arch).open(encoding="utf-8", newline="") as fh:
        aud = {r["metrica"]: float(r["valor"]) for r in csv.DictReader(fh)}
    f1_in, f1_oof = aud["F1 macro en validación, dentro de muestra"], aud["F1 macro en validación, fuera de pliegue"]
    add("AudF1In", "F1 macro de validación dentro de muestra (umbrales ajustados con toda la validación)", f1_in, "prop", arch, "auditoría T6")
    add("AudF1Oof", "F1 macro de validación fuera de pliegue (5 pliegues x 5 repeticiones)", f1_oof, "prop", arch, "auditoría T6")
    add("AudF1Dif", "optimismo del F1 macro de validación (dentro de muestra menos fuera de pliegue)", f1_in - f1_oof, "prop", arch, "auditoría T6")
    add("AudEceIn", "ECE de validación dentro de muestra", aud["ECE en validación, dentro de muestra"], "prop", arch, "auditoría T6")
    add("AudEceOof", "ECE de validación fuera de pliegue", aud["ECE en validación, fuera de pliegue"], "prop", arch, "auditoría T6")
    add("AudThrSdMean", "desviación típica media del umbral entre ajustes", aud["Desviación típica media del umbral entre ajustes"], "prop", arch, "auditoría T6")
    add("AudThrSdMax", "desviación típica máxima del umbral entre ajustes (STach)", aud["Desviación típica máxima del umbral entre ajustes"], "prop", arch, "auditoría T6")
    with (IEEE / arch).open(encoding="utf-8", newline="") as fh:                         # el texto nombra la clase de mayor dispersión
        detalle = {r["metrica"]: r["detalle"] for r in csv.DictReader(fh)}
    assert "STach" in detalle["Desviación típica máxima del umbral entre ajustes"], "cambió la clase de mayor dispersión del umbral: actualizar 03_resultados.tex"

    arch = "evidencia/prueba_sin_solape.csv"
    sub, extra = {}, {}
    with (IEEE / arch).open(encoding="utf-8", newline="") as fh:
        for fila in csv.reader(fh):
            if len(fila) == 10 and fila[0] != "subconjunto":
                sub[fila[0]] = {k: float(v) for k, v in zip(("n", "f1", "lo", "hi", "micro", "exacta", "auc", "auc_lo", "auc_hi"), fila[1:])}
            elif len(fila) == 2:
                extra[fila[0]] = float(fila[1])
    comp, sin_clase = sub["completa"], sub["sin registros sin clase"]
    sin_sol, ident = sub["sin registros solapados"], sub["solo identificables sin solape"]
    for pref, s, concepto in (("SinSol", sin_sol, "prueba sin los registros que comparten paciente"), ("SinClase", sin_clase, "prueba sin los registros sin ninguna clase"),
                              ("Ident", ident, "prueba solo con registros identificables sin solape")):
        add(f"{pref}N", f"registros de la {concepto}", s["n"], "n", arch, "T7")
        add(f"{pref}F1", f"F1 macro de la {concepto}", s["f1"], "prop", arch, "T7")
        add(f"{pref}Dif", f"F1 macro de la {concepto} menos el de la prueba completa", s["f1"] - comp["f1"], "prop", arch, "T7")
    for pref, s in (("SinSol", sin_sol), ("Ident", ident)):
        add(f"{pref}F1Lo", f"IC95 inferior del F1 macro ({pref})", s["lo"], "prop", arch, "T7")
        add(f"{pref}F1Hi", f"IC95 superior del F1 macro ({pref})", s["hi"], "prop", arch, "T7")
    add("SinSolAuroc", "AUROC macro de la prueba sin registros solapados", sin_sol["auc"], "prop", arch, "T7")
    add("SinSolAurocDif", "AUROC macro sin solapados menos el de la prueba completa", sin_sol["auc"] - comp["auc"], "prop", arch, "T7")
    add("FpTotal", "falsos positivos del ensemble afín en la prueba", extra["falsos_positivos_total"], "n", arch, "T7")
    add("FpSinClase", "falsos positivos que caen en los registros sin ninguna clase", extra["falsos_positivos_en_registros_sin_clase"], "n", arch, "T7")


def cifras_cobertura() -> None:
    """Resumen de la cobertura de etiquetas documentada frente a la inferida (``evidencia/cobertura_etiquetas.csv``, de ``cobertura_etiquetas.py``)."""
    arch = "evidencia/cobertura_etiquetas.csv"
    with (IEEE / arch).open(encoding="utf-8", newline="") as fh:
        filas = list(csv.DictReader(fh))
    sin_anotar = [f for f in filas if f["cobertura_inferida"] == "no anotada"]
    contar = lambda lista, doc: sum(f["cobertura_documentada"] == doc for f in lista)  # noqa: E731
    add("CobConfirmadas", "celdas origen-clase sin positivos que la documentación confirma como fuera del vocabulario", contar(sin_anotar, "fuera"), "n", arch, "T8")
    add("CobSinConfirmar", "celdas sin positivos que la documentación no permite confirmar", contar(sin_anotar, "sin documentar"), "n", arch, "T8")
    add("CobContradichas", "celdas sin positivos cuya clase la documentación sí cubre", contar(sin_anotar, "cubierta"), "n", arch, "T8")
    add("CobFueraConPos", "celdas con positivos de una clase que el vocabulario documentado del origen no incluye",
        sum(f["cobertura_inferida"] == "anotada" and f["cobertura_documentada"] == "fuera" for f in filas), "n", arch, "T8")
    assert contar(sin_anotar, "cubierta") == 0, "hay celdas sin positivos cuya clase la documentación cubre: actualizar 02_metodos.tex (dice que no contradice ninguna)"
    assert len(sin_anotar) == int(base_mask_cells()), "las celdas sin anotar ya no son las que usa el texto"


def base_mask_cells() -> float:
    with (IEEE / "evidencia" / "cifras.csv").open(encoding="utf-8", newline="") as fh:
        return float(next(r["valor"] for r in csv.DictReader(fh) if r["id"] == "MaskCells"))


def cifras_particion(base: dict) -> None:
    """Registros sin ninguna clase: todos en la prueba y cuántos son de PTB (data/cinc2020_12/split_assignments.csv)."""
    arch = "data/cinc2020_12/split_assignments.csv"
    with (REPO / arch).open(encoding="utf-8", newline="") as fh:
        vacios = [r for r in csv.DictReader(fh) if not any(int(r[c]) for c in CLASSES)]
    assert {r["split"] for r in vacios} == {"test"} and len(vacios) == int(base["AllZeroTest"]), "los registros sin clase ya no están todos en la prueba"
    add("AllZeroPtb", "registros sin ninguna clase del origen PTB (todos en la partición de prueba)", sum(r["source_db"] == "ptb" for r in vacios), "n", arch, "source_db=ptb")


def cifras_webapp() -> None:
    """Cifras del registro E00014 tal como las mostró la aplicación web: se leen del informe PDF que esta emitió (evidencia/webapp/)."""
    arch = "evidencia/webapp/informe_E00014.pdf"
    texto = subprocess.run(["pdftotext", "-enc", "UTF-8", "-layout", str(IEEE / arch), "-"], check=True, capture_output=True).stdout.decode("utf-8")
    with (REPO / "data" / "cinc2020_12" / "split_assignments.csv").open(encoding="utf-8", newline="") as fh:
        particion = next(r["split"] for r in csv.DictReader(fh) if r["record_name"] == "E00014")
    assert particion == "train", "E00014 ya no es de entrenamiento: el artículo dice que lo es"
    edad = re.search(r"Edad / Sexo\s+([\d.]+) / ", texto)
    codigos = re.search(r"Códigos Dx del header\s+(\d+), (\d+), (\d+)", texto)
    assert edad and codigos, "el informe de E00014 no trae la edad o los códigos Dx esperados"
    add("WebE14Edad", "edad del registro E00014 según su cabecera, en el informe de la aplicación", edad.group(1), "n", arch, "Edad / Sexo")
    for k, codigo in enumerate(codigos.groups(), start=1):
        add(f"WebE14Dx{k}", f"código SNOMED-CT nº {k} de la cabecera de E00014", codigo, "param", arch, "Códigos Dx del header")
    for clase in ("TAb", "SB", "MI"):
        fila = re.search(rf"^{clase}\s+([\d.]+)%\s+([\d.]+)%", texto, flags=re.M)
        assert fila, f"el informe de E00014 no trae la fila de {clase}"
        add(f"WebE14{clase}", f"probabilidad de {clase} para E00014, ensemble de la aplicación", fila.group(1), "pct", arch, f"{clase};split=train")
        add(f"WebE14{clase}Umbral", f"umbral de {clase} en el informe de la aplicación", fila.group(2), "pct", arch, f"{clase};split=train")


def main() -> int:
    (IEEE / "evidencia").mkdir(exist_ok=True)
    shutil.copy(COMPLETA / "evidencia" / "cifras.csv", IEEE / "evidencia" / "cifras.csv")
    shutil.copy(COMPLETA / "capitulos" / "cifras.tex", IEEE / "capitulos" / "cifras.tex")
    # IEEEtran pasa a minúscula los títulos: las llaves dobles conservan las siglas y los nombres propios de la bibliografía de la tesis
    bib = re.sub(r"^(\s*title\s*=\s*)\{(.*)\},\s*$", r"\1{{\2}},", (COMPLETA / "references.bib").read_text(encoding="utf-8"), flags=re.M)
    (IEEE / "references.bib").write_text(bib, encoding="utf-8", newline="\n")
    base = {r["id"]: float(r["valor"]) for r in csv.DictReader((IEEE / "evidencia" / "cifras.csv").open(encoding="utf-8"))}
    n_boot, semilla = int(base["NBoot"]), int(base["BootSeed"])

    datos = {s: leer(d) for s, d in SISTEMAS.items()}
    y, p, yhat = datos["EnsAf"]
    n = y.shape[0]
    assert n == int(base["NTest"]) and (datos["V1"][0] == y).all() and (datos["EnsTe"][0] == y).all()
    f1_macro = f1_score(y, yhat, average="macro", zero_division=0)
    assert abs(f1_macro - base["F1macEnsAfTest"]) < 1e-9, "las predicciones guardadas no reproducen el F1 macro de la tesis"
    arch = "runs/eval/*/predictions_test.csv"

    # --- AUROC por clase con IC95 por bootstrap sobre registros (mismos remuestreos que el resto de la tesis: semilla y B de la tesis)
    idx = np.random.default_rng(semilla).integers(0, n, size=(n_boot, n))
    for i, c in enumerate(CLASSES):
        puntual = roc_auc_score(y[:, i], p[:, i])
        assert abs(puntual - base[f"Aurocc{CK[c]}"]) < 1e-9, f"AUROC de {c} no coincide con la tesis"
        vals = np.array([roc_auc_score(y[b, i], p[b, i]) for b in idx if 0 < y[b, i].sum() < n])
        lo, hi = np.percentile(vals, [2.5, 97.5])
        add(f"AurocCI{CK[c]}Lo", f"IC95 inferior del AUROC de {c}, ensemble afín, test", lo, "prop", arch, f"bootstrap B={n_boot};seed={semilla}")
        add(f"AurocCI{CK[c]}Hi", f"IC95 superior del AUROC de {c}, ensemble afín, test", hi, "prop", arch, f"bootstrap B={n_boot};seed={semilla}")

    # --- promedios ponderados por la frecuencia de cada clase (soporte en la prueba) de F1 y AUROC, de cada sistema
    peso = y.sum(0) / y.sum()
    for s, (ys, ps, yh) in datos.items():
        f1c = f1_score(ys, yh, average=None, zero_division=0)
        auc = np.array([roc_auc_score(ys[:, i], ps[:, i]) for i in range(len(CLASSES))])
        add(f"F1Wt{s}", f"F1 promedio ponderado por la frecuencia de cada clase, {s}, test", float((peso * f1c).sum()), "prop", arch, "derivado")
        add(f"AurocWt{s}", f"AUROC promedio ponderado por la frecuencia de cada clase, {s}, test", float((peso * auc).sum()), "prop", arch, "derivado")

    # --- sensibilidad con especificidad fijada (la curva ROC no depende de la calibración monótona de cada clase)
    add("SpecFijaA", "especificidad fijada, nivel A", ESPEC_A, "prop", "scripts/calcular_extra.py", "parámetro")
    add("SpecFijaB", "especificidad fijada, nivel B", ESPEC_B, "prop", "scripts/calcular_extra.py", "parámetro")
    for s, esp, etiqueta in (("EnsAf", ESPEC_A, "S90"), ("V1", ESPEC_B, "S95"), ("V2", ESPEC_B, "S95"), ("EnsAf", ESPEC_B, "S95")):
        ys, ps, _ = datos[s]
        sens = np.array([sens_a_espec(ys[:, i], ps[:, i], esp) for i in range(len(CLASSES))])
        for i in range(len(CLASSES)):                       # comprobación independiente: umbral = (k+1)-ésimo mayor negativo, con k falsos positivos permitidos
            neg = np.sort(ps[ys[:, i] == 0, i])
            corte = neg[len(neg) - int((1 - esp) * len(neg) + 1e-9) - 1]
            assert abs(float((ps[ys[:, i] == 1, i] > corte).mean()) - sens[i]) < 2e-3, f"sensibilidad con especificidad fijada de {CLASSES[i]} ({s}, {esp})"
        nombre = {"EnsAf": "Ens"}.get(s, s)
        for i, c in enumerate(CLASSES):
            add(f"Sens{etiqueta}{CK[c]}{nombre}", f"sensibilidad de {c} con especificidad fijada en {esp}, {s}, test", sens[i], "prop", arch, "derivado")
        add(f"Sens{etiqueta}Mac{nombre}", f"sensibilidad macro con especificidad fijada en {esp}, {s}, test", sens.mean(), "prop", arch, "derivado")
        add(f"Sens{etiqueta}Wt{nombre}", f"sensibilidad ponderada con especificidad fijada en {esp}, {s}, test", float((peso * sens).sum()), "prop", arch, "derivado")

    # --- matriz de confusión multietiqueta del sistema final. Diagonal: sensibilidad P(pred_i = 1 | true_i = 1). Fuera de la diagonal:
    # P(pred_j = 1 | true_i = 1, true_j = 0), es decir, cuántos registros de la clase i, que no tienen la clase j, el sistema marca como j
    # (condicionar a true_j = 0 quita las coocurrencias legítimas, que en un problema multietiqueta no son errores).
    def celda(i: int, j: int) -> float:
        sel = (y[:, i] == 1) if i == j else (y[:, i] == 1) & (y[:, j] == 0)
        return float(yhat[sel, j].mean())
    m = np.array([[celda(i, j) for j in range(len(CLASSES))] for i in range(len(CLASSES))])
    for i, c in enumerate(CLASSES):
        assert abs(m[i, i] - base[f"Recc{CK[c]}"]) < 1e-9, f"la diagonal de {c} no coincide con la sensibilidad por clase de la tesis"
    pd.DataFrame(m, index=CLASSES, columns=CLASSES).to_csv(IEEE / "evidencia" / "matriz_confusion.csv", float_format="%.6f", lineterminator="\n")
    fuera = [(m[i, j], CLASSES[i], CLASSES[j]) for i in range(12) for j in range(12) if i != j]
    fuera.sort(reverse=True)
    for k, (v, ci, cj) in enumerate(fuera[:3], start=1):
        add(f"ConfTop{k}", f"mayor confusión fuera de la diagonal nº {k}: registros con {ci} y sin {cj} en que se predice {cj}", v, "prop", "evidencia/matriz_confusion.csv", f"{ci}->{cj}")
    add("ConfDiagMin", "menor valor de la diagonal (sensibilidad por clase)", np.diag(m).min(), "prop", "evidencia/matriz_confusion.csv", "diagonal")

    ic_sistemas(datos, idx, n_boot, semilla)
    cifras_calibracion_por_clase()
    cifras_tres_decimales(base)
    cifras_configuracion()
    cifras_auditoria_y_solape()
    cifras_cobertura()
    cifras_particion(base)
    cifras_webapp()

    with (IEEE / "evidencia" / "cifras_extra.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["id", "concepto", "valor", "unidad", "archivo", "clave"], lineterminator="\n")
        w.writeheader()
        w.writerows(FILAS)
    lineas = ["% Generado por tesis/ieee/scripts/calcular_extra.py a partir de evidencia/cifras_extra.csv: NO editar a mano."]
    for r in FILAS:
        texto = f"{r['valor']:.3f}" if r["unidad"] == "prop3" else natural(r["valor"], r["unidad"])
        lineas.append(r"\expandafter\gdef\csname cf:%s\endcsname{%s}" % (r["id"], texto))
        if r["unidad"] != "prop3":                                                   # versión con signo, como en las cifras de la tesis
            lineas.append(r"\expandafter\gdef\csname cfs:%s\endcsname{%s}" % (r["id"], con_signo(r["valor"], r["unidad"])))
    (IEEE / "capitulos" / "cifras_extra.tex").write_text("\n".join(lineas) + "\n", encoding="utf-8", newline="\n")
    print(f"{len(FILAS)} cifras adicionales; F1 macro comprobado contra la tesis: {redondear(f1_macro, 'prop')}; B={n_boot}, semilla={semilla}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
