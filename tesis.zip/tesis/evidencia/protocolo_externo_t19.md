# Protocolo de la evaluación externa en Chapman-Shaoxing y Ningbo (T19)

Escrito el 2026-11-01, **antes** de ejecutar ningún modelo sobre Chapman-Shaoxing (C) ni Ningbo (D) y de ver ninguna predicción sobre ellos. Su SHA-256 queda en
`evidencia/protocolo_externo_t19.sha256`. Cualquier cambio posterior es una **desviación**: se anota con fecha y motivo en `evidencia/protocolo_externo_t19_desviaciones.md` y
el resultado afectado se rotula exploratorio. Continúa a `protocolo_t19.md` (hash `e74e28f5cd4c561568646b3985db7efd86f77cb33a3e9a3d1e118587e68f5790`), cuyos sistemas, calibración,
umbrales y reglas no cambia.

## 1. Qué se afirma y qué no

- Se mide, **sin reentrenar, recalibrar ni reajustar nada**, el sistema principal (P3: ensemble de las recetas v1 y v2 con calibración afín por clase y umbrales de F1 con β = 1 fijados
  en validación) y los demás sistemas congelados de §4 en dos bases que no intervinieron en su diseño. **C y D son los resultados primarios** del trabajo; A y B pasan a ser
  desarrollo y exploración, con las reservas ya declaradas (se vieron al decidir las recetas, la calibración, el punto de operación y la ampliación de las semillas).
- Es la partición más cercana a confirmatoria que permiten los datos, no una confirmación plena: C y D no se usaron para entrenar, validar, calibrar, fijar umbrales ni elegir recetas, pero
  las tres decisiones de §2 y §3 (exclusiones, tratamiento de duplicados y clases evaluables) se tomaron mirando sus cabeceras y recuentos de etiquetas (§9), nunca predicciones.
- Se mide generalización a otras instituciones del mismo tipo de tarea (ECG de 12 derivaciones, 12 clases); no valida el uso clínico. No se compara con los resultados del Challenge ni se
  calcula su métrica: del Challenge 2021 solo se usan estas dos carpetas de datos.
- El resultado se reporta sea cual sea. No hay un valor mínimo que lo valide ni uno que lo invalide.

## 2. Datos

- **Fuente:** PhysioNet/CinC Challenge 2021 v1.0.3, carpetas `training/chapman_shaoxing` (C) y `training/ningbo` (D); derivan de la base `ecg-arrhythmia` (Zheng, Guo y Chu, 2022).
  10 s, 500 Hz, 12 derivaciones, códigos SNOMED CT. `SHA256SUMS.txt` de la descarga: `f29c2609343c38734f3a3d62be4a9052ca56a9e560e7ad2efc2118563fca2473`.
  Descarga con `descargar_challenge2021.sh` y comprobación de que esté completa con `tools/verificar_challenge2021.py` (45 152 registros: 10 247 de C y 34 905 de D).
- **Integridad:** 90 303 de los 90 304 archivos `.hea` y `.mat` coinciden con su hash publicado. `S23074.hea` (Ningbo) apuntaba a `JS23074.mat`: se renombró a `JS23074.hea` sin tocar su contenido.
- **Exclusión 1, hash distinto del publicado (decidida el 2026-10-31, tras ver el registro):** se excluye todo archivo cuyo SHA-256 no coincida con el publicado. Hoy es solo `JS13118`
  (Ningbo): el servidor sirve bytes distintos de los publicados, y la señal trae tres transitorios a fondo de escala en las 12 derivaciones, que se vieron al decidir. El criterio de exclusión es el hash, no la forma de la señal ni las etiquetas ni predicciones.
- **Exclusión 2, duplicados:** 87 grupos de dos registros con la **señal idéntica** (174 registros; 71 grupos entre C y D y 16 dentro de un mismo origen). Los grupos salen por dos vías que coinciden
  (SHA-256 publicado de los `.mat` y contenido de la señal leído de cada archivo). De cada grupo se conserva **un solo registro**, el primero por (origen, nombre) con C antes que D, y se excluye el otro (87 registros).
  Detalle por registro en `duplicados_externa.csv`. **26 de los 87 grupos tienen etiquetas discordantes en las 12 clases** (en los otros 61 coinciden); con la regla, el registro conservado puede traer una etiqueta
  distinta de la del descartado. Esa discordancia se estudia como análisis de sensibilidad (§8) y no cambia la regla.
- **Sin coincidencias con el Challenge 2020:** ninguna de las 45 151 señales utilizables coincide, byte a byte de la señal, con alguno de los 43 101 registros públicos del Challenge 2020
  (entrenamiento, validación, prueba A y B). No se descartan cuasi-duplicados ni solapes con registros no publicados.
- **Resultado:** 88 registros excluidos (`exclusiones_externa.txt`, SHA-256 `90224e4b96031d7a145c824b389575e180d0fa30ec8b1a33068e5a5c7b3ad842`).
  **C: 10 234 registros; D: 34 830.** HDF5 de solo prueba construidos con `examples/cinc2020/build_external_test.py` (una ventana de 10 s por registro, esquema `cinc2020_12_grouped_snomed_v2`,
  mismo preprocesamiento de `ecg/signal.py`: normalización `physical` y filtro paso banda). Se comprobó que el constructor reproduce exactamente las señales y etiquetas de `test_b.h5` (Georgia, 10 344 registros).
  SHA-256 de los HDF5, del manifiesto por registro y del resumen en `reparto_externo.json` (SHA-256 `158857c596750e7f0aca9c89656fe2188e1e804b75710463524009ed25e392fa`).
- **Pacientes:** C y D no traen identificador de paciente. La documentación de la base da 45 152 pacientes y 45 152 ECG, pero no dice de forma explícita que cada paciente aporte uno solo; se supone así y los
  IC son por registro. Los 87 grupos de señal idéntica muestran que una misma señal puede aparecer con nombres distintos.

## 3. Etiquetas y clases evaluables

- Las etiquetas son los códigos SNOMED CT de la línea `Dx` de cada cabecera, agrupados en las 12 clases con la misma tabla del entrenamiento (`ecg/schema.py`). Los registros sin ninguna de las 12 clases se
  mantienen como negativos (C: 18; D: 133) y se informa también el resultado sin ellos.
- **Cobertura:** la tabla de 63 etiquetas de la documentación de la base cubre las 12 clases; no separa C de D, así que la cobertura es «cubierta» para ambos. El artículo de *Scientific Data* de la base no pudo consultarse.
- **Clase evaluable (regla E0.4, fijada el 2026-10-30, antes de leer ningún recuento de etiquetas):** la fuente la cubre y hay al menos 50 positivos en el conjunto final de §2.
  **C: 11 clases** (todas menos `LVH`, 21 positivos). **D: 12 clases** (el mínimo es 748 positivos en `LVH`). Positivos por clase en `reparto_externo.json`.
- Todas las métricas agregadas de §6 (macro, micro, ponderadas, coincidencia exacta, ECE y Brier) se calculan **solo sobre las columnas evaluables** de cada origen. El cálculo sobre las 12 clases se informa como diagnóstico.
  Un registro cuya única clase no es evaluable (en C, solo `LVH`) se mantiene como negativo.

## 4. Sistemas

Los 37 sistemas de `protocolo_externo_t19_sistemas.csv` (SHA-256 `c2833871eda755b87457d765da7e57ce775540a9fc810579f9486eb23603ae57`), con el SHA-256 de su configuración, pesos (`best.pt`), calibración y
umbrales, y de sus predicciones ya guardadas en A y B. **Ninguno se reentrena, recalibra ni ajusta.** Código del experimento: commit `303d4b3`; el árbol actual (`fcf6f45`) solo añade el constructor de HDF5 externos, la descarga y verificación de
Challenge 2021, un comentario en `ecg/calibration.py` y las dependencias fijadas en `constraints.txt` (las versiones instaladas se anotan al evaluar).

| Grupo | Sistemas | Papel |
|---|---|---|
| **Principal** | **P3** (ensemble α = 0.5 de v1 y v2 con recalibración afín propia; semillas 42 y 43) | **titular** |
| Recetas | P1 (v1) y P2 (v2) | secundario |
| Semillas | P1, P2 y P3 de las semillas 101 a 109 (con la original suman 10 por receta) | secundario (variabilidad entre entrenamientos) |
| Pérdida enmascarada | P1m, P2m, P3m | secundario |
| Línea base | CNN convencional | secundario |
| Temperatura | P1t, P2t, P3t (calibración por temperatura en lugar de la afín) | secundario, exploratorio como en A y B |

Las ablaciones (S3) **no** se evalúan en C ni en D.

## 5. Procedimiento

- Una configuración por sistema y origen, copia de la de B con solo `test` apuntando a `data/cinc2021_externo/test_c.h5` o `test_d.h5` (`config_<experimento>_testc.json`, `_testd.json`).
- `evaluar_t19.sh 7` (etapa 7): `evaluate.py` y `ensemble_evaluate.py` con la calibración y la opción `--threshold-beta 1.0` de A y B. Cada sistema se evalúa **una sola vez en C y una sola vez en D**; el script se detiene
  si la carpeta `runs/t19/eval/<sistema>_C` o `_D` ya existe.
- **Verificación obligatoria:** los umbrales de C y D de cada sistema (`thresholds_validation.csv`) son byte a byte los de A y B (salen de la misma validación). Si no lo son, no se sigue.
- Se guardan y hashean las predicciones por registro. Se anotan las versiones de Python, PyTorch, NumPy y scikit-learn del equipo.
- Antes de lanzar se hace una pasada de tiempo sobre B para estimar la duración. Si una corrida falla por una causa técnica (corte, memoria) se repite con la misma configuración y se anota; un sistema no se repite por su resultado.

## 6. Métricas y análisis

- **Titular:** F1 macro de P3 en C (11 clases) y en D (12 clases), cada una con su IC del 95 %. No se agrupan C y D en un único resultado. Los dos titulares se informan sin corrección por comparaciones múltiples.
- **Secundarias:** F1 micro y ponderado, coincidencia exacta, AUROC macro, AUPRC macro, ECE (15 intervalos, sin IC) y Brier; por clase (F1, precisión, sensibilidad, especificidad, AUROC, AUPRC); y el resultado sin los registros sin clase.
- **Intervalos:** *bootstrap* de percentiles del 95 % sobre registros, 1 000 remuestreos con semilla 0, los mismos para todos los sistemas de un origen. Diferencias entre sistemas: pareadas con su IC.
  A, B, C y D se comparan entre sí con diferencias no pareadas (registros distintos): su IC sale de todas las diferencias entre remuestreos.
- **Semillas:** media y desviación típica (n − 1) de cada métrica entre las 10 semillas de cada receta; por semilla, ensemble menos la mejor receta individual de esa semilla, con el recuento de semillas en que es positiva y la
  prueba de signos exacta bilateral (con 10 semillas, p mínimo 0.00195). Sin corrección por comparaciones múltiples; se informan todas las métricas.
- **Línea base y variantes:** diferencias pareadas con P1 (CNN) o con el sistema sin enmascarar y con la afín (P1m, P2m, P3m, P1t, P2t, P3t).
- **Calidad de la comprobación:** los valores puntuales deben coincidir con scikit-learn y con `metrics_global.csv` de cada evaluación (tolerancias de las etapas anteriores).
- El análisis lo hace `analizar_t19.py --etapa 7` (se escribe y se prueba con datos sintéticos antes de evaluar, como en las etapas anteriores) y escribe en `evidencia/t19_etapa7/`.

## 7. Reglas

- Ninguna decisión de diseño se toma mirando C ni D: ni receta, ni calibración, ni umbral, ni punto de operación, ni clases evaluables, ni exclusiones. Si el resultado es malo, se informa así.
- No se reevalúa ningún sistema ni se repite una evaluación para obtener otro resultado.
- La recalibración o el reajuste de umbrales con datos de C o D (E13) **no forma parte de este protocolo**; si se hace, es después de registrar el resultado de §6, con su desviación, y se rotula exploratoria.
- Todo lo que se pruebe fuera de esta lista es exploratorio y así se rotula.

## 8. Análisis exploratorios fijados de antemano

1. **Sensibilidad a los duplicados discordantes:** repetir el análisis de P3 excluyendo **ambos** registros de cada uno de los 26 grupos con etiquetas discordantes (`duplicados_externa.csv`, columna `clases12_discordantes`).
2. Las 12 clases sin máscara de clases evaluables (diagnóstico de §3).
3. Los resultados en A y B, ya analizados en las etapas 1 a 4 y 6; se muestran junto a C y D pero no son confirmatorios.
4. Recalibración local con una mitad de cada origen (E13), solo después de registrar §6 y con su propia desviación.

## 9. Historial de uso de C y D antes de este protocolo

Se hizo, en este orden, con los datos de C y D (el 2026-10-31 y el 2026-11-01):
descarga (`wget`); recuento de archivos y tamaños; comprobación de cabeceras (derivaciones, frecuencia, muestras, línea `Dx`); renombrado de `S23074.hea`; SHA-256 de todos los archivos frente a `SHA256SUMS.txt`;
carga de `JS13118.mat` para ver su rango de valores; **lectura de los códigos de la línea `Dx` y recuentos de registros por código y por clase** (auditoría de cabeceras y cobertura), usados para la regla de ≥ 50 positivos;
lectura de la señal de los 45 152 `.mat` para calcular su contenido y hallar duplicados, y comparación de las etiquetas dentro de cada grupo duplicado; comparación del contenido con los 43 101 `.mat` del Challenge 2020;
construcción de los HDF5 con el preprocesamiento del proyecto y sus recuentos de positivos; y la comprobación de que el constructor reproduce `test_b.h5`.
**No se ejecutó ningún modelo sobre C ni D, no existe ninguna predicción sobre ellos y no existe ninguna carpeta `*_C` ni `*_D` en `runs/t19/eval/`.** Nada de lo anterior intervino en la receta, la calibración, los umbrales ni el
punto de operación de ningún sistema (todos entrenados, calibrados y fijados antes de bajar los datos, salvo las semillas 105 a 109, cuyas configuraciones se copiaron de las anteriores con solo la semilla cambiada).

## 10. Límites que ya se conocen

Sin identificador de paciente en C ni D (IC por registro, con el supuesto de §2); 26 grupos de duplicados con etiquetas discordantes; etiquetas no revisadas por cardiólogos y vocabulario de cada institución no verificado en el artículo de la base;
`LVH` no evaluable en C; no se descartan cuasi-duplicados; dos instituciones, no un muestreo de instituciones; la ejecución en GPU no es bit a bit reproducible y todo corre en un solo equipo; las versiones de las dependencias cambiaron
respecto del entrenamiento (`constraints.txt`); A y B ya se habían visto al decidir las recetas y la ampliación de semillas.

## 11. Orden de ejecución

1. Sellar este protocolo (SHA-256 y fecha) y registrarlo; el usuario lo revisa antes de seguir.
2. Escribir y probar con datos sintéticos `analizar_t19.py --etapa 7`; añadir la etapa 7 a `evaluar_t19.sh`.
3. Generar las configuraciones `*_testc.json` y `*_testd.json`, medir el tiempo y ejecutar `evaluar_t19.sh 7`.
4. Registrar las predicciones y sus SHA-256; `analizar_t19.py --etapa 7`; leer los resultados tal como salieron.
