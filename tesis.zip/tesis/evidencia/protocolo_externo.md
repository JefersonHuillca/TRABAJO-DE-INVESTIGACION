> **ANULADO el 2026-10-26 por decisión del usuario.** No se descargó ni se evaluó ningún dato externo y no se usa nada del Challenge 2021 (la descarga desde
> PhysioNet iba a menos de 10 KB/s). Se conserva solo como registro de lo que se había planeado.

# Protocolo de la evaluación confirmatoria externa

Escrito el 2026-10-23, **antes** de descargar los datos externos y de calcular cualquier cifra sobre ellos. Su SHA-256 queda en
`evidencia/protocolo_externo.sha256` y en el manifiesto. Cualquier cambio posterior invalida el carácter confirmatorio: si hace falta
cambiar algo, se declara como desviación del protocolo y el resultado afectado pasa a exploratorio.

## 1. Pregunta y alcance

¿Conserva el sistema final, congelado, su rendimiento en instituciones que no intervinieron en su desarrollo? Es una evaluación
retrospectiva en dos fuentes públicas. No es un estudio clínico ni prospectivo.

## 2. Datos

- **Fuente:** PhysioNet/Computing in Cardiology Challenge 2021, v1.0.3, carpetas de entrenamiento `chapman_shaoxing` (10 247 registros) y
  `ningbo` (34 905), licencia CC BY 4.0, 10 s a 500 Hz, códigos SNOMED-CT en la cabecera. Se comprobará con `SHA256SUMS.txt` si coinciden con
  `ecg-arrhythmia` 1.0.0 (45 152 ECG).
- **Procedencia:** la carpeta del registro. Se informa cada fuente por separado y agregadas.
- **No se usa ningún otro dato externo.** Los orígenes de 2020 no se reutilizan.

## 3. Sistemas congelados (no se reentrena, recalibra ni reajusta nada)

| Sistema | Papel | Identificación (SHA-256, primeros 16 caracteres) |
|---|---|---|
| Ensemble afín v1+v2, α = 0.5, umbrales por clase de F1 con β = 1 fijados en validación | **principal** | `models/resnet34_v1.pt` 91bec18eefb8f002; `models/resnet34_v2.pt` dbb6c208ce9cf047; `deploy/platt_a.csv` 673f8c8d8ad09600; `deploy/platt_b.csv` 7f41fd4e19764dda; `deploy/platt_ensemble.csv` 95550fd16ba44ecf |
| v1 con calibración afín | secundario | `models/resnet34_v1.pt`, `deploy/platt_a.csv` |
| v2 con calibración afín | secundario | `models/resnet34_v2.pt`, `deploy/platt_b.csv` |
| CNN 1D convencional (T13) | referencia | `examples/cinc2020/config_regular_cnn.json` b2b87ae357b04f61, semilla 42, partición actual, calibración afín y umbrales de F1 con β = 1 fijados en validación, **antes** de ver los datos externos; su hash de pesos se añade al manifiesto al terminar su entrenamiento y antes de T11 |

Código evaluado: commit `21afdb7` (el código no ha cambiado desde entonces salvo documentación). Versiones en `evidencia/manifiesto.json`.
El sistema enmascarado (T12) **no** forma parte de este protocolo: si se evalúa en estos datos después, es exploratorio.

## 4. Preprocesamiento y etiquetas

- Preprocesamiento: el de `ecg/signal.py` (orden estándar de las 12 derivaciones, milivoltios con la ganancia de la cabecera, 500 Hz, pasa-banda
  Butterworth 0.5–50 Hz de fase cero, recorte a ±5 mV, ventana central de 10 s = 5 000 muestras). Los registros de 10 s usan una sola ventana.
- Etiquetas: la correspondencia SNOMED-CT → 12 clases del esquema `cinc2020_12_grouped_snomed_v2` ya usado, sin cambios y sin añadir códigos.
  Un código sin clase se ignora.
- **Etiquetas desconocidas:** el vocabulario documentado de ambas fuentes cubre las 12 clases (T8). Una clase es **evaluable** en una fuente si
  tiene **al menos 50 positivos** en ella (umbral fijado aquí, antes de ver los datos). Las clases no evaluables no entran en las métricas
  principales; se informan de forma descriptiva y su ausencia no se cuenta como negativa confirmada. Las clases evaluables tratan la ausencia
  de código como negativo, que es lo que documenta el vocabulario de la fuente.

## 5. Exclusiones (fijadas antes de ver los resultados)

1. Registros que no se pueden leer o sin las 12 derivaciones: excluidos y contados.
2. **Duplicados exactos** de la señal respecto de cualquier registro de entrenamiento, validación o prueba de 2020 (comparación del SHA-256 de la
   señal cruda): excluidos y contados.
3. Registros sin ninguna de las 12 clases: se **mantienen** como negativos de todas las clases y se informa también el resultado sin ellos.
4. No se excluye ningún registro por el valor de la predicción ni por su etiqueta.

## 6. Métricas

- **Principal:** F1 macro del sistema principal sobre las clases evaluables, por fuente y agregada, con IC del 95 % por *bootstrap* de percentiles
  (1 000 remuestreos de registros, semilla 0, los mismos remuestreos para todos los sistemas).
- **Secundarias:** AUROC macro y AUPRC macro sobre las clases evaluables; coincidencia exacta; ECE (15 intervalos) y Brier del sistema principal;
  resultados por clase; todo por fuente y agregado; también el F1 macro sin máscara de evaluabilidad (todas las clases), por transparencia.
- **Comparación con la referencia:** diferencia pareada del F1 macro y del AUROC macro entre el sistema principal y la CNN, y entre el principal y
  v2, con IC por *bootstrap* pareado. Son comparaciones confirmatorias porque ambos sistemas están en este protocolo.
- Redondeo: dos decimales (tres solo para el F1 macro principal y su IC y para diferencias menores de 0.1).

## 7. Dependencia entre registros

Las fichas no indican identificador de paciente. Se asume un ECG por paciente (los recuentos de ECG y de pacientes de `ecg-arrhythmia`
coinciden, pero no se afirma) y el IC se calcula por registro. Si la auditoría de T10 identifica varios ECG por paciente, el IC se calcula por
clústeres de paciente y el cambio se anota como desviación.

## 8. Reglas de ejecución

- **Una sola evaluación.** Se registra la fecha y el SHA-256 de cada archivo de predicciones y de métricas.
- El resultado se reporta **sea cual sea**: no hay un F1 mínimo que lo haga válido ni uno que lo invalide.
- Ninguna decisión de diseño (receta, calibración, umbrales, punto de operación, clases, exclusiones) se cambia tras ver el resultado. Lo que se
  pruebe después se etiqueta como exploratorio.
- Las predicciones por registro se conservan y se publican con el paquete de reproducibilidad (T17).

## 9. Lo que este protocolo no resuelve

No separa pacientes dentro de cada fuente externa (sin identificadores), no revisa las etiquetas con cardiólogos, no mide variabilidad entre
semillas de entrenamiento (aplazada, T15) y no valida el uso clínico.
