# Desviaciones del protocolo externo T19

Cada desviación se anota aquí con fecha, motivo y sistemas afectados, que pasan a exploratorios si cambia lo que se mide o se decide. La numeración continúa la de
`protocolo_t19_desviaciones.md` (la 5 fue la ampliación de las semillas).

## 6. Recalibración local en Chapman-Shaoxing y Ningbo (E13, 2026-11-01)

- **Qué es y por qué:** el protocolo (§7 y §8) deja la recalibración local fuera del resultado confirmatorio y la autoriza **después** de registrarlo. El resultado de la etapa 7 ya está registrado
  (`protocolo_externo_t19_registro.md`): el F1 macro cae unos 0.27 a 0.29 respecto de A y `SB` y `STach` tienen buen AUROC pero sensibilidad cercana a 0.5, de modo que parte de la caída parece ser del
  punto de operación (umbrales y calibración fijados en otra institución). Por orden del usuario (maximizar el F1 y reducir falsos negativos y positivos) se mide cuánto se recupera con etiquetas locales.
- **Es exploratoria.** Usa etiquetas de C y D para ajustar parámetros, así que no es una evaluación independiente y **no cambia el titular**: el resultado confirmatorio es el de la etapa 7 (sistemas congelados).
  No se elige con ella un sistema principal nuevo. Los resultados se informan sea cual sea el sentido.
- **Sistemas:** los 10 originales de la etapa 7 (P1, P2, P3, P1m, P2m, P3m, CNN, P1t, P2t, P3t). No se usan las semillas 101 a 109. Parten de sus probabilidades finales ya guardadas
  (`predictions_test.csv` de `_C` y `_D`, con su SHA-256 registrado); no hay GPU ni reentrenamiento.
- **Variantes** (por clase, sobre las 12 columnas; después las métricas se calculan solo sobre las clases evaluables de cada origen, como en la etapa 7):
  - **V0:** sistema congelado (la etapa 7, sin cambios).
  - **V1, solo umbrales:** la calibración no cambia y el umbral de cada clase se vuelve a elegir para maximizar el F1 (β = 1) con la misma malla del proyecto (0.01 a 0.99, paso 0.01, `best_threshold_fbeta`).
  - **V2, calibración y umbrales:** además, la probabilidad se recalibra con una función afín por clase, `sigmoid(a·logit(p) + b)`, ajustada con `ecg.calibration.fit_platt_per_class` (mínima NLL, pendiente entre 0.05 y 10, sesgo entre −20 y 20); como parte de probabilidades ya calibradas
    de forma afín, la composición es otra función afín de los logits originales. Después se vuelven a elegir los umbrales sobre las probabilidades recalibradas.
  - **Regla por clase:** si el conjunto de ajuste tiene menos de 10 positivos o menos de 10 negativos de esa clase, la clase conserva sus parámetros y su umbral congelados (V0).
- **Esquema (ajuste y medición sobre registros distintos):** *cross-fit* de dos mitades. Los registros de cada origen se reparten al azar en dos mitades X e Y (semilla 0, sin estratificar; no hay identificador de paciente). Se ajusta con X y se predice Y, y a la inversa; así cada registro se predice
  **una vez, fuera de muestra**, y se mide sobre los n registros del origen. Para ver la estabilidad se repite con las semillas de partición 1, 2, 3 y 4 (valores puntuales, media ± desviación típica).
- **Métricas:** F1 macro (titular de la exploración), F1 micro y ponderado, sensibilidad y precisión macro, AUROC y AUPRC macro (V1 no los cambia; V2 tampoco el AUROC, por ser una transformación creciente), ECE y Brier, y los falsos negativos y falsos positivos totales
  sobre las clases evaluables por cada 1 000 registros. IC del 95 % por *bootstrap* de percentiles, 1 000 remuestreos con semilla 0 (los mismos de la etapa 7), solo para la partición de semilla 0; diferencias V1 menos V0 y V2 menos V0 pareadas. Por clase, solo para P3.
- **Curva de etiquetas locales (solo P3):** con la partición de semilla 0, se ajusta V2 con 100, 300, 1 000 y 3 000 registros de la mitad X (muestras aleatorias, 5 repeticiones con semillas 0 a 4) y con toda la mitad X, y se mide siempre sobre la mitad Y completa. Informa cuántos registros locales hacen falta; media ± desviación típica.
- **Comprobaciones:** cada registro queda fuera de muestra exactamente una vez; las métricas de V0 coinciden con las de la etapa 7 (`t19_etapa7/metricas_globales.csv`) a 1e-9.
- **Qué afecta:** nada del resultado confirmatorio. Todo lo de E13 se presenta como exploratorio y dice que se ajustó con etiquetas de la propia institución.
- **Límites que ya se conocen:** sin identificador de paciente, un mismo paciente podría caer en las dos mitades y favorecer a V1 y V2; los ajustes con pocos positivos son inestables; el F1 recuperado depende de cuántas etiquetas locales haya y no se puede obtener sin ellas.

## 7. Análisis exploratorios para acotar limitaciones declaradas (2026-11-11)

- **Qué es y por qué:** por orden del usuario se atacan, sin reentrenar, las limitaciones del artículo que se resuelven solo con cálculo: el ECE sin intervalo (limitación 5),
  los análisis no repetidos con los modelos reentrenados (limitación 8: sexo y edad, interferencia de red, robustez del sistema principal con varios sorteos e intervalos, varias ventanas por registro),
  la consistencia de la webapp con registros largos (limitación 11) y los casi duplicados de C y D (limitación 7).
- **Es exploratoria.** Se decide después de ver todos los resultados (A, B, C y D). No cambia ningún sistema, calibración, umbral, exclusión ni el titular; los resultados se informan sea cual sea su sentido.
  Parte de las predicciones congeladas de P3 (`predictions_test.csv` de `p3_A|B|C|D`, comprobadas contra su SHA-256) o vuelve a correr P3 tal como se evaluó (mismos pesos, calibraciones y umbrales,
  comprobando que la condición limpia reproduce esas predicciones).
- **Qué se hace:**
  - `tesis/scripts/limitaciones_cpu.py`: (a) ECE de P3 con el sesgo del remuestreo corregido (2·ECE − media de los remuestreos, con el intervalo bootstrap básico) y la prueba de consistencia de Bröcker y Smith
    (1 000 conjuntos de etiquetas sorteadas con las propias probabilidades, semilla 1): media y percentil 95 del ECE que tendría un sistema perfectamente calibrado con esos registros; (b) P3 por sexo y por edad
    (< 50, 50 a 64, 65 a 79, 80 o más años) con los 1 000 remuestreos de semilla 0 y las diferencias mujer menos hombre y 80 o más menos < 50.
  - `tesis/scripts/limitaciones_gpu.py` y `limitaciones_resumen_gpu.py`: robustez de P3 en A, B, C y D con las perturbaciones de `robustness.py` más interferencia de red de 50 y 60 Hz (0.1 y 0.3 mV nominales,
    atenuadas por el pasa-banda), 3 sorteos por nivel aleatorio e IC pareado del cambio de F1 macro del sorteo 0; y, en los registros de A y B de más de 10 s, la media de hasta 4 ventanas (la cadena de la webapp) frente a la ventana centrada evaluada.
  - `tesis/scripts/casi_duplicados_externa.py`: pares de C y D con similitud del coseno ≥ 0.99 (umbral fijado antes de mirar) entre huellas de 12 × 100 puntos, dentro de C y D y frente al Challenge 2020, y P3 sin esos registros.
- **Salidas:** `tesis/evidencia/limitaciones/` (las probabilidades perturbadas quedan en `runs/t19/limitaciones/`, no versionado).
- **Límites:** la interferencia se modela como una sinusoide de fase aleatoria por derivación sumada tras el filtro con su ganancia en régimen permanente; las huellas no detectan copias recortadas o desplazadas en el tiempo;
  los subgrupos de edad y sexo no se pensaron antes de ver las pruebas y varias comparaciones se hacen a la vez, sin corrección por multiplicidad.
