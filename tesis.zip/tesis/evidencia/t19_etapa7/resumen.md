# Etapa 7 de T19: evaluación externa en Chapman-Shaoxing y Ningbo

Según `protocolo_externo_t19.md`. IC del 95 % por bootstrap de percentiles (1000 remuestreos de registros, semilla 0, los mismos para todos los sistemas de un origen); el ECE va sin IC. Las métricas agregadas se calculan solo sobre las clases evaluables de cada origen (C: 11, sin LVH; D: 12). Valores con tres decimales. Generado por `scripts/analizar_t19.py`; el detalle por sistema y clase está en los CSV de esta carpeta.

## Chapman-Shaoxing (C) (n = 10 234)

| Sistema | F1 macro (IC95) | AUROC macro | AUPRC macro | ECE | Brier |
|---|---|---|---|---|---|
| P1 | 0.512 (0.504 a 0.520) | 0.863 (0.857 a 0.868) | 0.596 (0.587 a 0.607) | 0.085 | 0.087 (0.086 a 0.088) |
| P2 | 0.449 (0.441 a 0.457) | 0.821 (0.816 a 0.826) | 0.489 (0.480 a 0.500) | 0.089 | 0.103 (0.102 a 0.104) |
| P3 | 0.491 (0.482 a 0.499) | 0.862 (0.857 a 0.867) | 0.576 (0.566 a 0.587) | 0.082 | 0.090 (0.089 a 0.091) |
| P1m | 0.534 (0.525 a 0.542) | 0.863 (0.857 a 0.867) | 0.583 (0.574 a 0.595) | 0.081 | 0.081 (0.080 a 0.082) |
| P2m | 0.513 (0.505 a 0.520) | 0.831 (0.825 a 0.836) | 0.517 (0.509 a 0.528) | 0.079 | 0.088 (0.087 a 0.090) |
| P3m | 0.536 (0.527 a 0.544) | 0.865 (0.860 a 0.869) | 0.579 (0.570 a 0.591) | 0.075 | 0.079 (0.078 a 0.080) |
| CNN | 0.506 (0.497 a 0.513) | 0.857 (0.852 a 0.862) | 0.564 (0.555 a 0.574) | 0.083 | 0.092 (0.090 a 0.093) |
| P1t | 0.513 (0.505 a 0.522) | 0.863 (0.857 a 0.868) | 0.596 (0.586 a 0.606) | 0.133 | 0.105 (0.104 a 0.106) |
| P2t | 0.480 (0.472 a 0.488) | 0.821 (0.816 a 0.826) | 0.485 (0.477 a 0.496) | 0.127 | 0.116 (0.114 a 0.117) |
| P3t | 0.516 (0.507 a 0.524) | 0.863 (0.858 a 0.867) | 0.586 (0.576 a 0.596) | 0.127 | 0.099 (0.098 a 0.100) |

- P3, F1 macro, sin registros sin clase (n = 10 216): 0.491 (0.482 a 0.499)
- P3, F1 macro, 12 clases (diagnóstico) (n = 10 234): 0.454 (0.445 a 0.462)
- P3, F1 macro, sin duplicados discordantes (n = 10 208): 0.491 (0.482 a 0.499)

## Ningbo (D) (n = 34 830)

| Sistema | F1 macro (IC95) | AUROC macro | AUPRC macro | ECE | Brier |
|---|---|---|---|---|---|
| P1 | 0.460 (0.455 a 0.465) | 0.857 (0.854 a 0.859) | 0.546 (0.540 a 0.552) | 0.086 | 0.088 (0.087 a 0.088) |
| P2 | 0.433 (0.428 a 0.438) | 0.824 (0.821 a 0.827) | 0.473 (0.469 a 0.479) | 0.085 | 0.098 (0.097 a 0.099) |
| P3 | 0.462 (0.457 a 0.467) | 0.859 (0.856 a 0.861) | 0.542 (0.536 a 0.548) | 0.079 | 0.088 (0.087 a 0.089) |
| P1m | 0.504 (0.500 a 0.509) | 0.863 (0.860 a 0.865) | 0.552 (0.546 a 0.558) | 0.082 | 0.081 (0.080 a 0.082) |
| P2m | 0.493 (0.489 a 0.498) | 0.843 (0.840 a 0.846) | 0.502 (0.497 a 0.509) | 0.079 | 0.086 (0.085 a 0.087) |
| P3m | 0.514 (0.510 a 0.518) | 0.869 (0.866 a 0.871) | 0.558 (0.552 a 0.565) | 0.075 | 0.079 (0.078 a 0.079) |
| CNN | 0.471 (0.466 a 0.476) | 0.857 (0.854 a 0.860) | 0.525 (0.519 a 0.531) | 0.080 | 0.090 (0.089 a 0.090) |
| P1t | 0.463 (0.459 a 0.468) | 0.857 (0.854 a 0.859) | 0.545 (0.540 a 0.552) | 0.138 | 0.109 (0.108 a 0.109) |
| P2t | 0.462 (0.458 a 0.467) | 0.824 (0.821 a 0.827) | 0.471 (0.466 a 0.477) | 0.130 | 0.113 (0.112 a 0.113) |
| P3t | 0.476 (0.471 a 0.481) | 0.860 (0.858 a 0.863) | 0.550 (0.544 a 0.556) | 0.128 | 0.099 (0.098 a 0.100) |

- P3, F1 macro, sin registros sin clase (n = 34 697): 0.463 (0.458 a 0.467)
- P3, F1 macro, sin duplicados discordantes (n = 34 830): 0.462 (0.457 a 0.467)

## Semillas: media y desviación típica entre las 10 semillas de cada receta

| Prueba | Métrica | P1 | P2 | P3 (ensemble) |
|---|---|---|---|---|
| C | f1_macro | 0.491 ± 0.023 (0.455 a 0.532) | 0.446 ± 0.024 (0.422 a 0.502) | 0.478 ± 0.017 (0.455 a 0.508) |
| C | f1_micro | 0.550 ± 0.023 (0.516 a 0.589) | 0.512 ± 0.022 (0.485 a 0.546) | 0.545 ± 0.015 (0.528 a 0.568) |
| C | f1_ponderado | 0.552 ± 0.032 (0.497 a 0.604) | 0.505 ± 0.028 (0.466 a 0.550) | 0.541 ± 0.018 (0.519 a 0.569) |
| C | exacta | 0.207 ± 0.011 (0.190 a 0.220) | 0.209 ± 0.012 (0.193 a 0.223) | 0.222 ± 0.010 (0.209 a 0.238) |
| C | auroc_macro | 0.856 ± 0.011 (0.840 a 0.870) | 0.823 ± 0.016 (0.803 a 0.862) | 0.858 ± 0.009 (0.844 a 0.870) |
| C | auprc_macro | 0.588 ± 0.018 (0.560 a 0.622) | 0.508 ± 0.029 (0.483 a 0.584) | 0.582 ± 0.012 (0.561 a 0.599) |
| C | ece | 0.084 ± 0.002 (0.080 a 0.087) | 0.088 ± 0.004 (0.076 a 0.091) | 0.082 ± 0.002 (0.076 a 0.084) |
| C | brier | 0.087 ± 0.002 (0.083 a 0.089) | 0.101 ± 0.005 (0.089 a 0.105) | 0.089 ± 0.002 (0.085 a 0.091) |
| D | f1_macro | 0.459 ± 0.019 (0.430 a 0.496) | 0.428 ± 0.028 (0.402 a 0.498) | 0.456 ± 0.018 (0.431 a 0.489) |
| D | f1_micro | 0.524 ± 0.020 (0.496 a 0.564) | 0.501 ± 0.022 (0.475 a 0.535) | 0.527 ± 0.014 (0.513 a 0.546) |
| D | f1_ponderado | 0.530 ± 0.027 (0.485 a 0.576) | 0.499 ± 0.028 (0.462 a 0.547) | 0.528 ± 0.017 (0.511 a 0.553) |
| D | exacta | 0.192 ± 0.009 (0.178 a 0.203) | 0.203 ± 0.011 (0.186 a 0.216) | 0.212 ± 0.010 (0.198 a 0.229) |
| D | auroc_macro | 0.852 ± 0.011 (0.835 a 0.866) | 0.825 ± 0.017 (0.800 a 0.864) | 0.856 ± 0.010 (0.842 a 0.868) |
| D | auprc_macro | 0.545 ± 0.021 (0.513 a 0.583) | 0.489 ± 0.032 (0.463 a 0.576) | 0.549 ± 0.016 (0.527 a 0.576) |
| D | ece | 0.083 ± 0.003 (0.078 a 0.086) | 0.086 ± 0.004 (0.076 a 0.089) | 0.079 ± 0.002 (0.075 a 0.081) |
| D | brier | 0.086 ± 0.002 (0.081 a 0.089) | 0.097 ± 0.004 (0.086 a 0.101) | 0.087 ± 0.002 (0.083 a 0.090) |

## Ensemble menos mejor receta individual, por semilla

Positivo = el ensemble es mejor (en ECE y Brier, mejor individual menos ensemble). Prueba de signos exacta y bilateral sobre las 10 semillas (p mínimo 0.0020); sin corrección por comparaciones múltiples.

| Prueba | Métrica | Semillas con mejora | Valor p | Mejora media ± desviación |
|---|---|---|---|---|
| C | f1_macro | 1 de 10 | 0.021 | -0.016 ± 0.015 |
| C | f1_micro | 5 de 10 | 1.000 | -0.006 ± 0.019 |
| C | f1_ponderado | 3 de 10 | 0.344 | -0.013 ± 0.026 |
| C | exacta | 8 de 10 | 0.109 | 0.008 ± 0.011 |
| C | auroc_macro | 4 de 10 | 0.754 | -0.000 ± 0.003 |
| C | auprc_macro | 2 de 10 | 0.109 | -0.008 ± 0.012 |
| C | ece | 8 de 10 | 0.109 | 0.002 ± 0.002 |
| C | brier | 1 de 10 | 0.021 | -0.002 ± 0.002 |
| D | f1_macro | 5 de 10 | 1.000 | -0.007 ± 0.013 |
| D | f1_micro | 7 de 10 | 0.344 | 0.001 ± 0.020 |
| D | f1_ponderado | 5 de 10 | 1.000 | -0.004 ± 0.026 |
| D | exacta | 9 de 10 | 0.021 | 0.008 ± 0.012 |
| D | auroc_macro | 6 de 10 | 0.754 | 0.002 ± 0.003 |
| D | auprc_macro | 6 de 10 | 0.754 | -0.001 ± 0.008 |
| D | ece | 9 de 10 | 0.021 | 0.004 ± 0.002 |
| D | brier | 2 de 10 | 0.109 | -0.001 ± 0.002 |

## P3: prueba de referencia (A o B) menos prueba externa (no pareada)

| Referencia | Externa | Métrica | Referencia | Externa | Diferencia (IC95) |
|---|---|---|---|---|---|
| A | C | f1_macro | 0.764 | 0.491 | 0.274 (0.259 a 0.288) |
| A | C | f1_micro | 0.813 | 0.564 | 0.249 (0.240 a 0.258) |
| A | C | exacta | 0.542 | 0.230 | 0.312 (0.295 a 0.328) |
| A | C | auroc_macro | 0.958 | 0.862 | 0.096 (0.090 a 0.102) |
| A | C | auprc_macro | 0.817 | 0.576 | 0.241 (0.225 a 0.257) |
| A | C | ece | 0.011 | 0.082 | -0.072 |
| A | C | brier | 0.045 | 0.090 | -0.045 (-0.047 a -0.043) |
| A | D | f1_macro | 0.752 | 0.462 | 0.290 (0.278 a 0.302) |
| A | D | f1_micro | 0.803 | 0.545 | 0.258 (0.251 a 0.266) |
| A | D | exacta | 0.510 | 0.219 | 0.291 (0.276 a 0.306) |
| A | D | auroc_macro | 0.955 | 0.859 | 0.097 (0.093 a 0.101) |
| A | D | auprc_macro | 0.807 | 0.542 | 0.265 (0.252 a 0.279) |
| A | D | ece | 0.011 | 0.079 | -0.068 |
| A | D | brier | 0.045 | 0.088 | -0.043 (-0.045 a -0.041) |
| B | C | f1_macro | 0.524 | 0.491 | 0.034 (0.022 a 0.045) |
| B | C | f1_micro | 0.523 | 0.564 | -0.041 (-0.050 a -0.032) |
| B | C | exacta | 0.210 | 0.230 | -0.020 (-0.031 a -0.009) |
| B | C | auroc_macro | 0.834 | 0.862 | -0.028 (-0.035 a -0.022) |
| B | C | auprc_macro | 0.591 | 0.576 | 0.015 (0.001 a 0.027) |
| B | C | ece | 0.085 | 0.082 | 0.002 |
| B | C | brier | 0.105 | 0.090 | 0.016 (0.014 a 0.017) |
| B | D | f1_macro | 0.500 | 0.462 | 0.039 (0.030 a 0.047) |
| B | D | f1_micro | 0.502 | 0.545 | -0.043 (-0.050 a -0.035) |
| B | D | exacta | 0.177 | 0.219 | -0.042 (-0.050 a -0.033) |
| B | D | auroc_macro | 0.829 | 0.859 | -0.029 (-0.034 a -0.025) |
| B | D | auprc_macro | 0.586 | 0.542 | 0.045 (0.035 a 0.054) |
| B | D | ece | 0.092 | 0.079 | 0.013 |
| B | D | brier | 0.111 | 0.088 | 0.023 (0.022 a 0.025) |

## Diferencias pareadas (a menos b), P3 y variantes

| Prueba | Comparación | Métrica | Diferencia (IC95) | Remuestreos con diferencia > 0 |
|---|---|---|---|---|
| C | P3 menos P1 | f1_macro | -0.022 (-0.028 a -0.016) | 0.000 |
| C | P3 menos P1 | f1_micro | -0.009 (-0.014 a -0.004) | 0.001 |
| C | P3 menos P1 | auroc_macro | -0.001 (-0.003 a 0.002) | 0.307 |
| C | P3 menos P1 | auprc_macro | -0.020 (-0.025 a -0.015) | 0.000 |
| C | P3 menos P1 | ece | -0.003 | 0.000 |
| C | P3 menos P1 | brier | 0.002 (0.002 a 0.003) | 1.000 |
| C | P3 menos P2 | f1_macro | 0.041 (0.037 a 0.046) | 1.000 |
| C | P3 menos P2 | f1_micro | 0.047 (0.043 a 0.051) | 1.000 |
| C | P3 menos P2 | auroc_macro | 0.041 (0.037 a 0.044) | 1.000 |
| C | P3 menos P2 | auprc_macro | 0.088 (0.082 a 0.092) | 1.000 |
| C | P3 menos P2 | ece | -0.006 | 0.000 |
| C | P3 menos P2 | brier | -0.014 (-0.014 a -0.013) | 0.000 |
| C | P2 menos P1 | f1_macro | -0.063 (-0.071 a -0.056) | 0.000 |
| C | P2 menos P1 | f1_micro | -0.056 (-0.062 a -0.049) | 0.000 |
| C | P2 menos P1 | auroc_macro | -0.041 (-0.046 a -0.036) | 0.000 |
| C | P2 menos P1 | auprc_macro | -0.108 (-0.116 a -0.099) | 0.000 |
| C | P2 menos P1 | ece | 0.003 | 1.000 |
| C | P2 menos P1 | brier | 0.016 (0.015 a 0.017) | 1.000 |
| C | CNN menos P1 | f1_macro | -0.007 (-0.015 a 0.001) | 0.041 |
| C | CNN menos P1 | f1_micro | -0.036 (-0.043 a -0.030) | 0.000 |
| C | CNN menos P1 | auroc_macro | -0.006 (-0.010 a -0.001) | 0.003 |
| C | CNN menos P1 | auprc_macro | -0.032 (-0.040 a -0.024) | 0.000 |
| C | CNN menos P1 | ece | -0.003 | 0.000 |
| C | CNN menos P1 | brier | 0.004 (0.004 a 0.005) | 1.000 |
| C | CNN menos P3 | f1_macro | 0.015 (0.007 a 0.024) | 1.000 |
| C | CNN menos P3 | f1_micro | -0.028 (-0.034 a -0.021) | 0.000 |
| C | CNN menos P3 | auroc_macro | -0.005 (-0.009 a -0.001) | 0.009 |
| C | CNN menos P3 | auprc_macro | -0.012 (-0.020 a -0.004) | 0.005 |
| C | CNN menos P3 | ece | 0.000 | 0.703 |
| C | CNN menos P3 | brier | 0.002 (0.001 a 0.003) | 1.000 |
| C | P1m menos P1 | f1_macro | 0.021 (0.015 a 0.027) | 1.000 |
| C | P1m menos P1 | f1_micro | 0.041 (0.036 a 0.046) | 1.000 |
| C | P1m menos P1 | auroc_macro | 0.000 (-0.003 a 0.003) | 0.507 |
| C | P1m menos P1 | auprc_macro | -0.013 (-0.018 a -0.006) | 0.000 |
| C | P1m menos P1 | ece | -0.004 | 0.000 |
| C | P1m menos P1 | brier | -0.006 (-0.007 a -0.006) | 0.000 |
| C | P2m menos P2 | f1_macro | 0.064 (0.057 a 0.071) | 1.000 |
| C | P2m menos P2 | f1_micro | 0.095 (0.089 a 0.101) | 1.000 |
| C | P2m menos P2 | auroc_macro | 0.010 (0.005 a 0.015) | 1.000 |
| C | P2m menos P2 | auprc_macro | 0.028 (0.021 a 0.035) | 1.000 |
| C | P2m menos P2 | ece | -0.010 | 0.000 |
| C | P2m menos P2 | brier | -0.015 (-0.016 a -0.014) | 0.000 |
| C | P3m menos P3 | f1_macro | 0.045 (0.039 a 0.052) | 1.000 |
| C | P3m menos P3 | f1_micro | 0.083 (0.078 a 0.088) | 1.000 |
| C | P3m menos P3 | auroc_macro | 0.003 (-0.000 a 0.006) | 0.965 |
| C | P3m menos P3 | auprc_macro | 0.003 (-0.003 a 0.009) | 0.866 |
| C | P3m menos P3 | ece | -0.007 | 0.000 |
| C | P3m menos P3 | brier | -0.010 (-0.011 a -0.010) | 0.000 |
| C | P1 menos P1t | f1_macro | -0.001 (-0.003 a 0.000) | 0.059 |
| C | P1 menos P1t | f1_micro | -0.003 (-0.005 a -0.002) | 0.000 |
| C | P1 menos P1t | auroc_macro | -0.000 (-0.000 a 0.000) | 0.307 |
| C | P1 menos P1t | auprc_macro | 0.000 (-0.000 a 0.001) | 0.973 |
| C | P1 menos P1t | ece | -0.048 | 0.000 |
| C | P1 menos P1t | brier | -0.018 (-0.018 a -0.017) | 0.000 |
| C | P2 menos P2t | f1_macro | -0.031 (-0.034 a -0.028) | 0.000 |
| C | P2 menos P2t | f1_micro | -0.050 (-0.054 a -0.047) | 0.000 |
| C | P2 menos P2t | auroc_macro | 0.000 (0.000 a 0.000) | 1.000 |
| C | P2 menos P2t | auprc_macro | 0.003 (0.002 a 0.005) | 1.000 |
| C | P2 menos P2t | ece | -0.038 | 0.000 |
| C | P2 menos P2t | brier | -0.012 (-0.014 a -0.011) | 0.000 |
| C | P3 menos P3t | f1_macro | -0.025 (-0.030 a -0.020) | 0.000 |
| C | P3 menos P3t | f1_micro | -0.020 (-0.023 a -0.017) | 0.000 |
| C | P3 menos P3t | auroc_macro | -0.001 (-0.002 a 0.000) | 0.076 |
| C | P3 menos P3t | auprc_macro | -0.009 (-0.012 a -0.006) | 0.000 |
| C | P3 menos P3t | ece | -0.045 | 0.000 |
| C | P3 menos P3t | brier | -0.009 (-0.010 a -0.008) | 0.000 |
| D | P3 menos P1 | f1_macro | 0.002 (-0.001 a 0.005) | 0.854 |
| D | P3 menos P1 | f1_micro | 0.012 (0.010 a 0.015) | 1.000 |
| D | P3 menos P1 | auroc_macro | 0.002 (0.001 a 0.003) | 1.000 |
| D | P3 menos P1 | auprc_macro | -0.004 (-0.007 a -0.002) | 0.001 |
| D | P3 menos P1 | ece | -0.007 | 0.000 |
| D | P3 menos P1 | brier | 0.000 (0.000 a 0.001) | 0.994 |
| D | P3 menos P2 | f1_macro | 0.029 (0.026 a 0.032) | 1.000 |
| D | P3 menos P2 | f1_micro | 0.032 (0.030 a 0.035) | 1.000 |
| D | P3 menos P2 | auroc_macro | 0.035 (0.033 a 0.037) | 1.000 |
| D | P3 menos P2 | auprc_macro | 0.068 (0.065 a 0.071) | 1.000 |
| D | P3 menos P2 | ece | -0.006 | 0.000 |
| D | P3 menos P2 | brier | -0.010 (-0.010 a -0.010) | 0.000 |
| D | P2 menos P1 | f1_macro | -0.027 (-0.031 a -0.023) | 0.000 |
| D | P2 menos P1 | f1_micro | -0.020 (-0.023 a -0.017) | 0.000 |
| D | P2 menos P1 | auroc_macro | -0.033 (-0.035 a -0.030) | 0.000 |
| D | P2 menos P1 | auprc_macro | -0.073 (-0.076 a -0.068) | 0.000 |
| D | P2 menos P1 | ece | -0.000 | 0.184 |
| D | P2 menos P1 | brier | 0.011 (0.010 a 0.011) | 1.000 |
| D | CNN menos P1 | f1_macro | 0.011 (0.007 a 0.016) | 1.000 |
| D | CNN menos P1 | f1_micro | -0.018 (-0.021 a -0.014) | 0.000 |
| D | CNN menos P1 | auroc_macro | 0.000 (-0.002 a 0.003) | 0.656 |
| D | CNN menos P1 | auprc_macro | -0.021 (-0.026 a -0.016) | 0.000 |
| D | CNN menos P1 | ece | -0.006 | 0.000 |
| D | CNN menos P1 | brier | 0.002 (0.002 a 0.002) | 1.000 |
| D | CNN menos P3 | f1_macro | 0.010 (0.005 a 0.014) | 1.000 |
| D | CNN menos P3 | f1_micro | -0.030 (-0.034 a -0.026) | 0.000 |
| D | CNN menos P3 | auroc_macro | -0.002 (-0.004 a 0.001) | 0.115 |
| D | CNN menos P3 | auprc_macro | -0.017 (-0.022 a -0.012) | 0.000 |
| D | CNN menos P3 | ece | 0.001 | 1.000 |
| D | CNN menos P3 | brier | 0.002 (0.001 a 0.002) | 1.000 |
| D | P1m menos P1 | f1_macro | 0.044 (0.040 a 0.048) | 1.000 |
| D | P1m menos P1 | f1_micro | 0.054 (0.051 a 0.057) | 1.000 |
| D | P1m menos P1 | auroc_macro | 0.006 (0.004 a 0.008) | 1.000 |
| D | P1m menos P1 | auprc_macro | 0.006 (0.002 a 0.009) | 0.999 |
| D | P1m menos P1 | ece | -0.004 | 0.000 |
| D | P1m menos P1 | brier | -0.007 (-0.007 a -0.006) | 0.000 |
| D | P2m menos P2 | f1_macro | 0.060 (0.056 a 0.065) | 1.000 |
| D | P2m menos P2 | f1_micro | 0.079 (0.076 a 0.083) | 1.000 |
| D | P2m menos P2 | auroc_macro | 0.019 (0.016 a 0.022) | 1.000 |
| D | P2m menos P2 | auprc_macro | 0.029 (0.025 a 0.033) | 1.000 |
| D | P2m menos P2 | ece | -0.006 | 0.000 |
| D | P2m menos P2 | brier | -0.012 (-0.013 a -0.012) | 0.000 |
| D | P3m menos P3 | f1_macro | 0.052 (0.049 a 0.056) | 1.000 |
| D | P3m menos P3 | f1_micro | 0.077 (0.074 a 0.080) | 1.000 |
| D | P3m menos P3 | auroc_macro | 0.010 (0.008 a 0.012) | 1.000 |
| D | P3m menos P3 | auprc_macro | 0.016 (0.013 a 0.020) | 1.000 |
| D | P3m menos P3 | ece | -0.004 | 0.000 |
| D | P3m menos P3 | brier | -0.009 (-0.009 a -0.009) | 0.000 |
| D | P1 menos P1t | f1_macro | -0.003 (-0.004 a -0.002) | 0.000 |
| D | P1 menos P1t | f1_micro | -0.006 (-0.006 a -0.005) | 0.000 |
| D | P1 menos P1t | auroc_macro | -0.000 (-0.000 a 0.000) | 0.460 |
| D | P1 menos P1t | auprc_macro | 0.001 (0.000 a 0.001) | 1.000 |
| D | P1 menos P1t | ece | -0.052 | 0.000 |
| D | P1 menos P1t | brier | -0.021 (-0.021 a -0.021) | 0.000 |
| D | P2 menos P2t | f1_macro | -0.029 (-0.031 a -0.028) | 0.000 |
| D | P2 menos P2t | f1_micro | -0.047 (-0.049 a -0.045) | 0.000 |
| D | P2 menos P2t | auroc_macro | 0.000 (0.000 a 0.000) | 1.000 |
| D | P2 menos P2t | auprc_macro | 0.002 (0.002 a 0.003) | 1.000 |
| D | P2 menos P2t | ece | -0.045 | 0.000 |
| D | P2 menos P2t | brier | -0.015 (-0.015 a -0.014) | 0.000 |
| D | P3 menos P3t | f1_macro | -0.015 (-0.017 a -0.012) | 0.000 |
| D | P3 menos P3t | f1_micro | -0.015 (-0.017 a -0.014) | 0.000 |
| D | P3 menos P3t | auroc_macro | -0.002 (-0.002 a -0.001) | 0.000 |
| D | P3 menos P3t | auprc_macro | -0.008 (-0.010 a -0.006) | 0.000 |
| D | P3 menos P3t | ece | -0.049 | 0.000 |
| D | P3 menos P3t | brier | -0.011 (-0.012 a -0.011) | 0.000 |
