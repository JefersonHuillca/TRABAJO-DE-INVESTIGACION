# Limitaciones acotadas sin reentrenar (desviación 7, exploratorio, 2026-11-11)

Todo es exploratorio: se hizo después de ver A, B, C y D, no cambia ningún sistema, calibración, umbral ni el titular. Sistema: P3. En C y D, clases evaluables.
Al volver a correr P3 en la GPU, la condición limpia reproduce `predictions_test.csv` de A, B, C y D con diferencia 0 y 0 decisiones distintas.

| Limitación | Script | Resultado |
|---|---|---|
| 5 (ECE sin IC) | `limitaciones_cpu.py` | Ver tabla del ECE. En A el ECE corregido (0.008) es del tamaño del de un sistema perfectamente calibrado con esos registros (0.008); en B, C y D (0.08 a 0.09) es de 13 a 25 veces ese nivel. |
| 8 (sexo y edad) | `limitaciones_cpu.py` | Sin diferencia por sexo en A ni en B; en C y D, F1 macro de las mujeres 0.026 y 0.024 menor (IC excluye 0), AUROC igual. Por edad el F1 sube con la edad y el AUROC baja: efecto de la prevalencia, no del sistema. |
| 8 (robustez de P3, red eléctrica) | `limitaciones_gpu.py`, `limitaciones_resumen_gpu.py` | 3 sorteos (desviación típica entre sorteos ≤ 0.004) e IC pareado. La interferencia de 50 Hz es la perturbación más dañina en A: 0.3 mV nominales bajan el F1 macro 0.226; la de 60 Hz, que el filtro atenúa más, casi no afecta. |
| 8 y 11 (varias ventanas, webapp) | idem | 1 037 registros de A de más de 10 s (B no tiene): F1 macro 0.617 con una ventana y 0.622 con la media de 1.7 ventanas de media, +0.005 (−0.007 a 0.016). Si toda A se puntuara como la webapp: 0.753 frente a 0.752 (+0.001, −0.001 a 0.004). |
| 7 (casi duplicados) | `casi_duplicados_externa.py` | Ningún par con similitud ≥ 0.99, ni dentro de C y D ni con el Challenge 2020; con ≥ 0.95, 5 pares, todos dentro de Ningbo. Las métricas de C y D no cambian. |

## ECE (15 intervalos, macro)

| Prueba | ECE | ECE corregido (IC básico) | ECE de un sistema perfectamente calibrado: media (p95) | p |
|---|---|---|---|---|
| A | 0.0105 | 0.0077 (0.0063 a 0.0092) | 0.0081 (0.0090) | 0.001 |
| B | 0.0918 | 0.0913 (0.0895 a 0.0930) | 0.0060 (0.0066) | 0.001 |
| C | 0.0823 | 0.0819 (0.0804 a 0.0834) | 0.0060 (0.0067) | 0.001 |
| D | 0.0790 | 0.0789 (0.0781 a 0.0797) | 0.0032 (0.0035) | 0.001 |

Lectura: en A la descalibración se detecta (p = 0.001), pero es del orden del ruido de estimar el ECE con 4 949 registros. En las instituciones nuevas el ECE es casi todo descalibración real; el sesgo del estimador es despreciable con muestras grandes (≤ 0.0006).

## Robustez de P3: cambio del F1 macro (media de 3 sorteos; IC del sorteo 0)

| Perturbación | A | B | C | D |
|---|---|---|---|---|
| Ruido 0.05 mV | −0.077 | +0.007 | +0.031 | +0.020 |
| Ruido 0.10 mV | −0.118 | +0.014 | +0.056 | +0.042 |
| Deriva 0.1 mV | −0.025 | −0.018 | −0.004 | −0.005 |
| Deriva 0.2 mV | −0.137 | −0.044 | −0.023 | −0.022 |
| Amplitud ×0.5 | −0.078 | −0.060 | −0.047 | −0.065 |
| Amplitud ×1.5 | −0.031 | +0.039 | +0.015 | +0.006 |
| 1 derivación apagada | −0.013 | −0.014 | −0.013 | −0.012 |
| 3 derivaciones apagadas | −0.061 | −0.033 | −0.036 | −0.036 |
| Red 50 Hz 0.1 mV | −0.068 | −0.039 | −0.021 | −0.019 |
| Red 50 Hz 0.3 mV | −0.226 | −0.084 | −0.042 | −0.043 |
| Red 60 Hz 0.1 mV | 0.000 | +0.004 | +0.003 | +0.003 |
| Red 60 Hz 0.3 mV | −0.020 | +0.001 | +0.010 | +0.006 |

F1 macro sin perturbar: A 0.752, B 0.500, C 0.491, D 0.462. Los IC del sorteo 0 están en `robustez_p3_resumen.csv`.
El ruido sube el F1 en B, C y D porque esos orígenes quedan con baja sensibilidad con los umbrales de A: el ruido empuja probabilidades hacia arriba y gana sensibilidad y precisión
(el AUROC también sube un poco, +0.01 a +0.02), no porque la señal ruidosa sea mejor. Lo mismo con la amplitud ×1.5. La ganancia del pasa-banda ida y vuelta es 0.50 a 50 Hz y 0.23 a 60 Hz:
el filtro de 0.5 a 50 Hz deja pasar la mitad de la interferencia de 50 Hz, la frecuencia de la red en China y Europa, de donde vienen A, C y D.

## Lo que sigue sin resolver

- Sexo y edad: comparaciones múltiples sin corrección y grupos de edad no preespecificados.
- La webapp no se pasó por Flask con toda A (la cadena de ventanas se reprodujo fuera de ella; en 299 registros de A la webapp y esta cadena ya coincidían).
- Casi duplicados recortados o desplazados en el tiempo no se detectan con estas huellas.
- La interferencia es una sinusoide ideal por derivación; la real tiene armónicos y amplitud variable.

## SHA-256 de las salidas

```
c99eebba4084cc50d9f5143769a1b430e1ffa791122327a3629067bd2e09de88  ece.csv
525e28cf9c53a71488dd366e407feb929e074ecd416f801bc133de126e20ad3d  subgrupos.csv
b4f5eb8e901f2af00c7bb715c2263a17a4bedcd5983a3f4cfc223b0247655837  subgrupos_diferencias.csv
81ffea8e38952ef5c08769f37f71c9b2a52e4903d7e6bb225b8eba675b4ad28f  robustez_p3.csv
5552738974075101eb4f9f6617cc10be4f25c9804de04ab21815d9c9ece5a833  robustez_p3_resumen.csv
698be18416667cdd2207e369ddac6ab9845cdaae0825bab9fbd96bdb5ca444af  ventanas.csv
c261b80a63af286a071a24bad5b10745ccd1495019edd2651fa611bf6a6bed5f  casi_duplicados.csv
6a86f230ae1346ac0bea1253fd4ee24dee916ff008df5468a76d6a741a652406  casi_duplicados_sensibilidad.csv
0006f659a73940addb49b659b6bba0d36ed073ad7f90c3c7c8ed923ff56b340a  casi_duplicados.json
```
