# Desviaciones del protocolo T19

Cada desviación se anota aquí con fecha, motivo y sistemas afectados, que pasan a exploratorios si cambia lo que se mide o se decide.

## 1. El ECE se informa sin intervalo de confianza (2026-10-27)

- **Qué dice el protocolo (§5):** IC del 95 % por *bootstrap* de percentiles para las métricas, entre ellas el ECE.
- **Qué se hace:** el ECE (15 intervalos) se informa solo como valor puntual, también en sus diferencias entre sistemas y entre pruebas. El Brier y las demás métricas
  conservan su IC. Las columnas `lo` y `hi` del ECE quedan vacías en `evidencia/t19_etapa1/`.
- **Motivo:** al calcular los IC se vio que el valor puntual del ECE de la prueba A quedaba **fuera** de su propio IC por percentiles (P1: 0.0103 frente a una media de los
  remuestreos de 0.0134; P3: 0.0105 frente a 0.0134). El ECE es una suma de valores absolutos de diferencias de medias por intervalo: el ruido del remuestreo lo hace subir cuando la
  descalibración verdadera es pequeña, de modo que el IC por percentiles no es válido para esa métrica. El Brier no tiene ese sesgo (media de los remuestreos igual al valor puntual a cuatro decimales).
- **Qué afecta:** solo la forma de presentar el ECE. No cambia ningún valor puntual, ningún umbral, ninguna calibración ni ninguna decisión; ningún sistema pasa a exploratorio.
- **Cómo se descubrió:** después de ver los resultados de la prueba A, no antes. Se anota para que conste; la medida reduce lo que se afirma, no lo amplía.

## 2. Análisis añadidos fuera de la lista del protocolo (2026-10-27)

Se calcularon, y se rotulan **descriptivos o exploratorios**, estos análisis que el protocolo no enumera: la cardinalidad de etiquetas por registro (real y predicha), la diferencia
entre la prueba A y la B (no pareada), el F1 macro enmascarado de la prueba A (diagnóstico que ya figuraba en la documentación del proyecto), la precisión, sensibilidad y especificidad macro, el AUROC
ponderado por frecuencia de clase y los IC por origen con menos de 100 registros (que no informan). Ninguno alimentó una decisión.

## 3. Lecturas descriptivas añadidas en la etapa 3 (2026-10-27)

Se calcularon, y se rotulan **descriptivas**, estas lecturas que el protocolo no enumera: el recuento por semilla de cuántas veces P2 supera a P1 en F1 macro (sin prueba de hipótesis), la posición de cada ablación dentro del rango de P1 entre las 5 semillas y el cociente de cada diferencia entre la desviación típica de P1 entre semillas. Salen de `semillas.csv`, `semillas_resumen.csv`, `metricas_globales.csv` y `diferencias_pareadas.csv` sin ningún cálculo nuevo de remuestreo. Ninguna alimentó una decisión ni cambió un análisis preespecificado.

## 4. Análisis exploratorios añadidos tras ver las pruebas A y B (2026-10-27)

Se hicieron, y se rotulan **exploratorios**, tres análisis que el protocolo no enumera, para atender las observaciones 1, 4 y 12 de la segunda revisión del asesor: (a) la calibración por temperatura de P1, P2 y su *ensemble* (etapa 4, línea base de la calibración afín), (b) la robustez de P2 ante perturbaciones de la señal, con un sorteo por nivel (etapa 5), y (c) el F1 y el AUROC macro en el subconjunto de la prueba A separado por paciente (PTB-XL y PTB). Los tres reutilizan registros de prueba ya evaluados; se hicieron después de ver los resultados de A y de B, de modo que no son preespecificados. No alimentaron ninguna decisión: no cambiaron ninguna receta, calibración, umbral ni sistema principal, y el resultado se informa tal como salió. Los comandos, las salidas y sus SHA-256 están en `protocolo_t19_registro.md`.

## 5. Ampliación de las semillas de 5 a 10 (2026-10-31)

El protocolo T19 fijaba 5 semillas por receta (la original y 101 a 104). Se amplía a 10 con las semillas 105 a 109 de v1 y v2, con la misma receta y calendario (en cada configuración solo cambia `seed`; `aug_seed` de v2 sigue en 123). El motivo es la observación 3 del asesor: con 5 semillas la prueba de signos exacta bilateral no puede dar p < 0.05 (mínimo 0.0625); con 10 el mínimo baja a unos 0.002.
- **Qué es:** una desviación del número de semillas preespecificado, decidida por el usuario el 2026-10-30 (E0.8) y ordenada el 2026-10-31. Se decide **después de ver** los resultados de A y de B de las 5 semillas anteriores, de modo que ampliar la muestra es una parada que depende de los datos.
- **Salvaguardas:** las configuraciones y sus SHA-256 se registraron antes de entrenar; las 5 semillas nuevas se entrenan y se reportan todas, sin descartar ni repetir ninguna por su resultado (solo por causa técnica, anotándolo); se reportan tanto los resultados con 5 semillas como con 10; ninguna semilla nueva cambia una receta, una calibración ni un umbral.
- **Qué afecta:** las medias, desviaciones y la prueba de signos de la etapa 3 pasan a calcularse con 10 semillas (y se conservan las de 5). Las semillas nuevas se evalúan una sola vez en A, en B y, cuando se ordene, en Chapman-Shaoxing y Ningbo.
