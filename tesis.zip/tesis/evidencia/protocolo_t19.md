# Protocolo del reentrenamiento final (T19)

Escrito el 2026-10-26, **antes** de construir los HDF5 nuevos, de entrenar nada y de mirar ninguna cifra de las particiones nuevas. Su SHA-256 queda en
`evidencia/protocolo_t19.sha256` y en el manifiesto. Cualquier cambio posterior es una **desviación**: se anota con fecha y motivo en
`evidencia/protocolo_t19_desviaciones.md` y el resultado afectado se etiqueta como exploratorio. Sustituye a las fases 2 a 5 del plan anterior; el protocolo
de la evaluación externa (anulado) no se usa.

## 1. Qué se afirma y qué no

- Se mide el sistema **principal** (recetas v1 y v2 sin cambios, ensemble afín, umbrales de F1 con β = 1 fijados en validación) en dos particiones nuevas
  de prueba. Todo lo demás (variantes enmascaradas, CNN, ablaciones, semillas) es **secundario** y está listado aquí de antemano.
- **No es una evaluación confirmatoria plena.** Las recetas, la calibración afín y el punto de operación se eligieron mirando la prueba anterior, que incluía
  parte de Georgia y de los otros orígenes. La prueba A no se usa para ninguna decisión posterior a este protocolo; la prueba B (Georgia) es independiente
  del entrenamiento y de la validación, pero no del diseño. El artículo lo dirá así.
- No se compara con los resultados del Challenge ni se usa nada del Challenge 2021.

## 2. Datos y reparto

- Registros: los 43 101 del Challenge 2020 (6 orígenes), sin descartar ninguno. Esquema `cinc2020_12_grouped_snomed_v2`, preprocesamiento de `ecg/signal.py`.
- **Prueba B:** Georgia completa (10 344 registros). No entra en entrenamiento, validación ni prueba A.
- **Reparto del resto** (`build_datasets.py --holdout-origin georgia --groups-csv data/externo/patient_groups.csv --val-frac 0.15 --test-frac 0.15 --random-state 42`):
  por origen y por grupo de paciente; PTB-XL y PTB agrupados por paciente (19 131 pacientes, 22 315 registros con grupo); CPSC 2018, CPSC-Extra e INCART por registro
  (sin identificador de paciente).
- **Tamaños esperados** (comprobados el 2026-10-26 sobre los encabezados reales): entrenamiento 22 895, validación 4 913, prueba A 4 949, prueba B 10 344.
  Si el reparto escrito no los reproduce, no se entrena.
- Grupos de paciente: `data/externo/patient_groups.csv`, SHA-256 `93380f479662b3417ff5c502f0a639109809ff98f628735aac00e0b59c6daa46`. El manifiesto del reparto
  (el `split_assignments.csv` nuevo) se hashea y se publica.
- Verificación obligatoria antes de entrenar: ningún grupo de paciente aparece en dos particiones; Georgia solo está en `test_b`.

## 3. Sistemas

| Id | Sistema | Configuración (SHA-256) | Papel |
|---|---|---|---|
| P1 | ResNet v1 | `config.json` ccae4b3ae4a58242aea00b721fe9197a49c92f63adaa8cd7875a62cd8c6237fb, semilla 42 | principal |
| P2 | ResNet v2 | `config_resnet_v2.json` c5df3a4e44c748d3259a1f1849ea8de0812819e766b02ee4a6ecff26e488998a, semilla 43, `aug_seed` 123 | principal |
| P3 | Ensemble afín α = 0.5 de P1 y P2, con recalibración afín propia | derivado de P1 y P2 | **principal** |
| S1 | P1 y P2 con `mask_unannotated: true`, `mask_min_positives: 1` (mismas semillas) y su ensemble | las mismas configuraciones más esas dos claves | secundario |
| S2 | CNN 1D convencional | `config_regular_cnn.json` b2b87ae357b04f6192d09da75e1d81d3431d2d6ac3fcdf693b75f658fe48dae4, semilla 42 | secundario (línea base) |
| S3 | Ablaciones partiendo de P1, **una a la vez**: (a) `augment: true` con `aug_seed` 123; (b) `label_smoothing: 0.05`; (c) `early_stopping_metric: val_f1_macro`; (d) regularización de v2 (`conv_dropout` 0.3, `weight_decay` 0.0003, `learning_rate` 0.0005, paciencia y épocas de v2) | P1 con ese único cambio | secundario |
| S4 | Semillas 101, 102, 103 y 104 de P1 y de P2, y los ensembles P1(s)+P2(s) de cada semilla | configuraciones de P1 y P2 con solo `seed` cambiado | secundario |

Cambios obligatorios de rutas en todas: `train`, `dev` y `test` apuntan al directorio nuevo y `save_dir` a una carpeta propia del T19; ninguna otra clave cambia.
Calibración afín por clase en validación (`calibrate.py --method platt`), umbrales de F1 con β = 1 en validación, ensemble con α = 0.5 y recalibración afín del
promedio (procedimiento ya descrito en el artículo).

## 4. Orden de ejecución (por etapas; cada etapa se cierra antes de abrir la siguiente)

1. Construir los HDF5 nuevos y comprobar §2. Registrar los hashes del reparto y de los HDF5.
2. **Etapa 1:** P1, P2 y P3. Evaluación única de P3 (y de P1, P2) en prueba A y prueba B. GPU orientativa: v1 ≈ 30 min, v2 ≈ 118 min.
3. **Etapa 2:** S2 (CNN, algo más de 1 h) y S1 (≈ 2.5 h).
4. **Etapa 3:** S4 (≈ 2.5 h por semilla, 4 semillas) y S3 (≈ 4 a 6 h).
Un sistema no se reentrena porque su resultado decepcione; si una corrida falla por una causa técnica (corte, memoria), se repite con la **misma** configuración y semilla
y se anota.

## 5. Evaluación

- Cada sistema se evalúa **una sola vez** en prueba A y una sola vez en prueba B, con los umbrales y la calibración de su propia validación.
  Se guardan y hashean las predicciones por registro.
- Métricas: F1 macro, micro y ponderado, coincidencia exacta, AUROC macro, AUPRC macro, ECE (15 intervalos) y Brier; por clase; en prueba A, también por origen.
  IC del 95 % por *bootstrap* de percentiles (1 000 remuestreos de registros, semilla 0, los mismos para todos los sistemas); diferencias pareadas con su IC.
- **Métrica principal:** F1 macro de P3 en prueba A y en prueba B. Las demás son secundarias.
- Prueba B (Georgia): sin máscara de celdas, porque la cobertura de etiquetas de Georgia no está documentada; las 12 clases tienen más de 400 positivos.
- Los 24 registros sin clase se mantienen como negativos y se informa también el resultado sin ellos (hoy 6 caen en prueba A y 3 en prueba B).
- **Semillas (S4):** media y desviación típica entre semillas de cada métrica; para cada semilla, la diferencia ensemble menos mejor receta individual, con el número de
  semillas en que es positiva y una prueba de signos exacta. Las 5 semillas de cada receta (la original más cuatro) cuentan igual.
- **Ablaciones y línea base:** diferencias pareadas con P1, con IC; parámetros y minutos de entrenamiento de cada sistema en la tabla (equivalencia de carga de trabajo).
  Una ejecución por variante: son exploratorias y no miden variabilidad entre entrenamientos.

## 6. Reglas

- La validación solo ajusta pesos (parada anticipada), calibración y umbrales. Ninguna decisión de diseño se toma mirando prueba A o B.
- Todo lo que se pruebe fuera de esta lista es exploratorio y así se rotula.
- El resultado se reporta sea cual sea: no hay un valor mínimo que lo haga válido ni uno que lo invalide.
- Antes de entrenar se registra el commit del código (la rama `feat/reparto-por-origen-y-paciente` debe estar en un commit) y se corre `manifiesto.py`.

## 7. Límites que ya se conocen

Cuatro orígenes no traen identificador de paciente (solo PTB-XL y PTB quedan separados por paciente); la cobertura de etiquetas de CPSC-Extra y de Georgia no está
documentada; la ejecución en GPU no es bit a bit reproducible; todo corre en un solo equipo; las etiquetas no se revisaron con cardiólogos; la prueba B es independiente
solo en parte del diseño.
