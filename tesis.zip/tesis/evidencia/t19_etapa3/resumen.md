# Etapa 3 de T19: semillas (S4) y ablaciones (S3)

Valores con tres decimales. Cada semilla y cada ablación es una sola ejecución de entrenamiento; los IC del 95 % (bootstrap de percentiles, 1000 remuestreos de registros, semilla 0, los mismos para todos los sistemas) miden el muestreo de registros, no la variabilidad entre entrenamientos, que es lo que muestran las semillas. Generado por `scripts/analizar_t19.py`; el detalle por sistema, clase y origen está en los CSV de esta carpeta.

## Semillas: media y desviación típica entre las 5 semillas de cada receta

La original es la semilla 42 para P1 y la 43 para P2; las otras cuatro son 101 a 104 en ambas. P3 es el ensemble de P1 y P2 de la misma semilla.

### Prueba A

| Métrica | P1 | P2 | P3 (ensemble) |
|---|---|---|---|
| f1_macro | 0.729 ± 0.003 (0.727 a 0.734) | 0.741 ± 0.011 (0.723 a 0.751) | 0.749 ± 0.007 (0.737 a 0.755) |
| f1_micro | 0.784 ± 0.004 (0.779 a 0.790) | 0.796 ± 0.012 (0.775 a 0.804) | 0.802 ± 0.007 (0.790 a 0.807) |
| f1_ponderado | 0.787 ± 0.005 (0.782 a 0.793) | 0.798 ± 0.012 (0.777 a 0.807) | 0.804 ± 0.006 (0.793 a 0.808) |
| exacta | 0.480 ± 0.007 (0.470 a 0.488) | 0.502 ± 0.021 (0.465 a 0.518) | 0.510 ± 0.019 (0.479 a 0.529) |
| auroc_macro | 0.947 ± 0.002 (0.944 a 0.949) | 0.941 ± 0.007 (0.930 a 0.950) | 0.955 ± 0.002 (0.951 a 0.957) |
| auprc_macro | 0.783 ± 0.005 (0.774 a 0.788) | 0.779 ± 0.015 (0.763 a 0.797) | 0.805 ± 0.006 (0.793 a 0.808) |
| ece | 0.010 ± 0.000 (0.009 a 0.010) | 0.015 ± 0.001 (0.014 a 0.017) | 0.010 ± 0.001 (0.009 a 0.011) |
| brier | 0.049 ± 0.001 (0.048 a 0.051) | 0.048 ± 0.002 (0.046 a 0.052) | 0.045 ± 0.001 (0.045 a 0.047) |

### Prueba B (Georgia)

| Métrica | P1 | P2 | P3 (ensemble) |
|---|---|---|---|
| f1_macro | 0.496 ± 0.009 (0.489 a 0.512) | 0.479 ± 0.038 (0.447 a 0.545) | 0.498 ± 0.018 (0.477 a 0.527) |
| f1_micro | 0.498 ± 0.016 (0.476 a 0.518) | 0.481 ± 0.032 (0.451 a 0.534) | 0.505 ± 0.021 (0.483 a 0.539) |
| f1_ponderado | 0.487 ± 0.013 (0.469 a 0.504) | 0.475 ± 0.037 (0.443 a 0.538) | 0.494 ± 0.021 (0.470 a 0.527) |
| exacta | 0.169 ± 0.017 (0.145 a 0.189) | 0.169 ± 0.011 (0.154 a 0.181) | 0.182 ± 0.007 (0.177 a 0.193) |
| auroc_macro | 0.825 ± 0.008 (0.820 a 0.840) | 0.805 ± 0.018 (0.788 a 0.833) | 0.834 ± 0.008 (0.828 a 0.847) |
| auprc_macro | 0.580 ± 0.014 (0.571 a 0.605) | 0.547 ± 0.029 (0.528 a 0.597) | 0.596 ± 0.012 (0.586 a 0.611) |
| ece | 0.088 ± 0.005 (0.080 a 0.095) | 0.096 ± 0.007 (0.085 a 0.105) | 0.089 ± 0.003 (0.083 a 0.092) |
| brier | 0.109 ± 0.003 (0.104 a 0.113) | 0.118 ± 0.006 (0.107 a 0.123) | 0.109 ± 0.003 (0.104 a 0.111) |

### F1 macro por semilla

| Prueba | Semilla | P1 | P2 | P3 (ensemble) |
|---|---|---|---|---|
| A | orig | 0.730 | 0.745 | 0.752 |
| A | 101 | 0.727 | 0.751 | 0.755 |
| A | 102 | 0.734 | 0.723 | 0.737 |
| A | 103 | 0.728 | 0.744 | 0.751 |
| A | 104 | 0.727 | 0.743 | 0.749 |
| B | orig | 0.491 | 0.470 | 0.500 |
| B | 101 | 0.512 | 0.447 | 0.477 |
| B | 102 | 0.492 | 0.545 | 0.527 |
| B | 103 | 0.489 | 0.461 | 0.491 |
| B | 104 | 0.496 | 0.472 | 0.497 |

## Ensemble menos mejor receta individual, por semilla

Positivo = el ensemble es mejor (en ECE y Brier, mejor individual menos ensemble). La prueba de signos es exacta y bilateral sobre las 5 semillas: con 5 positivas de 5 el valor p es 0.0625, de modo que con este número de semillas no puede bajar de ese valor.

| Prueba | Métrica | Semillas con mejora | Valor p | Mejora media ± desviación | Semilla orig | Semilla 101 | Semilla 102 | Semilla 103 | Semilla 104 |
|---|---|---|---|---|---|---|---|---|---|
| A | f1_macro | 5 de 5 | 0.062 | 0.005 ± 0.001 | +0.007 | +0.004 | +0.004 | +0.007 | +0.006 |
| A | f1_micro | 4 de 5 | 0.375 | 0.003 ± 0.003 | +0.002 | +0.002 | -0.001 | +0.005 | +0.007 |
| A | f1_ponderado | 5 de 5 | 0.062 | 0.004 ± 0.003 | +0.004 | +0.001 | +0.000 | +0.008 | +0.005 |
| A | exacta | 2 de 5 | 1.000 | 0.004 ± 0.013 | -0.001 | +0.017 | -0.008 | -0.008 | +0.019 |
| A | auroc_macro | 5 de 5 | 0.062 | 0.006 ± 0.003 | +0.008 | +0.006 | +0.002 | +0.006 | +0.009 |
| A | auprc_macro | 5 de 5 | 0.062 | 0.016 ± 0.008 | +0.024 | +0.010 | +0.005 | +0.022 | +0.021 |
| A | ece | 2 de 5 | 1.000 | -0.000 ± 0.000 | -0.000 | -0.000 | -0.000 | +0.000 | +0.000 |
| A | brier | 5 de 5 | 0.062 | 0.002 ± 0.001 | +0.002 | +0.001 | +0.001 | +0.004 | +0.002 |
| B | f1_macro | 3 de 5 | 1.000 | -0.008 ± 0.018 | +0.009 | -0.035 | -0.019 | +0.002 | +0.001 |
| B | f1_micro | 4 de 5 | 0.375 | 0.000 ± 0.021 | +0.022 | -0.035 | +0.005 | +0.005 | +0.004 |
| B | f1_ponderado | 3 de 5 | 1.000 | -0.002 ± 0.023 | +0.028 | -0.035 | -0.012 | +0.005 | +0.003 |
| B | exacta | 3 de 5 | 1.000 | 0.004 ± 0.012 | -0.004 | -0.012 | +0.015 | +0.014 | +0.008 |
| B | auroc_macro | 5 de 5 | 0.062 | 0.007 ± 0.001 | +0.008 | +0.006 | +0.006 | +0.008 | +0.005 |
| B | auprc_macro | 5 de 5 | 0.062 | 0.012 ± 0.004 | +0.011 | +0.006 | +0.011 | +0.015 | +0.016 |
| B | ece | 3 de 5 | 1.000 | -0.001 ± 0.005 | +0.003 | -0.010 | +0.002 | +0.000 | -0.003 |
| B | brier | 3 de 5 | 1.000 | -0.000 ± 0.003 | +0.002 | -0.004 | +0.003 | +0.000 | -0.001 |

## Ablaciones desde P1 (S3, una ejecución cada una, semilla 42)

(a) `ABL_AUG`: aumentación (`augment`, `aug_seed` 123); (b) `ABL_LS`: suavizado de etiquetas 0.05; (c) `ABL_ES`: parada por `val_f1_macro`; (d) `ABL_REG`: regularización de v2 (`conv_dropout` 0.3, `weight_decay` 0.0003, `learning_rate` 0.0005, paciencias y épocas de v2).

### Prueba A

| Métrica | P1 | ABL_AUG | ABL_LS | ABL_ES | ABL_REG |
|---|---|---|---|---|---|
| f1_macro | 0.730 (0.718 a 0.739) | 0.730 (0.719 a 0.740) | 0.740 (0.728 a 0.750) | 0.729 (0.718 a 0.740) | 0.726 (0.715 a 0.737) |
| f1_micro | 0.782 (0.775 a 0.789) | 0.783 (0.776 a 0.789) | 0.800 (0.793 a 0.806) | 0.788 (0.781 a 0.794) | 0.783 (0.776 a 0.789) |
| exacta | 0.477 (0.462 a 0.491) | 0.477 (0.463 a 0.491) | 0.517 (0.504 a 0.531) | 0.486 (0.470 a 0.499) | 0.470 (0.456 a 0.484) |
| auroc_macro | 0.947 (0.944 a 0.950) | 0.947 (0.943 a 0.949) | 0.951 (0.947 a 0.954) | 0.946 (0.943 a 0.950) | 0.950 (0.947 a 0.953) |
| auprc_macro | 0.783 (0.771 a 0.796) | 0.775 (0.763 a 0.789) | 0.793 (0.781 a 0.806) | 0.779 (0.767 a 0.792) | 0.785 (0.772 a 0.798) |
| ece | 0.010 | 0.009 | 0.014 | 0.011 | 0.010 |
| brier | 0.049 (0.048 a 0.051) | 0.050 (0.048 a 0.051) | 0.046 (0.045 a 0.048) | 0.049 (0.047 a 0.050) | 0.049 (0.047 a 0.050) |

### Prueba B (Georgia)

| Métrica | P1 | ABL_AUG | ABL_LS | ABL_ES | ABL_REG |
|---|---|---|---|---|---|
| f1_macro | 0.491 (0.484 a 0.498) | 0.517 (0.509 a 0.524) | 0.468 (0.461 a 0.475) | 0.466 (0.459 a 0.473) | 0.493 (0.486 a 0.501) |
| f1_micro | 0.476 (0.470 a 0.482) | 0.509 (0.503 a 0.515) | 0.487 (0.480 a 0.494) | 0.466 (0.460 a 0.473) | 0.503 (0.497 a 0.510) |
| exacta | 0.145 (0.138 a 0.152) | 0.188 (0.181 a 0.195) | 0.192 (0.184 a 0.200) | 0.147 (0.141 a 0.154) | 0.167 (0.159 a 0.174) |
| auroc_macro | 0.821 (0.817 a 0.825) | 0.829 (0.825 a 0.833) | 0.807 (0.803 a 0.812) | 0.804 (0.800 a 0.808) | 0.833 (0.829 a 0.837) |
| auprc_macro | 0.575 (0.568 a 0.583) | 0.586 (0.578 a 0.594) | 0.569 (0.561 a 0.577) | 0.545 (0.537 a 0.553) | 0.583 (0.576 a 0.591) |
| ece | 0.095 | 0.088 | 0.091 | 0.096 | 0.093 |
| brier | 0.113 (0.112 a 0.115) | 0.108 (0.107 a 0.109) | 0.112 (0.111 a 0.113) | 0.115 (0.113 a 0.116) | 0.112 (0.110 a 0.113) |

### Diferencias pareadas con P1 (ablación menos P1)

| Prueba | Comparación | Métrica | Diferencia (IC95) | Remuestreos con diferencia > 0 |
|---|---|---|---|---|
| A | ABL_AUG menos P1 | f1_macro | 0.000 (-0.007 a 0.007) | 0.529 |
| A | ABL_AUG menos P1 | f1_micro | 0.001 (-0.003 a 0.006) | 0.673 |
| A | ABL_AUG menos P1 | exacta | 0.000 (-0.009 a 0.010) | 0.512 |
| A | ABL_AUG menos P1 | auroc_macro | -0.001 (-0.002 a 0.001) | 0.257 |
| A | ABL_AUG menos P1 | auprc_macro | -0.007 (-0.014 a -0.001) | 0.010 |
| A | ABL_AUG menos P1 | ece | -0.001 | 0.263 |
| A | ABL_AUG menos P1 | brier | 0.000 (-0.000 a 0.001) | 0.785 |
| A | ABL_LS menos P1 | f1_macro | 0.010 (0.002 a 0.018) | 0.991 |
| A | ABL_LS menos P1 | f1_micro | 0.018 (0.013 a 0.023) | 1.000 |
| A | ABL_LS menos P1 | exacta | 0.041 (0.029 a 0.052) | 1.000 |
| A | ABL_LS menos P1 | auroc_macro | 0.004 (0.001 a 0.006) | 1.000 |
| A | ABL_LS menos P1 | auprc_macro | 0.010 (0.003 a 0.017) | 0.996 |
| A | ABL_LS menos P1 | ece | 0.003 | 0.994 |
| A | ABL_LS menos P1 | brier | -0.003 (-0.004 a -0.002) | 0.000 |
| A | ABL_ES menos P1 | f1_macro | -0.001 (-0.008 a 0.007) | 0.443 |
| A | ABL_ES menos P1 | f1_micro | 0.006 (0.001 a 0.010) | 0.996 |
| A | ABL_ES menos P1 | exacta | 0.009 (-0.001 a 0.019) | 0.958 |
| A | ABL_ES menos P1 | auroc_macro | -0.001 (-0.003 a 0.001) | 0.253 |
| A | ABL_ES menos P1 | auprc_macro | -0.004 (-0.010 a 0.002) | 0.123 |
| A | ABL_ES menos P1 | ece | 0.001 | 0.677 |
| A | ABL_ES menos P1 | brier | -0.001 (-0.001 a -0.000) | 0.000 |
| A | ABL_REG menos P1 | f1_macro | -0.003 (-0.011 a 0.004) | 0.183 |
| A | ABL_REG menos P1 | f1_micro | 0.001 (-0.004 a 0.006) | 0.672 |
| A | ABL_REG menos P1 | exacta | -0.007 (-0.017 a 0.004) | 0.103 |
| A | ABL_REG menos P1 | auroc_macro | 0.003 (0.001 a 0.004) | 1.000 |
| A | ABL_REG menos P1 | auprc_macro | 0.002 (-0.005 a 0.007) | 0.735 |
| A | ABL_REG menos P1 | ece | 0.000 | 0.544 |
| A | ABL_REG menos P1 | brier | -0.001 (-0.001 a -0.000) | 0.002 |
| B | ABL_AUG menos P1 | f1_macro | 0.025 (0.020 a 0.031) | 1.000 |
| B | ABL_AUG menos P1 | f1_micro | 0.033 (0.028 a 0.038) | 1.000 |
| B | ABL_AUG menos P1 | exacta | 0.043 (0.037 a 0.049) | 1.000 |
| B | ABL_AUG menos P1 | auroc_macro | 0.008 (0.005 a 0.010) | 1.000 |
| B | ABL_AUG menos P1 | auprc_macro | 0.011 (0.006 a 0.015) | 1.000 |
| B | ABL_AUG menos P1 | ece | -0.007 | 0.000 |
| B | ABL_AUG menos P1 | brier | -0.005 (-0.006 a -0.005) | 0.000 |
| B | ABL_LS menos P1 | f1_macro | -0.023 (-0.030 a -0.017) | 0.000 |
| B | ABL_LS menos P1 | f1_micro | 0.011 (0.005 a 0.017) | 1.000 |
| B | ABL_LS menos P1 | exacta | 0.047 (0.041 a 0.054) | 1.000 |
| B | ABL_LS menos P1 | auroc_macro | -0.014 (-0.017 a -0.011) | 0.000 |
| B | ABL_LS menos P1 | auprc_macro | -0.007 (-0.012 a -0.002) | 0.005 |
| B | ABL_LS menos P1 | ece | -0.004 | 0.000 |
| B | ABL_LS menos P1 | brier | -0.001 (-0.002 a -0.001) | 0.000 |
| B | ABL_ES menos P1 | f1_macro | -0.025 (-0.031 a -0.019) | 0.000 |
| B | ABL_ES menos P1 | f1_micro | -0.010 (-0.015 a -0.005) | 0.000 |
| B | ABL_ES menos P1 | exacta | 0.003 (-0.003 a 0.008) | 0.812 |
| B | ABL_ES menos P1 | auroc_macro | -0.018 (-0.020 a -0.015) | 0.000 |
| B | ABL_ES menos P1 | auprc_macro | -0.031 (-0.035 a -0.026) | 0.000 |
| B | ABL_ES menos P1 | ece | 0.001 | 0.896 |
| B | ABL_ES menos P1 | brier | 0.001 (0.001 a 0.002) | 1.000 |
| B | ABL_REG menos P1 | f1_macro | 0.002 (-0.004 a 0.008) | 0.741 |
| B | ABL_REG menos P1 | f1_micro | 0.027 (0.022 a 0.032) | 1.000 |
| B | ABL_REG menos P1 | exacta | 0.022 (0.016 a 0.028) | 1.000 |
| B | ABL_REG menos P1 | auroc_macro | 0.012 (0.010 a 0.014) | 1.000 |
| B | ABL_REG menos P1 | auprc_macro | 0.008 (0.004 a 0.012) | 1.000 |
| B | ABL_REG menos P1 | ece | -0.002 | 0.000 |
| B | ABL_REG menos P1 | brier | -0.002 (-0.002 a -0.001) | 0.000 |

## Carga de trabajo

| Sistema | Parámetros entrenables | Épocas | Mejor época | Minutos | Monitor |
|---|---|---|---|---|---|
| P1 | 4 806 668 | 34 | 24 | 23.4 | val_loss |
| P2 | 4 806 668 | 102 | 87 | 82.3 | val_f1_macro |
| P1_S101 | 4 806 668 | 32 | 22 | 21.3 | val_loss |
| P2_S101 | 4 806 668 | 68 | 53 | 55.4 | val_f1_macro |
| P1_S102 | 4 806 668 | 46 | 36 | 31.3 | val_loss |
| P2_S102 | 4 806 668 | 27 | 12 | 25.3 | val_f1_macro |
| P1_S103 | 4 806 668 | 38 | 28 | 26.5 | val_loss |
| P2_S103 | 4 806 668 | 141 | 126 | 130.0 | val_f1_macro |
| P1_S104 | 4 806 668 | 39 | 29 | 26.3 | val_loss |
| P2_S104 | 4 806 668 | 93 | 78 | 82.1 | val_f1_macro |
| ABL_AUG | 4 806 668 | 36 | 26 | 31.2 | val_loss |
| ABL_LS | 4 806 668 | 51 | 41 | 34.4 | val_loss |
| ABL_ES | 4 806 668 | 80 | 74 | 54.2 | val_f1_macro |
| ABL_REG | 4 806 668 | 39 | 24 | 26.5 | val_loss |
