"""Exploratorio (desviación 7): robustez del sistema principal P3 y efecto de promediar ventanas. Usa la GPU; no entrena ni cambia nada.

Parte 1, robustez (limitaciones 8 y 11). P3 tal como se evaluó (P1 y P2 con su calibración afín, promedio α = 0.5, calibración afín del promedio y umbrales
de F1 de validación, todo leído de runs/t19/eval/p3_A) sobre las señales de A, B, C y D con las perturbaciones de examples/cinc2020/robustness.py
más interferencia de red de 50 y 60 Hz. La interferencia se suma a la señal ya filtrada con la amplitud que deja pasar el pasa-banda del preprocesamiento
(Butterworth de orden 3 aplicado ida y vuelta: ganancia |H(f)|²), así que el nivel nominal es el de la señal cruda. Las perturbaciones aleatorias se sortean
``SORTEOS`` veces; las deterministas (limpia, amplitud) una. Antes de nada se comprueba que la condición limpia reproduce predictions_test.csv.
Parte 2, varias ventanas (limitaciones 8 y 11). En los registros de A y B de más de 10 s se repite la cadena de la webapp: hasta 4 ventanas, cada una
calibrada y ensamblada, y la media de las ventanas; se compara con la ventana centrada que se evaluó.

Las probabilidades van a runs/t19/limitaciones/ (no versionado); el resumen lo calcula limitaciones_resumen_gpu.py.
Uso, desde la raíz del repo:  python -X utf8 -I tesis/scripts/limitaciones_gpu.py [--solo A,B,...] [--sin-ventanas]
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import h5py
import numpy as np
import torch
from scipy.signal import butter, sosfreqz

sys.path.insert(0, str(Path(__file__).resolve().parent))
import analizar_t19 as a19  # noqa: E402
sys.path.insert(0, str(a19.RAIZ / "tools"))
from build_examples import find_headers  # noqa: E402
from ecg import load, predict  # noqa: E402
from ecg.calibration import apply_platt_logits, ensemble_probabilities, load_platt_csv, load_thresholds_csv, to_logits  # noqa: E402
from ecg.schema import BANDPASS_HI_HZ, BANDPASS_LO_HZ, CLASS_NAMES  # noqa: E402
from ecg.signal import TARGET_FS  # noqa: E402
from examples.cinc2020.robustness import apply_perturbation  # noqa: E402

EVAL = a19.EVAL
SALIDA = a19.RAIZ / "runs" / "t19" / "limitaciones"
H5 = {"A": a19.RAIZ / "data" / "cinc2020_12_origen" / "test.h5", "B": a19.RAIZ / "data" / "cinc2020_12_origen" / "test_b.h5",
      "C": a19.EXT / "test_c.h5", "D": a19.EXT / "test_d.h5"}
CONDICIONES = (("clean", 0.0), ("gaussian_noise", 0.05), ("gaussian_noise", 0.10), ("baseline_wander", 0.10), ("baseline_wander", 0.20),
               ("amplitude_scale", 0.5), ("amplitude_scale", 1.5), ("lead_dropout", 1), ("lead_dropout", 3),
               ("red_50hz", 0.1), ("red_50hz", 0.3), ("red_60hz", 0.1), ("red_60hz", 0.3))          # los nueve primeros son los de robustness.py
DETERMINISTAS = ("clean", "amplitude_scale")
SORTEOS, LOTE, VENTANAS_MAX = 3, 64, 4
SOS = butter(3, [BANDPASS_LO_HZ / (TARGET_FS / 2), BANDPASS_HI_HZ / (TARGET_FS / 2)], btype="band", output="sos")
GANANCIA = {f: float(abs(sosfreqz(SOS, worN=[f], fs=TARGET_FS)[1][0]) ** 2) for f in (50, 60)}       # ida y vuelta (sosfiltfilt)


def clave(kind: str, level: float, sorteo: int) -> str:
    return f"{kind}|{level}|{sorteo}"


def perturbar(x: torch.Tensor, kind: str, level: float, rng: np.random.Generator) -> torch.Tensor:
    if kind.startswith("red_"):
        f = int(kind[4:6])
        t = torch.arange(x.shape[-1], device=x.device, dtype=x.dtype) / TARGET_FS
        fase = torch.tensor(rng.uniform(0, 2 * np.pi, size=(x.shape[0], x.shape[1], 1)), device=x.device, dtype=x.dtype)
        return x + float(level) * GANANCIA[f] * torch.sin(2 * np.pi * f * t[None, None, :] + fase)
    return apply_perturbation(x, kind, level, rng)


class P3:
    """La cadena del ensemble de ensemble_evaluate.py: logits con AMP, afín por modelo, promedio, afín del promedio."""

    def __init__(self, device: torch.device):
        r = json.loads((EVAL / "p3_A" / "evaluation_summary.json").read_text(encoding="utf-8"))
        assert r["ensemble_alpha"] == 0.5 and r["recalibrate_ensemble"] and r["normal_fallback_min_prob"] is None and r["nsr_exclusive_min_prob"] is None
        for prueba in "BCD":                                                    # la misma calibración y los mismos umbrales en las cuatro pruebas
            for f in ("platt_ensemble_validation.csv", "thresholds_validation.csv"):
                assert a19.sha256(EVAL / f"p3_{prueba}" / f) == a19.sha256(EVAL / "p3_A" / f), f"{f} de p3_{prueba} distinto del de p3_A"
        self.device = device
        self.modelos = [predict.load_model(a19.RAIZ / r[k], device)[0].eval() for k in ("checkpoint_a", "checkpoint_b")]
        self.platt = [load_platt_csv(a19.RAIZ / r[k], CLASS_NAMES) for k in ("platt_a", "platt_b")]
        self.platt_e = load_platt_csv(EVAL / "p3_A" / "platt_ensemble_validation.csv", CLASS_NAMES)
        self.umbrales = load_thresholds_csv(EVAL / "p3_A" / "thresholds_validation.csv", CLASS_NAMES)
        self.entradas = {k: str(r[k]) for k in ("checkpoint_a", "checkpoint_b", "platt_a", "platt_b")}

    @torch.no_grad()
    def __call__(self, x: torch.Tensor) -> np.ndarray:
        """x: (B, 12, 5000) en mV, ya en el dispositivo."""
        ps = []
        for m, ab in zip(self.modelos, self.platt):
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=self.device.type == "cuda"):
                z = m(x)
            ps.append(apply_platt_logits(z.float().cpu().numpy(), *ab))
        return apply_platt_logits(to_logits(ensemble_probabilities(ps[0], ps[1], 0.5)), *self.platt_e).astype(np.float32)


def referencia(prueba: str) -> tuple[np.ndarray, np.ndarray]:
    """Nombres y probabilidades de predictions_test.csv de P3, comprobado contra su SHA-256 registrado."""
    import pandas as pd
    ruta = EVAL / f"p3_{prueba}" / "predictions_test.csv"
    registrado = {**a19.SHA256, **a19.SHA256_EXT}[f"P3_{prueba}"]
    assert a19.sha256(ruta) == registrado, f"{ruta} no es la predicción registrada"
    d = pd.read_csv(ruta)
    return d["record_name"].to_numpy(), d[[f"prob_{c}" for c in CLASS_NAMES]].to_numpy(np.float32)


def robustez(p3: P3, prueba: str) -> None:
    salida = SALIDA / f"robustez_{prueba}.npz"
    if salida.exists():
        print(f"{prueba}: ya existe {salida}; no se repite")
        return
    nombres_ref, prob_ref = referencia(prueba)
    claves = [(k, lv, s) for k, lv in CONDICIONES for s in range(1 if k in DETERMINISTAS else SORTEOS)]
    rngs = {(k, lv, s): np.random.default_rng([s, i]) for i, (k, lv) in enumerate(CONDICIONES) for s in range(SORTEOS)}
    torch.manual_seed(0)                                                         # el ruido gaussiano de apply_perturbation usa el generador global
    salidas = {c: [] for c in claves}
    t0 = time.time()
    with h5py.File(H5[prueba], "r") as f:
        nombres = np.array([n.decode() if isinstance(n, bytes) else n for n in f["record_names"][:]])
        y = f["labels"][:]
        n = len(nombres)
        for i in range(0, n, LOTE):
            x = torch.from_numpy(f["signals"][i:i + LOTE]).permute(0, 2, 1).contiguous().to(p3.device)
            for c in claves:
                salidas[c].append(p3(perturbar(x, c[0], c[1], rngs[c])))
            if i // LOTE % 20 == 0:
                print(f"{prueba}: {i + len(x)}/{n} registros, {time.time() - t0:.0f} s", flush=True)
    prob = {clave(*c): np.concatenate(v) for c, v in salidas.items()}
    orden = {nm: j for j, nm in enumerate(nombres)}
    limpia = prob[clave("clean", 0.0, 0)][[orden[nm] for nm in nombres_ref]]
    dif = np.abs(limpia - prob_ref)
    decisiones = ((limpia >= p3.umbrales) != (prob_ref >= p3.umbrales)).sum()
    print(f"{prueba}: limpia frente a predictions_test.csv: diferencia máxima {dif.max():.2e}, media {dif.mean():.2e}, {decisiones} decisiones distintas")
    assert dif.max() < 5e-3, "la condición limpia no reproduce la evaluación registrada"
    SALIDA.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(salida, nombres=nombres, y=y, umbrales=p3.umbrales, **prob,
                        meta=json.dumps({"dif_max": float(dif.max()), "dif_media": float(dif.mean()), "decisiones_distintas": int(decisiones),
                                         "segundos": round(time.time() - t0, 1), "sorteos": SORTEOS, "ganancia_red": GANANCIA, **p3.entradas}))
    print(f"{prueba}: guardado {salida} ({time.time() - t0:.0f} s)", flush=True)


def ventanas(p3: P3, prueba: str, cabeceras: dict) -> None:
    salida = SALIDA / f"ventanas_{prueba}.npz"
    if salida.exists():
        print(f"{prueba}: ya existe {salida}; no se repite")
        return
    nombres_ref, prob_ref = referencia(prueba)
    largos, una, varias, k_usadas = [], [], [], []
    t0 = time.time()
    for j, nm in enumerate(nombres_ref):
        hea = cabeceras[nm]
        campos = hea.read_text(encoding="utf-8", errors="replace").split()
        if int(campos[3]) / float(campos[2]) <= 10.5:
            continue
        w, meta = load.load_wfdb_record_windows(hea.with_suffix(".mat"), hea, windows_max=VENTANAS_MAX, norm_mode="physical", bandpass=True)
        pv = p3(torch.from_numpy(w.transpose(0, 2, 1).copy()).to(p3.device))     # (K, 12): cada ventana calibrada y ensamblada, como la webapp
        largos.append(nm)
        una.append(prob_ref[j])
        varias.append(pv.mean(0))
        k_usadas.append(int(meta["num_windows"]))
        if len(largos) % 200 == 0:
            print(f"{prueba}: {len(largos)} registros largos, {time.time() - t0:.0f} s", flush=True)
    np.savez_compressed(salida, nombres=np.array(largos), una=np.array(una), varias=np.array(varias), ventanas=np.array(k_usadas),
                        umbrales=p3.umbrales, segundos=round(time.time() - t0, 1))
    print(f"{prueba}: {len(largos)} registros de más de 10 s; guardado {salida}", flush=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--solo", default="A,B,C,D", help="pruebas de la parte 1, separadas por comas")
    ap.add_argument("--sin-ventanas", action="store_true")
    args = ap.parse_args()
    device = predict.get_device("auto")
    print(f"Dispositivo: {device}; ganancia del pasa-banda ida y vuelta: {GANANCIA}")
    p3 = P3(device)
    for prueba in args.solo.split(","):
        robustez(p3, prueba)
    if not args.sin_ventanas:
        cabeceras = find_headers(a19.RAIZ / "dataset2020")
        for prueba in ("A", "B"):
            ventanas(p3, prueba, cabeceras)
    return 0


if __name__ == "__main__":
    sys.exit(main())
