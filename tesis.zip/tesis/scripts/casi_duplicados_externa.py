"""Exploratorio (desviación 7, limitación 7): casi duplicados de Chapman-Shaoxing (C) y Ningbo (D), entre sí y frente al Challenge 2020.

duplicados_externa.py solo encontró señales idénticas. Aquí cada registro de los HDF5 ya preprocesados (la ventana centrada de 10 s, filtrada y en mV)
se resume en 12 derivaciones × 100 medias de 0.1 s, se le resta su media y se divide por su norma, y se compara con todos los demás por similitud del coseno.
Así se encuentran copias recuantizadas, reescaladas o con un desplazamiento de nivel, no las recortadas o desplazadas en el tiempo.
Un par con similitud de al menos ``UMBRAL`` (fijado antes de mirar: 0.99) es un casi duplicado. Los registros sin señal (norma casi nula) no se comparan.

Análisis de sensibilidad: P3 en C y D sin ningún registro que forme parte de un par casi duplicado (dentro de C y D o con el Challenge 2020), sobre las clases
evaluables y con los 1 000 remuestreos de semilla 0, frente a la prueba completa.
Escribe en evidencia/limitaciones/: casi_duplicados.csv (pares con similitud ≥ 0.95), casi_duplicados.json y casi_duplicados_sensibilidad.csv.
Uso, desde la raíz del repo:  python -X utf8 -I tesis/scripts/casi_duplicados_externa.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import h5py
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import analizar_t19 as a19  # noqa: E402
from ecg.schema import CLASS_NAMES  # noqa: E402
from ecg.util import decode_h5_strings  # noqa: E402

SALIDA = a19.SALIDA / "limitaciones"
ORIGEN20 = a19.RAIZ / "data" / "cinc2020_12_origen"
FUENTES = {"C": a19.EXT / "test_c.h5", "D": a19.EXT / "test_d.h5",
           **{f"2020_{p}": ORIGEN20 / f"{p}.h5" for p in ("train", "val", "test", "test_b")}}
BLOQUE, PUNTOS, UMBRAL, GUARDAR, LOTE = 50, 100, 0.99, 0.95, 2048
MARCAS = (0.95, 0.98, 0.99, 0.999)


def huellas(ruta: Path) -> tuple[list[str], np.ndarray, np.ndarray]:
    """(nombres, etiquetas, huellas normalizadas (n, 1200) float32; fila de ceros si no hay señal)."""
    with h5py.File(ruta, "r") as f:
        nombres, y, n = decode_h5_strings(f["record_names"][:]), f["labels"][:], f["signals"].shape[0]
        h = np.empty((n, PUNTOS * 12), np.float32)
        for i in range(0, n, LOTE):
            x = f["signals"][i:i + LOTE].astype(np.float32)                                  # (b, 5000, 12)
            x = x.reshape(len(x), PUNTOS, BLOQUE, 12).mean(2).reshape(len(x), -1)
            x -= x.mean(1, keepdims=True)
            norma = np.linalg.norm(x, axis=1, keepdims=True)
            h[i:i + LOTE] = np.where(norma > 1e-3, x / np.maximum(norma, 1e-12), 0)
    return nombres, y, h


def main() -> int:
    SALIDA.mkdir(parents=True, exist_ok=True)
    nombres, etiquetas, fuente, bloques = [], [], [], []
    for k, ruta in FUENTES.items():
        nm, y, h = huellas(ruta)
        nombres += nm
        etiquetas.append(y)
        fuente += [k] * len(nm)
        bloques.append(h)
        print(f"{k}: {len(nm)} registros, {int((np.abs(h).sum(1) == 0).sum())} sin señal", flush=True)
    H, Y, fuente = np.concatenate(bloques), np.concatenate(etiquetas), np.array(fuente)
    externos = np.flatnonzero(np.isin(fuente, ["C", "D"]))
    pares = []
    for i in range(0, len(externos), LOTE // 2):
        filas = externos[i:i + LOTE // 2]
        s = H[filas] @ H.T                                                                      # (b, todos)
        for a, b in zip(*np.nonzero(s >= GUARDAR)):
            ia, ib = filas[a], b
            if ia == ib or (fuente[ib] in ("C", "D") and ib < ia):                              # cada par externo una sola vez
                continue
            pares.append((ia, ib, float(s[a, b])))
    print(f"pares con similitud ≥ {GUARDAR}: {len(pares)}", flush=True)
    df = pd.DataFrame([{"registro_a": nombres[a], "fuente_a": fuente[a], "registro_b": nombres[b], "fuente_b": fuente[b], "similitud": s,
                        "clases_a": ";".join(c for c, v in zip(CLASS_NAMES, Y[a]) if v), "clases_b": ";".join(c for c, v in zip(CLASS_NAMES, Y[b]) if v),
                        "clases_discordantes": bool((Y[a] != Y[b]).any())} for a, b, s in pares],
                      columns=["registro_a", "fuente_a", "registro_b", "fuente_b", "similitud", "clases_a", "clases_b", "clases_discordantes"])
    df.sort_values("similitud", ascending=False).to_csv(SALIDA / "casi_duplicados.csv", index=False)

    resumen = {"umbral": UMBRAL, "huella": f"12 derivaciones x {PUNTOS} medias de {BLOQUE} muestras, centrada y de norma 1", "por_umbral": {}}
    for u in MARCAS:
        d = df[df.similitud >= u]
        dentro = d[d.fuente_b.isin(["C", "D"])]
        resumen["por_umbral"][str(u)] = {"pares": len(d), "pares_dentro_de_C_y_D": len(dentro), "pares_entre_C_y_D": int((dentro.fuente_a != dentro.fuente_b).sum()),
                                         "pares_con_el_2020": len(d) - len(dentro), "pares_con_clases_discordantes": int(d.clases_discordantes.sum()),
                                         "registros_externos_afectados": len(set(d.registro_a) | set(dentro.registro_b))}

    # sensibilidad: P3 sin los registros externos que forman parte de un par con similitud >= UMBRAL
    d = df[df.similitud >= UMBRAL]
    fuera = set(d.registro_a) | set(d[d.fuente_b.isin(["C", "D"])].registro_b)
    reparto = json.loads((a19.ENTRADAS7 / "reparto_externo.json").read_text(encoding="utf-8"))
    datos, hashes, _ = a19.cargar_externo(("P3",), reparto)
    filas = []
    for prueba in a19.EXTERNOS:
        nm = datos["P3", prueba][0]
        ev = [CLASS_NAMES.index(c) for c in reparto["origenes"][prueba]["clases_evaluables"]]
        sel = np.array([n not in fuera for n in nm])
        for sub, s in (("completa", None), ("sin casi duplicados", sel)):
            puntual, boot = a19.analizar(a19.construir(datos, prueba, ("P3",), s, columnas=ev))
            for m in ("f1_macro", "f1_micro", "auroc_macro", "auprc_macro", "brier"):
                lo, hi = a19.ic(boot["P3"][m])
                filas.append({"prueba": prueba, "subconjunto": sub, "n": int(len(nm) if s is None else s.sum()), "metrica": m, "valor": puntual["P3"][m], "lo": lo, "hi": hi})
        resumen.setdefault("excluidos_en_la_sensibilidad", {})[prueba] = int((~sel).sum())
    pd.DataFrame(filas).to_csv(SALIDA / "casi_duplicados_sensibilidad.csv", index=False)
    resumen["predicciones_sha256"] = hashes
    (SALIDA / "casi_duplicados.json").write_text(json.dumps(resumen, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(resumen, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
