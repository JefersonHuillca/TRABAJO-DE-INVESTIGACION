"""Resume las probabilidades de limitaciones_gpu.py (desviación 7, exploratorio). Solo CPU.

Robustez: por prueba y perturbación, F1, sensibilidad y precisión macro con los umbrales congelados y AUROC macro (clases evaluables en C y D), su cambio
frente a la condición limpia como media ± desviación típica entre sorteos, y el IC del 95 % del cambio de F1 macro del sorteo 0 por bootstrap pareado
(1 000 remuestreos, semilla 0).
Ventanas: en los registros de más de 10 s, la media de hasta 4 ventanas (como la webapp) frente a la ventana centrada evaluada: F1 macro, decisiones que
cambian y diferencia de probabilidad, con IC pareado; y el F1 macro de toda la prueba si los registros largos se puntuaran como en la webapp.
Escribe en evidencia/limitaciones/: robustez_p3.csv, robustez_p3_resumen.csv y ventanas.csv.
Uso, desde la raíz del repo:  python -X utf8 -I tesis/scripts/limitaciones_resumen_gpu.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

sys.path.insert(0, str(Path(__file__).resolve().parent))
import analizar_t19 as a19  # noqa: E402
from ecg.schema import CLASS_NAMES  # noqa: E402

ENTRADA = a19.RAIZ / "runs" / "t19" / "limitaciones"
SALIDA = a19.SALIDA / "limitaciones"


def columnas(prueba: str) -> list[int]:
    if prueba in ("A", "B"):
        return list(range(len(CLASS_NAMES)))
    reparto = json.loads((a19.ENTRADAS7 / "reparto_externo.json").read_text(encoding="utf-8"))
    return [CLASS_NAMES.index(c) for c in reparto["origenes"][prueba]["clases_evaluables"]]


def conteos(y: np.ndarray, yh: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    return y * yh, (1 - y) * yh, y * (1 - yh)


def f1_macro(tp, fp, fn) -> np.ndarray:
    """F1 macro de sumas por clase (última dimensión = clases)."""
    return a19.f1_de(tp, fp, fn).mean(-1)


def metricas(y: np.ndarray, p: np.ndarray, yh: np.ndarray) -> dict:
    tp, fp, fn = (m.sum(0) for m in conteos(y, yh))
    auroc = [roc_auc_score(y[:, i], p[:, i]) for i in range(y.shape[1]) if 0 < y[:, i].sum() < len(y)]
    return {"f1_macro": float(f1_macro(tp, fp, fn)), "sens_macro": float(np.mean(a19.cociente(tp, tp + fn))),
            "prec_macro": float(np.mean(np.divide(tp, tp + fp, out=np.zeros(len(tp)), where=tp + fp > 0))), "auroc_macro": float(np.mean(auroc))}


def pesos(n: int) -> np.ndarray:
    idx = np.random.default_rng(a19.SEMILLA).integers(0, n, size=(a19.REMUESTREOS, n))
    return np.stack([np.bincount(f, minlength=n) for f in idx]).astype(np.float32)


def ic_delta_f1(w: np.ndarray, y: np.ndarray, yh0: np.ndarray, yh1: np.ndarray) -> tuple[float, float]:
    """IC 95 % por percentiles del cambio pareado de F1 macro (yh1 menos yh0) con los remuestreos ``w``."""
    f = [f1_macro(*(w @ m.astype(np.float32) for m in conteos(y, yh))) for yh in (yh0, yh1)]
    return tuple(np.percentile(f[1] - f[0], [2.5, 97.5]))


def robustez() -> None:
    filas, resumen = [], []
    for prueba in "ABCD":
        ruta = ENTRADA / f"robustez_{prueba}.npz"
        if not ruta.exists():
            print(f"falta {ruta}; se omite {prueba}")
            continue
        z = np.load(ruta)
        col = columnas(prueba)
        y, u = z["y"][:, col].astype(np.float32), z["umbrales"][col]
        claves = [k for k in z.files if k.count("|") == 2]
        p0 = z["clean|0.0|0"][:, col]
        yh0 = (p0 >= u).astype(np.float32)
        base = metricas(y, p0, yh0)
        w = pesos(len(y))
        for k in claves:
            kind, level, sorteo = k.split("|")
            p = z[k][:, col]
            yh = (p >= u).astype(np.float32)
            m = metricas(y, p, yh)
            fila = {"prueba": prueba, "perturbacion": kind, "nivel": float(level), "sorteo": int(sorteo), "n": len(y), **m,
                    **{f"delta_{x}": m[x] - base[x] for x in m}}
            if sorteo == "0" and kind != "clean":
                fila["delta_f1_lo"], fila["delta_f1_hi"] = ic_delta_f1(w, y, yh0, yh)
            filas.append(fila)
        print(f"{prueba}: {len(claves)} condiciones; limpia F1 macro {base['f1_macro']:.3f}; meta {z['meta']}", flush=True)
    df = pd.DataFrame(filas)
    df.to_csv(SALIDA / "robustez_p3.csv", index=False)
    for (prueba, kind, level), g in df.groupby(["prueba", "perturbacion", "nivel"], sort=False):
        s0 = g[g.sorteo == 0].iloc[0]
        resumen.append({"prueba": prueba, "perturbacion": kind, "nivel": level, "sorteos": len(g), "f1_macro": g.f1_macro.mean(),
                        "delta_f1_media": g.delta_f1_macro.mean(), "delta_f1_dt": g.delta_f1_macro.std(ddof=1) if len(g) > 1 else np.nan,
                        "delta_f1_lo_s0": s0.get("delta_f1_lo", np.nan), "delta_f1_hi_s0": s0.get("delta_f1_hi", np.nan),
                        "delta_auroc_media": g.delta_auroc_macro.mean(), "delta_sens_media": g.delta_sens_macro.mean(), "delta_prec_media": g.delta_prec_macro.mean()})
    pd.DataFrame(resumen).to_csv(SALIDA / "robustez_p3_resumen.csv", index=False)
    print(pd.DataFrame(resumen).round(3).to_string(index=False))


def ventanas() -> None:
    filas = []
    for prueba in "AB":
        ruta = ENTRADA / f"ventanas_{prueba}.npz"
        if not ruta.exists():
            print(f"falta {ruta}; se omite {prueba}")
            continue
        z = np.load(ruta)
        if len(z["nombres"]) == 0:
            print(f"{prueba}: ningún registro de más de 10 s")
            continue
        d = pd.read_csv(a19.EVAL / f"p3_{prueba}" / "predictions_test.csv")
        assert a19.sha256(a19.EVAL / f"p3_{prueba}" / "predictions_test.csv") == a19.SHA256[f"P3_{prueba}"]
        y_todo = d[[f"true_{c}" for c in CLASS_NAMES]].to_numpy(np.float32)
        p_todo = d[[f"prob_{c}" for c in CLASS_NAMES]].to_numpy(np.float32)
        pos = {n: i for i, n in enumerate(d.record_name)}
        idx = np.array([pos[n] for n in z["nombres"]])
        assert np.allclose(p_todo[idx], z["una"])
        u, y = z["umbrales"], y_todo[idx]
        yh1, yhk = (z["una"] >= u).astype(np.float32), (z["varias"] >= u).astype(np.float32)
        m1, mk = metricas(y, z["una"], yh1), metricas(y, z["varias"], yhk)
        lo, hi = ic_delta_f1(pesos(len(y)), y, yh1, yhk)
        p_web = p_todo.copy()
        p_web[idx] = z["varias"]
        yh_todo, yh_web = (p_todo >= u).astype(np.float32), (p_web >= u).astype(np.float32)
        lo_t, hi_t = ic_delta_f1(pesos(len(y_todo)), y_todo, yh_todo, yh_web)
        f_todo, f_web = metricas(y_todo, p_todo, yh_todo), metricas(y_todo, p_web, yh_web)
        filas.append({"prueba": prueba, "registros_largos": len(idx), "ventanas_media": float(z["ventanas"].mean()),
                      "f1_macro_una": m1["f1_macro"], "f1_macro_varias": mk["f1_macro"], "delta_f1": mk["f1_macro"] - m1["f1_macro"], "delta_f1_lo": lo, "delta_f1_hi": hi,
                      "auroc_macro_una": m1["auroc_macro"], "auroc_macro_varias": mk["auroc_macro"],
                      "decisiones_distintas": int((yh1 != yhk).sum()), "registros_con_alguna_decision_distinta": int((yh1 != yhk).any(1).sum()),
                      "dif_prob_media": float(np.abs(z["varias"] - z["una"]).mean()), "dif_prob_max": float(np.abs(z["varias"] - z["una"]).max()),
                      "f1_macro_prueba_evaluada": f_todo["f1_macro"], "f1_macro_prueba_como_webapp": f_web["f1_macro"],
                      "delta_f1_prueba": f_web["f1_macro"] - f_todo["f1_macro"], "delta_f1_prueba_lo": lo_t, "delta_f1_prueba_hi": hi_t})
    pd.DataFrame(filas).to_csv(SALIDA / "ventanas.csv", index=False)
    print(pd.DataFrame(filas).T.to_string())


if __name__ == "__main__":
    SALIDA.mkdir(parents=True, exist_ok=True)
    robustez()
    ventanas()
