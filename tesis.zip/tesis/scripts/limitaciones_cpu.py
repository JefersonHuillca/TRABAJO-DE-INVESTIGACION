"""Exploratorio (desviación 7): análisis que no necesitan GPU sobre las predicciones congeladas de P3 en A, B, C y D.

1. ECE con el sesgo del estimador a la vista (limitación 5). El IC por percentiles no vale para el ECE (desviación 1): el remuestreo lo hace subir.
   Se informa en su lugar (a) el ECE corregido por el sesgo del bootstrap, 2·ECE − media de los remuestreos, con el intervalo bootstrap básico
   [2·ECE − q97.5, 2·ECE − q2.5] (truncado en 0), y (b) la prueba de consistencia de Bröcker y Smith (2007): se sortean etiquetas y* ~ Bernoulli(p)
   con las mismas probabilidades, que es lo que verían si el sistema estuviera perfectamente calibrado, y se compara el ECE observado con esa
   distribución nula (media, percentil 95 y valor p de una cola).
2. P3 por sexo y por grupo de edad (limitación 8): F1, AUROC y AUPRC macro y Brier por subgrupo, con IC del 95 % por bootstrap (los 1 000 remuestreos
   de semilla 0 de analizar_t19.py, restringidos al subgrupo), y las diferencias mujer menos hombre y 80 o más menos menos de 50 en el mismo remuestreo.

En C y D las métricas van sobre las clases evaluables de cada origen, como en la etapa 7. Lee las predicciones comprobadas contra su SHA-256 y el sexo
y la edad de los HDF5; no entrena, no evalúa modelos y no cambia ningún umbral ni calibración.
Escribe en evidencia/limitaciones/: ece.csv, subgrupos.csv, subgrupos_diferencias.csv y entradas_cpu.json.
Uso, desde la raíz del repo:  python -X utf8 -I tesis/scripts/limitaciones_cpu.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import h5py
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import analizar_t19 as a19  # noqa: E402
from ecg.schema import CLASS_NAMES  # noqa: E402
from ecg.util import decode_h5_strings  # noqa: E402

SALIDA = a19.SALIDA / "limitaciones"
H5 = {"A": a19.RAIZ / "data" / "cinc2020_12_origen" / "test.h5", "B": a19.RAIZ / "data" / "cinc2020_12_origen" / "test_b.h5",
      "C": a19.EXT / "test_c.h5", "D": a19.EXT / "test_d.h5"}
EDADES = ((0, 50, "<50"), (50, 65, "50-64"), (65, 80, "65-79"), (80, 200, ">=80"))
SEXO = {"M": "hombre", "MALE": "hombre", "F": "mujer", "FEMALE": "mujer"}
CONSISTENCIA, SEMILLA_CONSISTENCIA = 1000, 1
METRICAS = ("f1_macro", "auroc_macro", "auprc_macro", "sens_macro", "espec_macro", "brier")
DIFERENCIAS = (("mujer", "hombre"), (">=80", "<50"))
POCOS = 10                      # una clase con menos positivos que esto en el subgrupo hace inestable su F1


def ece_pesos(s: a19.Sistema, w: np.ndarray, yt: np.ndarray | None = None) -> float:
    """El mismo ECE macro de analizar_t19.estadisticas; ``yt`` sustituye las etiquetas (prueba de consistencia)."""
    yt = s.yt if yt is None else yt
    total = w.sum()
    return float(np.mean([np.abs(np.bincount(s.bin[i], w * yt[i], a19.INTERVALOS) - np.bincount(s.bin[i], w * s.pt[i], a19.INTERVALOS)).sum() / total
                          for i in range(len(s.yt))]))


def cargar() -> tuple[dict, dict, dict]:
    datos, _, hashes = a19.cargar(("P3",))
    reparto = json.loads((a19.ENTRADAS7 / "reparto_externo.json").read_text(encoding="utf-8"))
    externos, hashes_ext, _ = a19.cargar_externo(("P3",), reparto)
    datos.update(externos)
    hashes.update(hashes_ext)
    columnas = {p: list(range(len(CLASS_NAMES))) for p in ("A", "B")}
    columnas.update({p: [CLASS_NAMES.index(c) for c in reparto["origenes"][p]["clases_evaluables"]] for p in a19.EXTERNOS})
    return datos, hashes, columnas


def metadatos(prueba: str, nombres: np.ndarray) -> pd.DataFrame:
    with h5py.File(H5[prueba], "r") as f:
        meta = pd.DataFrame({"sexo": decode_h5_strings(f["sexes"][:]), "edad": f["ages"][:].astype(float)},
                            index=decode_h5_strings(f["record_names"][:]))
    assert meta.index.is_unique and set(meta.index) == set(nombres), f"{prueba}: el HDF5 no tiene los registros de las predicciones"
    meta = meta.loc[list(nombres)]
    meta["sexo"] = meta["sexo"].str.strip().str.upper().map(SEXO).fillna("desconocido")
    return meta


def grupos(meta: pd.DataFrame) -> dict[str, np.ndarray]:
    g = {"todos": np.ones(len(meta), bool), "hombre": (meta.sexo == "hombre").to_numpy(), "mujer": (meta.sexo == "mujer").to_numpy()}
    edad = meta.edad.to_numpy()
    for lo, hi, nombre in EDADES:
        g[nombre] = np.isfinite(edad) & (edad >= lo) & (edad < hi)
    return g


def main() -> int:
    SALIDA.mkdir(parents=True, exist_ok=True)
    datos, hashes, columnas = cargar()
    ece_filas, sub_filas, dif_filas = [], [], []
    for prueba in ("A", "B", "C", "D"):
        nombres, y, p, yh = datos["P3", prueba]
        col = columnas[prueba]
        s = a19.Sistema(y[:, col], p[:, col], yh[:, col])
        n = len(y)
        idx = np.random.default_rng(a19.SEMILLA).integers(0, n, size=(a19.REMUESTREOS, n))        # los mismos remuestreos que analizar_t19.py
        pesos = [np.bincount(fila, minlength=n).astype(float) for fila in idx]

        # 1. ECE
        puntual = ece_pesos(s, np.ones(n))
        assert abs(puntual - a19.estadisticas(s, np.ones(n))["ece"]) < 1e-12
        boot = np.array([ece_pesos(s, w) for w in pesos])
        rng = np.random.default_rng(SEMILLA_CONSISTENCIA)
        nula = np.array([ece_pesos(s, np.ones(n), (rng.random(s.pt.shape) < s.pt).astype(float)) for _ in range(CONSISTENCIA)])
        q_lo, q_hi = np.percentile(boot, [2.5, 97.5])
        ece_filas.append({"prueba": prueba, "n": n, "clases": len(col), "ece": puntual, "media_remuestreos": boot.mean(), "sesgo_bootstrap": boot.mean() - puntual,
                          "ece_corregido": max(2 * puntual - boot.mean(), 0.0), "lo_basico": max(2 * puntual - q_hi, 0.0), "hi_basico": max(2 * puntual - q_lo, 0.0),
                          "nula_media": nula.mean(), "nula_p95": np.percentile(nula, 95),
                          "p_consistencia": (1 + int((nula >= puntual).sum())) / (1 + CONSISTENCIA)})
        print(f"{prueba}: ECE {puntual:.4f}, corregido {ece_filas[-1]['ece_corregido']:.4f}, nula {nula.mean():.4f} (p95 {ece_filas[-1]['nula_p95']:.4f})", flush=True)

        # 2. Subgrupos
        g = grupos(metadatos(prueba, nombres))
        boot_g = {k: a19.apilar([a19.estadisticas(s, w * m) for w in pesos]) for k, m in g.items() if m.sum() > 0}
        for k, m in g.items():
            if m.sum() == 0:
                continue
            e = a19.estadisticas(s, m.astype(float))
            positivos = y[m][:, col].sum(0)
            for met in METRICAS:
                lo, hi = a19.ic(boot_g[k][met])
                sub_filas.append({"prueba": prueba, "grupo": k, "n": int(m.sum()), "clases_con_pocos_positivos": int((positivos < POCOS).sum()),
                                  "metrica": met, "valor": e[met], "lo": lo, "hi": hi})
        for a, b in DIFERENCIAS:
            if a in boot_g and b in boot_g:
                for met in METRICAS:
                    d = boot_g[a][met] - boot_g[b][met]
                    lo, hi = a19.ic(d)
                    va, vb = (a19.estadisticas(s, g[k].astype(float))[met] for k in (a, b))
                    dif_filas.append({"prueba": prueba, "comparacion": f"{a} menos {b}", "metrica": met, "diferencia": va - vb, "lo": lo, "hi": hi})
        print(f"{prueba}: subgrupos {', '.join(f'{k} {int(m.sum())}' for k, m in g.items())}", flush=True)

    # el ECE puntual coincide con el registrado en las etapas 1 y 7
    reg = pd.concat([pd.read_csv(a19.SALIDA / "t19_etapa1" / "metricas_globales.csv"), pd.read_csv(a19.SALIDA / "t19_etapa7" / "metricas_globales.csv")])
    for f in ece_filas:
        r = reg.query("sistema == 'P3' and metrica == 'ece' and prueba == @f['prueba'] and subconjunto == 'completa'")
        assert len(r) == 1 and abs(r.valor.iloc[0] - f["ece"]) < 1e-6, f"ECE de {f['prueba']} distinto del registrado"

    pd.DataFrame(ece_filas).to_csv(SALIDA / "ece.csv", index=False)
    pd.DataFrame(sub_filas).to_csv(SALIDA / "subgrupos.csv", index=False)
    pd.DataFrame(dif_filas).to_csv(SALIDA / "subgrupos_diferencias.csv", index=False)
    (SALIDA / "entradas_cpu.json").write_text(json.dumps({"predicciones_sha256": hashes, "remuestreos": a19.REMUESTREOS, "semilla": a19.SEMILLA,
                                                          "consistencia": CONSISTENCIA, "semilla_consistencia": SEMILLA_CONSISTENCIA, "intervalos_ece": a19.INTERVALOS,
                                                          "edades": EDADES}, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(f"Escrito en {SALIDA}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
