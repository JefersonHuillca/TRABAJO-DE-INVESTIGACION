"""Figuras de datos del artículo IEEE (PDF vectorial en tesis/figuras/; vistas PNG en tesis/evidencia/vistas/).

Anchos de IEEE: una columna 3.5 in, dos columnas 7.16 in; texto de 7 a 8 pt a tamaño final, paleta Okabe-Ito y marcadores distintos
para que no dependan del color. Solo lee runs/t19/eval/ (predicciones ya guardadas, comprobadas contra su SHA-256 registrado) y evidencia/;
no entrena ni evalúa nada. Todas muestran el sistema final (ensemble P3) en la prueba A (azul, línea continua) y en la prueba B, Georgia
(naranja, línea discontinua).

Figuras: fig_roc_pr (curvas ROC y de precisión-sensibilidad de tres clases, como la Fig. 1 del trabajo original), fig_confusion (matriz de confusión multietiqueta, como su Fig. 2a) y fig_confiabilidad (diagrama de confiabilidad,
extensión de este trabajo) y fig_externa (F1 y sensibilidad por clase de P3 en Chapman-Shaoxing y Ningbo, congelado frente a umbrales
reajustados con etiquetas locales: exploratoria, desviación 6).

Requiere haber ejecutado antes calcular_t19.py (genera las matrices de confusión).
Uso, desde la raíz del repo:  python tesis/scripts/hacer_figuras.py
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import precision_recall_curve, roc_curve

IEEE = Path(__file__).resolve().parents[1]
REPO = IEEE.parent
sys.path.insert(0, str(IEEE / "scripts"))
import analizar_t19 as a19  # noqa: E402

EVAL = REPO / "runs" / "t19" / "eval"
CLASSES = ["NSR", "AxisDev", "MI", "TAb", "AF", "LVH", "VEctopy", "AVBlock", "STach", "BBB", "SB", "AEctopy_Junctional"]
AZUL, NARANJA, NEGRO = "#0072B2", "#D55E00", "#000000"
PRUEBAS = (("A", AZUL, "-", "o", "Test A"), ("B", NARANJA, "--", "s", "Test B (Georgia)"))
plt.rcParams.update({"font.family": "Arial", "font.size": 7, "axes.labelsize": 7, "axes.titlesize": 7.5, "xtick.labelsize": 6.5,
                     "ytick.labelsize": 6.5, "legend.fontsize": 6.5, "axes.linewidth": 0.5, "lines.linewidth": 1.0, "pdf.fonttype": 42,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": "#E6E6E6", "grid.linewidth": 0.4})


def pred(prueba: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    ruta = EVAL / f"p3_{prueba}" / "predictions_test.csv"
    assert a19.sha256(ruta) == a19.SHA256[f"P3_{prueba}"], f"{ruta} no es la predicción registrada"
    d = pd.read_csv(ruta)
    return (d[[f"true_{c}" for c in CLASSES]].to_numpy(np.uint8), d[[f"prob_{c}" for c in CLASSES]].to_numpy(float),
            d[[f"pred_{c}" for c in CLASSES]].to_numpy(np.uint8))


def guardar(fig, nombre: str) -> None:
    (IEEE / "figuras").mkdir(exist_ok=True)
    (IEEE / "evidencia" / "vistas").mkdir(parents=True, exist_ok=True)
    fig.savefig(IEEE / "figuras" / f"{nombre}.pdf", format="pdf")
    fig.savefig(IEEE / "evidencia" / "vistas" / f"{nombre}.png", format="png", dpi=150)
    plt.close(fig)


def punto_operacion(y: np.ndarray, yhat: np.ndarray, i: int) -> tuple[float, float, float]:
    """(1 - especificidad, sensibilidad, precisión) de la clase i con la decisión del sistema (umbral fijado en validación)."""
    tp = float(((yhat[:, i] == 1) & (y[:, i] == 1)).sum())
    fp = float(((yhat[:, i] == 1) & (y[:, i] == 0)).sum())
    return fp / (y[:, i] == 0).sum(), tp / y[:, i].sum(), tp / max(tp + fp, 1.0)


def roc_pr() -> None:
    datos = {p[0]: pred(p[0]) for p in PRUEBAS}
    ejemplos = ["AF", "AVBlock", "VEctopy"]          # los análogos de FA, bloqueo AV y extrasístoles del trabajo original
    fig, ax = plt.subplots(2, 3, figsize=(7.16, 3.2))
    for k, c in enumerate(ejemplos):
        i = CLASSES.index(c)
        for prueba, color, estilo, marca, etiqueta in PRUEBAS:
            y, p, yhat = datos[prueba]
            fpr, tpr, _ = roc_curve(y[:, i], p[:, i])
            pr, rc, _ = precision_recall_curve(y[:, i], p[:, i])
            f, s, prec = punto_operacion(y, yhat, i)
            ax[0, k].plot(fpr, tpr, color=color, ls=estilo, label=etiqueta)
            ax[0, k].plot([f], [s], marca, color=color, ms=4)
            ax[1, k].plot(rc, pr, color=color, ls=estilo)
            ax[1, k].plot([s], [prec], marca, color=color, ms=4)
        ax[0, k].set(title=c, xlim=(0, 0.5), ylim=(0.0, 1.0), xlabel="1 − specificity" if k == 1 else "", ylabel="Sensitivity" if k == 0 else "")
        ax[1, k].set(xlim=(0, 1), ylim=(0, 1.02), xlabel="Sensitivity" if k == 1 else "", ylabel="Precision (PPV)" if k == 0 else "")
    ax[0, 0].legend(loc="lower right", frameon=False)
    fig.tight_layout(pad=0.5, h_pad=0.8)
    guardar(fig, "fig_roc_pr")


def roc_todas() -> None:  # sin uso desde 2026-11-02: el apéndice con esta figura se retiró del artículo (obsoleto/apendice/)
    """Curvas ROC de las doce clases del sistema final en las dos pruebas (análogo de la Fig. 2 de datos extendidos del trabajo original)."""
    datos = {p[0]: pred(p[0]) for p in PRUEBAS}
    fig, ax = plt.subplots(4, 3, figsize=(7.16, 6.4), sharex=True, sharey=True)
    for k, c in enumerate(CLASSES):
        i, a = CLASSES.index(c), ax[k // 3, k % 3]
        for prueba, color, estilo, marca, etiqueta in PRUEBAS:
            y, p, yhat = datos[prueba]
            fpr, tpr, _ = roc_curve(y[:, i], p[:, i])
            a.plot(fpr, tpr, color=color, ls=estilo, lw=0.9, label=etiqueta)
            f, s, _ = punto_operacion(y, yhat, i)
            a.plot([f], [s], marca, color=color, ms=3)
        a.set(title=c.replace("_Junctional", "_Junct."), xlim=(0, 0.5), ylim=(0.0, 1.0))
    for a in ax[-1]:
        a.set_xlabel("1 − specificity")
    for a in ax[:, 0]:
        a.set_ylabel("Sensitivity")
    ax[0, 0].legend(loc="lower right", frameon=False, fontsize=6.5)
    fig.tight_layout(pad=0.5, h_pad=0.6, w_pad=0.6)
    guardar(fig, "fig_roc_todas")


def confusion() -> None:
    fig, ax = plt.subplots(1, 2, figsize=(7.16, 3.4), constrained_layout=True)
    etq = [c.replace("AEctopy_Junctional", "AEct-J") for c in CLASSES]
    im = None
    for a, (prueba, *_resto, titulo) in zip(ax, PRUEBAS):
        ruta = IEEE / "evidencia" / f"matriz_confusion_{prueba}.csv"
        if not ruta.exists():
            sys.exit(f"Falta {ruta.name}: ejecuta antes tesis/scripts/calcular_t19.py")
        m = pd.read_csv(ruta, index_col=0).to_numpy()
        soporte = pred(prueba)[0].sum(0)                              # registros positivos de cada clase (filas de la matriz)
        im = a.pcolormesh(np.arange(13) - 0.5, np.arange(13) - 0.5, m, cmap="Blues", vmin=0, vmax=1)   # vectorial (imshow incrusta una imagen)
        a.set(xlim=(-0.5, 11.5), ylim=(11.5, -0.5), aspect="equal")
        a.set_xticks(range(12), etq, rotation=90)
        a.set_yticks(range(12), [f"{e} ({int(n):,})".replace(",", " ") for e, n in zip(etq, soporte)])
        a.set(xlabel="Class predicted by the system", ylabel="Class of the recording" if prueba == "A" else "", title=titulo)
        a.grid(False)
        for i in range(12):
            for j in range(12):
                v = m[i, j]
                a.text(j, i, f"{v:.2f}".lstrip("0") if v < 1 else "1", ha="center", va="center", fontsize=6.2, color="white" if v > 0.55 else NEGRO)
    barra = fig.colorbar(im, ax=list(ax), fraction=0.02, pad=0.01)
    barra.ax.tick_params(labelsize=6.5)
    barra.solids.set_rasterized(False)                                 # la barra también vectorial
    guardar(fig, "fig_confusion")


def confiabilidad() -> None:
    bins = int(float(next(r["valor"] for r in csv.DictReader((IEEE / "evidencia" / "cifras_t19.csv").open(encoding="utf-8")) if r["id"] == "EceBins")))
    borde = np.linspace(0, 1, bins + 1)
    fig, a = plt.subplots(figsize=(3.5, 2.7))
    a.plot([0, 1], [0, 1], color="#808080", lw=0.6, ls=":")
    for prueba, color, estilo, marca, etiqueta in PRUEBAS:
        y, p, _ = pred(prueba)
        p, y = p.ravel(), y.ravel()
        k = np.clip(np.digitize(p, borde) - 1, 0, bins - 1)
        xs = [p[k == b].mean() for b in range(bins) if (k == b).any()]
        ys = [y[k == b].mean() for b in range(bins) if (k == b).any()]
        a.plot(xs, ys, marker=marca, color=color, ls=estilo, ms=3, label=etiqueta)
    a.set(xlabel="Predicted probability (bin mean)", ylabel="Observed frequency", xlim=(0, 1), ylim=(0, 1))
    a.legend(loc="upper left", frameon=False)
    fig.tight_layout(pad=0.4)
    guardar(fig, "fig_confiabilidad")


def externa() -> None:
    """F1 (arriba) y sensibilidad (abajo) por clase del sistema principal en C y D: congelado (V0) y con los umbrales reajustados con etiquetas locales (V1, E13)."""
    d = pd.read_csv(IEEE / "evidencia" / "e13_recalibracion_local" / "por_clase_P3.csv")
    rep_ = pd.read_json(IEEE / "evidencia" / "reparto_externo.json")["origenes"]
    gris, verde = "#8C8C8C", "#009E73"
    fig, ejes = plt.subplots(2, 2, figsize=(7.16, 3.4), sharey="row")
    for col, (o, nombre) in enumerate((("C", "Chapman-Shaoxing"), ("D", "Ningbo"))):
        evaluables = rep_[o]["clases_evaluables"]
        pos = rep_[o]["positivos"]
        x = np.arange(len(CLASSES))
        for fila, (medida, etiqueta) in enumerate((("f1", "F1"), ("sens", "Sensitivity"))):
            a = ejes[fila, col]
            for desp, v, color, hach, lab in ((-0.19, "V0", gris, "", "Frozen"), (0.19, "V1", verde, "////", "Local thresholds (exploratory)")):
                y = [d[(d.prueba == o) & (d.variante == v) & (d.clase == c)][medida].iloc[0] if c in evaluables else np.nan for c in CLASSES]
                a.bar(x + desp, y, width=0.36, color=color, hatch=hach, edgecolor="white" if hach == "" else "#005C45", linewidth=0.3, label=lab)
            for i, c in enumerate(CLASSES):
                if c not in evaluables:
                    a.text(i, 0.04, "not eval.", rotation=90, ha="center", va="bottom", fontsize=6.2, color="#555555")
            a.set(ylim=(0, 1), ylabel=etiqueta if col == 0 else "")
            if fila == 0:
                a.set_title(f"{nombre} (n = {rep_[o]['registros']:,})".replace(",", " "), fontsize=7.5)
                a.set_xticklabels([])
            else:
                a.set_xticks(x)
                a.set_xticklabels([f"{c.replace('AEctopy_Junctional', 'AEctopy_J')}\n{pos[c]:,}".replace(",", " ") for c in CLASSES], rotation=60, ha="right", fontsize=6.3)
    h, l = ejes[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=2, frameon=False, fontsize=6.5, bbox_to_anchor=(0.5, 1.0))
    fig.tight_layout(pad=0.4, h_pad=0.5, rect=(0, 0, 1, 0.94))
    guardar(fig, "fig_externa")


if __name__ == "__main__":
    roc_pr()
    confusion()
    confiabilidad()
    externa()
    print("4 figuras -> tesis/figuras/*.pdf (vistas PNG en tesis/evidencia/vistas/)")
    sys.exit(0)
