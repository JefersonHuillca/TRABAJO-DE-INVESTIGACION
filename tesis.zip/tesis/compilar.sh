#!/usr/bin/env bash
# Compila el artículo IEEE con pdfLaTeX + BibTeX: pdflatex, bibtex, pdflatex, pdflatex (la secuencia de la compilación rápida de Texmaker).
# Uso, desde Git Bash:  bash tesis/compilar.sh [limpio]
# -disable-installer hace que un paquete que falte dé error en lugar de abrir una ventana de instalación.
# Sale con 0 solo si no hay errores de TeX, ni citas o referencias sin definir, ni más de 20 páginas.
set -u
MIK="${MIK:-/c/Users/juerg/AppData/Local/Programs/MiKTeX/miktex/bin/x64}"
LIMITE=180
PAGINAS_MAX=20
cd "$(dirname "$0")" || exit 2
OPC="-disable-installer -interaction=nonstopmode -file-line-error -halt-on-error"

paso() {   # paso <etiqueta> <orden...>: ejecuta con tiempo límite y guarda la salida en build_<etiqueta>.txt
  local et="$1"; shift
  timeout "$LIMITE" "$@" > "build_${et}.txt" 2>&1
  local rc=$?
  [ "$rc" -eq 124 ] && echo "TIEMPO AGOTADO ($LIMITE s) en el paso $et"
  return "$rc"
}

[ "${1:-}" = "limpio" ] && rm -f main.aux main.bbl main.blg main.out
paso 1_pdflatex "$MIK/pdflatex.exe" $OPC main.tex || { echo "ERROR en la primera pasada (ver build_1_pdflatex.txt)"; grep -m5 -E "^\S+:[0-9]+:|^!" build_1_pdflatex.txt; exit 1; }
paso 2_bibtex "$MIK/bibtex.exe" main || echo "AVISO: bibtex terminó con código distinto de 0; ver build_2_bibtex.txt"
paso 3_pdflatex "$MIK/pdflatex.exe" $OPC main.tex || { echo "ERROR en la segunda pasada (ver build_3_pdflatex.txt)"; grep -m5 -E "^\S+:[0-9]+:|^!" build_3_pdflatex.txt; exit 1; }
paso 4_pdflatex "$MIK/pdflatex.exe" $OPC main.tex || { echo "ERROR en la tercera pasada (ver build_4_pdflatex.txt)"; grep -m5 -E "^\S+:[0-9]+:|^!" build_4_pdflatex.txt; exit 1; }


PAG=$("$MIK/pdfinfo.exe" main.pdf 2>/dev/null | awk '/^Pages:/{print $2}')
ERR=$(grep -c -E "^!|^\S+:[0-9]+:" build_4_pdflatex.txt)
IND=$(grep -c -E "LaTeX Warning: (Citation|Reference).*undefined|There were undefined" main.log)
ESP=$(grep -c "Warning--" build_2_bibtex.txt)
OVF=$(awk '/Overfull \\hbox/{ if (match($0,/\(([0-9.]+)pt too wide\)/,m) && m[1]+0>10) n++ } END{print n+0}' main.log)
echo "páginas: $PAG (máximo $PAGINAS_MAX) | errores de TeX: $ERR | citas o referencias indefinidas: $IND | avisos de BibTeX: $ESP | Overfull \\hbox > 10 pt: $OVF"
[ "$ERR" -eq 0 ] && [ "$IND" -eq 0 ] && [ "${PAG:-999}" -le "$PAGINAS_MAX" ]
